#include "silveton/PitchCoordinator.h"
#include <algorithm>
#include <cmath>
#include <cstdlib>

namespace silveton {

void PitchCoordinator::setBendRangeSemitones(int value) {
    bendRangeSemitones_ = std::clamp(value, 1, 24);
    manualRangeSemitones_ = std::clamp(manualRangeSemitones_, 1, bendRangeSemitones_);
}

void PitchCoordinator::setManualRangeSemitones(int value) {
    manualRangeSemitones_ = std::clamp(value, 1, bendRangeSemitones_);
}

void PitchCoordinator::setBlendRange(int ch, int semitones) {
    if (ch < 0 || ch >= 16) return;
    blendRange_[static_cast<std::size_t>(ch)] = semitones < 0 ? -1 : std::clamp(semitones, 0, 24);
}

int PitchCoordinator::blendRange(int ch) const {
    if (ch < 0 || ch >= 16) return -1;
    return blendRange_[static_cast<std::size_t>(ch)];
}

void PitchCoordinator::setTransportRange(int ch, int semitones) {
    if (ch < 0 || ch >= 16) return;
    transportRange_[static_cast<std::size_t>(ch)] = semitones <= 0 ? -1 : std::clamp(semitones, 1, 24);
}

int PitchCoordinator::transportRange(int ch) const {
    if (ch < 0 || ch >= 16) return -1;
    return transportRange_[static_cast<std::size_t>(ch)];
}

int PitchCoordinator::bendFor(int ch) const {
    const int t = transportRange(ch);
    if (t > 0) return t;
    const int b = blendRange(ch);
    return b >= 0 ? b : bendRangeSemitones_;
}

int PitchCoordinator::manualFor(int ch) const {
    const int b = blendRange(ch);
    return b >= 0 ? b : manualRangeSemitones_;
}

int PitchCoordinator::compose14(int ch, const State& state) const {
    const int range = bendFor(ch);
    // A Sound with bend range 0 ignores Pitch Bend: pass the wheel as it is.
    if (range <= 0) return std::clamp(state.manualBend14, 0, 16383);
    const double manualNorm = (double(state.manualBend14) - 8192.0) / 8192.0;
    const double manualSemitones = manualNorm * double(manualFor(ch));
    const double total = std::clamp(state.ribbonSemitones + manualSemitones,
                                    -double(range), double(range));
    const double normalized = total / double(range);
    return std::clamp(int(std::lround(8192.0 + normalized * 8192.0)), 0, 16383);
}

bool PitchCoordinator::pendingChangeInaudible(int ch) const {
    if (ch < 0 || ch >= 16) return false;
    const auto& state = states_[static_cast<std::size_t>(ch)];
    if (state.lastOutputBend14 < 0) return false;
    const int range = bendFor(ch);
    if (range <= 0) return false;
    // One cent in 14-bit Pitch Bend units at this channel's range (range 2 -> ~41).
    const double unitsPerCent = 8192.0 / (static_cast<double>(range) * 100.0);
    const int delta = std::abs(compose14(ch, state) - state.lastOutputBend14);
    return delta > 0 && static_cast<double>(delta) < unitsPerCent;
}

std::vector<MidiMessage> PitchCoordinator::emitIfChanged(int ch) {
    if (ch < 0 || ch >= 16) return {};
    auto& state = states_[static_cast<std::size_t>(ch)];
    const int bend = compose14(ch, state);
    if (bend == state.lastOutputBend14) return {};
    state.lastOutputBend14 = bend;
    return {MidiMessage::pitchBend(ch, bend)};
}

std::vector<MidiMessage> PitchCoordinator::setRibbonSemitones(int ch, double semitones) {
    if (ch < 0 || ch >= 16) return {};
    states_[static_cast<std::size_t>(ch)].ribbonSemitones = std::clamp(semitones,
                                             -24.0, 24.0);
    return emitIfChanged(ch);
}

void PitchCoordinator::storeRibbonSemitones(int ch, double semitones) {
    if (ch < 0 || ch >= 16) return;
    states_[static_cast<std::size_t>(ch)].ribbonSemitones = std::clamp(semitones,
        -24.0, 24.0);
}

std::vector<MidiMessage> PitchCoordinator::setManualBend14(int ch, int bend14) {
    if (ch < 0 || ch >= 16) return {};
    states_[static_cast<std::size_t>(ch)].manualBend14 = std::clamp(bend14, 0, 16383);
    return emitIfChanged(ch);
}

void PitchCoordinator::rememberManualBend14(int ch, int bend14) {
    if (ch < 0 || ch >= 16) return;
    states_[static_cast<std::size_t>(ch)].manualBend14 = std::clamp(bend14, 0, 16383);
}

int PitchCoordinator::manualBend14(int ch) const {
    if (ch < 0 || ch >= 16) return 8192;
    return states_[static_cast<std::size_t>(ch)].manualBend14;
}

void PitchCoordinator::clearRibbonContribution(int ch) {
    if (ch < 0 || ch >= 16) return;
    auto& state = states_[static_cast<std::size_t>(ch)];
    state.ribbonSemitones = 0.0;
    state.lastOutputBend14 = -1;
}

std::vector<MidiMessage> PitchCoordinator::forceEmitChannel(int ch) {
    if (ch < 0 || ch >= 16) return {};
    states_[static_cast<std::size_t>(ch)].lastOutputBend14 = -1;
    return emitIfChanged(ch);
}

std::vector<MidiMessage> PitchCoordinator::resetChannel(int ch) {
    if (ch < 0 || ch >= 16) return {};
    states_[static_cast<std::size_t>(ch)] = State{};
    states_[static_cast<std::size_t>(ch)].lastOutputBend14 = 8192;
    return {MidiMessage::pitchBend(ch, 8192)};
}

std::vector<MidiMessage> PitchCoordinator::resetAll() {
    std::vector<MidiMessage> out;
    for (int ch = 0; ch < 16; ++ch) {
        auto one = resetChannel(ch);
        out.insert(out.end(), one.begin(), one.end());
    }
    return out;
}

void PitchCoordinator::clearAll() {
    states_ = {};
}

} // namespace silveton
