#include "silveton/sampler/ProgramEditor.h"

#include <algorithm>
#include <cmath>
#include <memory>
#include <utility>

namespace silveton::sampler {
namespace {

ProgramEditResult fail(std::string message) {
    return {nullptr, std::move(message)};
}

ProgramEditResult clone(ProgramPtr source) {
    if (source == nullptr) return fail("PROGRAM is null");
    return {std::make_shared<Program>(*source), {}};
}

ProgramLayer* layerAt(std::shared_ptr<Program>& program, std::size_t index) {
    if (program == nullptr || index >= program->layers.size()) return nullptr;
    return &program->layers[index];
}

bool finite(float v) noexcept { return std::isfinite(v); }

EnvelopeParams sanitizedEnvelope(const EnvelopeParams& input) noexcept {
    EnvelopeParams out = input;
    out.attackSec = std::clamp(out.attackSec, 0.0F, 120.0F);
    out.decaySec = std::clamp(out.decaySec, 0.0F, 120.0F);
    out.sustain = std::clamp(out.sustain, 0.0F, 1.0F);
    out.releaseSec = std::clamp(out.releaseSec, 0.0F, 120.0F);
    return out;
}

bool envelopeFinite(const EnvelopeParams& p) noexcept {
    return finite(p.attackSec) && finite(p.decaySec) && finite(p.sustain) && finite(p.releaseSec);
}

} // namespace

ProgramEditResult ProgramEditor::updateBasic(ProgramPtr source, bool mono, bool legato, float portamentoSec) {
    if (!finite(portamentoSec)) return fail("PROGRAM portamento is not finite");
    auto result = clone(std::move(source));
    if (!result.ok()) return result;
    auto program = std::const_pointer_cast<Program>(result.program);
    program->mono = mono;
    program->legato = mono && legato;
    program->portamentoSec = std::clamp(portamentoSec, 0.0F, 30.0F);
    return {program, {}};
}

ProgramEditResult ProgramEditor::addLayer(ProgramPtr source, std::string name, MultisamplePtr multisample) {
    if (multisample == nullptr) return fail("PROGRAM layer MULTISAMPLE is null");
    auto result = clone(std::move(source));
    if (!result.ok()) return result;
    auto program = std::const_pointer_cast<Program>(result.program);
    ProgramLayer layer;
    layer.name = name.empty() ? multisample->name : std::move(name);
    layer.multisample = std::move(multisample);
    program->layers.push_back(std::move(layer));
    return {program, {}};
}

ProgramEditResult ProgramEditor::removeLayer(ProgramPtr source, std::size_t layerIndex) {
    auto result = clone(std::move(source));
    if (!result.ok()) return result;
    auto program = std::const_pointer_cast<Program>(result.program);
    if (layerIndex >= program->layers.size()) return fail("PROGRAM layer index is out of range");
    program->layers.erase(program->layers.begin() + static_cast<std::ptrdiff_t>(layerIndex));
    return {program, {}};
}

ProgramEditResult ProgramEditor::moveLayer(ProgramPtr source, std::size_t fromIndex, std::size_t toIndex) {
    auto result = clone(std::move(source));
    if (!result.ok()) return result;
    auto program = std::const_pointer_cast<Program>(result.program);
    if (fromIndex >= program->layers.size() || toIndex >= program->layers.size()) return fail("PROGRAM layer index is out of range");
    if (fromIndex == toIndex) return {program, {}};
    auto layer = std::move(program->layers[fromIndex]);
    program->layers.erase(program->layers.begin() + static_cast<std::ptrdiff_t>(fromIndex));
    program->layers.insert(program->layers.begin() + static_cast<std::ptrdiff_t>(toIndex), std::move(layer));
    return {program, {}};
}

ProgramEditResult ProgramEditor::assignMultisample(ProgramPtr source, std::size_t layerIndex, MultisamplePtr multisample) {
    if (multisample == nullptr) return fail("PROGRAM layer MULTISAMPLE is null");
    auto result = clone(std::move(source));
    if (!result.ok()) return result;
    auto program = std::const_pointer_cast<Program>(result.program);
    auto* layer = layerAt(program, layerIndex);
    if (layer == nullptr) return fail("PROGRAM layer index is out of range");
    layer->multisample = std::move(multisample);
    return {program, {}};
}

ProgramEditResult ProgramEditor::updateLayerBasic(
    ProgramPtr source, std::size_t layerIndex, bool enabled,
    int keyLow, int keyHigh, int velocityLow, int velocityHigh,
    int velocityFadeIn, int velocityFadeOut, int transposeSemitones,
    float tuneCents, float levelDb, float pan, float delaySec, bool damperEnabled) {
    if (!finite(tuneCents) || !finite(levelDb) || !finite(pan) || !finite(delaySec)) return fail("PROGRAM layer value is not finite");
    if (keyLow < 0 || keyHigh > 127 || keyLow > keyHigh) return fail("PROGRAM layer key range is invalid");
    if (velocityLow < 1 || velocityHigh > 127 || velocityLow > velocityHigh) return fail("PROGRAM layer velocity range is invalid");
    const int velocitySpan = velocityHigh - velocityLow;
    if (velocityFadeIn < 0 || velocityFadeOut < 0 || velocityFadeIn > velocitySpan || velocityFadeOut > velocitySpan) {
        return fail("PROGRAM layer velocity crossfade is invalid");
    }
    auto result = clone(std::move(source));
    if (!result.ok()) return result;
    auto program = std::const_pointer_cast<Program>(result.program);
    auto* layer = layerAt(program, layerIndex);
    if (layer == nullptr) return fail("PROGRAM layer index is out of range");
    layer->enabled = enabled;
    layer->keyLow = static_cast<std::uint8_t>(keyLow);
    layer->keyHigh = static_cast<std::uint8_t>(keyHigh);
    layer->velocityLow = static_cast<std::uint8_t>(velocityLow);
    layer->velocityHigh = static_cast<std::uint8_t>(velocityHigh);
    layer->velocityFadeIn = static_cast<std::uint8_t>(velocityFadeIn);
    layer->velocityFadeOut = static_cast<std::uint8_t>(velocityFadeOut);
    layer->transposeSemitones = static_cast<std::int8_t>(std::clamp(transposeSemitones, -48, 48));
    layer->tuneCents = std::clamp(tuneCents, -100.0F, 100.0F);
    layer->levelDb = std::clamp(levelDb, -96.0F, 24.0F);
    layer->pan = std::clamp(pan, -1.0F, 1.0F);
    layer->delaySec = std::clamp(delaySec, 0.0F, 30.0F);
    layer->damperEnabled = damperEnabled;
    return {program, {}};
}

ProgramEditResult ProgramEditor::updateLayerAmpEnvelope(ProgramPtr source, std::size_t layerIndex, const EnvelopeParams& envelope) {
    if (!envelopeFinite(envelope)) return fail("PROGRAM AMP envelope contains a non-finite value");
    auto result = clone(std::move(source));
    if (!result.ok()) return result;
    auto program = std::const_pointer_cast<Program>(result.program);
    auto* layer = layerAt(program, layerIndex);
    if (layer == nullptr) return fail("PROGRAM layer index is out of range");
    layer->ampEnvelope = sanitizedEnvelope(envelope);
    return {program, {}};
}

ProgramEditResult ProgramEditor::updateLayerPitch(ProgramPtr source, std::size_t layerIndex, float pitchEnvelopeCents, const EnvelopeParams& envelope) {
    if (!finite(pitchEnvelopeCents) || !envelopeFinite(envelope)) return fail("PROGRAM PITCH value is not finite");
    auto result = clone(std::move(source));
    if (!result.ok()) return result;
    auto program = std::const_pointer_cast<Program>(result.program);
    auto* layer = layerAt(program, layerIndex);
    if (layer == nullptr) return fail("PROGRAM layer index is out of range");
    layer->pitchEnvelopeCents = std::clamp(pitchEnvelopeCents, -4800.0F, 4800.0F);
    layer->pitchEnvelope = sanitizedEnvelope(envelope);
    return {program, {}};
}

ProgramEditResult ProgramEditor::updateLayerFilter(ProgramPtr source, std::size_t layerIndex, const FilterParams& filter, const EnvelopeParams& envelope) {
    if (static_cast<int>(filter.mode) < static_cast<int>(FilterMode::LowPass) || static_cast<int>(filter.mode) > static_cast<int>(FilterMode::Bypass)) {
        return fail("PROGRAM FILTER mode is invalid");
    }
    if (!finite(filter.cutoffHz) || !finite(filter.resonance) || !finite(filter.keyTrack) ||
        !finite(filter.velocityAmount) || !finite(filter.envelopeAmount) || !finite(filter.lfoAmount) || !envelopeFinite(envelope)) {
        return fail("PROGRAM FILTER value is not finite");
    }
    auto result = clone(std::move(source));
    if (!result.ok()) return result;
    auto program = std::const_pointer_cast<Program>(result.program);
    auto* layer = layerAt(program, layerIndex);
    if (layer == nullptr) return fail("PROGRAM layer index is out of range");
    layer->filter.mode = filter.mode;
    layer->filter.cutoffHz = std::clamp(filter.cutoffHz, 10.0F, 40000.0F);
    layer->filter.resonance = std::clamp(filter.resonance, 0.0F, 1.0F);
    layer->filter.keyTrack = std::clamp(filter.keyTrack, -4.0F, 4.0F);
    layer->filter.velocityAmount = std::clamp(filter.velocityAmount, -10.0F, 10.0F);
    layer->filter.envelopeAmount = std::clamp(filter.envelopeAmount, -10.0F, 10.0F);
    layer->filter.lfoAmount = std::clamp(filter.lfoAmount, -10.0F, 10.0F);
    layer->filterEnvelope = sanitizedEnvelope(envelope);
    return {program, {}};
}

ProgramEditResult ProgramEditor::updateLayerLfo(ProgramPtr source, std::size_t layerIndex, int lfoIndex, const LfoParams& lfo) {
    if (lfoIndex < 0 || lfoIndex > 1) return fail("PROGRAM LFO index is out of range");
    if (static_cast<int>(lfo.wave) < static_cast<int>(LfoWave::Sine) || static_cast<int>(lfo.wave) > static_cast<int>(LfoWave::RandomHold)) {
        return fail("PROGRAM LFO waveform is invalid");
    }
    if (!finite(lfo.frequencyHz) || !finite(lfo.delaySec) || !finite(lfo.fadeSec) || !finite(lfo.pitchCents) ||
        !finite(lfo.filterOctaves) || !finite(lfo.ampDepth)) return fail("PROGRAM LFO value is not finite");
    auto result = clone(std::move(source));
    if (!result.ok()) return result;
    auto program = std::const_pointer_cast<Program>(result.program);
    auto* layer = layerAt(program, layerIndex);
    if (layer == nullptr) return fail("PROGRAM layer index is out of range");
    LfoParams next = lfo;
    next.frequencyHz = std::clamp(next.frequencyHz, 0.01F, 40.0F);
    next.delaySec = std::clamp(next.delaySec, 0.0F, 30.0F);
    next.fadeSec = std::clamp(next.fadeSec, 0.0F, 30.0F);
    next.pitchCents = std::clamp(next.pitchCents, -2400.0F, 2400.0F);
    next.filterOctaves = std::clamp(next.filterOctaves, -10.0F, 10.0F);
    next.ampDepth = std::clamp(next.ampDepth, -1.0F, 1.0F);
    if (lfoIndex == 0) layer->lfo1 = next; else layer->lfo2 = next;
    return {program, {}};
}

} // namespace silveton::sampler
