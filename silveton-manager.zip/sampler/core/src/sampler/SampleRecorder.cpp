#include "silveton/sampler/SampleRecorder.h"

#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstring>
#include <limits>

namespace silveton::sampler {
namespace {

void putLe16(std::ofstream& f, std::uint16_t v) {
    const std::array<char,2> b{{static_cast<char>(v & 0xFFU), static_cast<char>((v >> 8U) & 0xFFU)}};
    f.write(b.data(), static_cast<std::streamsize>(b.size()));
}
void putLe32(std::ofstream& f, std::uint32_t v) {
    const std::array<char,4> b{{static_cast<char>(v & 0xFFU), static_cast<char>((v >> 8U) & 0xFFU),
                               static_cast<char>((v >> 16U) & 0xFFU), static_cast<char>((v >> 24U) & 0xFFU)}};
    f.write(b.data(), static_cast<std::streamsize>(b.size()));
}
void putLe64(std::ofstream& f, std::uint64_t v) {
    std::array<char,8> b{};
    for (unsigned i=0U;i<8U;++i) b[i]=static_cast<char>((v>>(i*8U))&0xFFU);
    f.write(b.data(), static_cast<std::streamsize>(b.size()));
}

} // namespace

SampleRecorder::~SampleRecorder() { (void)stop(); }

bool SampleRecorder::start(const std::string& path, std::uint32_t sampleRate, std::uint16_t channels,
                           std::uint32_t ringFrames) {
    if (recording()) return false;
    if (path.empty() || sampleRate < 8000U || sampleRate > 384000U || channels == 0U || channels > 2U || ringFrames < 1024U) {
        setError("Invalid recorder configuration");
        return false;
    }
    path_ = path;
    sampleRate_ = sampleRate;
    channels_ = channels;
    ringSamples_ = static_cast<std::uint64_t>(ringFrames) * channels;
    if (ringSamples_ > static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max())) {
        setError("Recorder ring is too large");
        return false;
    }
    try {
        ring_.assign(static_cast<std::size_t>(ringSamples_), 0.0F);
    } catch (...) {
        setError("Recorder ring allocation failed");
        return false;
    }
    file_.open(path_, std::ios::binary | std::ios::trunc);
    if (!file_) { setError("Cannot create recording file: " + path_); return false; }
    if (!writeHeader()) { setError("Cannot write recording header"); file_.close(); return false; }
    writeSamples_.store(0U, std::memory_order_relaxed);
    readSamples_.store(0U, std::memory_order_relaxed);
    framesWritten_.store(0U, std::memory_order_relaxed);
    droppedFrames_.store(0U, std::memory_order_relaxed);
    stopRequested_.store(false, std::memory_order_relaxed);
    {
        std::lock_guard<std::mutex> lock(errorMutex_);
        error_.clear();
    }
    running_.store(true, std::memory_order_release);
    writer_ = std::thread(&SampleRecorder::writerLoop, this);
    return true;
}

bool SampleRecorder::push(const float* interleaved, std::uint32_t frames) noexcept {
    if (!running_.load(std::memory_order_acquire) || interleaved == nullptr || frames == 0U) return false;
    const std::uint64_t count = static_cast<std::uint64_t>(frames) * channels_;
    const std::uint64_t w = writeSamples_.load(std::memory_order_relaxed);
    const std::uint64_t r = readSamples_.load(std::memory_order_acquire);
    if (count > ringSamples_ - std::min(ringSamples_, w - r)) {
        droppedFrames_.fetch_add(frames, std::memory_order_relaxed);
        return false;
    }
    const std::uint64_t start = w % ringSamples_;
    const std::uint64_t first = std::min(count, ringSamples_ - start);
    std::memcpy(ring_.data() + static_cast<std::size_t>(start), interleaved, static_cast<std::size_t>(first) * sizeof(float));
    if (first < count) {
        std::memcpy(ring_.data(), interleaved + static_cast<std::size_t>(first), static_cast<std::size_t>(count - first) * sizeof(float));
    }
    writeSamples_.store(w + count, std::memory_order_release);
    return true;
}

bool SampleRecorder::stop() {
    if (!recording() && !writer_.joinable()) return error().empty();
    stopRequested_.store(true, std::memory_order_release);
    if (writer_.joinable()) writer_.join();
    running_.store(false, std::memory_order_release);
    bool ok = error().empty();
    if (file_.is_open()) {
        if (ok && !finalizeHeader()) { setError("Failed to finalize recording header"); ok = false; }
        file_.flush();
        if (!file_) { setError("Failed to flush recording file"); ok = false; }
        file_.close();
    }
    return ok && error().empty();
}

std::string SampleRecorder::error() const {
    std::lock_guard<std::mutex> lock(errorMutex_);
    return error_;
}

void SampleRecorder::setError(std::string message) {
    std::lock_guard<std::mutex> lock(errorMutex_);
    if (error_.empty()) error_ = std::move(message);
}

bool SampleRecorder::writeHeader() {
    // RF64 is used from the beginning so long takes do not hit RIFF's 4 GiB size field.
    file_.write("RF64",4); putLe32(file_,0xFFFFFFFFU); file_.write("WAVE",4);
    file_.write("ds64",4); putLe32(file_,28U);
    putLe64(file_,0U); // RIFF size, finalized on stop
    putLe64(file_,0U); // data size
    putLe64(file_,0U); // sample frames
    putLe32(file_,0U); // no table entries
    file_.write("fmt ",4); putLe32(file_,16U);
    putLe16(file_,3U); // IEEE float
    putLe16(file_,channels_);
    putLe32(file_,sampleRate_);
    const std::uint64_t byteRate64=static_cast<std::uint64_t>(sampleRate_)*channels_*4U;
    if(byteRate64>std::numeric_limits<std::uint32_t>::max()) return false;
    putLe32(file_,static_cast<std::uint32_t>(byteRate64));
    putLe16(file_,static_cast<std::uint16_t>(channels_*4U));
    putLe16(file_,32U);
    file_.write("data",4); putLe32(file_,0xFFFFFFFFU);
    return static_cast<bool>(file_);
}

bool SampleRecorder::finalizeHeader() {
    const std::uint64_t frames=framesWritten_.load(std::memory_order_relaxed);
    const std::uint64_t dataBytes=frames*channels_*4U;
    const std::uint64_t riffBytes=72U+dataBytes; // file size (80+data) - 8
    file_.seekp(20,std::ios::beg);
    putLe64(file_,riffBytes); putLe64(file_,dataBytes); putLe64(file_,frames);
    file_.seekp(0,std::ios::end);
    return static_cast<bool>(file_);
}

void SampleRecorder::writerLoop() {
    constexpr std::uint64_t kBatchSamples=65536U;
    std::vector<std::uint8_t> encoded(static_cast<std::size_t>(kBatchSamples)*4U);
    while (true) {
        const std::uint64_t r=readSamples_.load(std::memory_order_relaxed);
        const std::uint64_t w=writeSamples_.load(std::memory_order_acquire);
        const std::uint64_t available=w-r;
        if (available==0U) {
            if (stopRequested_.load(std::memory_order_acquire)) break;
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
            continue;
        }
        const std::uint64_t count=std::min(available,kBatchSamples);
        for(std::uint64_t i=0U;i<count;++i){
            float value=ring_[static_cast<std::size_t>((r+i)%ringSamples_)];
            if(!std::isfinite(value)) value=0.0F;
            std::uint32_t bits=0U; std::memcpy(&bits,&value,sizeof(bits));
            const auto o=static_cast<std::size_t>(i)*4U;
            encoded[o]=static_cast<std::uint8_t>(bits&0xFFU);
            encoded[o+1U]=static_cast<std::uint8_t>((bits>>8U)&0xFFU);
            encoded[o+2U]=static_cast<std::uint8_t>((bits>>16U)&0xFFU);
            encoded[o+3U]=static_cast<std::uint8_t>((bits>>24U)&0xFFU);
        }
        file_.write(reinterpret_cast<const char*>(encoded.data()),static_cast<std::streamsize>(count*4U));
        if(!file_){setError("Recording disk write failed");break;}
        readSamples_.store(r+count,std::memory_order_release);
        framesWritten_.fetch_add(count/channels_,std::memory_order_relaxed);
    }
    running_.store(false,std::memory_order_release);
}

} // namespace silveton::sampler
