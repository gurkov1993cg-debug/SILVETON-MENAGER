#include "silveton/sampler/SampleStreamPrefetcher.h"

#include <algorithm>
#include <cerrno>
#include <chrono>
#include <cstddef>
#include <sys/mman.h>
#include <unistd.h>

#if defined(__linux__) || defined(__ANDROID__)
#include <pthread.h>
#include <sched.h>
#ifndef MADV_POPULATE_READ
#define MADV_POPULATE_READ 22
#endif
#endif

namespace silveton::sampler {
namespace {

constexpr std::int64_t kRefreshMs = 100;   // re-assert residency of an unchanged window
constexpr auto kPassInterval = std::chrono::milliseconds(2);   // while voices play
constexpr auto kIdleInterval = std::chrono::milliseconds(10);  // nothing to read ahead

std::uintptr_t pageSize() noexcept {
    static const std::uintptr_t size = [] {
        const long v = ::sysconf(_SC_PAGESIZE);
        return static_cast<std::uintptr_t>(v > 0 ? v : 4096L);
    }();
    return size;
}

std::int64_t nowMs() noexcept {
    return std::chrono::duration_cast<std::chrono::milliseconds>(
        std::chrono::steady_clock::now().time_since_epoch()).count();
}

} // namespace

bool SampleStreamPrefetcher::start() noexcept {
    if (run_.load(std::memory_order_acquire)) return true;
    for (auto& c : cache_) c = SlotCache{};
    run_.store(true, std::memory_order_release);
    try {
        thread_ = std::thread(&SampleStreamPrefetcher::loop, this);
    } catch (...) {
        run_.store(false, std::memory_order_release);
        return false;
    }
    return true;
}

void SampleStreamPrefetcher::stop() noexcept {
    run_.store(false, std::memory_order_release);
    if (thread_.joinable()) thread_.join();
}

void SampleStreamPrefetcher::runOnce() noexcept {
    const std::uintptr_t page = pageSize();
    const std::int64_t now = nowMs();
    bool work = false;
    for (std::size_t slot = 0; slot < SamplerEngine::kMaxStreamWindows; ++slot) {
        SamplerEngine::StreamWindow w{};
        if (!engine_.readStreamWindow(slot, w) || w.begin == 0U || w.bytes == 0U) {
            cache_[slot] = SlotCache{};
            continue;
        }
        work = true;
        const std::uintptr_t b = w.begin & ~(page - 1U);
        const std::uintptr_t e = (w.begin + w.bytes + page - 1U) & ~(page - 1U);
        SlotCache& c = cache_[slot];
        const bool fresh = c.end != 0U && (now - c.stampMs) < kRefreshMs;
        if (fresh && b >= c.begin && e <= c.end) continue;   // already resident
        std::uintptr_t from = b;
        if (fresh && b >= c.begin && b < c.end) from = c.end; // only the new part
        if (e > from) {
            void* addr = reinterpret_cast<void*>(from);
            const std::size_t len = static_cast<std::size_t>(e - from);
            int rc = -1;
#if defined(__linux__) || defined(__ANDROID__)
            if (advice_.load(std::memory_order_relaxed) == 0) {
                // Synchronously fault the pages in here, so the audio thread
                // finds them mapped. Returns ENOMEM (no crash) for unmapped memory.
                rc = ::madvise(addr, len, MADV_POPULATE_READ);
                if (rc == 0) {
                    populateWorked_ = true;
                } else if (errno == EINVAL && !populateWorked_) {
                    advice_.store(1, std::memory_order_relaxed); // kernel < 5.14: never supported
                }
            }
#else
            (void)populateWorked_; // MADV_POPULATE_READ exists only on Linux/Android
#endif
            if (rc != 0) {
                // Asynchronous read-ahead into the page cache (older kernels / macOS tests).
                (void)::madvise(addr, len, MADV_WILLNEED);
            }
            requests_.fetch_add(1U, std::memory_order_relaxed);
        }
        c.begin = b;
        c.end = e;
        if (from == b) c.stampMs = now;
    }
    lastPassHadWork_ = work;
}

void SampleStreamPrefetcher::loop() noexcept {
#if defined(__linux__) || defined(__ANDROID__)
    (void)::pthread_setname_np(::pthread_self(), "SilvPrefetch");
    if (firstCpu_ >= 0 && lastCpu_ >= firstCpu_) {
        cpu_set_t set;
        CPU_ZERO(&set);
        for (int cpu = firstCpu_; cpu <= lastCpu_; ++cpu) CPU_SET(cpu, &set);
        (void)::sched_setaffinity(0, sizeof(set), &set);
    }
#endif
    while (run_.load(std::memory_order_acquire)) {
        runOnce();
        std::this_thread::sleep_for(lastPassHadWork_ ? kPassInterval : kIdleInterval);
    }
}

} // namespace silveton::sampler
