#pragma once
#include "silveton/MidiTypes.h"
#include <array>
#include <vector>

namespace silveton {

// Combines the independent pitch controls that use MIDI Pitch Bend into one
// value per channel: physical wheel + Ribbon.
class PitchCoordinator {
public:
    void setBendRangeSemitones(int value);
    void setManualRangeSemitones(int value);
    // Blend-native mode: the Pitch Bend range of the Sound on this channel as
    // REPORTED by the PA600 (never written by the app). Wheel and Ribbon are
    // composed inside that range. -1 = use the app transport range above.
    void setBlendRange(int ch, int semitones);
    int blendRange(int ch) const;
    // While the Ribbon (PITCH BEND output) is in use the app raises this
    // channel's RPN 0 to the Ribbon's own range; the wheel keeps the blend's
    // range inside it. -1 = no override (the blend's range is the transport).
    void setTransportRange(int ch, int semitones);
    int transportRange(int ch) const;

    std::vector<MidiMessage> setRibbonSemitones(int ch, double semitones);
    // State-only setters + a single emit, for updating several lanes at once.
    void storeRibbonSemitones(int ch, double semitones);
    std::vector<MidiMessage> emitChannel(int ch) { return emitIfChanged(ch); }
    // True when the value emitChannel() would send differs from the last one
    // sent by less than one cent (inaudible): used to skip steps while moving.
    bool pendingChangeInaudible(int ch) const;
    std::vector<MidiMessage> setManualBend14(int ch, int bend14);
    void rememberManualBend14(int ch, int bend14);
    int manualBend14(int ch) const;
    void clearRibbonContribution(int ch);
    std::vector<MidiMessage> forceEmitChannel(int ch);

    std::vector<MidiMessage> resetChannel(int ch);
    std::vector<MidiMessage> resetAll();
    void clearAll();

private:
    struct State {
        double ribbonSemitones{0.0};
        int manualBend14{8192};
        int lastOutputBend14{-1};
    };

    int compose14(int ch, const State& state) const;
    int bendFor(int ch) const;
    int manualFor(int ch) const;
    std::vector<MidiMessage> emitIfChanged(int ch);

    int bendRangeSemitones_{12};
    int manualRangeSemitones_{2};
    std::array<State, 16> states_{};
    std::array<int, 16> blendRange_{{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1}};
    std::array<int, 16> transportRange_{{-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1}};
};

} // namespace silveton
