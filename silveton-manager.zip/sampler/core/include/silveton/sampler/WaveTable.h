#pragma once
// SILVETON_TRANSWAVE_V1
// A "wave table" is a row of single-cycle frames cut out of the user's own recordings. The sound reads one cycle of it in a loop
// (so the pitch is always the key) and moves between two neighbouring frames - that is the TRANSWAVE movement.
// The tables are made on the control thread (never in the audio callback) and handed to the engine as an immutable map.

#include "silveton/sampler/SamplerTypes.h"

#include <cstdint>
#include <memory>
#include <unordered_map>
#include <vector>

namespace silveton::sampler {

constexpr int kWaveMaxFrames = 32;
constexpr int kWaveSlots = 8;
constexpr int kWaveModeOff = 0;
constexpr int kWaveModeAuto = 1;
constexpr int kWaveModeMulti = 2;

struct WaveTable {
    int frames{0};
    int length{0};      // samples of one cycle (a power of two)
    int channels{1};    // 1 or 2
    std::vector<float> data;   // [frame][sample][channel]

    [[nodiscard]] const float* frame(int k) const noexcept {
        return data.data() + static_cast<std::size_t>(k) * static_cast<std::size_t>(length) * static_cast<std::size_t>(channels);
    }
};
using WaveTablePtr = std::shared_ptr<const WaveTable>;
using WaveTableMap = std::unordered_map<std::uint64_t, WaveTablePtr>;

// The zone of `program` that sounds for `key` (velocity 100), or its first zone; nullptr when the program has none.
[[nodiscard]] const SampleZone* waveSourceZone(const Program& program, int key) noexcept;

// The key under which the table of `zone` with these settings is kept (the same on the control and the audio side).
// 0 = no table for this zone (mode off, or it cannot be made).
[[nodiscard]] std::uint64_t waveKey(const SampleZone& zone, const ToneExtra& x) noexcept;

// The table itself (nullptr when the recording is too short / empty / not a pitched sound).
[[nodiscard]] WaveTablePtr buildWaveTable(const SampleZone& zone, const ToneExtra& x);

// Keeps the tables made so far and makes the missing ones for a state. Control thread only.
class WaveTableCache {
public:
    // Returns the map the engine needs for `state` (nullptr when no sound uses a wave table).
    std::shared_ptr<const WaveTableMap> refresh(const EngineState& state);

private:
    WaveTableMap cache_;
};

} // namespace silveton::sampler
