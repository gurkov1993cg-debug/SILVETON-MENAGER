#pragma once
// SILVETON_MAC_FS_V1 - the small part of std::filesystem the sampler core uses, written with plain POSIX calls.
// macOS 10.13 (the iMac 2011) has no std::filesystem in its C++ library, so the core uses this instead.
// Names and behaviour follow std::filesystem for exactly the calls the core makes; nothing else is offered.
// Failures throw std::runtime_error (the core catches std::exception), like std::filesystem_error would.

#include <cerrno>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <stdexcept>
#include <string>
#include <system_error>
#include <vector>

#include <dirent.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

namespace silveton::fsx {

class path {
public:
    path() = default;
    path(const std::string& s) : text_(s) {}          // NOLINT(google-explicit-constructor): same as std::filesystem::path
    path(const char* s) : text_(s == nullptr ? "" : s) {}   // NOLINT(google-explicit-constructor)

    [[nodiscard]] const std::string& string() const noexcept { return text_; }
    [[nodiscard]] std::string generic_string() const { return text_; }
    [[nodiscard]] const char* c_str() const noexcept { return text_.c_str(); }
    [[nodiscard]] bool empty() const noexcept { return text_.empty(); }
    [[nodiscard]] bool is_absolute() const noexcept { return !text_.empty() && text_[0] == '/'; }
    [[nodiscard]] bool is_relative() const noexcept { return !is_absolute(); }

    [[nodiscard]] bool has_parent_path() const { return !parent_path().empty(); }

    [[nodiscard]] path parent_path() const {
        if (text_.empty()) return {};
        // "dir/" ends with an empty file name, so its parent is "dir" (as std::filesystem)
        if (text_.size() > 1U && text_.back() == '/') {
            std::size_t keep = text_.size();
            while (keep > 0U && text_[keep - 1U] == '/') --keep;
            if (keep > 0U) return path(text_.substr(0U, keep));
        }
        // the last component starts after the last '/' that is not a trailing one
        std::size_t end = text_.size();
        while (end > 1U && text_[end - 1U] == '/') --end;       // ignore trailing slashes
        const std::size_t slash = text_.rfind('/', end - 1U);
        if (slash == std::string::npos) return {};
        std::size_t cut = slash;
        while (cut > 1U && text_[cut - 1U] == '/') --cut;       // squeeze the slashes before the last name
        if (cut == 0U) return path("/");
        return path(text_.substr(0U, cut));
    }

    [[nodiscard]] path filename() const {
        if (text_.empty()) return {};
        if (text_.back() == '/') return {};                      // "dir/" has an empty file name (as std::filesystem)
        const std::size_t slash = text_.rfind('/');
        return slash == std::string::npos ? *this : path(text_.substr(slash + 1U));
    }

    [[nodiscard]] path extension() const {
        const std::string name = filename().string();
        if (name.empty() || name == "." || name == "..") return {};
        const std::size_t dot = name.rfind('.');
        if (dot == std::string::npos || dot == 0U) return {};
        return path(name.substr(dot));
    }

    [[nodiscard]] path stem() const {
        const std::string name = filename().string();
        if (name.empty() || name == "." || name == "..") return path(name);
        const std::size_t dot = name.rfind('.');
        if (dot == std::string::npos || dot == 0U) return path(name);
        return path(name.substr(0U, dot));
    }

    [[nodiscard]] path lexically_normal() const {
        if (text_.empty()) return {};
        const bool absolute = is_absolute();
        const bool trailing = text_.back() == '/';
        std::vector<std::string> parts;
        std::size_t i = 0U;
        while (i <= text_.size()) {
            std::size_t j = text_.find('/', i);
            if (j == std::string::npos) j = text_.size();
            const std::string part = text_.substr(i, j - i);
            if (part.empty() || part == ".") {
                // skip
            } else if (part == "..") {
                if (!parts.empty() && parts.back() != "..") parts.pop_back();
                else if (!absolute) parts.push_back("..");
            } else {
                parts.push_back(part);
            }
            i = j + 1U;
        }
        std::string out = absolute ? "/" : "";
        for (std::size_t k = 0U; k < parts.size(); ++k) {
            if (k != 0U) out += '/';
            out += parts[k];
        }
        if (out.empty()) return path(".");
        if (trailing && out.back() != '/') out += '/';
        return path(out);
    }

    path& operator/=(const path& other) {
        if (other.empty()) {
            if (!text_.empty() && text_.back() != '/') text_ += '/';
        } else if (other.is_absolute() || text_.empty()) {
            text_ = other.text_;
        } else {
            if (text_.back() != '/') text_ += '/';
            text_ += other.text_;
        }
        return *this;
    }
    friend path operator/(path a, const path& b) { a /= b; return a; }
    friend bool operator==(const path& a, const path& b) { return a.text_ == b.text_; }
    friend bool operator!=(const path& a, const path& b) { return a.text_ != b.text_; }

private:
    std::string text_;
};

inline bool exists(const path& p) {
    struct stat st{};
    return !p.empty() && ::stat(p.c_str(), &st) == 0;
}
inline bool is_directory(const path& p) {
    struct stat st{};
    return !p.empty() && ::stat(p.c_str(), &st) == 0 && S_ISDIR(st.st_mode);
}
inline bool is_regular_file(const path& p) {
    struct stat st{};
    return !p.empty() && ::stat(p.c_str(), &st) == 0 && S_ISREG(st.st_mode);
}

inline path current_path() {
    char buffer[4096];
    if (::getcwd(buffer, sizeof buffer) == nullptr) throw std::runtime_error("current_path failed");
    return path(buffer);
}

inline bool create_directories(const path& p) {
    if (p.empty() || is_directory(p)) return false;
    const path parent = p.parent_path();
    if (!parent.empty() && !is_directory(parent) && parent != p) create_directories(parent);
    if (::mkdir(p.c_str(), 0777) != 0 && errno != EEXIST) {
        throw std::runtime_error("cannot create folder " + p.string() + ": " + std::strerror(errno));
    }
    return true;
}

inline bool remove(const path& p) {
    if (::unlink(p.c_str()) == 0) return true;
    if (errno == ENOENT) return false;
    if (::rmdir(p.c_str()) == 0) return true;
    if (errno == ENOENT) return false;
    throw std::runtime_error("cannot remove " + p.string() + ": " + std::strerror(errno));
}

inline std::uintmax_t remove_all(const path& p) {
    struct stat st{};
    if (p.empty() || ::lstat(p.c_str(), &st) != 0) return 0U;
    std::uintmax_t count = 0U;
    if (S_ISDIR(st.st_mode)) {
        DIR* dir = ::opendir(p.c_str());
        if (dir != nullptr) {
            std::vector<std::string> names;
            while (dirent* entry = ::readdir(dir)) {
                const std::string name = entry->d_name;
                if (name != "." && name != "..") names.push_back(name);
            }
            ::closedir(dir);
            for (const auto& name : names) count += remove_all(p / name);
        }
    }
    if (remove(p)) ++count;
    return count;
}

inline void rename(const path& from, const path& to) {
    if (::rename(from.c_str(), to.c_str()) != 0) {
        throw std::runtime_error("cannot rename " + from.string() + " to " + to.string() + ": " + std::strerror(errno));
    }
}

enum class copy_options { none = 0, overwrite_existing = 1 };

inline bool copy_file(const path& from, const path& to, copy_options options = copy_options::none) {
    if (exists(to) && options != copy_options::overwrite_existing) {
        throw std::runtime_error("target exists: " + to.string());
    }
    std::ifstream in(from.string(), std::ios::binary);
    if (!in) throw std::runtime_error("cannot read " + from.string());
    std::ofstream out(to.string(), std::ios::binary | std::ios::trunc);
    if (!out) throw std::runtime_error("cannot write " + to.string());
    char buffer[1 << 16];
    while (in) {
        in.read(buffer, sizeof buffer);
        const std::streamsize got = in.gcount();
        if (got > 0) out.write(buffer, got);
    }
    out.flush();
    if (!out) throw std::runtime_error("cannot write " + to.string());
    return true;
}

// Like std::filesystem::weakly_canonical: the part that exists is made canonical, the rest is appended and normalised.
inline path weakly_canonical(const path& p, std::error_code& ec) {
    ec.clear();
    if (p.empty()) return {};
    path head = p.is_absolute() ? p : (current_path() / p);
    std::vector<std::string> tail;
    for (;;) {
        char resolved[4096];
        if (::realpath(head.c_str(), resolved) != nullptr) {
            path out(resolved);
            for (auto it = tail.rbegin(); it != tail.rend(); ++it) out /= path(*it);
            return out.lexically_normal();
        }
        if (errno != ENOENT && errno != ENOTDIR) {
            ec = std::error_code(errno, std::generic_category());
            return {};
        }
        const std::string name = head.filename().string();
        const path parent = head.parent_path();
        if (parent.empty() || parent == head) {
            ec = std::error_code(ENOENT, std::generic_category());
            return {};
        }
        if (!name.empty()) tail.push_back(name);
        head = parent;
    }
}

} // namespace silveton::fsx
