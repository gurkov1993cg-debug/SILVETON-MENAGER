#pragma once

#include <atomic>
#include <cstdint>
#include <fstream>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

namespace silveton::sampler {

class SampleRecorder {
public:
    SampleRecorder() = default;
    ~SampleRecorder();
    SampleRecorder(const SampleRecorder&) = delete;
    SampleRecorder& operator=(const SampleRecorder&) = delete;

    // Creates a 32-bit float RF64/WAVE file. Ring allocation and file opening
    // happen here, never on the realtime audio callback.
    bool start(const std::string& path, std::uint32_t sampleRate, std::uint16_t channels,
               std::uint32_t ringFrames = 262144U);
    bool push(const float* interleaved, std::uint32_t frames) noexcept;
    bool stop();

    [[nodiscard]] bool recording() const noexcept { return running_.load(std::memory_order_acquire); }
    [[nodiscard]] std::uint64_t framesWritten() const noexcept { return framesWritten_.load(std::memory_order_relaxed); }
    [[nodiscard]] std::uint64_t droppedFrames() const noexcept { return droppedFrames_.load(std::memory_order_relaxed); }
    [[nodiscard]] std::string error() const;

private:
    void writerLoop();
    bool writeHeader();
    bool finalizeHeader();
    void setError(std::string message);

    std::string path_;
    std::ofstream file_;
    std::vector<float> ring_;
    std::uint64_t ringSamples_{0U};
    std::uint32_t sampleRate_{0U};
    std::uint16_t channels_{0U};
    std::atomic<std::uint64_t> writeSamples_{0U};
    std::atomic<std::uint64_t> readSamples_{0U};
    std::atomic<std::uint64_t> framesWritten_{0U};
    std::atomic<std::uint64_t> droppedFrames_{0U};
    std::atomic<bool> running_{false};
    std::atomic<bool> stopRequested_{false};
    std::thread writer_;
    mutable std::mutex errorMutex_;
    std::string error_;
};

} // namespace silveton::sampler
