#pragma once

#include "silveton/sampler/SamplerTypes.h"
#include <cstdint>
#include <memory>
#include <string>

namespace silveton::sampler {

struct SampleEditResult {
    std::shared_ptr<SampleData> sample;
    std::string error;
    [[nodiscard]] bool ok() const noexcept { return sample != nullptr && error.empty(); }
};

class SampleEditor {
public:
    [[nodiscard]] static SampleEditResult materialize(const SampleData& source);
    [[nodiscard]] static SampleEditResult trim(const SampleData& source,
                                               std::uint64_t startFrame,
                                               std::uint64_t endFrameExclusive);
    [[nodiscard]] static SampleEditResult normalize(const SampleData& source, float targetPeakDb = -0.1F);
    [[nodiscard]] static SampleEditResult reverse(const SampleData& source);
    [[nodiscard]] static SampleEditResult fade(const SampleData& source,
                                               std::uint64_t fadeInFrames,
                                               std::uint64_t fadeOutFrames);
    [[nodiscard]] static SampleEditResult setLoop(const SampleData& source,
                                                  std::uint64_t startFrame,
                                                  std::uint64_t endFrameExclusive,
                                                  std::uint32_t crossfadeFrames);
    [[nodiscard]] static SampleEditResult clearLoop(const SampleData& source);
    [[nodiscard]] static SampleEditResult updateMetadata(const SampleData& source,
                                                         const std::string& name,
                                                         std::uint8_t rootKey,
                                                         float fineTuneCents);
    [[nodiscard]] static std::uint64_t nearestZeroCrossing(const SampleData& source,
                                                           std::uint64_t aroundFrame,
                                                           std::uint64_t searchRadius) noexcept;
};

} // namespace silveton::sampler
