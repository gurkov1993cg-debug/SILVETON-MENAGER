#pragma once

#include "silveton/sampler/SamplerEngine.h"

#include <atomic>
#include <cstdint>
#include <thread>

namespace silveton::sampler {

// Brings the part of the sample bank that the playing voices will need next
// into memory on an ordinary (non-realtime) thread.
//
// Only the attack of every sample is kept in RAM. The rest of the sample is
// read from the memory-mapped SILVETON_BANK.sv. Without this thread the audio
// thread itself had to wait for the flash storage whenever a voice reached a
// part of the bank that was not cached yet - that wait is longer than the
// 1 ms audio period and is heard as a crackle.
//
// The thread never writes, never takes a lock the audio thread uses and cannot
// crash on a bank that was just unloaded (madvise only reports an error then).
class SampleStreamPrefetcher {
public:
    explicit SampleStreamPrefetcher(const SamplerEngine& engine) noexcept : engine_(engine) {}
    ~SampleStreamPrefetcher() { stop(); }

    SampleStreamPrefetcher(const SampleStreamPrefetcher&) = delete;
    SampleStreamPrefetcher& operator=(const SampleStreamPrefetcher&) = delete;

    // Optional CPU range for the read-ahead thread (Linux/Android only), set
    // before start(). The sampler keeps it on CPU 0-5, away from the audio core.
    void setCpuRange(int firstCpu, int lastCpu) noexcept { firstCpu_ = firstCpu; lastCpu_ = lastCpu; }

    bool start() noexcept;
    void stop() noexcept;
    [[nodiscard]] bool running() const noexcept { return run_.load(std::memory_order_acquire); }

    // Diagnostics: number of memory ranges requested since start.
    [[nodiscard]] std::uint64_t requests() const noexcept { return requests_.load(std::memory_order_relaxed); }

    // One pass over all voices (also used by tests). Thread-safe w.r.t. audio.
    void runOnce() noexcept;

private:
    void loop() noexcept;

    struct SlotCache {
        std::uintptr_t begin{0U};
        std::uintptr_t end{0U};
        std::int64_t stampMs{0};
    };

    const SamplerEngine& engine_;
    std::thread thread_{};
    std::atomic<bool> run_{false};
    std::atomic<std::uint64_t> requests_{0U};
    std::atomic<int> advice_{0};
    bool populateWorked_{false};
    int firstCpu_{-1};
    int lastCpu_{-1};
    bool lastPassHadWork_{false};
    SlotCache cache_[SamplerEngine::kMaxStreamWindows]{};
};

} // namespace silveton::sampler
