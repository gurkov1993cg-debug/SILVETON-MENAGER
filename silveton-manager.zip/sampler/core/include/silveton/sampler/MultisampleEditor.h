#pragma once

#include "silveton/sampler/SamplerTypes.h"
#include <cstddef>
#include <memory>
#include <string>

namespace silveton::sampler {

struct MultisampleEditResult {
    std::shared_ptr<Multisample> multisample;
    std::string error;
    [[nodiscard]] bool ok() const noexcept { return multisample != nullptr && error.empty(); }
};

class MultisampleEditor {
public:
    [[nodiscard]] static MultisampleEditResult rename(const MultisamplePtr& source, const std::string& name);
    [[nodiscard]] static MultisampleEditResult addZone(const MultisamplePtr& source, const SampleZone& zone);
    [[nodiscard]] static MultisampleEditResult insertZone(const MultisamplePtr& source, std::size_t index, const SampleZone& zone);
    [[nodiscard]] static MultisampleEditResult removeZone(const MultisamplePtr& source, std::size_t index);
    [[nodiscard]] static MultisampleEditResult moveZone(const MultisamplePtr& source, std::size_t from, std::size_t to);
    [[nodiscard]] static MultisampleEditResult updateZone(const MultisamplePtr& source, std::size_t index,
                                                          const SampleZone& zone);

private:
    [[nodiscard]] static bool validateZone(const SampleZone& zone, std::string& error) noexcept;
};

} // namespace silveton::sampler
