#pragma once

#include "silveton/sampler/SetPackage.h"

#include <cstdint>
#include <string>

namespace silveton::sampler {

struct SvRuntimeLoadResult {
    SetData data{};
    std::string error;
    [[nodiscard]] bool ok() const noexcept { return error.empty(); }
};

class SvBankRuntime {
public:
    // Reads the single-file SILVETON_BANK.sv format produced by SILVETON Manager.
    // Audio payload stays mmap-backed; only the attack prefix is copied into RAM.
    [[nodiscard]] static SvRuntimeLoadResult load(
        const std::string& path,
        std::uint64_t attackPreloadFrames = 65536U,
        bool verifyIntegrity = false);
};

} // namespace silveton::sampler
