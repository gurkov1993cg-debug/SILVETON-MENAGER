#pragma once
#include "silveton/MidiTypes.h"
#include <array>
#include <cstdint>
#include <vector>

namespace silveton {

// TIME portamento: every interval glides in exactly the same total time.
//
// The PA600's own portamento does the glide (CC#65 ON). Korg's portamento is
// rate based, so before every note the app sends the CC#5 value that makes
// that particular interval last timeMs (KorgGlideModel). Pitch Bend, the wheel
// and the Ribbon are never touched.
// Korg portamento timing model: glide time of the PA600's own portamento for
// CC#5 value v and an interval of I semitones is
//     t(v, I) = a(v) + b(v) * I     [ms]
// Manual model set by PORTA BALANCE (or a table stored by an older version's
// microphone calibration). ccFor() inverts it: the CC#5 value that makes THIS
// interval take exactly the requested time.
class KorgGlideModel {
public:
    struct Point { int cc; double aMs; double bMsPerSemitone; };
    KorgGlideModel();
    void setPoints(const std::vector<Point>& points, bool calibrated);
    // Manual (by ear) model: time per semitone doubles every `ccPerDoubling`
    // CC#5 steps. Only this ratio decides whether an octave and a semitone
    // take the same time; the player sets it with PORTA BALANCE.
    void setManualBalance(double ccPerDoubling);
    double manualBalance() const { return balance_; }
    const std::vector<Point>& points() const { return points_; }
    bool calibrated() const { return calibrated_; }
    double timeFor(int cc, double intervalSemitones) const;
    int ccFor(double intervalSemitones, double timeMs) const;
private:
    std::vector<Point> points_;
    bool calibrated_{false};
    double balance_{11.0};
};

class Portamento {
public:
    struct Config {
        bool enabled{false};
        int timeMs{120}; // total glide time, independent of the interval
    };
    KorgGlideModel& model() { return model_; }
    const KorgGlideModel& model() const { return model_; }
    // CC#5 to send before the note on channel ch (-1 = none).
    int nativeCcForNote(int ch, int note);

    static constexpr int kMinTimeMs = 0;
    static constexpr int kMaxTimeMs = 5000;

    void setConfig(const Config& config);
    const Config& config() const { return config_; }

    // App PORTA button. ON: the Uppers whose Sound (blend) had portamento ON
    // get it back; when no Sound had it, all three Uppers get it. OFF: CC#65 = 0
    // on every Upper that had it (the PA600 switches its portamento off too).
    std::vector<MidiMessage> setEnabled(bool enabled);

    // The PA600 reported the portamento switch of the Sound just selected on
    // Upper ch (CC#65 right before its Program Change). The app follows it:
    // nothing is sent (the keyboard already switched), only the app's state
    // changes. Portamento is ON while at least one Upper has it.
    void applyBlend(int ch, bool on);
    // Portamento active on this Upper (app ON and this Upper included).
    bool activeOn(int ch) const;
    // Bit mask of the Uppers with portamento active (bit0 = U1).
    int activeMask() const;
    // What the last Sound reports said (-1 unknown, 0 off, 1 on).
    int blendState(int ch) const;
    void setTimeMs(int ms);

    // Re-assert Korg portamento ON + the last CC#5 (after connect / Program Change).
    std::vector<MidiMessage> sync() const;
    std::vector<MidiMessage> syncForChannel(int ch) const;

    // Last note that started on this Upper (-1 = none: the next note gets no CC#5).
    int lastNote(int ch) const;
    void reset();
    void resetChannel(int ch);

private:
    Config config_{};
    std::array<int, 3> lastNote_{{-1, -1, -1}};
    KorgGlideModel model_{};
    std::array<int, 3> lastCc_{{-1, -1, -1}};
    std::array<bool, 3> chOn_{{true, true, true}};
    std::array<int, 3> blend_{{-1, -1, -1}};
};

} // namespace silveton
