# IMAK2011OO — SILVETON SAMPLER за Мак (iMac 2011, macOS High Sierra, Intel x86_64) и за таблета (Galaxy Tab A11, Android, само C++)

Един проект, две програми от един и същ код: приложението за Мак и приложението за таблета (без Котлин и без Джава).
Същата програма като семплера в таблета, пренесена 1:1 на C++ за Мак. Работи със същите файлове:
`SILVETON_BANK.sv` (банката със звуците), `SILVETON_BLENDS.SVSET` (смесите, комбитата, ефектите), `SILVETON_SETS/<име>.SVSET`
(готовите сетове). При ЗАПАЗИ програмата пише тези файлове до банката, а таблетът ги чете и зарежда по същия начин.

Само частите, които са на таблета (root, Magisk, заключен изход за слушалки, Direct ALSA), са заменени:
звукът излиза през **CoreAudio**, а клавиатурата (Korg USB-MIDI) се чете през **CoreMIDI**.

## Папки

| Папка | Какво има вътре |
|---|---|
| `core/` | Звуковото ядро (семплер, гласове, ефекти, формат на банката/сетовете) — същият код като на таблета. `fsx` (FsCompat.h) заменя `std::filesystem`, който го няма в macOS 10.13. Тестове: `core/tests/` |
| `host/` | Мостът между екраните и ядрото (`NativeSamplerEngine`, `SamplerHost.cpp`) и двете „врати“: `host/src/mac/CoreAudioOutput.cpp` (звук) и `CoreMidiInput.cpp` (MIDI). На други системи (Linux тестовата машина) се ползва `DefaultIoOther.cpp`. |
| `ui/` | Рисуването и екраните. `Gfx.*` е програмен чертожник (Canvas/Paint/Path/Shader като на Android), `Fonts.cpp` + `resources/fonts` чертаят текста. `SilvetonSamplerView` са всички екрани (в отделни файлове `View_*.cpp`), `SamplerAppController` е управлението (банка, смеси, сетове, запазване). |
| `app/android/` | Таблетът без Котлин: `AndroidApp.cpp` (NativeActivity — прозорец, докосване, бутони за звука, екранна клавиатура, рисуване), `GlRenderer.*` (рисуване през видеокартата, EGL + OpenGL ES 3), `AndroidRoot.cpp` + `RootScripts.inc` (рут настройките на таблета: Magisk, права за /dev/snd, маршрути на звука, реалтайм нишки). |
| `host/src/android/` | `SamplerHostAndroid.cpp` — собственият звуков и MIDI двигател на таблета (директно ALSA, слушалки, реалтайм нишки), същият като в Котлин версията, но като чист C++. |
| `android/` | Gradle проектът, който прави APK-то (манифест, икони, настройки на NDK). В него няма нито един Котлин/Джава файл. |
| `app/mac/main.mm` | Прозорецът на Мак (AppKit): показва картинката, предава мишката/клавиатурата/колелото и пуска часовника (60 пъти в секунда). |
| `resources/fonts` | Шрифтовете (Roboto, DejaVu — свободни лицензи), слагат се вътре в приложението. |
| `third_party/stb` | stb_truetype (общодостъпен, с една поправка за композитни букви). |

## Откъде е какво (файл на екрана → таблета `SilvetonSamplerView.kt`)

| Файл | Редове в таблета |
|---|---|
| `View_A.cpp` (състояние, докосване, кадър) | 1–700, 3476–3565 |
| `View_Side.cpp` (странична лента, горна лента) | 734–927 |
| `View_Combi.cpp` (КОМБИ; редът с разделите и страниците TUNE / VOICE са пренаредени — SILVETON_MENU_V5) | 927–1700 |
| `View_Eq.cpp` (EQ, анализатор, избор на звук) | 1700–2051, 3263–3400 |
| `View_List.cpp` (СПИСЪК) | 2053–2333 |
| `View_Write.cpp` (WRITE / COPY / MOVE) | 2335–2580 |
| `View_Effects.cpp` (ЕФЕКТИ) | 2582–2721 |
| `View_Settings.cpp` (НАСТРОЙКИ, MIDI, ИНФО) | 2723–2928, 3388–3470 |
| `View_Dialogs.cpp` (прозорците) | 2932–3261 |
| `View_Kit.cpp` (чертожни помощници) | 3556–4141 |

Версията е последната на таблета (SET v14, MULTICORE + VOICE_CEILING). Лъковите инструменти (ЛЪК/BOW) ги няма в нея.

## Екранът КОМБИ (SILVETON_MENU_V5, еднакъв на таблета и на Мака)

* Лентите на Upper-ите носят само това, което се пипа при свирене: име, ON / SOLO / MUTE, PAN, плъзгач (по-дълъг), T / Q и обхват.
* Под лентите има **един ред раздели, винаги в един и същ ред**: `TUNE · RANGE · TONE` (за звука, който лентата показва — ОСНОВЕН или слой)
  и `VOICE · EQ · CTRL · FX` (за целия Upper). Отвореният раздел свети. Няма отделна страна „ОБЩО“.
* `VOICE` събира на едно място POLY / MONO / LEGATO, портаментото (SILVETON / KRONOS) и PITCH BEND. `TUNE` е само октава, транспониране, фина настройка.
* Цветове (SILVETON_SERIOUS_V1): надписите са бели върху тъмно и черни върху светло; цветът казва само състояние —
  зелено = пуснато / избрано (светнал бутон, рамка на избрания Upper, LED, активен обхват), жълто = SOLO, червено = MUTE / грешка / триене, синьо = маркиран.
  Всеки бутон за вкл./изкл. минава през `litKey` (`View_Kit.cpp`), за да изглежда еднакво навсякъде.

## Бързо рисуване (SILVETON_FAST_DRAW_V1)

Същата картинка, пиксел по пиксел (проверява се от `imak_ui_render`: леко рисуване = пълно прерисуване), но по-малко работа:
* `Gfx.cpp`, `fillSpan`: линеен градиент, който се мени само отгоре надолу (`ta == 0`), е един цвят на ред; само отляво надясно (`tb == 0`) — цветовете на колоните се смятат веднъж на операция (`gLut.row`).
* `overSolidRun`: освен SSE2 има и път с векторни типове на компилатора (NEON на таблета) — същата целочислена аритметика като `over()`.
* `FrameRenderer`: „запомнена основа“ (`base`) — когато промените започват пак от една и съща операция в списъка (влачене на точка в EQ, копче), всичко преди нея се рисува веднъж в `base`;
  променената област се копира от нея (`Canvas::copyPixels`) и отгоре се рисуват само операциите след основата (`Canvas::replayRange`). Основата важи само докато операциите ѝ са същите (по хеш) и само в областта си (`baseArea`).
* `WaveHost.inc`: таблиците към звуковия двигател се пращат само когато са се променили.

## Рисуване през видеокартата (SILVETON_GPU_DRAW_V1) — таблетът

Както в старата Котлин версия (там Андроид рисува `onDraw(Canvas)` през видеокартата и прерисува цялата страница на всеки кадър), така и тук: екраните викат същите
команди (`drawRect`, `drawText`, `drawPath`, градиенти), те се записват в списък от операции (`FrameRenderer::record`), а `app/android/GlRenderer.cpp` рисува целия списък на видеокартата.
* EGL и OpenGL ES 3.0 се зареждат с `dlopen` (без GL заглавни файлове при билд). Една шейдърна програма, едно рисуване за целия списък (по един екземпляр на операция, в реда на списъка).
* Правоъгълници: покритието по краищата се смята във фрагментния шейдър със същата формула като `rasterRect`.
* Форми и букви (`Polys`): точното покритие на софтуерния рисувач (`detail::polysCoverageMask`) се реже на плочки 16 × 16; празните и напълно покритите плочки не заемат памет (един запис в „директория“),
  останалите се пазят в една текстура. Форма, която не се променя (ключ `geomHash`), не се смята пак. Когато няма място (`compact()`), остава каквото е ползвано в последните две картинки.
* Преливания: таблицата от 256 цвята на софтуерния рисувач (`detail::gradientTable`), по един ред на текстура за преливане. Картинки: билинейно.
* Всичко е с умножено покритие и „over“ смесване (`ONE, ONE_MINUS_SRC_ALPHA`). Картинката се пази непроменена, ако списъкът е същият (по хеш) — тогава нищо не се рисува.
* При създаване се рисува малка тестова картинка и се проверява на пиксели. Процесорът не рисува картинката на таблета: ако видеокартата не тръгне,
  `AndroidApp` опитва пак след 2 секунди (причината е в журнала, етикет SILVETON). Няма надписи на екрана за това.
* Проверка: `cmake -DIMAK_GL_COMPARE=ON`, после `imak_ui_render_gl` (LIBGL_ALWAYS_SOFTWARE=1 с Mesa) рисува всеки екран и с видеокартата, и със софтуерния рисувач и сравнява (разлика най-много 2 от 255).

## TRANSWAVE (SILVETON_TRANSWAVE_V1)

Звук, който се променя, докато държиш клавиша: ред от кадри (по един период на вълната), през които минава позицията.
* Страница **WAVE** в КОМБИ, до TONE (за ОСНОВЕН и за всеки слой). Режими: OFF · AUTO (семплът на звука се реже сам на 2–32 кадъра; START, SPAN, FRAMES) ·
  MULTI (до 8 други звука са кадрите; докосване = избор от списъка със звуци, дълго = изчисти).
  Позицията се движи ръчно (POSITION) или от ENV (за TIME), LFO (RATE), VEL, MOD WHEEL, AFTERTOUCH, NOTE; AMOUNT казва колко. SMOOTH 0 = стъпала, 1 = плавно.
* Не зависи от „SYNTH ИЗКЛ“ (то е винаги включено): има собствен ключ `waveMode`.
* Ядро: `core/src/sampler/WaveTable.cpp` реже кадрите (период от корена на зоната, уточнен с автокорелация; начало на кадъра на възходящо пресичане на нулата;
  краят се слива с началото; всички кадри с една гръмкост). Таблиците се правят на контролната нишка (`WaveTableCache::refresh`, извиква се от `installState` на хоста
  чрез `host/src/WaveHost.inc`) и отиват към двигателя като непроменяема карта (`SamplerEngine::setWaveTables`). Звуковата нишка само чете.
* Свирене: при нота таблицата се намира по `waveKey(зона, настройки)`; един цикъл се чете в кръг с височината на клавиша (`ratio / periodFrames`), между два съседни
  кадъра (4-точкова интерполация). Нотата не свършва с края на семпъла, а с обвивката. Струва по-малко от обикновеното четене.
* Записва се в SET (версия 15). Хост: `nativeSetSoundWaveParam` / `nativeSoundWaveParams` (id 0 режим … 10..17 звук на кадър 1..8).
* Тестове: `testTranswave`, `testTranswaveStreamed` (core), хост тест, снимки `combi_wave_*`.

## Таблетът (Samsung Galaxy Tab A11, SM-X130, root)

* Приложението е `NativeActivity` (`android:hasCode="false"`): цялата програма е библиотеката `libsilveton_sampler.so`, няма Котлин, няма Джава.
  Пакетът е същият `com.silveton.sampler`.
* Екраните са същите като на Мака (`ui/`). Рисуването е само през видеокартата (виж „Рисуване през видеокартата“).
* Вместо Android тостове и клавиатура има плочка с текст и екранна клавиатура вътре в картинката (латиница и кирилица по БДС, бутон EN/БГ; за числа — цифрова).
* Бутоните за сила на звука променят MASTER с ±2 dB; Back затваря прозорец.
* Звукът и MIDI са на самия двигател на таблета; рут настройките (`RootScripts.inc`) са взети от Котлин версията точно както бяха настроени.
* Старата Котлин версия остава в историята на репото като резервна.
* Проверено на тестовата машина: синтаксис с имитации на Android заглавни файлове, свързване на библиотеката, цялата проверка на екраните през таблетния мост.
  Истинската проверка е билдът в GitHub и пускането върху таблета.

## Как се строи

На Мак (както прави GitHub): `cmake -S . -B build -G Xcode -DCMAKE_OSX_ARCHITECTURES=x86_64 -DCMAKE_OSX_DEPLOYMENT_TARGET=10.13`,
после `cmake --build build --config Release --target SILVETON_SAMPLER`. Тестовете: цел `imak_check` (строи и пуска всички).
На Linux (тестова машина, без приложението): `cmake -S . -B b -G Ninja -DIMAK_WERROR=ON && ninja -C b imak_check`.
Снимки на екраните: `b/ui/imak_ui_render resources/fonts <папка>`.
Таблетът (APK): в папка `android/` — `gradle --no-daemon assembleRelease` (Gradle 8.9, AGP 8.7.3, NDK 27.2.12479018, cmake 3.22.1, само arm64-v8a);
Gradle сам строи `CMakeLists.txt` от главната папка (клонът за Android). В GitHub това го прави `silveton-apk.yml` в репото на таблета (SILVETON-SEMPLER);
`IMAK2011OO.yml` в репото на Мака строи само Мака. И двете репота получават един и същ зип с кода (с различно име).

## Важно за кода

* Таблетната библиотека иска позиционно независим код (`CMAKE_POSITION_INDEPENDENT_CODE ON` в клона за Android) и се свързва с `--no-undefined`.
* Мак версията се строи БЕЗ `-Werror`; на Linux тестовата машина с `-Werror` (опция `IMAK_WERROR`).
* Рисуването е програмно (един буфер от пиксели 0xAARRGGBB), за да изглежда еднакво навсякъде; на Мак буферът се показва с CoreGraphics. На таблета същият списък от операции се рисува на видеокартата.
* Екранът е 1340 × 800 единици и се мащабира еднакво към прозореца. Десен бутон (или Ctrl + клик) = „нулирай“.

## Only in the Manager's copy (SILVETON_SEND_V1 / SILVETON_PROJECT_V1, 2026-10-22)
- host `addBankSounds(path)` / `saveOpenCombi(path)` / `loadOpenCombi(path)` (facade `nativeAddBankSounds`, `nativeSaveOpenCombi`, `nativeLoadOpenCombi`).
- `SamplerAppController`: `addSoundsFromBank`, `currentBankFile`, `saveProjectState`, `loadProjectState`, `setExtraBankFiles` (the sent files go in
  every time a bank is loaded, before the LIST: `applyBankFile`, `deleteBankSounds`), `waitForBankLoad`.
- SILVETON_PASTE_V1: host `writeSoundCombi` (facade `nativeWriteSoundCombi`), `SamplerAppController::pasteSoundsToList`,
  `SilvetonSamplerView::chosenListPosition` / `listPasted` / `setPasteOffer` (right button on a LIST position: ПОСТАВИ) (View_List.cpp).
- SILVETON_LIST_DELETE_SOUNDS_V1: host `soundsOnlyInCombi` / `removeSoundPlaces` (facade `nativeSoundsOnlyInCombi`, `nativeRemoveSoundPlaces`),
  `SamplerAppController::soundsOnlyInListEntry` / `deleteListEntryWithSounds` / `setRemovedSounds` / `setSoundsRemovedHandler`, LIST > DELETE in View_List.cpp.
- SILVETON_EVEN_DECAY_LIVE_V1: core `EvenDecayLive` (include/silveton/sampler/EvenDecay.h), `UpperPart::evenDecayMs` (Upper parameter 49),
  the per-Upper processor in SamplerEngine::render, the SetPackage block "SVXD" after everything (set version unchanged),
  КОМБИ > TONE knob ЗАТИХВАНЕ (View_Combi.cpp).
- The tablet and the Mac sampler (IMAK2011OO) do not have these; nothing else of the sampler is changed. See STRUCTURE.md of the Manager.
