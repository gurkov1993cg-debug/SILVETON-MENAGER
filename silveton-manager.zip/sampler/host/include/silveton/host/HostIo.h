#pragma once
// SILVETON_MAC_HOST_IO_V1 - the two doors of the sampler to the outside world on the computer:
// one stereo sound output and one MIDI input. The sampler (SamplerHost) only knows these two small
// interfaces. On the Mac they are CoreAudio and CoreMIDI (host/mac), for the tests they are the
// "offline" and "manual" versions below, which need no sound card at all.

#include <algorithm>
#include <array>
#include <atomic>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace silveton::host {

// ------------------------------------------------------------------ sound output
class AudioOutput {
public:
    // Called on the audio thread: fill `frames` stereo frames (interleaved float, left first).
    using RenderFn = void (*)(void* user, float* interleavedStereo, std::uint32_t frames);

    virtual ~AudioOutput() = default;
    // wantedRate / wantedFrames are wishes (96000 / 96 on the tablet). The real values are read back
    // with sampleRate() / framesPerBurst() after a successful open().
    virtual bool open(RenderFn fn, void* user, double wantedRate, std::uint32_t wantedFrames) = 0;
    virtual bool start() = 0;
    virtual void stop() = 0;
    virtual void close() = 0;
    [[nodiscard]] virtual double sampleRate() const = 0;               // 0 while closed
    [[nodiscard]] virtual std::uint32_t framesPerBurst() const = 0;    // size of one block the device asks for
    [[nodiscard]] virtual double latencyMs() const = 0;                // -1 = unknown
    [[nodiscard]] virtual int xrunCount() const { return 0; }
    [[nodiscard]] virtual bool needsRecovery() const { return false; }
    [[nodiscard]] virtual std::string deviceName() const { return {}; }
    [[nodiscard]] virtual std::string lastError() const { return {}; }
};

// ------------------------------------------------------------------ MIDI input
class MidiInput {
public:
    // Called from the MIDI thread, one complete channel message at a time (status 0x80..0xEF).
    using MessageFn = void (*)(void* user, std::uint8_t status, std::uint8_t data1, std::uint8_t data2);

    virtual ~MidiInput() = default;
    // Start listening to every MIDI source that is (or becomes) connected.
    virtual bool open(MessageFn fn, void* user) = 0;
    virtual void close() = 0;
    [[nodiscard]] virtual int sourceCount() const = 0;
    [[nodiscard]] virtual std::vector<std::string> sourceNames() const { return {}; }
    [[nodiscard]] virtual std::string lastError() const { return {}; }
};

// Turns a stream of raw MIDI bytes into complete channel messages (running status, interleaved real-time
// bytes and SysEx are handled; the sampler does not use SysEx or system messages). Same rules as the
// tablet's direct MIDI reader.
class MidiByteParser {
public:
    template <class Sink>
    void feed(std::uint8_t byte, Sink&& sink) {
        // System real-time bytes can be interleaved anywhere and do not touch running status.
        if (byte >= 0xF8U) return;
        if (inSysEx_) {
            if (byte == 0xF7U) inSysEx_ = false;
            return;
        }
        if ((byte & 0x80U) != 0U) {
            if (byte == 0xF0U) {
                reset();
                inSysEx_ = true;
                return;
            }
            pendingStatus_ = byte;
            count_ = 0U;
            needed_ = dataBytesForStatus(byte);
            runningStatus_ = byte < 0xF0U ? byte : 0U;
            if (needed_ == 0U) pendingStatus_ = 0U;
            return;
        }
        if (pendingStatus_ == 0U) {
            if (runningStatus_ == 0U) return;
            pendingStatus_ = runningStatus_;
            needed_ = dataBytesForStatus(runningStatus_);
            count_ = 0U;
        }
        if (count_ < data_.size()) data_[count_] = static_cast<std::uint8_t>(byte & 0x7FU);
        ++count_;
        if (count_ < needed_) return;
        const std::uint8_t status = pendingStatus_;
        const std::uint8_t d1 = needed_ >= 1U ? data_[0] : 0U;
        const std::uint8_t d2 = needed_ >= 2U ? data_[1] : 0U;
        if (status < 0xF0U) sink(status, d1, d2);
        pendingStatus_ = runningStatus_;
        count_ = 0U;
        needed_ = pendingStatus_ != 0U ? dataBytesForStatus(pendingStatus_) : 0U;
    }

    void reset() noexcept { *this = MidiByteParser{}; }

    static std::uint8_t dataBytesForStatus(std::uint8_t status) noexcept {
        if (status >= 0x80U && status <= 0xBFU) return 2U;
        if (status >= 0xC0U && status <= 0xDFU) return 1U;
        if (status >= 0xE0U && status <= 0xEFU) return 2U;
        if (status == 0xF1U || status == 0xF3U) return 1U;
        if (status == 0xF2U) return 2U;
        return 0U;
    }

private:
    std::uint8_t runningStatus_{0U};
    std::uint8_t pendingStatus_{0U};
    std::uint8_t needed_{0U};
    std::uint8_t count_{0U};
    std::array<std::uint8_t, 2> data_{};
    bool inSysEx_{false};
};

// ------------------------------------------------------------------ the two helpers for tests
// A sound output without a sound card: nothing runs by itself, the test asks for blocks with pump().
class OfflineAudioOutput final : public AudioOutput {
public:
    OfflineAudioOutput(double rate, std::uint32_t burst) : rate_(rate), burst_(burst) {}
    bool open(RenderFn fn, void* user, double, std::uint32_t) override {
        fn_ = fn; user_ = user; opened_ = true; return true;
    }
    bool start() override { running_ = true; return opened_; }
    void stop() override { running_ = false; }
    void close() override { running_ = false; opened_ = false; fn_ = nullptr; }
    [[nodiscard]] double sampleRate() const override { return opened_ ? rate_ : 0.0; }
    [[nodiscard]] std::uint32_t framesPerBurst() const override { return opened_ ? burst_ : 0U; }
    [[nodiscard]] double latencyMs() const override { return opened_ ? 2.0 * 1000.0 * burst_ / rate_ : -1.0; }
    [[nodiscard]] bool running() const noexcept { return running_; }
    // Renders `frames` stereo frames (in blocks of one burst, like a sound card would ask for them).
    std::vector<float> pump(std::uint32_t frames) {
        std::vector<float> out(static_cast<std::size_t>(frames) * 2U, 0.0F);
        if (!opened_ || !running_ || fn_ == nullptr) return out;
        std::uint32_t done = 0U;
        while (done < frames) {
            const std::uint32_t n = std::min(burst_, frames - done);
            fn_(user_, out.data() + static_cast<std::size_t>(done) * 2U, n);
            done += n;
        }
        return out;
    }
private:
    double rate_;
    std::uint32_t burst_;
    RenderFn fn_{nullptr};
    void* user_{nullptr};
    bool opened_{false};
    bool running_{false};
};

// A MIDI input where the test plays the keyboard by hand.
class ManualMidiInput final : public MidiInput {
public:
    bool open(MessageFn fn, void* user) override { fn_ = fn; user_ = user; opened_ = true; return true; }
    void close() override { opened_ = false; fn_ = nullptr; }
    [[nodiscard]] int sourceCount() const override { return opened_ ? 1 : 0; }
    [[nodiscard]] std::vector<std::string> sourceNames() const override {
        return opened_ ? std::vector<std::string>{"manual"} : std::vector<std::string>{};
    }
    void send(std::uint8_t status, std::uint8_t d1, std::uint8_t d2) {
        if (opened_ && fn_ != nullptr) fn_(user_, status, d1, d2);
    }
    // Raw bytes, through the same parser the real inputs use.
    void sendBytes(const std::vector<std::uint8_t>& bytes) {
        for (const std::uint8_t b : bytes) {
            parser_.feed(b, [this](std::uint8_t s, std::uint8_t a, std::uint8_t c) { send(s, a, c); });
        }
    }
private:
    MessageFn fn_{nullptr};
    void* user_{nullptr};
    bool opened_{false};
    MidiByteParser parser_{};
};

// The real devices of the platform (CoreAudio / CoreMIDI on the Mac). On other systems: a silent
// output and an empty MIDI input, so the program still starts and can be tested.
std::unique_ptr<AudioOutput> makeDefaultAudioOutput();
std::unique_ptr<MidiInput> makeDefaultMidiInput();

} // namespace silveton::host
