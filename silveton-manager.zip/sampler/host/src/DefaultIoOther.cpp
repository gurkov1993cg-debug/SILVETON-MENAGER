// SILVETON_MAC_HOST_IO_V1 - platforms without CoreAudio / CoreMIDI (the Linux test machine): the default
// devices are a silent output and an empty MIDI input, so everything still starts and can be tested.
#if !defined(__APPLE__)
#include "silveton/host/HostIo.h"

namespace silveton::host {

std::unique_ptr<AudioOutput> makeDefaultAudioOutput() {
    return std::make_unique<OfflineAudioOutput>(48000.0, 96U);
}

std::unique_ptr<MidiInput> makeDefaultMidiInput() {
    return std::make_unique<ManualMidiInput>();
}

} // namespace silveton::host
#endif
