// SILVETON_MAC_COREMIDI_V1 - the keyboard input of the Mac sampler (replaces the tablet's raw MIDI reader).
// Every MIDI source of the Mac (a Korg over USB, Bluetooth MIDI, the IAC bus ...) is connected; sources that
// appear or disappear later are picked up on their own. The bytes go through the same parser as on the tablet.
#if defined(__APPLE__)

#include "silveton/host/HostIo.h"

#include <CoreFoundation/CoreFoundation.h>
#include <CoreMIDI/CoreMIDI.h>

#include <atomic>
#include <memory>
#include <mutex>
#include <string>
#include <vector>

namespace silveton::host {
namespace {

std::string endpointName(MIDIEndpointRef endpoint) {
    CFStringRef name = nullptr;
    std::string out;
    if (MIDIObjectGetStringProperty(endpoint, kMIDIPropertyDisplayName, &name) == noErr && name != nullptr) {
        char buffer[256];
        if (CFStringGetCString(name, buffer, sizeof buffer, kCFStringEncodingUTF8)) out = buffer;
        CFRelease(name);
    }
    return out;
}

class CoreMidiInput final : public MidiInput {
public:
    ~CoreMidiInput() override { close(); }

    bool open(MessageFn fn, void* user) override {
        close();
        fn_ = fn;
        user_ = user;
        error_.clear();
        OSStatus rc = MIDIClientCreate(CFSTR("SILVETON"), &CoreMidiInput::notifyProc, this, &client_);
        if (rc != noErr) { error_ = "MIDIClientCreate failed (" + std::to_string(static_cast<int>(rc)) + ")"; client_ = 0; return false; }
        rc = MIDIInputPortCreate(client_, CFSTR("SILVETON IN"), &CoreMidiInput::readProc, this, &port_);
        if (rc != noErr) {
            error_ = "MIDIInputPortCreate failed (" + std::to_string(static_cast<int>(rc)) + ")";
            MIDIClientDispose(client_);
            client_ = 0;
            return false;
        }
        opened_.store(true, std::memory_order_release);
        rescan();
        return true;
    }

    void close() override {
        if (!opened_.exchange(false, std::memory_order_acq_rel)) return;
        {
            std::lock_guard<std::mutex> lock(mutex_);
            for (auto& s : sources_) (void)MIDIPortDisconnectSource(port_, s->endpoint);
        }
        (void)MIDIPortDispose(port_);
        (void)MIDIClientDispose(client_);
        port_ = 0;
        client_ = 0;
        std::lock_guard<std::mutex> lock(mutex_);
        sources_.clear();
        retired_.clear();
        lastSeenCount_ = 0;
    }

    [[nodiscard]] int sourceCount() const override {
        if (!opened_.load(std::memory_order_acquire)) return 0;
        // Plugging a keyboard in or out changes the number of sources; look again when it differs.
        const ItemCount now = MIDIGetNumberOfSources();
        if (dirty_.exchange(false, std::memory_order_acq_rel) || now != lastSeenCount_.load(std::memory_order_relaxed)) {
            const_cast<CoreMidiInput*>(this)->rescan();
        }
        std::lock_guard<std::mutex> lock(mutex_);
        return static_cast<int>(sources_.size());
    }

    [[nodiscard]] std::vector<std::string> sourceNames() const override {
        std::lock_guard<std::mutex> lock(mutex_);
        std::vector<std::string> out;
        for (const auto& s : sources_) out.push_back(s->name);
        return out;
    }

    [[nodiscard]] std::string lastError() const override { return error_; }

private:
    struct Source {
        MIDIEndpointRef endpoint{0};
        std::string name;
        MidiByteParser parser;
        CoreMidiInput* owner{nullptr};
    };

    // Connect every source that is not connected yet, drop those that are gone.
    void rescan() {
        std::lock_guard<std::mutex> lock(mutex_);
        const ItemCount count = MIDIGetNumberOfSources();
        lastSeenCount_.store(count, std::memory_order_relaxed);
        std::vector<MIDIEndpointRef> present;
        for (ItemCount i = 0; i < count; ++i) present.push_back(MIDIGetSource(i));

        for (auto it = sources_.begin(); it != sources_.end();) {
            bool still = false;
            for (const MIDIEndpointRef e : present) if (e == (*it)->endpoint) { still = true; break; }
            if (still) { ++it; continue; }
            (void)MIDIPortDisconnectSource(port_, (*it)->endpoint);
            retired_.push_back(std::move(*it));      // a message may still be on its way: keep the object alive until close()
            it = sources_.erase(it);
        }
        for (const MIDIEndpointRef e : present) {
            if (e == 0) continue;
            bool known = false;
            for (const auto& s : sources_) if (s->endpoint == e) { known = true; break; }
            if (known) continue;
            auto source = std::make_unique<Source>();
            source->endpoint = e;
            source->name = endpointName(e);
            source->owner = this;
            if (MIDIPortConnectSource(port_, e, source.get()) == noErr) sources_.push_back(std::move(source));
        }
    }

    static void readProc(const MIDIPacketList* list, void*, void* sourceRef) {
        auto* source = static_cast<Source*>(sourceRef);
        if (source == nullptr || list == nullptr || source->owner == nullptr || source->owner->fn_ == nullptr) return;
        CoreMidiInput* owner = source->owner;
        const MIDIPacket* packet = &list->packet[0];
        for (UInt32 p = 0; p < list->numPackets; ++p) {
            for (UInt16 i = 0; i < packet->length; ++i) {
                source->parser.feed(packet->data[i], [owner](std::uint8_t s, std::uint8_t a, std::uint8_t b) {
                    owner->fn_(owner->user_, s, a, b);
                });
            }
            packet = MIDIPacketNext(packet);
        }
    }

    static void notifyProc(const MIDINotification* message, void* ref) {
        if (message != nullptr && message->messageID == kMIDIMsgSetupChanged) {
            static_cast<CoreMidiInput*>(ref)->dirty_.store(true, std::memory_order_release);
        }
    }

    MessageFn fn_{nullptr};
    void* user_{nullptr};
    MIDIClientRef client_{0};
    MIDIPortRef port_{0};
    std::atomic<bool> opened_{false};
    mutable std::atomic<bool> dirty_{false};
    mutable std::atomic<ItemCount> lastSeenCount_{0};
    mutable std::mutex mutex_;
    std::vector<std::unique_ptr<Source>> sources_;
    std::vector<std::unique_ptr<Source>> retired_;
    std::string error_;
};

} // namespace

std::unique_ptr<MidiInput> makeCoreMidiInput() { return std::make_unique<CoreMidiInput>(); }

} // namespace silveton::host
#endif
