// SILVETON_MAC_HOST_V1
// The sampler "host" for the Mac: everything the tablet program does around the sound core (loading
// banks, sets and combis, saving, the sound/combi/list/FX/global editing, MIDI scanning, meters),
// taken over one to one from the tablet bridge (SamplerAudioBridge.cpp). Only the outside doors differ:
// the sound goes out through an AudioOutput (CoreAudio on the Mac), the keyboard comes in through a
// MidiInput (CoreMIDI), and there is no root, no headphone lock and no Direct ALSA.

#include "silveton/host/HostIo.h"
#include "silveton/host/NativeSamplerEngine.h"

#include "silveton/sampler/AudioFileLoader.h"
#include "silveton/sampler/KorgImporter.h"
#include "silveton/sampler/MultisampleEditor.h"
#include "silveton/sampler/SampleEditor.h"
#include "silveton/sampler/ProgramEditor.h"
#include "silveton/sampler/SamplerEngine.h"
#include "silveton/sampler/SamplerLibrary.h"
#include "silveton/sampler/SetPackage.h"
#include "silveton/sampler/SvBankRuntime.h"
#include "silveton/sampler/SvBankFormat.h"
#include "silveton/sampler/SampleStreamPrefetcher.h"

#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cerrno>
#include <cstdint>
#include <cstring>
#include <limits>
#include <map>
#include <memory>
#include <deque>
#include <mutex>
#include <optional>
#include <set>
#include <sstream>
#include <string>
#include <thread>
#include <vector>

namespace silveton::host {
namespace {
using namespace silveton::sampler;

// ---------------------------------------------------------------- SILVETON_BANK_INFO_V1
// INFO / DELETE of whole SOUNDs in SILVETON_BANK.sv on the tablet. A deleted
// SOUND takes its samples with it (only samples no other SOUND uses), the bank
// file is written again smaller (new file next to it, then renamed over it).
struct Sha256Stream {
    std::array<std::uint32_t, 8> h{{0x6a09e667U,0xbb67ae85U,0x3c6ef372U,0xa54ff53aU,0x510e527fU,0x9b05688cU,0x1f83d9abU,0x5be0cd19U}};
    std::array<std::uint8_t, 64> buf{};
    std::size_t used{0U};
    std::uint64_t bits{0U};
    static std::uint32_t rr(std::uint32_t x, int n) { return (x >> n) | (x << (32 - n)); }
    void block(const std::uint8_t* p) {
        static constexpr std::uint32_t k[64] = {
            0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,
            0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
            0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,
            0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
            0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,
            0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2};
        std::uint32_t w[64];
        for (int i = 0; i < 16; ++i) w[i] = (std::uint32_t(p[4*i]) << 24) | (std::uint32_t(p[4*i+1]) << 16) | (std::uint32_t(p[4*i+2]) << 8) | std::uint32_t(p[4*i+3]);
        for (int i = 16; i < 64; ++i) {
            const std::uint32_t s0 = rr(w[i-15],7) ^ rr(w[i-15],18) ^ (w[i-15] >> 3);
            const std::uint32_t s1 = rr(w[i-2],17) ^ rr(w[i-2],19) ^ (w[i-2] >> 10);
            w[i] = w[i-16] + s0 + w[i-7] + s1;
        }
        std::uint32_t a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],hh=h[7];
        for (int i = 0; i < 64; ++i) {
            const std::uint32_t t1 = hh + (rr(e,6) ^ rr(e,11) ^ rr(e,25)) + ((e & f) ^ (~e & g)) + k[i] + w[i];
            const std::uint32_t t2 = (rr(a,2) ^ rr(a,13) ^ rr(a,22)) + ((a & b) ^ (a & c) ^ (b & c));
            hh = g; g = f; f = e; e = d + t1; d = c; c = b; b = a; a = t1 + t2;
        }
        h[0]+=a; h[1]+=b; h[2]+=c; h[3]+=d; h[4]+=e; h[5]+=f; h[6]+=g; h[7]+=hh;
    }
    void add(const std::uint8_t* p, std::size_t n) {
        bits += static_cast<std::uint64_t>(n) * 8U;
        while (n > 0U) {
            if (used == 0U && n >= 64U) { block(p); p += 64; n -= 64; continue; }
            const std::size_t take = std::min<std::size_t>(64U - used, n);
            std::memcpy(buf.data() + used, p, take); used += take; p += take; n -= take;
            if (used == 64U) { block(buf.data()); used = 0U; }
        }
    }
    std::array<std::uint8_t, 32> finish() {
        const std::uint64_t total = bits;
        const std::uint8_t one = 0x80U; add(&one, 1U); bits -= 8U;
        const std::uint8_t zero = 0U;
        while (used != 56U) { add(&zero, 1U); bits -= 8U; }
        std::uint8_t len[8];
        for (int i = 0; i < 8; ++i) len[i] = static_cast<std::uint8_t>(total >> (56 - 8 * i));
        add(len, 8U);
        std::array<std::uint8_t, 32> out{};
        for (int i = 0; i < 8; ++i) for (int j = 0; j < 4; ++j) out[static_cast<std::size_t>(4*i+j)] = static_cast<std::uint8_t>(h[static_cast<std::size_t>(i)] >> (24 - 8 * j));
        return out;
    }
};

struct MappedFile {
    const std::uint8_t* data{nullptr};
    std::size_t size{0U};
    bool open(const std::string& path) {
        const int fd = ::open(path.c_str(), O_RDONLY | O_CLOEXEC);
        if (fd < 0) return false;
        struct stat st{};
        if (::fstat(fd, &st) != 0 || st.st_size <= 0) { ::close(fd); return false; }
        void* m = ::mmap(nullptr, static_cast<std::size_t>(st.st_size), PROT_READ, MAP_PRIVATE, fd, 0);
        ::close(fd);
        if (m == MAP_FAILED) return false;
        data = static_cast<const std::uint8_t*>(m);
        size = static_cast<std::size_t>(st.st_size);
        return true;
    }
    ~MappedFile() { if (data != nullptr) ::munmap(const_cast<std::uint8_t*>(data), size); }
};

struct BankModel {
    SvBankHeader header{};
    std::vector<SvSoundRecord> sounds;
    std::vector<SvSoundLayerRecord> layers;
    std::vector<SvMultisampleRecord> multisamples;
    std::vector<SvSampleRecord> samples;
    std::vector<SvZoneRecord> zones;
};

bool readBankModel(const MappedFile& f, BankModel& m, std::string& error) {
    if (!deserializeHeader(f.data, f.size, m.header, error)) return false;
    auto section = [&](SvSection s) { return m.header.sections[static_cast<std::size_t>(s)]; };
    auto readAll = [&](SvSection s, std::uint32_t count, std::size_t recSize, auto& vec, auto reader) {
        const auto sec = section(s);
        if (sec.offset + static_cast<std::uint64_t>(count) * recSize > f.size) return false;
        vec.resize(count);
        for (std::uint32_t i = 0U; i < count; ++i)
            if (!reader(f.data + sec.offset + static_cast<std::uint64_t>(i) * recSize, recSize, vec[i])) return false;
        return true;
    };
    if (!readAll(SvSection::Sounds, m.header.soundCount, kSvSoundRecordSize, m.sounds, readSoundRecord) ||
        !readAll(SvSection::SoundLayers, m.header.soundLayerCount, kSvSoundLayerRecordSize, m.layers, readSoundLayerRecord) ||
        !readAll(SvSection::Multisamples, m.header.multisampleCount, kSvMultisampleRecordSize, m.multisamples, readMultisampleRecord) ||
        !readAll(SvSection::Samples, m.header.sampleCount, kSvSampleRecordSize, m.samples, readSampleRecord) ||
        !readAll(SvSection::Zones, m.header.zoneCount, kSvZoneRecordSize, m.zones, readZoneRecord)) {
        error = "SILVETON_BANK.sv records cannot be read";
        return false;
    }
    return true;
}

std::string bankString(const MappedFile& f, const BankModel& m, std::uint32_t offset) {
    const auto sec = m.header.sections[static_cast<std::size_t>(SvSection::Strings)];
    if (offset >= sec.size) return {};
    std::size_t pos = static_cast<std::size_t>(sec.offset + offset);
    const std::size_t end = static_cast<std::size_t>(std::min<std::uint64_t>(sec.offset + sec.size, f.size));
    std::string out;
    while (pos < end && f.data[pos] != 0U) out.push_back(static_cast<char>(f.data[pos++]));
    return out;
}

// Sample ids used by a SOUND.
std::set<std::uint32_t> soundSamples(const BankModel& m, const SvSoundRecord& s) {
    std::map<std::uint32_t, const SvMultisampleRecord*> msById;
    for (const auto& ms : m.multisamples) msById[ms.multisampleId] = &ms;
    std::set<std::uint32_t> ids;
    for (std::uint32_t l = s.firstLayer; l < s.firstLayer + s.layerCount && l < m.layers.size(); ++l) {
        const auto it = msById.find(m.layers[l].multisampleId);
        if (it == msById.end()) continue;
        for (std::uint32_t z = it->second->firstZone; z < it->second->firstZone + it->second->zoneCount && z < m.zones.size(); ++z)
            ids.insert(m.zones[z].sampleId);
    }
    return ids;
}

// Text for INFO: first line "TOTAL\tsounds\tsamples\taudioBytes\tfileBytes", then
// one line per SOUND "slot\tname\tsamples\tbytes" (bytes = audio only this SOUND uses... and shared).
std::string bankInfoText(const std::string& path, std::string& error) {
    MappedFile f;
    if (!f.open(path)) { error = "Cannot open " + path; return {}; }
    BankModel m;
    if (!readBankModel(f, m, error)) return {};
    std::map<std::uint32_t, const SvSampleRecord*> sampleById;
    for (const auto& r : m.samples) sampleById[r.sampleId] = &r;
    std::set<std::uint64_t> allAudio;
    std::uint64_t totalAudio = 0U;
    for (const auto& r : m.samples) if (allAudio.insert(r.audioOffset).second) totalAudio += r.audioSize;
    std::ostringstream out;
    out << "TOTAL\t" << m.sounds.size() << "\t" << m.samples.size() << "\t" << totalAudio << "\t" << f.size << "\n";
    for (const auto& s : m.sounds) {
        const auto ids = soundSamples(m, s);
        std::set<std::uint64_t> audio;
        std::uint64_t bytes = 0U;
        for (auto id : ids) {
            const auto it = sampleById.find(id);
            if (it != sampleById.end() && audio.insert(it->second->audioOffset).second) bytes += it->second->audioSize;
        }
        std::string name = bankString(f, m, s.nameOffset);
        for (auto& ch : name) if (ch == '\t' || ch == '\n') ch = ' ';
        out << s.soundSlotId << "\t" << name << "\t" << ids.size() << "\t" << bytes << "\n";
    }
    return out.str();
}

bool removeBankSounds(const std::string& path, const std::set<std::uint16_t>& slots, std::string& error) {
    std::string tmp = path + ".tmp";
    {
        MappedFile f;
        if (!f.open(path)) { error = "Cannot open " + path; return false; }
        BankModel m;
        if (!readBankModel(f, m, error)) return false;
        BankModel n;
        n.header = m.header;
        std::set<std::uint32_t> usedMs;
        for (const auto& s : m.sounds) {
            if (slots.count(s.soundSlotId) != 0U) continue;
            SvSoundRecord r = s;
            r.firstLayer = static_cast<std::uint32_t>(n.layers.size());
            for (std::uint32_t l = s.firstLayer; l < s.firstLayer + s.layerCount && l < m.layers.size(); ++l) {
                n.layers.push_back(m.layers[l]);
                usedMs.insert(m.layers[l].multisampleId);
            }
            r.layerCount = static_cast<std::uint32_t>(n.layers.size()) - r.firstLayer;
            n.sounds.push_back(r);
        }
        if (n.sounds.empty()) { error = "The last SOUND cannot be deleted"; return false; }
        std::set<std::uint32_t> usedSamples;
        for (const auto& ms : m.multisamples) {
            if (usedMs.count(ms.multisampleId) == 0U) continue;
            SvMultisampleRecord r = ms;
            r.firstZone = static_cast<std::uint32_t>(n.zones.size());
            for (std::uint32_t z = ms.firstZone; z < ms.firstZone + ms.zoneCount && z < m.zones.size(); ++z) {
                n.zones.push_back(m.zones[z]);
                usedSamples.insert(m.zones[z].sampleId);
            }
            r.zoneCount = static_cast<std::uint32_t>(n.zones.size()) - r.firstZone;
            n.multisamples.push_back(r);
        }
        // audio: every kept piece once, aligned to 64 bytes
        std::map<std::uint64_t, std::uint64_t> newOffset;
        std::vector<std::pair<std::uint64_t, std::uint64_t>> copies;   // old offset, size
        std::uint64_t audioSize = 0U;
        for (const auto& r : m.samples) {
            if (usedSamples.count(r.sampleId) == 0U) continue;
            SvSampleRecord k = r;
            auto it = newOffset.find(r.audioOffset);
            if (it == newOffset.end()) {
                audioSize = (audioSize + 63U) & ~std::uint64_t{63U};
                it = newOffset.emplace(r.audioOffset, audioSize).first;
                copies.emplace_back(r.audioOffset, r.audioSize);
                audioSize += r.audioSize;
            }
            k.audioOffset = it->second;
            n.samples.push_back(k);
        }
        // layout
        auto& h = n.header;
        h.soundCount = static_cast<std::uint32_t>(n.sounds.size());
        h.soundLayerCount = static_cast<std::uint32_t>(n.layers.size());
        h.multisampleCount = static_cast<std::uint32_t>(n.multisamples.size());
        h.sampleCount = static_cast<std::uint32_t>(n.samples.size());
        h.zoneCount = static_cast<std::uint32_t>(n.zones.size());
        std::vector<std::uint8_t> records[5];
        for (const auto& r : n.sounds) appendSoundRecord(records[0], r);
        for (const auto& r : n.layers) appendSoundLayerRecord(records[1], r);
        for (const auto& r : n.multisamples) appendMultisampleRecord(records[2], r);
        for (const auto& r : n.samples) appendSampleRecord(records[3], r);
        for (const auto& r : n.zones) appendZoneRecord(records[4], r);
        const auto oldStrings = m.header.sections[static_cast<std::size_t>(SvSection::Strings)];
        const auto oldAudio = m.header.sections[static_cast<std::size_t>(SvSection::Audio)];
        std::uint64_t pos = kSvBankHeaderSize;
        auto place = [&](SvSection s, std::uint64_t size, std::uint64_t align) {
            pos = (pos + align - 1U) / align * align;
            h.sections[static_cast<std::size_t>(s)] = SvSectionDesc{pos, size};
            pos += size;
        };
        place(SvSection::Sounds, records[0].size(), 64U);
        place(SvSection::SoundLayers, records[1].size(), 64U);
        place(SvSection::Multisamples, records[2].size(), 64U);
        place(SvSection::Samples, records[3].size(), 64U);
        place(SvSection::Zones, records[4].size(), 64U);
        place(SvSection::Strings, oldStrings.size, 64U);
        place(SvSection::Audio, audioSize, 4096U);
        h.fileSize = pos;
        // write: header placeholder, payload streamed (SHA-256 on the way), header again
        const int fd = ::open(tmp.c_str(), O_WRONLY | O_CREAT | O_TRUNC | O_CLOEXEC, 0644);
        if (fd < 0) { error = "Cannot write " + tmp; return false; }
        Sha256Stream sha;
        std::uint64_t written = 0U;
        bool ok = true;
        auto put = [&](const std::uint8_t* p, std::size_t len, bool hash) {
            while (ok && len > 0U) {
                const ssize_t w = ::write(fd, p, len);
                if (w <= 0) { if (errno == EINTR) continue; ok = false; break; }
                if (hash) sha.add(p, static_cast<std::size_t>(w));
                p += w; len -= static_cast<std::size_t>(w); written += static_cast<std::uint64_t>(w);
            }
        };
        std::vector<std::uint8_t> zeros(4096, 0U);
        auto padTo = [&](std::uint64_t to) {
            while (ok && written < to) put(zeros.data(), static_cast<std::size_t>(std::min<std::uint64_t>(zeros.size(), to - written)), true);
        };
        const auto headerBytes = serializeHeader(h);
        put(headerBytes.data(), headerBytes.size(), false);
        while (ok && written < kSvBankHeaderSize) put(zeros.data(), static_cast<std::size_t>(kSvBankHeaderSize - written), false);
        const SvSection order[5] = {SvSection::Sounds, SvSection::SoundLayers, SvSection::Multisamples, SvSection::Samples, SvSection::Zones};
        for (int i = 0; i < 5 && ok; ++i) {
            padTo(h.sections[static_cast<std::size_t>(order[i])].offset);
            put(records[i].data(), records[i].size(), true);
        }
        padTo(h.sections[static_cast<std::size_t>(SvSection::Strings)].offset);
        if (oldStrings.offset + oldStrings.size <= f.size) put(f.data + oldStrings.offset, static_cast<std::size_t>(oldStrings.size), true);
        const std::uint64_t audioBase = h.sections[static_cast<std::size_t>(SvSection::Audio)].offset;
        for (const auto& c : copies) {
            padTo(audioBase + newOffset[c.first]);
            if (oldAudio.offset + c.first + c.second > f.size) { ok = false; error = "Bank audio is outside the file"; break; }
            put(f.data + oldAudio.offset + c.first, static_cast<std::size_t>(c.second), true);
        }
        padTo(h.fileSize);
        h.payloadSha256 = sha.finish();
        const auto finalHeader = serializeHeader(h);
        if (ok && ::lseek(fd, 0, SEEK_SET) == 0) { written = 0U; put(finalHeader.data(), finalHeader.size(), false); }
        else ok = false;
        if (ok && ::fsync(fd) != 0) ok = false;
        ::close(fd);
        if (!ok) { ::unlink(tmp.c_str()); if (error.empty()) error = "Writing the bank failed (storage full?)"; return false; }
    }
    if (::rename(tmp.c_str(), path.c_str()) != 0) { ::unlink(tmp.c_str()); error = "Cannot replace " + path; return false; }
    return true;
}

// Built-in playable fallback instrument. It is deliberately generated in the
// native realtime path so a fresh APK can verify MIDI -> DSP -> Direct ALSA
// without requiring a bank file. As soon as a real PROGRAM/COMBI is loaded,
// installState() disables this fallback automatically.
class BuiltinTestInstrument {
public:
    static constexpr std::size_t kVoiceCount = 24U;
    static constexpr std::size_t kTableSize = 2048U;
    static constexpr std::size_t kEventCount = 128U;

    BuiltinTestInstrument() noexcept {
        constexpr double pi = 3.14159265358979323846;
        for (std::size_t i = 0; i < kTableSize; ++i) {
            const double p = 2.0 * pi * static_cast<double>(i) / static_cast<double>(kTableSize);
            table_[i] = static_cast<float>(
                0.78 * std::sin(p) +
                0.16 * std::sin(2.0 * p) +
                0.06 * std::sin(3.0 * p));
        }
    }

    void setEnabled(bool enabled) noexcept {
        enabled_.store(enabled, std::memory_order_release);
        if (!enabled) push({3U, 0U, 0U});
    }

    bool enabled() const noexcept { return enabled_.load(std::memory_order_acquire); }

    void noteOn(std::uint8_t key, std::uint8_t velocity) noexcept {
        if (enabled() && velocity != 0U) push({1U, key, velocity});
    }
    void noteOff(std::uint8_t key) noexcept {
        if (enabled()) push({2U, key, 0U});
    }
    void panic() noexcept { push({3U, 0U, 0U}); }

    void render(float* interleavedStereo, std::uint32_t frames, int sampleRate) noexcept {
        if (interleavedStereo == nullptr || frames == 0U || sampleRate <= 0) return;
        consumeEvents(sampleRate);
        if (!enabled()) return;

        const float sr = static_cast<float>(sampleRate);
        const float attackStep = 1.0F / std::max(1.0F, sr * 0.004F);
        const float decayK = 1.0F - std::exp(-1.0F / std::max(1.0F, sr * 0.24F));
        const float releaseMul = std::exp(std::log(0.0001F) / std::max(1.0F, sr * 0.32F));

        for (std::uint32_t f = 0; f < frames; ++f) {
            float mono = 0.0F;
            for (auto& v : voices_) {
                if (!v.active) continue;

                if (!v.releasing) {
                    if (v.env < 0.999F && v.attack) {
                        v.env += attackStep;
                        if (v.env >= 1.0F) { v.env = 1.0F; v.attack = false; }
                    } else {
                        v.env += (0.48F - v.env) * decayK;
                    }
                } else {
                    v.env *= releaseMul;
                    if (v.env < 0.0001F) { v.active = false; continue; }
                }

                const auto i0 = static_cast<std::size_t>(v.phase) & (kTableSize - 1U);
                const auto i1 = (i0 + 1U) & (kTableSize - 1U);
                const float frac = v.phase - static_cast<float>(static_cast<std::size_t>(v.phase));
                const float osc = table_[i0] + (table_[i1] - table_[i0]) * frac;
                mono += osc * v.env * v.velocityGain * 0.035F;

                v.phase += v.phaseStep;
                if (v.phase >= static_cast<float>(kTableSize)) v.phase -= static_cast<float>(kTableSize);
            }

            interleavedStereo[static_cast<std::size_t>(f) * 2U] += mono;
            interleavedStereo[static_cast<std::size_t>(f) * 2U + 1U] += mono;
        }
    }

private:
    struct Event { std::uint8_t type; std::uint8_t key; std::uint8_t velocity; };
    struct Voice {
        bool active{false};
        bool releasing{false};
        bool attack{true};
        std::uint8_t key{0U};
        float phase{0.0F};
        float phaseStep{0.0F};
        float env{0.0F};
        float velocityGain{0.0F};
        std::uint64_t age{0U};
    };

    void push(Event e) noexcept {
        if (writeLock_.test_and_set(std::memory_order_acquire)) return;
        const unsigned w = write_.load(std::memory_order_relaxed);
        const unsigned next = (w + 1U) % static_cast<unsigned>(kEventCount);
        if (next != read_.load(std::memory_order_acquire)) {
            events_[w] = e;
            write_.store(next, std::memory_order_release);
        }
        writeLock_.clear(std::memory_order_release);
    }

    void consumeEvents(int sampleRate) noexcept {
        unsigned r = read_.load(std::memory_order_relaxed);
        const unsigned w = write_.load(std::memory_order_acquire);
        while (r != w) {
            const Event e = events_[r];
            r = (r + 1U) % static_cast<unsigned>(kEventCount);
            if (e.type == 1U) startVoice(e.key, e.velocity, sampleRate);
            else if (e.type == 2U) releaseKey(e.key);
            else if (e.type == 3U) for (auto& v : voices_) v = Voice{};
        }
        read_.store(r, std::memory_order_release);
    }

    void startVoice(std::uint8_t key, std::uint8_t velocity, int sampleRate) noexcept {
        Voice* chosen = nullptr;
        for (auto& v : voices_) if (!v.active) { chosen = &v; break; }
        if (chosen == nullptr) {
            chosen = &voices_[0];
            for (auto& v : voices_) if (v.env < chosen->env || (v.env == chosen->env && v.age < chosen->age)) chosen = &v;
        }
        const double frequency = 440.0 * std::pow(2.0, (static_cast<int>(key) - 69) / 12.0);
        chosen->active = true;
        chosen->releasing = false;
        chosen->attack = true;
        chosen->key = key;
        chosen->phase = 0.0F;
        chosen->phaseStep = static_cast<float>(frequency * static_cast<double>(kTableSize) / static_cast<double>(sampleRate));
        chosen->env = 0.0F;
        chosen->velocityGain = std::sqrt(static_cast<float>(velocity) / 127.0F);
        chosen->age = ++age_;
    }

    void releaseKey(std::uint8_t key) noexcept {
        for (auto& v : voices_) if (v.active && v.key == key) v.releasing = true;
    }

    std::array<float, kTableSize> table_{};
    std::array<Voice, kVoiceCount> voices_{};
    std::array<Event, kEventCount> events_{};
    std::atomic<unsigned> write_{0U};
    std::atomic<unsigned> read_{0U};
    std::atomic<bool> enabled_{true};
    std::atomic_flag writeLock_ = ATOMIC_FLAG_INIT;
    std::uint64_t age_{0U};
};

class SamplerHost {
public:
    SamplerHost() = default;
    ~SamplerHost() { close(); }

    // The two doors to the outside (see HostIo.h). Used only while the sampler is closed; without them the
    // platform's own devices are taken (CoreAudio / CoreMIDI on the Mac).
    void setAudioOutput(std::unique_ptr<AudioOutput> out) {
        std::lock_guard<std::mutex> lock(controlMutex_);
        if (!opened_.load(std::memory_order_acquire)) audio_ = std::move(out);
    }
    void setMidiInput(std::unique_ptr<MidiInput> in) {
        std::lock_guard<std::mutex> lock(controlMutex_);
        if (!midiOpen_.load(std::memory_order_acquire)) midi_ = std::move(in);
    }

    // PORTA BALANCE of the SILVETON keyboard processor (3..40, default 11).
    void setPortamentoBalance(float balance) noexcept { engine_.setPortamentoBalance(balance); }
    void setPortamentoNear(float ms) noexcept { engine_.setPortamentoNear(ms); }
    // SILVETON_VOICE_CEILING_V1: how many notes may sound at once
    void setVoiceCeiling(int voices) noexcept { engine_.setVoiceCeiling(voices); }
    [[nodiscard]] int voiceCeiling() const noexcept { return engine_.voiceCeiling(); }

    // The Mac has no locked headphone output; the call stays so the screens can keep asking.
    bool enforceHeadphoneRoute(bool) noexcept { return true; }

    bool open() {
        std::lock_guard<std::mutex> lock(controlMutex_);
        // MIDI is an independent realtime input path. Start it first so a temporary sound-output
        // failure never makes the keyboard disappear.
        (void)startMidiLocked();
        // Bank read-ahead runs on an ordinary thread, never on the audio thread.
        prefetcher_.setCpuRange(0, 5);
        if (!prefetcher_.running()) (void)prefetcher_.start();
        return openLocked();
    }

    bool start() {
        std::lock_guard<std::mutex> lock(controlMutex_);
        wantStarted_.store(true, std::memory_order_release);
        return startLocked();
    }

    void stop() {
        std::lock_guard<std::mutex> lock(controlMutex_);
        wantStarted_.store(false, std::memory_order_release);
        (void)stopLocked();
    }

    void close() {
        std::lock_guard<std::mutex> lock(controlMutex_);
        wantStarted_.store(false, std::memory_order_release);
        (void)stopLocked();
        stopMidiLocked();
        prefetcher_.stop();
        closeAudioLocked();
    }

    bool recover() {
        std::lock_guard<std::mutex> lock(controlMutex_);
        if (!needsRecovery()) return true;
        const bool resume = wantStarted_.load(std::memory_order_acquire);
        (void)stopLocked();
        closeAudioLocked();
        if (!openLocked()) return false;
        recoverRequested_.store(false, std::memory_order_release);
        return !resume || startLocked();
    }

    bool loadAudioFile(const std::string& path) {
        // Two seconds at 48 kHz is preloaded for instant attack; the remainder
        // stays mmap-backed. Higher-rate files preload the same frame count,
        // still avoiding full-library RAM residency on the 4 GB target tablet.
        const auto loaded = AudioFileLoader::loadStreaming(path, 96000U);
        if (!loaded.ok()) { setTextError(loaded.error); return false; }
        return installMultisample(makeSingleSampleMultisample(loaded.sample, loaded.sample->name), loaded.sample->name);
    }

    bool loadKmp(const std::string& path) {
        const auto imported = library_.importKmp(path);
        if (!imported.success || imported.multisampleIds.empty()) {
            setTextError(imported.error.empty() ? "KMP library import returned no multisample" : imported.error);
            return false;
        }
        const auto ms = library_.multisample(imported.multisampleIds.front());
        if (ms == nullptr) { setTextError("Imported KMP multisample is missing from library"); return false; }
        return installMultisample(ms, ms->name);
    }

    std::vector<int> importKmpToLibrary(const std::string& path) {
        const auto imported = library_.importKmp(path);
        if (!imported.success) { setTextError(imported.error); return {}; }
        std::vector<int> ids; ids.reserve(imported.multisampleIds.size());
        for (const auto id : imported.multisampleIds) ids.push_back(static_cast<int>(id));
        setTextError({});
        return ids;
    }

    std::vector<int> importKscToLibrary(const std::string& path) {
        const auto imported = library_.importKsc(path);
        if (!imported.success) { setTextError(imported.error); return {}; }
        std::vector<int> ids; ids.reserve(imported.multisampleIds.size());
        for (const auto id : imported.multisampleIds) ids.push_back(static_cast<int>(id));
        setTextError({});
        return ids;
    }

    std::vector<int> multisampleIds() const {
        const auto raw = library_.multisampleIds();
        std::vector<int> ids; ids.reserve(raw.size());
        for (const auto id : raw) ids.push_back(static_cast<int>(id));
        return ids;
    }

    std::vector<std::string> multisampleNames() const { return library_.multisampleNames(); }

    std::vector<std::string> kscNames(const std::string& path) {
        if (!ensureKscCache(path)) return {};
        std::vector<std::string> names;
        names.reserve(kscCache_.multisamples.size());
        for (const auto& ms : kscCache_.multisamples) names.push_back(ms != nullptr ? ms->name : std::string{});
        return names;
    }

    bool loadKscItem(const std::string& path, int index) {
        if (!ensureKscCache(path)) return false;
        if (index < 0 || static_cast<std::size_t>(index) >= kscCache_.multisamples.size()) {
            setTextError("KSC multisample index is out of range");
            return false;
        }
        const auto& ms = kscCache_.multisamples[static_cast<std::size_t>(index)];
        if (ms == nullptr) { setTextError("KSC multisample is empty"); return false; }
        return installMultisample(ms, ms->name);
    }

    bool loadSvBank(const std::string& path) {
        const auto loaded = SvBankRuntime::load(path, 65536U, false);
        if (!loaded.ok()) { setTextError(loaded.error); return false; }
        if (loaded.data.programs.empty() || loaded.data.programs.front().program == nullptr) {
            setTextError("SILVETON bank contains no playable SOUND");
            return false;
        }

        // Preserve user performance objects across a SOUND-bank replacement.
        // SILVETON_SOUND_BY_NAME_V1: a BLEND finds its sounds again by their NAME in the
        // new bank (the 1..500 place is only the first guess), so a bank with re-ordered
        // sounds never makes a BLEND play a different sound. A sound that is not in the
        // new bank is not replaced by another one - its part goes off.
        const auto preserved = library_.snapshot();
        auto merged = loaded.data;
        merged.global = preserved.global;
        merged.combis = preserved.combis;
        merged.lists = preserved.lists;
        library_.replace(merged);

        const auto bankSounds = bankSoundCandidates();
        for (const auto& saved : preserved.combis) {
            Combi rebound = saved.combi;
            for (auto& upper : rebound.uppers) rebindUpper(upper, bankSounds);
            if (!library_.writeCombi(saved.address, rebound)) {
                setTextError("Failed to restore COMBI after SILVETON bank load");
                return false;
            }
        }
        // Do not accept a bank merely because SOUND names are visible. Select
        // a SOUND that resolves all the way to a valid SAMPLE.
        const ProgramSlot* selectedSound = nullptr;
        std::uint8_t selectedKey = 60U;
        std::uint8_t selectedVelocity = 100U;
        for (const auto& slot : loaded.data.programs) {
            if (slot.program == nullptr) continue;
            for (const auto& layer : slot.program->layers) {
                if (!layer.enabled || layer.multisample == nullptr) continue;
                for (const auto& zone : layer.multisample->zones) {
                    if (zone.sample == nullptr || !zone.sample->valid()) continue;
                    const int keyLow = std::max<int>(layer.keyLow, zone.keyLow);
                    const int keyHigh = std::min<int>(layer.keyHigh, zone.keyHigh);
                    const int velLow = std::max<int>(layer.velocityLow, zone.velocityLow);
                    const int velHigh = std::min<int>(layer.velocityHigh, zone.velocityHigh);
                    if (keyLow > keyHigh || velLow > velHigh || velHigh <= 0) continue;
                    selectedSound = &slot;
                    selectedKey = static_cast<std::uint8_t>(std::clamp<int>(zone.rootKey, keyLow, keyHigh));
                    selectedVelocity = static_cast<std::uint8_t>(std::clamp<int>(100, std::max(1, velLow), velHigh));
                    break;
                }
                if (selectedSound != nullptr) break;
            }
            if (selectedSound != nullptr) break;
        }
        if (selectedSound == nullptr || selectedSound->program == nullptr) {
            setTextError("SILVETON bank has SOUND names but no playable SAMPLE path");
            return false;
        }

        // Offline proof with the exact mmap-backed objects. No hardware audio
        // route is opened, stopped or changed by this probe.
        auto probeState = std::make_shared<EngineState>();
        probeState->combi.name = selectedSound->program->name;
        auto& probeUpper = probeState->combi.uppers[0];
        probeUpper.name = selectedSound->program->name;
        probeUpper.enabled = true;
        probeUpper.mute = false;
        probeUpper.solo = false;
        probeUpper.program = selectedSound->program;
        probeUpper.soundSlotId = selectedSound->address.slot;
        probeUpper.midiChannel = 0U;

        SamplerEngine probeEngine;
        probeEngine.prepare(48000.0, 256U);
        probeEngine.setInterpolationQuality(InterpolationQuality::LiveCubic4);
        probeEngine.setState(probeState);
        if (!probeEngine.postNoteOn(0U, selectedKey, selectedVelocity)) {
            setTextError("SILVETON bank playback probe could not queue MIDI note");
            return false;
        }
        std::vector<float> probeAudio(256U * 2U, 0.0F);
        float probePeak = 0.0F;
        for (int blockIndex = 0; blockIndex < 64 && probePeak <= 1.0e-6F; ++blockIndex) {
            probeEngine.render(probeAudio.data(), 256U);
            for (const float value : probeAudio) {
                const float magnitude = value < 0.0F ? -value : value;
                if (magnitude > probePeak) probePeak = magnitude;
            }
        }
        if (!(probePeak > 1.0e-6F)) {
            setTextError("SILVETON bank loaded but SAMPLE playback path is silent");
            return false;
        }

        auto state = std::make_shared<EngineState>();
        if (state_ != nullptr) state->global = state_->global;
        state->combi.name = selectedSound->program->name;
        auto& firstUpper = state->combi.uppers[0];
        firstUpper.name = selectedSound->program->name;
        firstUpper.enabled = true;
        firstUpper.mute = false;
        firstUpper.solo = false;
        firstUpper.program = selectedSound->program;
        firstUpper.soundSlotId = selectedSound->address.slot;
        firstUpper.midiChannel = 0U;
        if (!installState(std::move(state))) return false;
        setTextError({});
        return true;
    }

    bool loadSet(const std::string& path) {
        const auto loaded = SetPackage::load(path);
        if (!loaded.ok()) { setTextError(loaded.error); return false; }
        library_.replace(loaded.data);
        auto state = std::make_shared<EngineState>();
        state->global = loaded.data.global;
        if (!loaded.data.combis.empty()) {
            state->combi = loaded.data.combis.front().combi;
        } else if (!loaded.data.programs.empty() && loaded.data.programs.front().program != nullptr) {
            state->combi.name = loaded.data.programs.front().program->name;
            state->combi.uppers[0].enabled = true;
            state->combi.uppers[0].program = loaded.data.programs.front().program;
            state->combi.uppers[0].midiChannel = 0U;
        } else {
            setTextError("SET contains no playable COMBI or PROGRAM");
            return false;
        }
        return installState(std::move(state));
    }

    bool saveSet(const std::string& path) {
        syncCurrentStateToLibrary();
        const auto saved = SetPackage::save(path, library_.snapshot());
        if (!saved.success) { setTextError(saved.error); return false; }
        setTextError({});
        return true;
    }

    bool saveUserPerformanceState(const std::string& path) {
        syncCurrentStateToLibrary();
        auto data = library_.snapshot();
        data.samples.clear();
        data.multisamples.clear();
        data.programs.clear();
        for (auto& slot : data.combis) {
            for (auto& upper : slot.combi.uppers) { upper.program.reset(); for (auto& l : upper.layers) l.program.reset(); }
        }
        const auto saved = SetPackage::save(path, data);
        if (!saved.success) { setTextError(saved.error); return false; }
        setTextError({});
        return true;
    }

    bool loadUserPerformanceState(const std::string& path) {
        const auto loaded = SetPackage::load(path);
        if (!loaded.ok()) { setTextError(loaded.error); return false; }

        const auto bankSounds = bankSoundCandidates();   // SILVETON_SOUND_BY_NAME_V1
        for (const auto& saved : loaded.data.combis) {
            Combi rebound = saved.combi;
            for (auto& upper : rebound.uppers) {
                if (upper.soundSlotId == kNoSoundSlot) upper.program.reset();
                rebindUpper(upper, bankSounds);
            }
            if (!library_.writeCombi(saved.address, rebound)) {
                setTextError("Could not restore saved BLEND/COMBI");
                return false;
            }
        }
        for (const auto& saved : loaded.data.lists) {
            if (!library_.writeList(saved.address, saved.list)) {
                setTextError("Could not restore saved LIST");
                return false;
            }
        }
        setTextError({});
        return true;
    }

    // SILVETON_SET_SAVE_AS_V1: LOAD of a saved set. The LIST and all BLENDS are
    // replaced by the ones in the file (nothing old is mixed in), and the GLOBAL
    // settings saved with the set come back too. The sound bank is not touched.
    bool replaceUserPerformanceState(const std::string& path) {
        const auto check = SetPackage::load(path);
        if (!check.ok()) { setTextError(check.error); return false; }
        const auto before = library_.snapshot();
        for (const auto& c : before.combis) library_.clearCombi(c.address);
        for (const auto& l : before.lists) library_.clearList(l.address);
        if (!loadUserPerformanceState(path)) return false;
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        next->global = check.data.global;
        library_.setGlobal(next->global);
        if (!installState(std::move(next))) return false;
        setTextError({});
        return true;
    }

    bool saveBank(const std::string& path, int bank) {
        if (bank < 0 || bank > 65535) { setTextError("Bank number is out of range"); return false; }
        syncCurrentStateToLibrary();
        const auto bankData = library_.snapshotBank(static_cast<std::uint16_t>(bank));
        if (bankData.programs.empty() && bankData.combis.empty() && bankData.lists.empty()) {
            setTextError("Selected bank is empty");
            return false;
        }
        const auto saved = SetPackage::save(path, bankData);
        if (!saved.success) { setTextError(saved.error); return false; }
        setTextError({});
        return true;
    }

    bool loadBank(const std::string& path, int targetBank, bool overwrite) {
        if (targetBank < 0 || targetBank > 65535) { setTextError("Target bank is out of range"); return false; }
        const auto loaded = SetPackage::load(path);
        if (!loaded.ok()) { setTextError(loaded.error); return false; }
        const auto merged = library_.mergeBank(loaded.data, static_cast<std::uint16_t>(targetBank), overwrite);
        if (!merged.success) { setTextError(merged.error); return false; }
        setTextError({});
        return true;
    }

    bool writeCurrentProgram(const SlotAddress& address, int upperIndex, const std::string& name) {
        if (upperIndex < 0 || upperIndex >= kUpperCount || state_ == nullptr) {
            setTextError("Invalid Upper index for Write Program");
            return false;
        }
        const auto& source = state_->combi.uppers[static_cast<std::size_t>(upperIndex)].program;
        if (source == nullptr) { setTextError("Selected Upper has no PROGRAM"); return false; }
        auto copy = std::make_shared<Program>(*source);
        copy->name = name.empty() ? source->name : name;
        if (!library_.writeProgram(address, copy)) { setTextError("Write Program failed"); return false; }
        setTextError({});
        return true;
    }

    bool updateProgramBasic(const SlotAddress& address, bool mono, bool legato, float portamentoSec) {
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        return commitProgramEdit(address, source, ProgramEditor::updateBasic(source, mono, legato, portamentoSec));
    }

    bool addProgramLayer(const SlotAddress& address, std::uint32_t multisampleId, const std::string& name) {
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        const auto ms = library_.multisample(multisampleId);
        if (ms == nullptr) { setTextError("MULTISAMPLE id is not available"); return false; }
        return commitProgramEdit(address, source, ProgramEditor::addLayer(source, name, ms));
    }

    bool removeProgramLayer(const SlotAddress& address, int layerIndex) {
        if (layerIndex < 0) { setTextError("PROGRAM layer index is out of range"); return false; }
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        return commitProgramEdit(address, source, ProgramEditor::removeLayer(source, static_cast<std::size_t>(layerIndex)));
    }

    bool moveProgramLayer(const SlotAddress& address, int fromIndex, int toIndex) {
        if (fromIndex < 0 || toIndex < 0) { setTextError("PROGRAM layer index is out of range"); return false; }
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        return commitProgramEdit(address, source, ProgramEditor::moveLayer(source, static_cast<std::size_t>(fromIndex), static_cast<std::size_t>(toIndex)));
    }

    bool assignProgramMultisample(const SlotAddress& address, int layerIndex, std::uint32_t multisampleId) {
        if (layerIndex < 0) { setTextError("PROGRAM layer index is out of range"); return false; }
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        const auto ms = library_.multisample(multisampleId);
        if (ms == nullptr) { setTextError("MULTISAMPLE id is not available"); return false; }
        return commitProgramEdit(address, source, ProgramEditor::assignMultisample(source, static_cast<std::size_t>(layerIndex), ms));
    }

    bool updateProgramLayerBasic(const SlotAddress& address, int layerIndex, bool enabled,
                                 int keyLow, int keyHigh, int velocityLow, int velocityHigh,
                                 int velocityFadeIn, int velocityFadeOut, int transposeSemitones,
                                 float tuneCents, float levelDb, float pan, float delaySec, bool damperEnabled) {
        if (layerIndex < 0) { setTextError("PROGRAM layer index is out of range"); return false; }
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        return commitProgramEdit(address, source, ProgramEditor::updateLayerBasic(
            source, static_cast<std::size_t>(layerIndex), enabled, keyLow, keyHigh, velocityLow, velocityHigh,
            velocityFadeIn, velocityFadeOut, transposeSemitones, tuneCents, levelDb, pan, delaySec, damperEnabled));
    }

    bool updateProgramAmpEnvelope(const SlotAddress& address, int layerIndex,
                                  float attack, float decay, float sustain, float release) {
        if (layerIndex < 0) { setTextError("PROGRAM layer index is out of range"); return false; }
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        return commitProgramEdit(address, source, ProgramEditor::updateLayerAmpEnvelope(
            source, static_cast<std::size_t>(layerIndex), EnvelopeParams{attack, decay, sustain, release}));
    }

    bool updateProgramPitch(const SlotAddress& address, int layerIndex, float amountCents,
                            float attack, float decay, float sustain, float release) {
        if (layerIndex < 0) { setTextError("PROGRAM layer index is out of range"); return false; }
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        return commitProgramEdit(address, source, ProgramEditor::updateLayerPitch(
            source, static_cast<std::size_t>(layerIndex), amountCents, EnvelopeParams{attack, decay, sustain, release}));
    }

    bool updateProgramFilter(const SlotAddress& address, int layerIndex, int mode,
                             float cutoffHz, float resonance, float keyTrack, float velocityAmount,
                             float envelopeAmount, float lfoAmount,
                             float attack, float decay, float sustain, float release) {
        if (layerIndex < 0) { setTextError("PROGRAM layer index is out of range"); return false; }
        if (mode < static_cast<int>(FilterMode::LowPass) || mode > static_cast<int>(FilterMode::Bypass)) {
            setTextError("PROGRAM FILTER mode is invalid"); return false;
        }
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        FilterParams filter{};
        filter.mode = static_cast<FilterMode>(mode);
        filter.cutoffHz = cutoffHz;
        filter.resonance = resonance;
        filter.keyTrack = keyTrack;
        filter.velocityAmount = velocityAmount;
        filter.envelopeAmount = envelopeAmount;
        filter.lfoAmount = lfoAmount;
        return commitProgramEdit(address, source, ProgramEditor::updateLayerFilter(
            source, static_cast<std::size_t>(layerIndex), filter, EnvelopeParams{attack, decay, sustain, release}));
    }

    bool updateProgramLfo(const SlotAddress& address, int layerIndex, int lfoIndex, int wave,
                          float frequencyHz, float delaySec, float fadeSec, bool keySync,
                          float pitchCents, float filterOctaves, float ampDepth) {
        if (layerIndex < 0) { setTextError("PROGRAM layer index is out of range"); return false; }
        if (wave < static_cast<int>(LfoWave::Sine) || wave > static_cast<int>(LfoWave::RandomHold)) {
            setTextError("PROGRAM LFO waveform is invalid"); return false;
        }
        const auto source = library_.program(address);
        if (source == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        LfoParams lfo{};
        lfo.wave = static_cast<LfoWave>(wave);
        lfo.frequencyHz = frequencyHz;
        lfo.delaySec = delaySec;
        lfo.fadeSec = fadeSec;
        lfo.keySync = keySync;
        lfo.pitchCents = pitchCents;
        lfo.filterOctaves = filterOctaves;
        lfo.ampDepth = ampDepth;
        return commitProgramEdit(address, source, ProgramEditor::updateLayerLfo(
            source, static_cast<std::size_t>(layerIndex), lfoIndex, lfo));
    }

    bool writeCurrentSample(std::uint32_t id, int upperIndex, int layerIndex, int zoneIndex, const std::string& name) {
        if (upperIndex < 0 || upperIndex >= kUpperCount || state_ == nullptr) {
            setTextError("Invalid Upper index for Write Sample"); return false;
        }
        const auto& program = state_->combi.uppers[static_cast<std::size_t>(upperIndex)].program;
        if (program == nullptr || layerIndex < 0 || static_cast<std::size_t>(layerIndex) >= program->layers.size()) {
            setTextError("Selected PROGRAM layer is invalid"); return false;
        }
        const auto& ms = program->layers[static_cast<std::size_t>(layerIndex)].multisample;
        if (ms == nullptr || zoneIndex < 0 || static_cast<std::size_t>(zoneIndex) >= ms->zones.size() || ms->zones[static_cast<std::size_t>(zoneIndex)].sample == nullptr) {
            setTextError("Selected MULTISAMPLE zone has no SAMPLE"); return false;
        }
        const auto source = ms->zones[static_cast<std::size_t>(zoneIndex)].sample;
        auto edited = SampleEditor::updateMetadata(*source, name.empty() ? source->name : name, source->rootKey, source->fineTuneCents);
        if (!edited.ok() || !library_.writeSample(id, edited.sample)) { setTextError(edited.error.empty() ? "Write Sample failed" : edited.error); return false; }
        setTextError({}); return true;
    }

    bool updateSampleMetadata(std::uint32_t id, const std::string& name, int rootKey, float fineTuneCents) {
        const auto source = library_.sample(id); if (source == nullptr) { setTextError("SAMPLE id is not available"); return false; }
        return commitSampleEdit(id, source, SampleEditor::updateMetadata(*source, name, static_cast<std::uint8_t>(std::clamp(rootKey,0,127)), fineTuneCents));
    }
    bool trimSample(std::uint32_t id, std::uint64_t startFrame, std::uint64_t endFrame) {
        const auto source = library_.sample(id); if (source == nullptr) { setTextError("SAMPLE id is not available"); return false; }
        return commitSampleEdit(id, source, SampleEditor::trim(*source, startFrame, endFrame));
    }
    bool normalizeSample(std::uint32_t id, float targetPeakDb) {
        const auto source = library_.sample(id); if (source == nullptr) { setTextError("SAMPLE id is not available"); return false; }
        return commitSampleEdit(id, source, SampleEditor::normalize(*source, targetPeakDb));
    }
    bool reverseSample(std::uint32_t id) {
        const auto source = library_.sample(id); if (source == nullptr) { setTextError("SAMPLE id is not available"); return false; }
        return commitSampleEdit(id, source, SampleEditor::reverse(*source));
    }
    bool fadeSample(std::uint32_t id, std::uint64_t fadeInFrames, std::uint64_t fadeOutFrames) {
        const auto source = library_.sample(id); if (source == nullptr) { setTextError("SAMPLE id is not available"); return false; }
        return commitSampleEdit(id, source, SampleEditor::fade(*source, fadeInFrames, fadeOutFrames));
    }
    bool setSampleLoop(std::uint32_t id, std::uint64_t startFrame, std::uint64_t endFrame, std::uint32_t crossfadeFrames) {
        const auto source = library_.sample(id); if (source == nullptr) { setTextError("SAMPLE id is not available"); return false; }
        return commitSampleEdit(id, source, SampleEditor::setLoop(*source, startFrame, endFrame, crossfadeFrames));
    }
    bool clearSampleLoop(std::uint32_t id) {
        const auto source = library_.sample(id); if (source == nullptr) { setTextError("SAMPLE id is not available"); return false; }
        return commitSampleEdit(id, source, SampleEditor::clearLoop(*source));
    }
    std::int64_t sampleNearestZeroCrossing(std::uint32_t id, std::uint64_t aroundFrame, std::uint64_t radius) {
        const auto source = library_.sample(id); if (source == nullptr) { setTextError("SAMPLE id is not available"); return -1; }
        setTextError({}); return static_cast<std::int64_t>(SampleEditor::nearestZeroCrossing(*source, aroundFrame, radius));
    }

    bool renameMultisample(std::uint32_t id, const std::string& name) {
        const auto source = library_.multisample(id); if (source == nullptr) { setTextError("MULTISAMPLE id is not available"); return false; }
        return commitMultisampleEdit(id, source, MultisampleEditor::rename(source, name));
    }
    bool addMultisampleZone(std::uint32_t id, std::uint32_t sampleId, int insertIndex,
                            int keyLow, int keyHigh, int velocityLow, int velocityHigh, int rootKey,
                            int transpose, float tuneCents, float gainDb, float pan,
                            bool oneShot, bool reverse, bool nonTranspose) {
        const auto source = library_.multisample(id); if (source == nullptr) { setTextError("MULTISAMPLE id is not available"); return false; }
        const auto sample = library_.sample(sampleId); if (sample == nullptr) { setTextError("SAMPLE id is not available"); return false; }
        SampleZone z{}; z.sample=sample; z.keyLow=static_cast<std::uint8_t>(std::clamp(keyLow,0,127)); z.keyHigh=static_cast<std::uint8_t>(std::clamp(keyHigh,0,127));
        z.velocityLow=static_cast<std::uint8_t>(std::clamp(velocityLow,1,127)); z.velocityHigh=static_cast<std::uint8_t>(std::clamp(velocityHigh,1,127)); z.rootKey=static_cast<std::uint8_t>(std::clamp(rootKey,0,127));
        z.transposeSemitones=static_cast<std::int8_t>(std::clamp(transpose,-64,63)); z.tuneCents=tuneCents; z.gainDb=gainDb; z.pan=pan; z.oneShot=oneShot; z.reverse=reverse; z.nonTranspose=nonTranspose;
        const auto result = insertIndex < 0 ? MultisampleEditor::addZone(source,z) : MultisampleEditor::insertZone(source,static_cast<std::size_t>(insertIndex),z);
        return commitMultisampleEdit(id, source, result);
    }
    bool updateMultisampleZone(std::uint32_t id, int zoneIndex, std::uint32_t sampleId,
                               int keyLow, int keyHigh, int velocityLow, int velocityHigh, int rootKey,
                               int transpose, float tuneCents, float gainDb, float pan,
                               bool oneShot, bool reverse, bool nonTranspose) {
        if (zoneIndex < 0) { setTextError("Zone index is out of range"); return false; }
        const auto source = library_.multisample(id); if (source == nullptr) { setTextError("MULTISAMPLE id is not available"); return false; }
        const auto sample = library_.sample(sampleId); if (sample == nullptr) { setTextError("SAMPLE id is not available"); return false; }
        SampleZone z{}; z.sample=sample; z.keyLow=static_cast<std::uint8_t>(std::clamp(keyLow,0,127)); z.keyHigh=static_cast<std::uint8_t>(std::clamp(keyHigh,0,127));
        z.velocityLow=static_cast<std::uint8_t>(std::clamp(velocityLow,1,127)); z.velocityHigh=static_cast<std::uint8_t>(std::clamp(velocityHigh,1,127)); z.rootKey=static_cast<std::uint8_t>(std::clamp(rootKey,0,127));
        z.transposeSemitones=static_cast<std::int8_t>(std::clamp(transpose,-64,63)); z.tuneCents=tuneCents; z.gainDb=gainDb; z.pan=pan; z.oneShot=oneShot; z.reverse=reverse; z.nonTranspose=nonTranspose;
        return commitMultisampleEdit(id, source, MultisampleEditor::updateZone(source,static_cast<std::size_t>(zoneIndex),z));
    }
    bool removeMultisampleZone(std::uint32_t id, int zoneIndex) {
        if (zoneIndex < 0) { setTextError("Zone index is out of range"); return false; }
        const auto source=library_.multisample(id); if(source==nullptr){setTextError("MULTISAMPLE id is not available");return false;}
        return commitMultisampleEdit(id,source,MultisampleEditor::removeZone(source,static_cast<std::size_t>(zoneIndex)));
    }
    bool moveMultisampleZone(std::uint32_t id, int fromIndex, int toIndex) {
        if(fromIndex<0||toIndex<0){setTextError("Zone index is out of range");return false;}
        const auto source=library_.multisample(id); if(source==nullptr){setTextError("MULTISAMPLE id is not available");return false;}
        return commitMultisampleEdit(id,source,MultisampleEditor::moveZone(source,static_cast<std::size_t>(fromIndex),static_cast<std::size_t>(toIndex)));
    }

    bool writeCurrentMultisample(std::uint32_t id, int upperIndex, int layerIndex, const std::string& name) {
        if (upperIndex < 0 || upperIndex >= kUpperCount || state_ == nullptr) {
            setTextError("Invalid Upper index for Write Multisample");
            return false;
        }
        const auto& program = state_->combi.uppers[static_cast<std::size_t>(upperIndex)].program;
        if (program == nullptr || layerIndex < 0 || static_cast<std::size_t>(layerIndex) >= program->layers.size()) {
            setTextError("Selected PROGRAM layer has no MULTISAMPLE");
            return false;
        }
        const auto& source = program->layers[static_cast<std::size_t>(layerIndex)].multisample;
        if (source == nullptr) { setTextError("Selected PROGRAM layer has no MULTISAMPLE"); return false; }
        auto copy = std::make_shared<Multisample>(*source);
        if (!name.empty()) copy->name = name;
        if (!library_.writeMultisample(id, copy)) { setTextError("Write Multisample failed"); return false; }
        setTextError({});
        return true;
    }

    bool writeCurrentCombi(const SlotAddress& address, const std::string& name) {
        if (state_ == nullptr) { setTextError("No active COMBI"); return false; }
        Combi copy = state_->combi;
        if (!name.empty()) copy.name = name;
        if (!library_.writeCombi(address, copy)) { setTextError("Write Combi failed"); return false; }
        setTextError({});
        return true;
    }

    bool updateUpperMain(int upperIndex, bool enabled, bool solo, bool mute,
                         float levelDb, float pan, int keyLow, int keyHigh, int voiceMode) {
        if (upperIndex < 0 || upperIndex >= kUpperCount) { setTextError("Invalid Upper index"); return false; }
        if (keyLow < 0 || keyLow > 127 || keyHigh < 0 || keyHigh > 127 || keyLow > keyHigh) { setTextError("Invalid Upper key range"); return false; }
        if (voiceMode < static_cast<int>(UpperVoiceMode::Poly) || voiceMode > static_cast<int>(UpperVoiceMode::Legato)) { setTextError("Invalid Upper voice mode"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& u = next->combi.uppers[static_cast<std::size_t>(upperIndex)];
        u.enabled = enabled;
        u.solo = solo;
        u.mute = mute;
        u.levelDb = std::clamp(levelDb, -60.0F, 18.0F);
        u.pan = std::clamp(pan, -1.0F, 1.0F);
        u.keyLow = static_cast<std::uint8_t>(keyLow);
        u.keyHigh = static_cast<std::uint8_t>(keyHigh);
        u.voiceMode = static_cast<UpperVoiceMode>(voiceMode);
        return installState(std::move(next));
    }

    bool updateUpperTune(int upperIndex, int octave, int transpose, float fineCents,
                         int pitchBendRange, float portamentoSec) {
        if (upperIndex < 0 || upperIndex >= kUpperCount) { setTextError("Invalid Upper index"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& u = next->combi.uppers[static_cast<std::size_t>(upperIndex)];
        u.octave = static_cast<std::int8_t>(std::clamp(octave, -4, 4));
        // SILVETON_TUNE_RANGES_V1: TRANSPOSE -12..+12, FINE TUNE -1200..+1200 cents.
        u.transposeSemitones = static_cast<std::int8_t>(std::clamp(transpose, -12, 12));
        u.tuneCents = std::clamp(fineCents, -1200.0F, 1200.0F);
        u.pitchBendRange = static_cast<std::int8_t>(std::clamp(pitchBendRange, 0, 24));
        u.portamentoSec = std::clamp(portamentoSec, 0.0F, 0.1F); // TIME 1..100 ms like the SILVETON keyboard processor
        return installState(std::move(next));
    }

    bool updateUpperRange(int upperIndex, int velocityLow, int velocityHigh) {
        if (upperIndex < 0 || upperIndex >= kUpperCount) { setTextError("Invalid Upper index"); return false; }
        if (velocityLow < 1 || velocityLow > 127 || velocityHigh < 1 || velocityHigh > 127 || velocityLow > velocityHigh) { setTextError("Invalid Upper velocity range"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& u = next->combi.uppers[static_cast<std::size_t>(upperIndex)];
        u.velocityLow = static_cast<std::uint8_t>(velocityLow);
        u.velocityHigh = static_cast<std::uint8_t>(velocityHigh);
        return installState(std::move(next));
    }

    bool updateUpperControl(int upperIndex, bool breath, bool expression, bool aftertouch,
                            bool damper, int midiChannel) {
        if (upperIndex < 0 || upperIndex >= kUpperCount) { setTextError("Invalid Upper index"); return false; }
        if (midiChannel < 0 || midiChannel > 15) { setTextError("Invalid Upper MIDI channel"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& u = next->combi.uppers[static_cast<std::size_t>(upperIndex)];
        u.breathEnabled = breath;
        u.expressionEnabled = expression;
        u.aftertouchEnabled = aftertouch;
        u.damperEnabled = damper;
        u.midiChannel = static_cast<std::uint8_t>(midiChannel);
        return installState(std::move(next));
    }

    bool updateUpperTone(int upperIndex, float ampAttackScale, float ampDecayScale,
                         float ampSustainScale, float ampReleaseScale,
                         float filterCutoffOctaves, float filterResonanceOffset,
                         float lfoRateScale, float lfoDepthScale,
                         float eqLowDb, float eqMidDb, float eqHighDb) {
        if (upperIndex < 0 || upperIndex >= kUpperCount) { setTextError("Invalid Upper index"); return false; }
        const float values[] = {ampAttackScale, ampDecayScale, ampSustainScale, ampReleaseScale,
                                filterCutoffOctaves, filterResonanceOffset, lfoRateScale, lfoDepthScale,
                                eqLowDb, eqMidDb, eqHighDb};
        for (float v : values) if (!std::isfinite(v)) { setTextError("Upper TONE contains non-finite value"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& u = next->combi.uppers[static_cast<std::size_t>(upperIndex)];
        u.ampAttackScale = std::clamp(ampAttackScale, 0.0F, 16.0F);
        u.ampDecayScale = std::clamp(ampDecayScale, 0.0F, 16.0F);
        u.ampSustainScale = std::clamp(ampSustainScale, 0.0F, 2.0F);
        u.ampReleaseScale = std::clamp(ampReleaseScale, 0.0F, 16.0F);
        u.filterCutoffOctaves = std::clamp(filterCutoffOctaves, -10.0F, 10.0F);
        u.filterResonanceOffset = std::clamp(filterResonanceOffset, -1.0F, 1.0F);
        u.lfoRateScale = std::clamp(lfoRateScale, 0.0F, 16.0F);
        u.lfoDepthScale = std::clamp(lfoDepthScale, 0.0F, 8.0F);
        u.eqLowDb = std::clamp(eqLowDb, -18.0F, 18.0F);
        u.eqMidDb = std::clamp(eqMidDb, -18.0F, 18.0F);
        u.eqHighDb = std::clamp(eqHighDb, -18.0F, 18.0F);
        // SILVETON_EQ5_V1: LOW / MID / HIGH are bands 1 / 3 / 5 of the common EQ
        u.eq.band[0].gainDb = u.eqLowDb; u.eq.band[2].gainDb = u.eqMidDb; u.eq.band[4].gainDb = u.eqHighDb;
        return installState(std::move(next));
    }

    // TONE page: 0 attack ms, 1 decay ms, 2 sustain 0..1, 3 release ms, 4 cutoff Hz, 5 resonance 0..1.
    // A negative value clears the setting (the PROGRAM default is used again).
    bool setUpperToneParam(int upperIndex, int param, float value) {
        if (upperIndex < 0 || upperIndex >= kUpperCount || param < 0 || param > 5) { setTextError("Invalid TONE parameter"); return false; }
        if (!std::isfinite(value)) { setTextError("TONE value is not finite"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& u = next->combi.uppers[static_cast<std::size_t>(upperIndex)];
        const float v = value < 0.0F ? -1.0F : value;
        switch (param) {
            case 0: u.toneAttackMs = v < 0.0F ? v : std::min(v, kToneMaxTimeMs); break;
            case 1: u.toneDecayMs = v < 0.0F ? v : std::min(v, kToneMaxTimeMs); break;
            case 2: u.toneSustain = v < 0.0F ? v : std::min(v, 1.0F); break;
            case 3: u.toneReleaseMs = v < 0.0F ? v : std::min(v, kToneMaxTimeMs); break;
            case 4: u.toneCutoffHz = v < 0.0F ? v : std::clamp(v, 20.0F, kToneCutoffOpenHz); break;
            default: u.toneResonance = v < 0.0F ? v : std::min(v, 1.0F); break;
        }
        return installState(std::move(next));
    }


    // ---------------------------------------------------------------- SILVETON_PARAMS_V1
    // Generic access to the new Upper settings (one id, one value), so every
    // page talks to the engine the same way. Ids of setUpperParam / upperParams:
    //   0..14  TONE of the basic sound: startMs, endMs, filterEnvOct, filterEnvMs, velToLevel, velToCutoff,
    //          highPassHz, lfoRateHz, lfoDepthCents, lfoDelayMs, lfoFadeMs, lfoModWheel, eqLow, eqMid, eqHigh
    //   15     EQ on; 16..35 bands 1..5 x (on, freq, gain, q); 36 hpOn 37 hpHz 38 hpSlope 39 lpOn 40 lpHz 41 lpSlope
    //   42 portaMode (0 SILVETON 1 KRONOS) 43 fingered 44 rateMode 45 portaTime 0..127
    //   46 fxSend3 47 fxSend4 48 pitchBendRange
    static constexpr int kUpperParamCount = 49;

    static void applyToneExtra(ToneExtra& x, int id, float v) {
        switch (id) {
            case 0: x.startMs = std::clamp(v, 0.0F, kToneMaxStartMs); break;
            case 1: x.endMs = std::clamp(v, 0.0F, 600000.0F); break;
            case 2: x.filterEnvOctaves = std::clamp(v, -8.0F, 8.0F); break;
            case 3: x.filterEnvMs = std::clamp(v, 1.0F, 20000.0F); break;
            case 4: x.velToLevel = std::clamp(v, 0.0F, 1.0F); break;
            case 5: x.velToCutoff = std::clamp(v, 0.0F, 8.0F); break;
            case 6: x.highPassHz = std::clamp(v, 0.0F, 4000.0F); break;
            case 7: x.lfoRateHz = std::clamp(v, 0.1F, 20.0F); break;
            case 8: x.lfoDepthCents = std::clamp(v, 0.0F, 1200.0F); break;
            case 9: x.lfoDelayMs = std::clamp(v, 0.0F, 10000.0F); break;
            case 10: x.lfoFadeMs = std::clamp(v, 0.0F, 10000.0F); break;
            case 11: x.lfoModWheel = v >= 0.5F; break;
            case 12: x.eqLowDb = std::clamp(v, -18.0F, 18.0F); break;
            case 13: x.eqMidDb = std::clamp(v, -18.0F, 18.0F); break;
            case 14: x.eqHighDb = std::clamp(v, -18.0F, 18.0F); break;
            default: break;
        }
    }
    static void readToneExtra(const ToneExtra& x, std::vector<float>& out) {
        out.insert(out.end(), {x.startMs, x.endMs, x.filterEnvOctaves, x.filterEnvMs, x.velToLevel, x.velToCutoff, x.highPassHz,
                               x.lfoRateHz, x.lfoDepthCents, x.lfoDelayMs, x.lfoFadeMs, x.lfoModWheel ? 1.0F : 0.0F, x.eqLowDb, x.eqMidDb, x.eqHighDb});
    }

    bool setUpperParam(int upperIndex, int id, float v) {
        if (upperIndex < 0 || upperIndex >= kUpperCount || id < 0 || id >= kUpperParamCount || !std::isfinite(v)) { setTextError("Invalid Upper parameter"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& u = next->combi.uppers[static_cast<std::size_t>(upperIndex)];
        if (id <= 14) applyToneExtra(u.toneExtra, id, v);
        else if (id == 15) u.eq.on = v >= 0.5F;
        else if (id <= 35) {
            auto& b = u.eq.band[static_cast<std::size_t>((id - 16) / 4)];
            switch ((id - 16) % 4) {
                case 0: b.on = v >= 0.5F; break;
                case 1: b.freqHz = std::clamp(v, 20.0F, 20000.0F); break;
                case 2: b.gainDb = std::clamp(v, -18.0F, 18.0F); break;
                default: b.q = std::clamp(v, 0.1F, 10.0F); break;
            }
            u.eqLowDb = u.eq.band[0].gainDb; u.eqMidDb = u.eq.band[2].gainDb; u.eqHighDb = u.eq.band[4].gainDb;
        }
        else if (id == 36) u.eq.hpOn = v >= 0.5F;
        else if (id == 37) u.eq.hpHz = std::clamp(v, 10.0F, 2000.0F);
        else if (id == 38) u.eq.hpSlopeDb = v >= 18.0F ? 24U : 12U;
        else if (id == 39) u.eq.lpOn = v >= 0.5F;
        else if (id == 40) u.eq.lpHz = std::clamp(v, 1000.0F, 20000.0F);
        else if (id == 41) u.eq.lpSlopeDb = v >= 18.0F ? 24U : 12U;
        else if (id == 42) u.portaMode = v >= 0.5F ? PortamentoMode::Kronos : PortamentoMode::Silveton;
        else if (id == 43) u.portaFingered = v >= 0.5F;
        else if (id == 44) u.portaRateMode = v >= 0.5F;
        else if (id == 45) u.portaTime = static_cast<std::uint8_t>(std::clamp(static_cast<int>(std::lround(v)), 0, 127));
        else if (id == 46) u.fxSend3 = std::clamp(v, 0.0F, 1.0F);
        else if (id == 47) u.fxSend4 = std::clamp(v, 0.0F, 1.0F);
        else if (id == 48) u.pitchBendRange = static_cast<std::int8_t>(std::clamp(static_cast<int>(std::lround(v)), 0, 24));
        return installState(std::move(next));
    }

    std::vector<float> upperParams(int upperIndex) const {
        std::vector<float> out;
        if (upperIndex < 0 || upperIndex >= kUpperCount || state_ == nullptr) return out;
        const auto& u = state_->combi.uppers[static_cast<std::size_t>(upperIndex)];
        readToneExtra(u.toneExtra, out);
        out.push_back(u.eq.on ? 1.0F : 0.0F);
        for (const auto& b : u.eq.band) out.insert(out.end(), {b.on ? 1.0F : 0.0F, b.freqHz, b.gainDb, b.q});
        out.insert(out.end(), {u.eq.hpOn ? 1.0F : 0.0F, u.eq.hpHz, static_cast<float>(u.eq.hpSlopeDb), u.eq.lpOn ? 1.0F : 0.0F, u.eq.lpHz, static_cast<float>(u.eq.lpSlopeDb)});
        out.insert(out.end(), {u.portaMode == PortamentoMode::Kronos ? 1.0F : 0.0F, u.portaFingered ? 1.0F : 0.0F, u.portaRateMode ? 1.0F : 0.0F, static_cast<float>(u.portaTime)});
        out.insert(out.end(), {u.fxSend3, u.fxSend4, static_cast<float>(u.pitchBendRange)});
        return out;
    }

    // SILVETON_LAYERS_V1. Ids of setLayerParam / layerParams (layer 0..3):
    //   0 enabled 1 levelDb 2 pan 3 transpose 4 octave 5 tuneCents 6 keyLow 7 keyHigh 8 velLow 9 velHigh
    //   10..15 TONE attackMs decayMs sustain releaseMs cutoffHz resonance (-1 = PROGRAM default)
    //   16..30 TONE extra (same order as the Upper ids 0..14)
    //   layerParams adds 31 = soundSlotId
    static constexpr int kLayerParamCount = 31;

    bool setLayerParam(int upperIndex, int layer, int id, float v) {
        if (upperIndex < 0 || upperIndex >= kUpperCount || layer < 0 || layer >= kUpperLayers || id < 0 || id >= kLayerParamCount || !std::isfinite(v)) { setTextError("Invalid layer parameter"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& l = next->combi.uppers[static_cast<std::size_t>(upperIndex)].layers[static_cast<std::size_t>(layer)];
        const auto i8 = [](float x, int lo, int hi) { return static_cast<std::int8_t>(std::clamp(static_cast<int>(std::lround(x)), lo, hi)); };
        const auto u8 = [](float x, int lo, int hi) { return static_cast<std::uint8_t>(std::clamp(static_cast<int>(std::lround(x)), lo, hi)); };
        const auto tone = [](float x, float hi) { return x < 0.0F ? -1.0F : std::min(x, hi); };
        switch (id) {
            case 0: l.enabled = v >= 0.5F; break;
            case 1: l.levelDb = std::clamp(v, -60.0F, 12.0F); break;
            case 2: l.pan = std::clamp(v, -1.0F, 1.0F); break;
            case 3: l.transposeSemitones = i8(v, -12, 12); break;
            case 4: l.octave = i8(v, -3, 3); break;
            case 5: l.tuneCents = std::clamp(v, -1200.0F, 1200.0F); break;
            case 6: l.keyLow = u8(v, 0, 127); break;
            case 7: l.keyHigh = u8(v, 0, 127); break;
            case 8: l.velocityLow = u8(v, 1, 127); break;
            case 9: l.velocityHigh = u8(v, 1, 127); break;
            case 10: l.tone.attackMs = tone(v, kToneMaxTimeMs); break;
            case 11: l.tone.decayMs = tone(v, kToneMaxTimeMs); break;
            case 12: l.tone.sustain = tone(v, 1.0F); break;
            case 13: l.tone.releaseMs = tone(v, kToneMaxTimeMs); break;
            case 14: l.tone.cutoffHz = v < 0.0F ? -1.0F : std::clamp(v, 20.0F, kToneCutoffOpenHz); break;
            case 15: l.tone.resonance = tone(v, 1.0F); break;
            default: applyToneExtra(l.tone.x, id - 16, v); break;
        }
        return installState(std::move(next));
    }

    // The SOUND of a layer: 1..500 = bank SOUND, 0 = none (the layer is turned off).
    bool setLayerSound(int upperIndex, int layer, int slot) {
        if (upperIndex < 0 || upperIndex >= kUpperCount || layer < 0 || layer >= kUpperLayers) { setTextError("Invalid layer"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& l = next->combi.uppers[static_cast<std::size_t>(upperIndex)].layers[static_cast<std::size_t>(layer)];
        if (slot <= 0 || slot > 65535 || !((slot <= static_cast<int>(kFixedSoundSlotCount)) || isBuiltinSlot(static_cast<std::uint16_t>(slot)))) { l.program.reset(); l.soundSlotId = kNoSoundSlot; l.enabled = false; l.name.clear(); return installState(std::move(next)); }
        auto program = programForSlot(static_cast<std::uint16_t>(slot));
        if (program == nullptr) { setTextError("SOUND slot is empty"); return false; }
        l.program = program; l.soundSlotId = static_cast<std::uint16_t>(slot); l.name = program->name; l.enabled = true;
        return installState(std::move(next));
    }

    std::vector<float> layerParams(int upperIndex, int layer) const {
        std::vector<float> out;
        if (upperIndex < 0 || upperIndex >= kUpperCount || layer < 0 || layer >= kUpperLayers || state_ == nullptr) return out;
        const auto& l = state_->combi.uppers[static_cast<std::size_t>(upperIndex)].layers[static_cast<std::size_t>(layer)];
        out.insert(out.end(), {l.enabled ? 1.0F : 0.0F, l.levelDb, l.pan, static_cast<float>(l.transposeSemitones), static_cast<float>(l.octave), l.tuneCents,
                               static_cast<float>(l.keyLow), static_cast<float>(l.keyHigh), static_cast<float>(l.velocityLow), static_cast<float>(l.velocityHigh),
                               l.tone.attackMs, l.tone.decayMs, l.tone.sustain, l.tone.releaseMs, l.tone.cutoffHz, l.tone.resonance});
        readToneExtra(l.tone.x, out);
        out.push_back(static_cast<float>(l.soundSlotId));
        return out;
    }

    std::string layerName(int upperIndex, int layer) const {
        if (upperIndex < 0 || upperIndex >= kUpperCount || layer < 0 || layer >= kUpperLayers || state_ == nullptr) return {};
        return state_->combi.uppers[static_cast<std::size_t>(upperIndex)].layers[static_cast<std::size_t>(layer)].name;
    }

    // SILVETON_FX_V3: unit 0..3 = send slot, 4..10 = INSERT of Upper 1..7. Ids:
    //   0 type 1 wet 2 timeMs 3 feedback 4 rateHz 5 depth 6 tone 7 preDelayMs 8 damping 9 size 10 mod
    //   11 tempoSync 12 tempoBpm 13 division 14 param1 15 param2 16 param3
    static constexpr int kFxParamCount = 17;
    static EffectSlot* fxUnitOf(Combi& c, int unit) {
        if (unit >= 0 && unit < kFxSendSlots) return &c.fx[static_cast<std::size_t>(unit)];
        if (unit >= kFxSendSlots && unit < kFxSendSlots + kUpperCount) return &c.insert[static_cast<std::size_t>(unit - kFxSendSlots)];
        return nullptr;
    }
    bool setFxParam(int unit, int id, float v) {
        if (id < 0 || id >= kFxParamCount || !std::isfinite(v)) { setTextError("Invalid FX parameter"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        EffectSlot* f = fxUnitOf(next->combi, unit);
        if (f == nullptr) { setTextError("Invalid FX unit"); return false; }
        switch (id) {
            case 0: { const int t = static_cast<int>(std::lround(v)); f->type = (t >= 0 && t < kEffectTypeCount) ? static_cast<EffectType>(t) : EffectType::Off; break; }
            case 1: f->wet = std::clamp(v, 0.0F, 1.0F); break;
            case 2: f->timeMs = std::clamp(v, 0.1F, 2500.0F); break;
            case 3: f->feedback = std::clamp(v, -0.95F, 0.95F); break;
            case 4: f->rateHz = std::clamp(v, 0.02F, 12.0F); break;
            case 5: f->depth = std::clamp(v, 0.0F, 1.0F); break;
            case 6: f->tone = std::clamp(v, 0.0F, 24.0F); break;
            case 7: f->preDelayMs = std::clamp(v, 0.0F, 200.0F); break;
            case 8: f->damping = std::clamp(v, 0.0F, 1.0F); break;
            case 9: f->size = std::clamp(v, 0.0F, 1.0F); break;
            case 10: f->mod = std::clamp(v, 0.0F, 1.0F); break;
            case 11: f->tempoSync = v >= 0.5F; break;
            case 12: f->tempoBpm = std::clamp(v, 30.0F, 300.0F); break;
            case 13: f->division = std::clamp(v, 1.0F / 64.0F, 1.0F); break;
            case 14: f->param1 = std::clamp(v, -60.0F, 60.0F); break;
            case 15: f->param2 = std::clamp(v, -60.0F, 60.0F); break;
            default: f->param3 = std::clamp(v, -60.0F, 10000.0F); break;
        }
        return installState(std::move(next));
    }
    std::vector<float> fxParams(int unit) const {
        std::vector<float> out;
        if (state_ == nullptr) return out;
        Combi c = state_->combi;   // a copy only for the lookup helper
        const EffectSlot* f = fxUnitOf(c, unit);
        if (f == nullptr) return out;
        out = {static_cast<float>(f->type), f->wet, f->timeMs, f->feedback, f->rateHz, f->depth, f->tone, f->preDelayMs, f->damping, f->size, f->mod,
               f->tempoSync ? 1.0F : 0.0F, f->tempoBpm, f->division, f->param1, f->param2, f->param3};
        return out;
    }

    // SILVETON_ANALYZER_V1
    std::vector<float> analyzerFrame(int upper, bool afterEq) {
        if (upper < 0 || upper >= kUpperCount) { engine_.setAnalyzerTap(-1, true); return {}; }
        engine_.setAnalyzerTap(upper, afterEq);
        std::vector<float> out(8192U);
        engine_.readAnalyzer(out.data(), out.size());
        return out;
    }


    // ---------------------------------------------------------------- SILVETON_POLYSIX_V1
    // Synth functions of one sound (sound 0 = basic, 1..4 = layer). Ids:
    //   0 pwmWidth 1 pwmDepth 2 pwmRateHz 3 pwmMix 4 subLevel 5 subOctave 6 unisonVoices 7 unisonDetuneCents
    //   8 unisonSpread 9 drive 10 filterType 11 filterKeyTrack 12 filter2Type 13 filter2Hz 14 filter2Res
    //   15 filter2Parallel 16 analogFeel 17 synthBypass (SILVETON_SYNTH_BYPASS_V1: 1 = SYNTH ИЗКЛ); 20 + route*4 + (0 source, 1 target, 2 amount, 3 bipolar), route 0..7
    static constexpr int kSynthParamCount = 52;
    static void applySynth(ToneExtra& x, ModMatrix& m, int id, float v) {
        const auto i8 = [](float f, int lo, int hi) { return static_cast<std::int8_t>(std::clamp(static_cast<int>(std::lround(f)), lo, hi)); };
        if (id >= 20) {
            const int r = (id - 20) / 4, k = (id - 20) % 4;
            if (r < 0 || r >= kModRoutes) return;
            auto& route = m.route[static_cast<std::size_t>(r)];
            switch (k) {
                case 0: route.source = static_cast<ModSource>(std::clamp(static_cast<int>(std::lround(v)), 0, kModSourceCount - 1)); break;
                case 1: route.target = static_cast<ModTarget>(std::clamp(static_cast<int>(std::lround(v)), 0, kModTargetCount - 1)); break;
                case 2: route.amount = std::clamp(v, -1.0F, 1.0F); break;
                default: route.bipolar = v >= 0.5F; break;
            }
            return;
        }
        switch (id) {
            case 0: x.pwmWidth = v < 0.02F ? 0.0F : std::clamp(v, 0.02F, 0.98F); break;
            case 1: x.pwmDepth = std::clamp(v, 0.0F, 0.45F); break;
            case 2: x.pwmRateHz = std::clamp(v, 0.02F, 20.0F); break;
            case 3: x.pwmMix = std::clamp(v, 0.0F, 1.0F); break;
            case 4: x.subLevel = std::clamp(v, 0.0F, 1.0F); break;
            case 5: x.subOctave = i8(v, 1, 2); break;
            case 6: x.unisonVoices = i8(v, 1, 4); break;
            case 7: x.unisonDetuneCents = std::clamp(v, 0.0F, 100.0F); break;
            case 8: x.unisonSpread = std::clamp(v, 0.0F, 1.0F); break;
            case 9: x.drive = std::clamp(v, 0.0F, 1.0F); break;
            case 10: x.filterType = i8(v, 0, 2); break;
            case 11: x.filterKeyTrack = std::clamp(v, -1.0F, 1.0F); break;
            case 12: x.filter2Type = i8(v, 0, 4); break;
            case 13: x.filter2Hz = std::clamp(v, 20.0F, 20000.0F); break;
            case 14: x.filter2Res = std::clamp(v, 0.0F, 1.0F); break;
            case 15: x.filter2Parallel = v >= 0.5F; break;
            case 16: x.analogFeel = v >= 0.5F; break;
            case 17: x.synthBypass = v >= 0.5F; break;
            default: break;
        }
    }
    static void readSynth(const ToneExtra& x, const ModMatrix& m, std::vector<float>& out) {
        out.insert(out.end(), {x.pwmWidth, x.pwmDepth, x.pwmRateHz, x.pwmMix, x.subLevel, static_cast<float>(x.subOctave), static_cast<float>(x.unisonVoices), x.unisonDetuneCents,
                               x.unisonSpread, x.drive, static_cast<float>(x.filterType), x.filterKeyTrack, static_cast<float>(x.filter2Type), x.filter2Hz, x.filter2Res,
                               x.filter2Parallel ? 1.0F : 0.0F, x.analogFeel ? 1.0F : 0.0F, x.synthBypass ? 1.0F : 0.0F, 0.0F, 0.0F});
        for (const auto& r : m.route) out.insert(out.end(), {static_cast<float>(r.source), static_cast<float>(r.target), r.amount, r.bipolar ? 1.0F : 0.0F});
    }
    bool setSoundSynthParam(int upperIndex, int sound, int id, float v) {
        if (upperIndex < 0 || upperIndex >= kUpperCount || sound < 0 || sound > kUpperLayers || id < 0 || id >= kSynthParamCount || !std::isfinite(v)) { setTextError("Invalid synth parameter"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& u = next->combi.uppers[static_cast<std::size_t>(upperIndex)];
        if (sound == 0) applySynth(u.toneExtra, u.toneMod, id, v);
        else { auto& l = u.layers[static_cast<std::size_t>(sound - 1)]; applySynth(l.tone.x, l.tone.mod, id, v); }
        return installState(std::move(next));
    }
    std::vector<float> soundSynthParams(int upperIndex, int sound) const {
        std::vector<float> out;
        if (upperIndex < 0 || upperIndex >= kUpperCount || sound < 0 || sound > kUpperLayers || state_ == nullptr) return out;
        const auto& u = state_->combi.uppers[static_cast<std::size_t>(upperIndex)];
        if (sound == 0) readSynth(u.toneExtra, u.toneMod, out);
        else { const auto& l = u.layers[static_cast<std::size_t>(sound - 1)]; readSynth(l.tone.x, l.tone.mod, out); }
        return out;
    }

#include "WaveHost.inc"

    std::vector<float> upperState(int upperIndex) const {
        std::vector<float> out;
        if (upperIndex < 0 || upperIndex >= kUpperCount || state_ == nullptr) return out;
        const auto& u = state_->combi.uppers[static_cast<std::size_t>(upperIndex)];
        out = {
            u.enabled ? 1.0F : 0.0F, u.solo ? 1.0F : 0.0F, u.mute ? 1.0F : 0.0F,
            u.levelDb, u.pan, static_cast<float>(u.keyLow), static_cast<float>(u.keyHigh),
            static_cast<float>(u.velocityLow), static_cast<float>(u.velocityHigh),
            static_cast<float>(u.voiceMode), static_cast<float>(u.octave),
            static_cast<float>(u.transposeSemitones), u.tuneCents, static_cast<float>(u.pitchBendRange),
            u.portamentoSec, u.breathEnabled ? 1.0F : 0.0F, u.expressionEnabled ? 1.0F : 0.0F,
            u.aftertouchEnabled ? 1.0F : 0.0F, u.damperEnabled ? 1.0F : 0.0F,
            static_cast<float>(u.midiChannel), u.ampAttackScale, u.ampDecayScale,
            u.ampSustainScale, u.ampReleaseScale, u.filterCutoffOctaves, u.filterResonanceOffset,
            u.lfoRateScale, u.lfoDepthScale, u.eqLowDb, u.eqMidDb, u.eqHighDb, u.fxSend1, u.fxSend2
        };
        const UpperToneValues tone = effectiveUpperTone(u);
        out.insert(out.end(), {tone.attackMs, tone.decayMs, tone.sustain, tone.releaseMs, tone.cutoffHz, tone.resonance,
                               u.toneAttackMs >= 0.0F ? 1.0F : 0.0F, u.toneDecayMs >= 0.0F ? 1.0F : 0.0F,
                               u.toneSustain >= 0.0F ? 1.0F : 0.0F, u.toneReleaseMs >= 0.0F ? 1.0F : 0.0F,
                               u.toneCutoffHz >= 0.0F ? 1.0F : 0.0F, u.toneResonance >= 0.0F ? 1.0F : 0.0F});
        return out;
    }

    std::string upperSoundName(int upperIndex) const {
        if (upperIndex < 0 || upperIndex >= kUpperCount || state_ == nullptr) return {};
        const auto& p = state_->combi.uppers[static_cast<std::size_t>(upperIndex)].program;
        return p == nullptr ? std::string{} : p->name;
    }

    std::string combiName() const { return state_ == nullptr ? std::string{} : state_->combi.name; }


    std::vector<int> combiCatalogSlots() const {
        std::vector<int> out;
        out.reserve(500U);
        for (int slot = 1; slot <= 500; ++slot) {
            SlotAddress address{};
            address.bank = 0;
            address.page = 0;
            address.slot = static_cast<std::uint16_t>(slot);
            if (library_.combi(address).has_value()) out.push_back(slot);
        }
        return out;
    }

    std::vector<std::string> combiCatalogNames() const {
        std::vector<std::string> out;
        out.reserve(500U);
        for (int slot = 1; slot <= 500; ++slot) {
            SlotAddress address{};
            address.bank = 0;
            address.page = 0;
            address.slot = static_cast<std::uint16_t>(slot);
            const auto combi = library_.combi(address);
            if (combi.has_value()) out.push_back(combi->name);
        }
        return out;
    }

    // SILVETON_POLYSIX_V1: a SOUND slot is a bank SOUND (1..500) or a built-in wave (9001..).
    static bool isBuiltinSlot(std::uint16_t slot) noexcept {
        return slot >= kBuiltinWaveFirstSlot && slot < kBuiltinWaveFirstSlot + static_cast<std::uint16_t>(kBuiltinWaveCount);
    }
    ProgramPtr programForSlot(std::uint16_t slot) const {
        if (slot >= 1U && slot <= kFixedSoundSlotCount) return library_.program(SlotAddress{0U, 0U, slot});
        if (isBuiltinSlot(slot)) return builtinWaveProgram(static_cast<int>(slot - kBuiltinWaveFirstSlot));
        return nullptr;
    }
    // SILVETON_SOUND_BY_NAME_V1: every SOUND of the bank (1..500) with the place it has now.
    std::vector<SoundCandidate> bankSoundCandidates() const {
        std::vector<SoundCandidate> out;
        for (const auto& item : library_.programCatalog()) {
            if (item.address.bank != 0U || item.address.page != 0U) continue;
            if (item.address.slot < 1U || item.address.slot > kFixedSoundSlotCount) continue;
            out.push_back(SoundCandidate{item.address.slot, item.name});
        }
        return out;
    }
    // Finds the sound a part remembers: by its NAME in the bank (the place is only the first
    // guess and is updated when the sound sits elsewhere now). Built-in waves have fixed
    // places. Not found = nullptr (the place and the name stay remembered, nothing else is bound).
    ProgramPtr programForRemembered(std::uint16_t& slot, const std::string& name,
                                    const std::vector<SoundCandidate>& bankSounds) const {
        if (slot == kNoSoundSlot) return nullptr;
        if (isBuiltinSlot(slot)) return programForSlot(slot);
        const auto found = resolveSoundByName(slot, name, bankSounds);
        if (!found.found) return nullptr;
        slot = found.slot;
        return programForSlot(slot);
    }
    // Binds every sound of an Upper (basic + layers) to its SOUND, found by name. Missing = off.
    void rebindUpper(UpperPart& upper, const std::vector<SoundCandidate>& bankSounds) const {
        if (upper.soundSlotId != kNoSoundSlot) {
            upper.program = programForRemembered(upper.soundSlotId, upper.name, bankSounds);
            if (upper.program != nullptr) upper.name = upper.program->name; else if (!upper.hasAnySound()) upper.enabled = false;
        }
        for (auto& l : upper.layers) {
            if (l.soundSlotId == kNoSoundSlot) { l.program.reset(); l.enabled = false; continue; }
            l.program = programForRemembered(l.soundSlotId, l.name, bankSounds);
            if (l.program != nullptr) l.name = l.program->name; else l.enabled = false;
        }
        if (upper.program == nullptr && !upper.hasAnySound()) upper.enabled = false;
    }

    std::vector<int> soundCatalogAddresses() const {
        std::vector<int> out;
        for (const auto& item : library_.programCatalog()) {
            out.push_back(static_cast<int>(item.address.bank));
            out.push_back(static_cast<int>(item.address.page));
            out.push_back(static_cast<int>(item.address.slot));
        }
        // SILVETON_BANK_LOAD_FIX_V1: the built-in waves are not offered as SOUNDs - the Polysix
        // functions work on the bank recordings only (what was asked for).
        return out;
    }

    std::vector<std::string> soundCatalogNames() const {
        std::vector<std::string> out;
        for (const auto& item : library_.programCatalog()) out.push_back(item.name);
        return out;
    }

    bool updateUpperFxSends(int upperIndex, float send1, float send2) {
        if (upperIndex < 0 || upperIndex >= kUpperCount) { setTextError("Invalid Upper index"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& upper = next->combi.uppers[static_cast<std::size_t>(upperIndex)];
        upper.fxSend1 = std::clamp(send1, 0.0F, 1.0F);
        upper.fxSend2 = std::clamp(send2, 0.0F, 1.0F);
        return installState(std::move(next));
    }

    bool updateUpperControllerRoute(int upperIndex, int routeIndex, int source, int destination,
                                    int cc, float amount, bool bipolar) {
        if (upperIndex < 0 || upperIndex >= kUpperCount) { setTextError("Invalid Upper index"); return false; }
        if (routeIndex < 0 || routeIndex >= kMaxUpperControllerRoutes) { setTextError("Invalid controller route index"); return false; }
        if (source < static_cast<int>(ControllerSource::Off) || source > static_cast<int>(ControllerSource::ControlChange)) { setTextError("Invalid controller source"); return false; }
        if (destination < static_cast<int>(ModDestination::LevelDb) || destination > static_cast<int>(ModDestination::FxSend2)) { setTextError("Invalid modulation destination"); return false; }
        if (!std::isfinite(amount)) { setTextError("Controller route amount is not finite"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& route = next->combi.uppers[static_cast<std::size_t>(upperIndex)].controllerRoutes[static_cast<std::size_t>(routeIndex)];
        route.source = static_cast<ControllerSource>(source);
        route.destination = static_cast<ModDestination>(destination);
        route.cc = static_cast<std::uint8_t>(std::clamp(cc, 0, 127));
        route.amount = std::clamp(amount, -96.0F, 96.0F);
        route.bipolar = bipolar;
        return installState(std::move(next));
    }

    bool updateCombiFx(int slot, int type, float wet, float timeMs, float feedback,
                       float rateHz, float depth, float tone) {
        if (slot < 0 || slot >= kFxSendSlots) { setTextError("Invalid COMBI FX slot"); return false; }
        if (type < static_cast<int>(EffectType::Off) || type >= kEffectTypeCount) { setTextError("Invalid COMBI FX type"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& fx = next->combi.fx[static_cast<std::size_t>(slot)];
        fx.type = static_cast<EffectType>(type);
        fx.wet = std::clamp(wet, 0.0F, 1.0F);
        fx.timeMs = std::clamp(timeMs, 1.0F, 2500.0F);
        fx.feedback = std::clamp(feedback, 0.0F, 0.95F);
        fx.rateHz = std::clamp(rateHz, 0.02F, 12.0F);
        fx.depth = std::clamp(depth, 0.0F, 1.0F);
        fx.tone = std::clamp(tone, 0.0F, 1.0F);
        return installState(std::move(next));
    }

    bool updateCombiFxRouting(int routing) {
        if (routing < static_cast<int>(EffectRouting::Parallel) || routing > static_cast<int>(EffectRouting::Fx1IntoFx2)) { setTextError("Invalid COMBI FX routing"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        next->combi.fxRouting = static_cast<EffectRouting>(routing);
        return installState(std::move(next));
    }

    std::vector<float> combiFxState() const {
        std::vector<float> out;
        if (state_ == nullptr) return out;
        const auto append = [&out](const EffectSlot& fx) {
            out.push_back(static_cast<float>(fx.type));
            out.push_back(fx.wet); out.push_back(fx.timeMs); out.push_back(fx.feedback);
            out.push_back(fx.rateHz); out.push_back(fx.depth); out.push_back(fx.tone);
        };
        for (const auto& f : state_->combi.fx) append(f);
        out.push_back(static_cast<float>(state_->combi.fxRouting));
        return out;
    }

    std::vector<float> globalState() const {
        std::vector<float> out;
        if (state_ == nullptr) return out;
        const auto& g = state_->global;
        out = {g.masterTuneHz, static_cast<float>(g.transposeSemitones), g.masterGainDb,
               g.eqLowDb, g.eqMidDb, g.eqHighDb, g.limiterEnabled ? 1.0F : 0.0F,
               g.limiterCeilingDb, static_cast<float>(g.velocityCurve),
               static_cast<float>(g.breathCc), static_cast<float>(g.expressionCc),
               static_cast<float>(g.damperCc), g.pitchBendEnabled ? 1.0F : 0.0F,
               g.aftertouchEnabled ? 1.0F : 0.0F};
        // SILVETON_MIDI_FULL_V1: 14 scaleRoot, 15..26 scale cents, 27 MIDI IN mask,
        // 28..31 filters (notes, CC, bend, aftertouch), 32..34 breath min/max/curve,
        // 35..37 expression min/max/curve, 38 damper polarity reversed.
        out.push_back(static_cast<float>(g.scaleRoot));
        for (const float cents : g.scaleOffsetsCents) out.push_back(cents);
        out.push_back(static_cast<float>(g.midiInputChannelMask));
        out.push_back(g.filterNotes ? 1.0F : 0.0F);
        out.push_back(g.filterControlChange ? 1.0F : 0.0F);
        out.push_back(g.filterPitchBend ? 1.0F : 0.0F);
        out.push_back(g.filterAftertouch ? 1.0F : 0.0F);
        out.push_back(g.breathMin); out.push_back(g.breathMax); out.push_back(g.breathCurve);
        out.push_back(g.expressionMin); out.push_back(g.expressionMax); out.push_back(g.expressionCurve);
        out.push_back(g.damperPolarityReversed ? 1.0F : 0.0F);
        return out;
    }

    bool writeGlobal() {
        if (state_ == nullptr) { setTextError("No active GLOBAL state"); return false; }
        library_.setGlobal(state_->global);
        setTextError({});
        return true;
    }

    bool updateGlobal(float masterTuneHz, int transposeSemitones, float masterGainDb,
                      float eqLowDb, float eqMidDb, float eqHighDb, bool limiterEnabled,
                      float limiterCeilingDb, int velocityCurve, int breathCc, int expressionCc,
                      int damperCc, bool pitchBendEnabled, bool aftertouchEnabled) {
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& g = next->global;
        g.masterTuneHz = std::clamp(masterTuneHz, 400.0F, 480.0F);
        g.transposeSemitones = static_cast<std::int8_t>(std::clamp(transposeSemitones, -12, 12));
        g.masterGainDb = std::clamp(masterGainDb, -60.0F, 18.0F);
        g.eqLowDb = std::clamp(eqLowDb, -18.0F, 18.0F);
        g.eqMidDb = std::clamp(eqMidDb, -18.0F, 18.0F);
        g.eqHighDb = std::clamp(eqHighDb, -18.0F, 18.0F);
        g.limiterEnabled = false;  // SILVETON_MASTER_6DB_V1: no limiter in the sound
        (void)limiterEnabled;
        g.limiterCeilingDb = std::clamp(limiterCeilingDb, -12.0F, 0.0F);
        g.velocityCurve = static_cast<std::uint8_t>(std::clamp(velocityCurve, 0, 4));
        g.breathCc = static_cast<std::uint8_t>(std::clamp(breathCc, 0, 127));
        g.expressionCc = static_cast<std::uint8_t>(std::clamp(expressionCc, 0, 127));
        g.damperCc = static_cast<std::uint8_t>(std::clamp(damperCc, 0, 127));
        g.pitchBendEnabled = pitchBendEnabled;
        g.aftertouchEnabled = aftertouchEnabled;
        library_.setGlobal(g);
        return installState(std::move(next));
    }

    bool updateGlobalAdvanced(int scaleRoot, const std::array<float, 12>& scaleOffsetsCents,
                              std::uint16_t midiInputChannelMask, bool filterNotes,
                              bool filterControlChange, bool filterPitchBend, bool filterAftertouch,
                              float breathMin, float breathMax, float breathCurve,
                              float expressionMin, float expressionMax, float expressionCurve,
                              bool damperPolarityReversed) {
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& g = next->global;
        g.scaleRoot = static_cast<std::uint8_t>(std::clamp(scaleRoot, 0, 11));
        for (std::size_t i = 0; i < g.scaleOffsetsCents.size(); ++i) {
            g.scaleOffsetsCents[i] = std::clamp(scaleOffsetsCents[i], -100.0F, 100.0F);
        }
        g.midiInputChannelMask = midiInputChannelMask;
        g.filterNotes = filterNotes;
        g.filterControlChange = filterControlChange;
        g.filterPitchBend = filterPitchBend;
        g.filterAftertouch = filterAftertouch;
        g.breathMin = std::clamp(breathMin, 0.0F, 0.9999F);
        g.breathMax = std::clamp(breathMax, g.breathMin + 0.0001F, 1.0F);
        g.breathCurve = std::clamp(breathCurve, 0.1F, 8.0F);
        g.expressionMin = std::clamp(expressionMin, 0.0F, 0.9999F);
        g.expressionMax = std::clamp(expressionMax, g.expressionMin + 0.0001F, 1.0F);
        g.expressionCurve = std::clamp(expressionCurve, 0.1F, 8.0F);
        g.damperPolarityReversed = damperPolarityReversed;
        library_.setGlobal(g);
        return installState(std::move(next));
    }

    bool writeList(const SlotAddress& address, const SetList& list) {
        if (!library_.writeList(address, list)) { setTextError("Write List failed"); return false; }
        setTextError({});
        return true;
    }

    // SILVETON_LIST_POSITIONS_V1: COMBI address 0/0/0 marks an empty LIST position,
    // so a BLEND can sit at any position 1..200 like a Korg Performance.
    static bool emptyListAddress(const SlotAddress& a) noexcept { return a.bank == 0U && a.page == 0U && a.slot == 0U; }

    bool setListEntry(const SlotAddress& listAddress, int index, int number, const std::string& name, const SlotAddress& combiAddress) {
        if (index < 0) { setTextError("LIST entry index is invalid"); return false; }
        const bool empty = emptyListAddress(combiAddress);
        const auto combi = empty ? std::optional<Combi>{} : library_.combi(combiAddress);
        if (!empty && !combi.has_value()) { setTextError("LIST target COMBI slot is empty"); return false; }
        ListEntry entry{};
        entry.number = static_cast<std::uint16_t>(std::clamp(number, 0, 65535));
        entry.name = empty ? std::string("-") : (name.empty() ? combi->name : name);
        entry.combiBank = combiAddress.bank; entry.combiPage = combiAddress.page; entry.combiSlot = combiAddress.slot;
        if (!library_.setListEntry(listAddress, static_cast<std::size_t>(index), entry)) { setTextError("LIST entry update failed"); return false; }
        setTextError({}); return true;
    }

    bool insertListEntry(const SlotAddress& listAddress, int index, int number, const std::string& name, const SlotAddress& combiAddress) {
        if (index < 0) { setTextError("LIST entry index is invalid"); return false; }
        const bool empty = emptyListAddress(combiAddress);
        const auto combi = empty ? std::optional<Combi>{} : library_.combi(combiAddress);
        if (!empty && !combi.has_value()) { setTextError("LIST target COMBI slot is empty"); return false; }
        ListEntry entry{};
        entry.number = static_cast<std::uint16_t>(std::clamp(number, 0, 65535));
        entry.name = empty ? std::string("-") : (name.empty() ? combi->name : name);
        entry.combiBank = combiAddress.bank; entry.combiPage = combiAddress.page; entry.combiSlot = combiAddress.slot;
        if (!library_.insertListEntry(listAddress, static_cast<std::size_t>(index), entry)) { setTextError("LIST entry insert failed"); return false; }
        if (activeListAddress_.has_value() && *activeListAddress_ == listAddress && activeListEntry_ >= index) ++activeListEntry_;
        setTextError({}); return true;
    }

    bool removeListEntry(const SlotAddress& listAddress, int index) {
        if (index < 0 || !library_.removeListEntry(listAddress, static_cast<std::size_t>(index))) { setTextError("LIST entry remove failed"); return false; }
        if (activeListAddress_.has_value() && *activeListAddress_ == listAddress) {
            if (activeListEntry_ == index) activeListEntry_ = -1;
            else if (activeListEntry_ > index) --activeListEntry_;
        }
        setTextError({}); return true;
    }

    bool moveListEntry(const SlotAddress& listAddress, int fromIndex, int toIndex) {
        if (fromIndex < 0 || toIndex < 0 || !library_.moveListEntry(listAddress, static_cast<std::size_t>(fromIndex), static_cast<std::size_t>(toIndex))) { setTextError("LIST entry move failed"); return false; }
        if (activeListAddress_.has_value() && *activeListAddress_ == listAddress) {
            if (activeListEntry_ == fromIndex) activeListEntry_ = toIndex;
            else if (fromIndex < activeListEntry_ && activeListEntry_ <= toIndex) --activeListEntry_;
            else if (toIndex <= activeListEntry_ && activeListEntry_ < fromIndex) ++activeListEntry_;
        }
        setTextError({}); return true;
    }

    bool moveList(const SlotAddress& from, const SlotAddress& to, bool overwrite) {
        if (!library_.moveList(from, to, overwrite)) { setTextError("LIST move failed"); return false; }
        if (activeListAddress_.has_value() && *activeListAddress_ == from) activeListAddress_ = to;
        setTextError({}); return true;
    }

    bool activateListEntry(const SlotAddress& listAddress, int index) {
        if (index < 0) { setTextError("LIST entry index is invalid"); return false; }
        const auto list = library_.list(listAddress);
        if (!list.has_value() || static_cast<std::size_t>(index) >= list->entries.size()) { setTextError("LIST entry is not available"); return false; }
        const auto& entry = list->entries[static_cast<std::size_t>(index)];
        const SlotAddress combiAddress{entry.combiBank, entry.combiPage, entry.combiSlot};
        if (!activateCombi(combiAddress)) return false;
        activeListAddress_ = listAddress;
        activeListEntry_ = index;
        setTextError({}); return true;
    }

    // Marks which LIST position the loaded sound belongs to, without reloading it.
    bool setActiveListEntry(const SlotAddress& listAddress, int index) {
        const auto list = library_.list(listAddress);
        if (index < 0 || !list.has_value() || static_cast<std::size_t>(index) >= list->entries.size()) {
            if (activeListAddress_.has_value() && *activeListAddress_ == listAddress) activeListEntry_ = -1;
            return true;
        }
        activeListAddress_ = listAddress;
        activeListEntry_ = index;
        return true;
    }

    int activeListEntry(const SlotAddress& listAddress) const noexcept {
        return activeListAddress_.has_value() && *activeListAddress_ == listAddress ? activeListEntry_ : -1;
    }

    std::vector<int> listEntryNumbers(const SlotAddress& address) const {
        std::vector<int> out; const auto list = library_.list(address); if (!list.has_value()) return out;
        out.reserve(list->entries.size()); for (const auto& e : list->entries) out.push_back(static_cast<int>(e.number)); return out;
    }

    std::vector<std::string> listEntryNames(const SlotAddress& address) const {
        std::vector<std::string> out; const auto list = library_.list(address); if (!list.has_value()) return out;
        out.reserve(list->entries.size()); for (const auto& e : list->entries) out.push_back(e.name); return out;
    }

    std::vector<int> listEntryCombiAddresses(const SlotAddress& address) const {
        std::vector<int> out; const auto list = library_.list(address); if (!list.has_value()) return out;
        out.reserve(list->entries.size()*3U); for (const auto& e : list->entries) { out.push_back(e.combiBank); out.push_back(e.combiPage); out.push_back(e.combiSlot); } return out;
    }

    bool clearProgram(const SlotAddress& address) { return library_.clearProgram(address); }
    bool clearCombi(const SlotAddress& address) { return library_.clearCombi(address); }
    bool clearList(const SlotAddress& address) {
        const bool ok = library_.clearList(address);
        if (ok && activeListAddress_.has_value() && *activeListAddress_ == address) { activeListAddress_.reset(); activeListEntry_ = -1; }
        return ok;
    }
    bool clearMultisample(std::uint32_t id) { return library_.clearMultisample(id); }

    bool programSlotOccupied(const SlotAddress& address) const { return library_.hasProgram(address); }
    bool combiSlotOccupied(const SlotAddress& address) const { return library_.hasCombi(address); }
    bool listSlotOccupied(const SlotAddress& address) const { return library_.hasList(address); }
    bool renameProgram(const SlotAddress& address, const std::string& name) { return library_.renameProgram(address, name); }
    bool renameCombi(const SlotAddress& address, const std::string& name) { return library_.renameCombi(address, name); }
    bool renameList(const SlotAddress& address, const std::string& name) { return library_.renameList(address, name); }
    bool copyProgram(const SlotAddress& from, const SlotAddress& to, bool overwrite) { return library_.copyProgram(from, to, overwrite); }
    bool copyCombi(const SlotAddress& from, const SlotAddress& to, bool overwrite) { return library_.copyCombi(from, to, overwrite); }
    bool copyList(const SlotAddress& from, const SlotAddress& to, bool overwrite) { return library_.copyList(from, to, overwrite); }

    bool activateProgram(const SlotAddress& address, int upperIndex) {
        if (upperIndex < 0 || upperIndex >= kUpperCount) { setTextError("Invalid Upper index"); return false; }
        const bool builtin = address.bank == 0U && address.page == 0U && isBuiltinSlot(address.slot);
        const auto program = builtin ? programForSlot(address.slot) : library_.program(address);
        if (program == nullptr) { setTextError("PROGRAM slot is empty"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& upper = next->combi.uppers[static_cast<std::size_t>(upperIndex)];
        upper.program = program;
        upper.soundSlotId = (address.bank == 0U && address.page == 0U && ((address.slot >= 1U && address.slot <= kFixedSoundSlotCount) || builtin)) ? address.slot : kNoSoundSlot;
        upper.name = program->name; // visible name arrives 1:1 from SILVETON_BANK.sv
        upper.enabled = true;
        return installState(std::move(next));
    }

    bool clearUpperSound(int upperIndex) {
        if (upperIndex < 0 || upperIndex >= kUpperCount) { setTextError("Invalid Upper index"); return false; }
        auto next = std::make_shared<EngineState>(state_ != nullptr ? *state_ : EngineState{});
        auto& upper = next->combi.uppers[static_cast<std::size_t>(upperIndex)];
        upper.program.reset();
        upper.soundSlotId = kNoSoundSlot;
        upper.enabled = false;
        upper.solo = false;
        upper.mute = false;
        return installState(std::move(next));
    }

    bool activateCombi(const SlotAddress& address) {
        const auto combi = library_.combi(address);
        if (!combi.has_value()) { setTextError("COMBI slot is empty"); return false; }
        auto next = std::make_shared<EngineState>();
        next->global = state_ != nullptr ? state_->global : library_.global();
        next->combi = *combi;
        // SILVETON_FX_TAIL_V1: a new BLEND -> the old effect rings out, no cut.
        next->combiGeneration = (state_ != nullptr ? state_->combiGeneration : 0U) + 1U;
        const auto bankSounds = bankSoundCandidates();   // SILVETON_SOUND_BY_NAME_V1
        for (auto& upper : next->combi.uppers) {
            rebindUpper(upper, bankSounds);   // SILVETON_LAYERS_V1 / SILVETON_POLYSIX_V1: basic sound, layers, built-in waves
            if (upper.soundSlotId != kNoSoundSlot && upper.program == nullptr) {
                setTextError("COMBI references an empty SOUND slot");
                return false;
            }
        }
        return installState(std::move(next));
    }

    bool setSetName(const std::string& name) {
        if (name.empty()) { setTextError("SET name cannot be empty"); return false; }
        library_.setSetName(name);
        return true;
    }

    // SILVETON_SCAN_V1: SCAN for TERCA (1) and SCALE (2), like the SILVETON
    // processor / Korg Pa. While scanning the keys make no sound; TERCA takes the
    // three-note shape held (tonality), SCALE takes every key pressed (notes of
    // the scale). When all scan keys are up the result is published and the
    // keyboard plays normally again. Keys held before SCAN are released normally.
    void startScan(int mode) noexcept {
        scanTercaPending_ = false;
        scanScaleCollected_ = 0;
        scanKeyPending_ = false;
        scanMode_.store(mode >= 1 && mode <= 3 ? mode : 0, std::memory_order_release);
    }
    std::vector<int> scanInfo() const {
        return {scanMode_.load(std::memory_order_acquire), tercaRoot_.load(std::memory_order_acquire),
                tercaCell_.load(std::memory_order_acquire), static_cast<int>(tercaSerial_.load(std::memory_order_acquire)),
                scaleMask_.load(std::memory_order_acquire), static_cast<int>(scaleSerial_.load(std::memory_order_acquire)),
                keyScan_.load(std::memory_order_acquire), static_cast<int>(keyScanSerial_.load(std::memory_order_acquire))};
    }
    void setTerca(int upperMask, int root, int cell) noexcept { engine_.setTerca(upperMask, root, cell); }
    void setScaleUppers(int upperMask) noexcept { engine_.setScaleUppers(upperMask); }

    void scanObserveOn(int mode, std::uint8_t key) noexcept {
        if (mode == 2) { scanScaleCollected_ |= 1 << (key % 12U); return; }
        // SILVETON_KEY_SCAN_V1: KEY RANGE - the first key pressed is the limit.
        if (mode == 3) { if (!scanKeyPending_) { scanKeyValue_ = key; scanKeyPending_ = true; } return; }
        if (scanTercaPending_) return;
        int mask = 0;
        for (int n = 0; n < 128; ++n) if (scanSwallowed_[static_cast<std::size_t>(n)] != 0U) mask |= 1 << (n % 12);
        if (__builtin_popcount(static_cast<unsigned>(mask)) != 3) return;
        static constexpr int kCells[6][3] = {{0, 4, 7}, {0, 2, 4}, {0, 3, 7}, {0, 2, 3}, {0, 1, 3}, {0, 1, 4}};
        for (int cell = 0; cell < 6; ++cell) {
            for (int root = 0; root < 12; ++root) {
                int shape = 0;
                for (int k = 0; k < 3; ++k) shape |= 1 << ((root + kCells[cell][k]) % 12);
                if (shape != mask) continue;
                scanTercaRoot_ = root;
                scanTercaCell_ = cell;
                scanTercaPending_ = true;
                return;
            }
        }
    }

    void scanFinishIfReleased(int mode) noexcept {
        for (const auto refs : scanSwallowed_) if (refs != 0U) return;
        if (mode == 1 && scanTercaPending_) {
            tercaRoot_.store(scanTercaRoot_, std::memory_order_release);
            tercaCell_.store(scanTercaCell_, std::memory_order_release);
            tercaSerial_.fetch_add(1U, std::memory_order_acq_rel);
            scanTercaPending_ = false;
            scanMode_.store(0, std::memory_order_release);
        } else if (mode == 3 && scanKeyPending_) {
            keyScan_.store(scanKeyValue_, std::memory_order_release);
            keyScanSerial_.fetch_add(1U, std::memory_order_acq_rel);
            scanKeyPending_ = false;
            scanMode_.store(0, std::memory_order_release);
        } else if (mode == 2 && scanScaleCollected_ != 0) {
            scaleMask_.store(scanScaleCollected_, std::memory_order_release);
            scaleSerial_.fetch_add(1U, std::memory_order_acq_rel);
            scanScaleCollected_ = 0;
            scanMode_.store(0, std::memory_order_release);
        }
    }

    bool midi(std::uint8_t status, std::uint8_t data1, std::uint8_t data2) noexcept {
        const std::uint8_t kind = static_cast<std::uint8_t>(status & 0xF0U);
        const std::uint8_t ch = static_cast<std::uint8_t>(status & 0x0FU);
        {
            const bool isOn = kind == 0x90U && data2 > 0U;
            const bool isOff = kind == 0x80U || (kind == 0x90U && data2 == 0U);
            if (isOn || isOff) {
                const std::size_t n = static_cast<std::size_t>(data1 & 0x7FU);
                const int mode = scanMode_.load(std::memory_order_acquire);
                if (isOff && scanSwallowed_[n] != 0U) {
                    --scanSwallowed_[n];
                    if (mode != 0) scanFinishIfReleased(mode);
                    midiActivitySerial_.fetch_add(1U, std::memory_order_release);
                    return true;
                }
                if (isOn && mode != 0) {
                    if (scanSwallowed_[n] < 255U) ++scanSwallowed_[n];
                    scanObserveOn(mode, static_cast<std::uint8_t>(n));
                    midiActivitySerial_.fetch_add(1U, std::memory_order_release);
                    return true;
                }
            }
        }
        midiLastStatus_.store(static_cast<int>(status), std::memory_order_relaxed);
        midiLastData1_.store(static_cast<int>(data1), std::memory_order_relaxed);
        midiLastData2_.store(static_cast<int>(data2), std::memory_order_relaxed);
        midiActivitySerial_.fetch_add(1U, std::memory_order_release);
        if (kind == 0x80U || (kind == 0x90U && data2 == 0U)) testInstrument_.noteOff(data1);
        else if (kind == 0x90U) testInstrument_.noteOn(data1, data2);
        else if (kind == 0xB0U && (data1 == 120U || data1 == 123U)) testInstrument_.panic();
        switch (kind) {
            case 0x80U: return engine_.postNoteOff(ch, data1, data2);
            case 0x90U: return data2 == 0U ? engine_.postNoteOff(ch, data1, 0U) : engine_.postNoteOn(ch, data1, data2);
            case 0xB0U: return engine_.postControlChange(ch, data1, data2);
            case 0xD0U: return engine_.postChannelPressure(ch, data1);
            case 0xE0U: {
                const int raw = static_cast<int>(data1) | (static_cast<int>(data2) << 7);
                return engine_.postPitchBend(ch, static_cast<std::int16_t>(raw - 8192));
            }
            default: return true;
        }
    }

    bool panic() noexcept { testInstrument_.panic(); return engine_.postPanic(); }

    MeterSnapshot meters() const noexcept { return engine_.meters(); }
    int sampleRate() const noexcept { return sampleRate_.load(std::memory_order_relaxed); }
    int framesPerBurst() const noexcept { return framesPerBurst_.load(std::memory_order_relaxed); }
    int bufferSizeFrames() const noexcept { return bufferSizeFrames_.load(std::memory_order_relaxed); }
    int xrunCount() const noexcept { return audio_ != nullptr ? audio_->xrunCount() : 0; }
    int midiDeviceCount() const noexcept { return (midi_ != nullptr && midiOpen_.load(std::memory_order_acquire)) ? midi_->sourceCount() : 0; }
    int midiLastError() const noexcept { return midiLastError_.load(std::memory_order_relaxed); }
    std::uint64_t midiActivitySerial() const noexcept { return midiActivitySerial_.load(std::memory_order_acquire); }
    int midiLastStatus() const noexcept { return midiLastStatus_.load(std::memory_order_relaxed); }
    int midiLastData1() const noexcept { return midiLastData1_.load(std::memory_order_relaxed); }
    int midiLastData2() const noexcept { return midiLastData2_.load(std::memory_order_relaxed); }
    bool testInstrumentEnabled() const noexcept { return testInstrument_.enabled(); }
    bool testNoteOn(std::uint8_t note, std::uint8_t velocity) noexcept {
        if (!testInstrument_.enabled() || velocity == 0U) return false;
        testInstrument_.noteOn(note, velocity);
        return true;
    }
    void testNoteOff(std::uint8_t note) noexcept { testInstrument_.noteOff(note); }

    // The status structure of the screens predates the backends. These fields stay for compatibility
    // and deliberately report "not applicable" instead of inventing fake values.
    int sharingMode() const noexcept { return -1; }
    int performanceMode() const noexcept { return -1; }
    int deviceId() const noexcept { return -1; }

    int lastError() const noexcept { return lastError_.load(std::memory_order_relaxed); }
    bool needsRecovery() const noexcept { return recoverRequested_.load(std::memory_order_acquire) || (audio_ != nullptr && opened_.load(std::memory_order_acquire) && audio_->needsRecovery()); }
    bool started() const noexcept { return started_.load(std::memory_order_acquire); }

    // Latency of the sound output as the device reports it (-1 = not known).
    double estimatedOutputLatencyMs() const noexcept {
        if (audio_ == nullptr || !opened_.load(std::memory_order_acquire)) return -1.0;
        return audio_->latencyMs();
    }

    // Name of the sound device, and the names of the connected MIDI sources (for INFO).
    std::string audioDeviceName() const { return audio_ != nullptr ? audio_->deviceName() : std::string(); }
    std::vector<std::string> midiSourceNames() const { return midi_ != nullptr ? midi_->sourceNames() : std::vector<std::string>(); }

    std::string textError() const {
        std::lock_guard<std::mutex> lock(errorMutex_);
        return textError_;
    }

private:
    static constexpr unsigned kChannels = 2U;
    static constexpr double kWantedRate = 96000.0;            // as on the tablet (the device may give another rate)
    static constexpr std::uint32_t kWantedFrames = 96U;       // about 1 ms at 96 kHz

    static void renderThunk(void* user, float* out, std::uint32_t frames) {
        static_cast<SamplerHost*>(user)->renderBlocks(out, frames);
    }
    static void midiThunk(void* user, std::uint8_t status, std::uint8_t data1, std::uint8_t data2) {
        (void)static_cast<SamplerHost*>(user)->midi(status, data1, data2);
    }

    // Audio thread: the device asks for `frames`; the engine is asked in pieces of at most maxBlock_.
    void renderBlocks(float* out, std::uint32_t frames) noexcept {
        const std::uint32_t chunk = std::max<std::uint32_t>(1U, maxBlock_);
        std::uint32_t done = 0U;
        while (done < frames) {
            const std::uint32_t n = std::min(chunk, frames - done);
            float* p = out + static_cast<std::size_t>(done) * kChannels;
            engine_.render(p, n);
            testInstrument_.render(p, n, sampleRate());
            const std::size_t samples = static_cast<std::size_t>(n) * kChannels;
            // The tablet clips at the 16-bit conversion; here the sound card gets a clean -1..+1.
            for (std::size_t i = 0U; i < samples; ++i) {
                const float v = p[i];
                p[i] = v > 1.0F ? 1.0F : (v < -1.0F ? -1.0F : (v == v ? v : 0.0F));
            }
            done += n;
        }
    }

    bool startMidiLocked() {
        if (midiOpen_.load(std::memory_order_acquire)) return true;
        if (!midi_) midi_ = makeDefaultMidiInput();
        if (!midi_) { midiLastError_.store(-1, std::memory_order_relaxed); return false; }
        const bool ok = midi_->open(&SamplerHost::midiThunk, this);
        midiLastError_.store(ok ? 0 : -1, std::memory_order_relaxed);
        midiOpen_.store(ok, std::memory_order_release);
        return ok;
    }

    void stopMidiLocked() noexcept {
        if (midi_ != nullptr && midiOpen_.load(std::memory_order_acquire)) midi_->close();
        midiOpen_.store(false, std::memory_order_release);
    }

    bool openLocked() {
        if (opened_.load(std::memory_order_acquire)) return true;
        if (!audio_) audio_ = makeDefaultAudioOutput();
        if (!audio_ || !audio_->open(&SamplerHost::renderThunk, this, kWantedRate, kWantedFrames)) {
            const std::string why = audio_ ? audio_->lastError() : std::string();
            lastError_.store(-1, std::memory_order_relaxed);
            recoverRequested_.store(true, std::memory_order_release);
            setTextError(std::string("AUDIO: the sound output could not be opened") + (why.empty() ? std::string() : " (" + why + ")"));
            return false;
        }
        const double sr = audio_->sampleRate();
        const std::uint32_t burst = audio_->framesPerBurst();
        if (sr < 8000.0 || burst == 0U) {
            audio_->close();
            lastError_.store(-2, std::memory_order_relaxed);
            recoverRequested_.store(true, std::memory_order_release);
            setTextError("AUDIO: the sound output gave no usable rate");
            return false;
        }
        sampleRate_.store(static_cast<int>(std::lround(sr)), std::memory_order_relaxed);
        framesPerBurst_.store(static_cast<int>(burst), std::memory_order_relaxed);
        bufferSizeFrames_.store(static_cast<int>(burst) * 2, std::memory_order_relaxed);
        maxBlock_ = std::clamp<std::uint32_t>(burst * 4U, 1024U, 4096U);
        engine_.prepare(sr, maxBlock_);
        // SILVETON_START_REFRESH_V1: every start of the program begins clean - the engine is rebuilt for
        // this rate, the Studio interpolation is set again and the MASTER starts at -6 dB (no limiter).
        engine_.setInterpolationQuality(InterpolationQuality::Studio);
        // SILVETON_MULTICORE_V1: the voices are shared out over the cores next to the audio thread.
        {
            const unsigned cores = std::thread::hardware_concurrency();
            const int renderThreads = cores >= 8U ? 4 : (cores >= 6U ? 3 : (cores >= 4U ? 2 : 1));
            engine_.setRenderThreads(renderThreads);
        }
        if (state_ != nullptr) {
            auto fresh = std::make_shared<EngineState>(*state_);
            fresh->global.masterGainDb = -6.0F;
            fresh->global.limiterEnabled = false;
            state_ = fresh;
            library_.setGlobal(fresh->global);
        }
        if (state_ != nullptr) engine_.setState(state_);
        lastError_.store(0, std::memory_order_relaxed);
        recoverRequested_.store(false, std::memory_order_release);
        setTextError({});
        opened_.store(true, std::memory_order_release);
        return true;
    }

    bool startLocked() {
        if (started_.load(std::memory_order_acquire)) return true;
        if (!opened_.load(std::memory_order_acquire) && !openLocked()) return false;
        if (!audio_->start()) {
            lastError_.store(-3, std::memory_order_relaxed);
            recoverRequested_.store(true, std::memory_order_release);
            const std::string why = audio_->lastError();
            setTextError(std::string("AUDIO: the sound output did not start") + (why.empty() ? std::string() : " (" + why + ")"));
            return false;
        }
        started_.store(true, std::memory_order_release);
        setTextError({});
        return true;
    }

    bool stopLocked() {
        if (audio_ != nullptr && opened_.load(std::memory_order_acquire)) audio_->stop();
        started_.store(false, std::memory_order_release);
        return true;
    }

    void closeAudioLocked() noexcept {
        if (audio_ != nullptr && opened_.load(std::memory_order_acquire)) audio_->close();
        opened_.store(false, std::memory_order_release);
        sampleRate_.store(0, std::memory_order_relaxed);
        framesPerBurst_.store(0, std::memory_order_relaxed);
        bufferSizeFrames_.store(0, std::memory_order_relaxed);
    }

    bool commitSampleEdit(std::uint32_t id, const SamplePtr& previous, SampleEditResult result) {
        if (!result.ok()) { setTextError(result.error); return false; }
        if (!library_.writeSample(id, result.sample)) { setTextError("SAMPLE write-back failed"); return false; }
        if (state_ != nullptr) {
            auto next = std::make_shared<EngineState>(*state_); bool changed=false;
            for (auto& upper : next->combi.uppers) {
                if (upper.program == nullptr) continue;
                std::shared_ptr<Program> pc;
                for (std::size_t li=0U; li<upper.program->layers.size(); ++li) {
                    const auto& oldMs=upper.program->layers[li].multisample; if(oldMs==nullptr) continue;
                    std::shared_ptr<Multisample> mc;
                    for(std::size_t zi=0U; zi<oldMs->zones.size(); ++zi){
                        if(oldMs->zones[zi].sample!=previous) continue;
                        if(mc==nullptr) mc=std::make_shared<Multisample>(*oldMs);
                        mc->zones[zi].sample=result.sample;
                    }
                    if(mc!=nullptr){ if(pc==nullptr) pc=std::make_shared<Program>(*upper.program); pc->layers[li].multisample=mc; }
                }
                if(pc!=nullptr){ upper.program=pc; changed=true; }
            }
            if(changed && !installState(std::move(next))) return false;
        }
        setTextError({}); return true;
    }

    bool commitMultisampleEdit(std::uint32_t id, const MultisamplePtr& previous, MultisampleEditResult result) {
        if(!result.ok()){setTextError(result.error);return false;}
        if(!library_.writeMultisample(id,result.multisample)){setTextError("MULTISAMPLE write-back failed");return false;}
        if(state_!=nullptr){auto next=std::make_shared<EngineState>(*state_);bool changed=false;for(auto& upper:next->combi.uppers){if(upper.program==nullptr)continue;std::shared_ptr<Program> pc;for(std::size_t li=0U;li<upper.program->layers.size();++li){if(upper.program->layers[li].multisample!=previous)continue;if(pc==nullptr)pc=std::make_shared<Program>(*upper.program);pc->layers[li].multisample=result.multisample;}if(pc!=nullptr){upper.program=pc;changed=true;}}if(changed&&!installState(std::move(next)))return false;}
        setTextError({});return true;
    }

    bool commitProgramEdit(const SlotAddress& address, const ProgramPtr& previous, ProgramEditResult result) {
        if (!result.ok()) { setTextError(result.error); return false; }
        if (!library_.writeProgram(address, result.program)) { setTextError("PROGRAM write-back failed"); return false; }
        if (state_ != nullptr) {
            auto next = std::make_shared<EngineState>(*state_);
            bool activeChanged = false;
            for (auto& upper : next->combi.uppers) {
                if (upper.program == previous) {
                    upper.program = result.program;
                    activeChanged = true;
                }
            }
            if (activeChanged && !installState(std::move(next))) return false;
        }
        setTextError({});
        return true;
    }

    bool ensureKscCache(const std::string& path) {
        if (path == kscCachePath_ && kscCache_.ok()) return true;
        auto imported = KorgImporter::loadKsc(path);
        if (!imported.ok()) { setTextError(imported.error); return false; }
        kscCachePath_ = path;
        kscCache_ = std::move(imported);
        setTextError({});
        return true;
    }

    MultisamplePtr makeSingleSampleMultisample(const SamplePtr& sample, const std::string& name) {
        auto ms = std::make_shared<Multisample>();
        ms->name = name;
        SampleZone z{};
        z.sample = sample;
        z.keyLow = 0U; z.keyHigh = 127U; z.velocityLow = 1U; z.velocityHigh = 127U;
        z.rootKey = sample->rootKey;
        ms->zones.push_back(z);
        return ms;
    }

    bool installMultisample(const MultisamplePtr& ms, const std::string& name) {
        if (ms == nullptr) return false;
        auto program = std::make_shared<Program>();
        program->name = name;
        ProgramLayer layer{};
        layer.name = "Layer 1";
        layer.multisample = ms;
        program->layers.push_back(layer);
        auto state = std::make_shared<EngineState>();
        state->combi.name = name;
        auto& u = state->combi.uppers[0];
        u.name = "Upper 1";
        u.enabled = true;
        u.program = program;
        u.midiChannel = 0U;
        return installState(std::move(state));
    }

    // SILVETON_SYNTH_MENU_OFF_V1: the SYNTH and MATRIX pages are gone from the screen, so every
    // sound plays as the plain recording - exactly the SYNTH ИЗКЛ sound (no PWM, SUB, UNISON,
    // DRIVE, character filters, filter 2 or matrix; one voice per sound, lighter on the CPU).
    // The knob values stay stored in the SET untouched.
    static void forceSynthOff(EngineState& s) noexcept {
        for (auto& u : s.combi.uppers) {
            u.toneExtra.synthBypass = true;
            for (auto& l : u.layers) l.tone.x.synthBypass = true;
        }
    }

    bool installState(std::shared_ptr<const EngineState> state) {
        if (state == nullptr) return false;
        auto plain = std::make_shared<EngineState>(*state);   // SILVETON_SYNTH_MENU_OFF_V1
        forceSynthOff(*plain);
        prepareWaveTables(*plain);   // SILVETON_TRANSWAVE_V1: the tables go to the engine before the state
        std::lock_guard<std::mutex> lock(controlMutex_);
        state_ = std::move(plain);
        // Real bank SOUND is authoritative. The old diagnostic TEST EP is retired.
        testInstrument_.setEnabled(false);
        engine_.setState(state_);
        return true;
    }

    void syncCurrentStateToLibrary() {
        if (state_ == nullptr) return;
        library_.setGlobal(state_->global);
    }


    void setTextError(const std::string& s) {
        std::lock_guard<std::mutex> lock(errorMutex_);
        textError_ = s;
    }

    SamplerEngine engine_;
    SampleStreamPrefetcher prefetcher_{engine_};
    BuiltinTestInstrument testInstrument_{};
    std::atomic<std::uint64_t> midiActivitySerial_{0U};
    std::atomic<int> midiLastStatus_{0};
    std::atomic<int> midiLastData1_{0};
    std::atomic<int> midiLastData2_{0};
    SamplerLibrary library_{"SILVETON SET"};
    KorgCollectionResult kscCache_{};
    std::string kscCachePath_;
    std::shared_ptr<const EngineState> state_{std::make_shared<EngineState>()};
    std::optional<SlotAddress> activeListAddress_{};
    int activeListEntry_{-1};
    std::atomic<int> scanMode_{0};
    std::array<std::uint8_t, 128> scanSwallowed_{};
    bool scanTercaPending_{false};
    int scanTercaRoot_{0};
    int scanTercaCell_{0};
    int scanScaleCollected_{0};
    bool scanKeyPending_{false};
    int scanKeyValue_{0};
    std::atomic<int> keyScan_{-1};
    std::atomic<std::uint32_t> keyScanSerial_{0U};
    std::atomic<int> tercaRoot_{-1};
    std::atomic<int> tercaCell_{-1};
    std::atomic<unsigned> tercaSerial_{0U};
    std::atomic<int> scaleMask_{0};
    std::atomic<unsigned> scaleSerial_{0U};

    std::unique_ptr<AudioOutput> audio_{};
    std::unique_ptr<MidiInput> midi_{};
    std::uint32_t maxBlock_{1024U};
    std::atomic<bool> opened_{false};
    std::atomic<bool> midiOpen_{false};
    std::atomic<bool> started_{false};
    std::atomic<bool> wantStarted_{false};
    std::atomic<bool> recoverRequested_{false};
    std::atomic<int> sampleRate_{0};
    std::atomic<int> framesPerBurst_{0};
    std::atomic<int> bufferSizeFrames_{0};
    std::atomic<int> midiLastError_{0};
    std::atomic<int> lastError_{0};
    mutable std::mutex controlMutex_;
    mutable std::mutex errorMutex_;
    std::string textError_;
};

std::unique_ptr<SamplerHost> gSampler;
SamplerHost& sampler() { if (!gSampler) gSampler = std::make_unique<SamplerHost>(); return *gSampler; }

SlotAddress makeAddress(int bank, int page, int slot) noexcept {
    SlotAddress a{};
    a.bank = static_cast<std::uint16_t>(std::clamp(bank, 0, 65535));
    a.page = static_cast<std::uint16_t>(std::clamp(page, 0, 65535));
    a.slot = static_cast<std::uint16_t>(std::clamp(slot, 0, 65535));
    return a;
}

std::vector<float> metersArray(const MeterSnapshot& m) {
    std::vector<float> v(7U + static_cast<std::size_t>(kUpperCount) * 2U, 0.0F);
    v[0]=m.peakLeft; v[1]=m.peakRight; v[2]=m.limiterGainReductionDb;
    v[3]=static_cast<float>(m.activeVoices); v[4]=static_cast<float>(m.droppedEvents);
    for (std::size_t i = 0; i < static_cast<std::size_t>(kUpperCount); ++i) {
        const std::size_t base = 5U + i * 2U;
        v[base] = m.upperPeakLeft[i];
        v[base + 1U] = m.upperPeakRight[i];
    }
    v[5U + static_cast<std::size_t>(kUpperCount) * 2U] = m.cpuLoadPercent;   // SILVETON_CPU_METER_V1
    v[6U + static_cast<std::size_t>(kUpperCount) * 2U] = static_cast<float>(m.coresWorking);   // SILVETON_MULTICORE_V1 (last value)
    return v;
}

}  // namespace

void NativeSamplerEngine::nativeSamplerInit() {gSampler = std::make_unique<SamplerHost>();}

bool NativeSamplerEngine::nativeAudioOpen() {return sampler().open()?true:false;}

bool NativeSamplerEngine::nativeAudioStart() {return sampler().start()?true:false;}

void NativeSamplerEngine::nativeAudioStop() {sampler().stop();}

void NativeSamplerEngine::nativeAudioClose() {sampler().close();}

bool NativeSamplerEngine::nativeAudioRecover() {return sampler().recover()?true:false;}

bool NativeSamplerEngine::nativeAudioNeedsRecovery() {return sampler().needsRecovery()?true:false;}

bool NativeSamplerEngine::nativeEnforceOutputRoute() {return sampler().enforceHeadphoneRoute(true)?true:false;}

void NativeSamplerEngine::nativeSetPortaBalance(int balance) {sampler().setPortamentoBalance(static_cast<float>(balance));}

void NativeSamplerEngine::nativeSetVoiceCeiling(int voices) {sampler().setVoiceCeiling(static_cast<int>(voices));}

void NativeSamplerEngine::nativeSetPortaNear(int ms) {sampler().setPortamentoNear(static_cast<float>(ms));}

std::string NativeSamplerEngine::nativeBankInfo(const std::string& path) {std::string err;const auto t=bankInfoText((path),err);return  std::string(t.empty()?("ERROR\t"+err).c_str():t.c_str());}

std::string NativeSamplerEngine::nativeRemoveBankSounds(const std::string& path, const std::vector<int>& slots) {
    std::set<std::uint16_t> s;
    for (const int x : slots) if (x >= 1 && x <= 65535) s.insert(static_cast<std::uint16_t>(x));
    std::string err;
    const bool ok = removeBankSounds(path, s, err);
    return ok ? std::string() : (err.empty() ? std::string("Delete failed") : err);
}

bool NativeSamplerEngine::nativeLoadAudio(const std::string& path) {return sampler().loadAudioFile((path))?true:false;}

bool NativeSamplerEngine::nativeLoadKmp(const std::string& path) {return sampler().loadKmp((path))?true:false;}

std::vector<int> NativeSamplerEngine::nativeImportKmpToLibrary(const std::string& path) {return (sampler().importKmpToLibrary((path)));}

std::vector<int> NativeSamplerEngine::nativeImportKscToLibrary(const std::string& path) {return (sampler().importKscToLibrary((path)));}

std::vector<int> NativeSamplerEngine::nativeMultisampleIds() {return (sampler().multisampleIds());}

std::vector<std::string> NativeSamplerEngine::nativeMultisampleNames() {    return sampler().multisampleNames();
}

std::vector<std::string> NativeSamplerEngine::nativeKscNames(const std::string& path) {    return sampler().kscNames(path);
}

bool NativeSamplerEngine::nativeLoadKscItem(const std::string& path, int index) {return sampler().loadKscItem((path),index)?true:false;}

bool NativeSamplerEngine::nativeLoadSvBank(const std::string& path) {return sampler().loadSvBank((path))?true:false;}

bool NativeSamplerEngine::nativeLoadSet(const std::string& path) {return sampler().loadSet((path))?true:false;}

bool NativeSamplerEngine::nativeSaveUserPerformanceState(const std::string& path) {return sampler().saveUserPerformanceState((path))?true:false;}

bool NativeSamplerEngine::nativeLoadUserPerformanceState(const std::string& path) {return sampler().loadUserPerformanceState((path))?true:false;}

bool NativeSamplerEngine::nativeReplaceUserPerformanceState(const std::string& path) {return sampler().replaceUserPerformanceState((path))?true:false;}

bool NativeSamplerEngine::nativeSaveBank(const std::string& path, int bank) {return sampler().saveBank((path),bank)?true:false;}

bool NativeSamplerEngine::nativeLoadBank(const std::string& path, int targetBank, bool overwrite) {return sampler().loadBank((path),targetBank,overwrite)?true:false;}

bool NativeSamplerEngine::nativeWriteSample(int id, int upper, int layer, int zone, const std::string& name) {return sampler().writeCurrentSample(static_cast<std::uint32_t>(std::max(0,id)),upper,layer,zone,(name))?true:false;}

bool NativeSamplerEngine::nativeUpdateSampleMetadata(int id, const std::string& name, int rootKey, float fineTune) {return sampler().updateSampleMetadata(static_cast<std::uint32_t>(std::max(0,id)),(name),rootKey,fineTune)?true:false;}

bool NativeSamplerEngine::nativeTrimSample(int id, std::int64_t start, std::int64_t end) {if(start<0||end<0)return false;return sampler().trimSample(static_cast<std::uint32_t>(std::max(0,id)),static_cast<std::uint64_t>(start),static_cast<std::uint64_t>(end))?true:false;}

bool NativeSamplerEngine::nativeNormalizeSample(int id, float targetDb) {return sampler().normalizeSample(static_cast<std::uint32_t>(std::max(0,id)),targetDb)?true:false;}

bool NativeSamplerEngine::nativeReverseSample(int id) {return sampler().reverseSample(static_cast<std::uint32_t>(std::max(0,id)))?true:false;}

bool NativeSamplerEngine::nativeFadeSample(int id, std::int64_t fadeIn, std::int64_t fadeOut) {if(fadeIn<0||fadeOut<0)return false;return sampler().fadeSample(static_cast<std::uint32_t>(std::max(0,id)),static_cast<std::uint64_t>(fadeIn),static_cast<std::uint64_t>(fadeOut))?true:false;}

bool NativeSamplerEngine::nativeSetSampleLoop(int id, std::int64_t start, std::int64_t end, int crossfade) {if(start<0||end<0||crossfade<0)return false;return sampler().setSampleLoop(static_cast<std::uint32_t>(std::max(0,id)),static_cast<std::uint64_t>(start),static_cast<std::uint64_t>(end),static_cast<std::uint32_t>(crossfade))?true:false;}

bool NativeSamplerEngine::nativeClearSampleLoop(int id) {return sampler().clearSampleLoop(static_cast<std::uint32_t>(std::max(0,id)))?true:false;}

std::int64_t NativeSamplerEngine::nativeSampleNearestZeroCrossing(int id, std::int64_t around, std::int64_t radius) {if(around<0||radius<0)return static_cast<std::int64_t>(-1);return static_cast<std::int64_t>(sampler().sampleNearestZeroCrossing(static_cast<std::uint32_t>(std::max(0,id)),static_cast<std::uint64_t>(around),static_cast<std::uint64_t>(radius)));}

bool NativeSamplerEngine::nativeWriteMultisample(int id, int upper, int layer, const std::string& name) {return sampler().writeCurrentMultisample(static_cast<std::uint32_t>(std::max(0,id)),upper,layer,(name))?true:false;}

bool NativeSamplerEngine::nativeRenameMultisample(int id, const std::string& name) {return sampler().renameMultisample(static_cast<std::uint32_t>(std::max(0,id)),(name))?true:false;}

bool NativeSamplerEngine::nativeAddMultisampleZone(int id, int sampleId, int insertIndex, int keyLow, int keyHigh, int velLow, int velHigh, int rootKey, int transpose, float tune, float gain, float pan, bool oneShot, bool reverse, bool nonTranspose) {return sampler().addMultisampleZone(static_cast<std::uint32_t>(std::max(0,id)),static_cast<std::uint32_t>(std::max(0,sampleId)),insertIndex,keyLow,keyHigh,velLow,velHigh,rootKey,transpose,tune,gain,pan,oneShot,reverse,nonTranspose)?true:false;}

bool NativeSamplerEngine::nativeUpdateMultisampleZone(int id, int zoneIndex, int sampleId, int keyLow, int keyHigh, int velLow, int velHigh, int rootKey, int transpose, float tune, float gain, float pan, bool oneShot, bool reverse, bool nonTranspose) {return sampler().updateMultisampleZone(static_cast<std::uint32_t>(std::max(0,id)),zoneIndex,static_cast<std::uint32_t>(std::max(0,sampleId)),keyLow,keyHigh,velLow,velHigh,rootKey,transpose,tune,gain,pan,oneShot,reverse,nonTranspose)?true:false;}

bool NativeSamplerEngine::nativeRemoveMultisampleZone(int id, int zoneIndex) {return sampler().removeMultisampleZone(static_cast<std::uint32_t>(std::max(0,id)),zoneIndex)?true:false;}

bool NativeSamplerEngine::nativeMoveMultisampleZone(int id, int fromIndex, int toIndex) {return sampler().moveMultisampleZone(static_cast<std::uint32_t>(std::max(0,id)),fromIndex,toIndex)?true:false;}

bool NativeSamplerEngine::nativeClearMultisample(int id) {return sampler().clearMultisample(static_cast<std::uint32_t>(std::max(0,id)))?true:false;}

bool NativeSamplerEngine::nativeProgramSlotOccupied(int bank, int page, int slot) {return sampler().programSlotOccupied(makeAddress(bank,page,slot))?true:false;}

bool NativeSamplerEngine::nativeCombiSlotOccupied(int bank, int page, int slot) {return sampler().combiSlotOccupied(makeAddress(bank,page,slot))?true:false;}

bool NativeSamplerEngine::nativeListSlotOccupied(int bank, int page, int slot) {return sampler().listSlotOccupied(makeAddress(bank,page,slot))?true:false;}

bool NativeSamplerEngine::nativeRenameProgram(int bank, int page, int slot, const std::string& name) {return sampler().renameProgram(makeAddress(bank,page,slot),(name))?true:false;}

bool NativeSamplerEngine::nativeRenameCombi(int bank, int page, int slot, const std::string& name) {return sampler().renameCombi(makeAddress(bank,page,slot),(name))?true:false;}

bool NativeSamplerEngine::nativeRenameList(int bank, int page, int slot, const std::string& name) {return sampler().renameList(makeAddress(bank,page,slot),(name))?true:false;}

bool NativeSamplerEngine::nativeCopyProgram(int fb, int fp, int fs, int tb, int tp, int ts, bool overwrite) {return sampler().copyProgram(makeAddress(fb,fp,fs),makeAddress(tb,tp,ts),overwrite)?true:false;}

bool NativeSamplerEngine::nativeCopyCombi(int fb, int fp, int fs, int tb, int tp, int ts, bool overwrite) {return sampler().copyCombi(makeAddress(fb,fp,fs),makeAddress(tb,tp,ts),overwrite)?true:false;}

bool NativeSamplerEngine::nativeCopyList(int fb, int fp, int fs, int tb, int tp, int ts, bool overwrite) {return sampler().copyList(makeAddress(fb,fp,fs),makeAddress(tb,tp,ts),overwrite)?true:false;}

bool NativeSamplerEngine::nativeMidi(int status, int d1, int d2) {return sampler().midi(static_cast<std::uint8_t>(status&0xFF),static_cast<std::uint8_t>(d1&0x7F),static_cast<std::uint8_t>(d2&0x7F))?true:false;}

int NativeSamplerEngine::nativeMidiDeviceCount() {return sampler().midiDeviceCount();}

int NativeSamplerEngine::nativeMidiLastError() {return sampler().midiLastError();}

std::int64_t NativeSamplerEngine::nativeMidiActivitySerial() {return static_cast<std::int64_t>(sampler().midiActivitySerial());}

std::vector<int> NativeSamplerEngine::nativeMidiLastMessage() {    return std::vector<int>{sampler().midiLastStatus(), sampler().midiLastData1(), sampler().midiLastData2()};
}

bool NativeSamplerEngine::nativeAudioStarted() {return sampler().started()?true:false;}

bool NativeSamplerEngine::nativeTestInstrumentEnabled() {return sampler().testInstrumentEnabled()?true:false;}

bool NativeSamplerEngine::nativeTestNoteOn(int note, int velocity) {return sampler().testNoteOn(static_cast<std::uint8_t>(std::clamp(note,0,127)),static_cast<std::uint8_t>(std::clamp(velocity,0,127)))?true:false;}

void NativeSamplerEngine::nativeTestNoteOff(int note) {sampler().testNoteOff(static_cast<std::uint8_t>(std::clamp(note,0,127)));}

bool NativeSamplerEngine::nativePanic() {return sampler().panic()?true:false;}

std::vector<float> NativeSamplerEngine::nativeMeters() {return metersArray(sampler().meters());}

std::vector<int> NativeSamplerEngine::nativeAudioInfo() {    return std::vector<int>{sampler().sampleRate(), sampler().framesPerBurst(), sampler().bufferSizeFrames(), sampler().xrunCount(), sampler().sharingMode(), sampler().performanceMode(), sampler().deviceId()};
}

double NativeSamplerEngine::nativeLatencyMs() {return sampler().estimatedOutputLatencyMs();}

int NativeSamplerEngine::nativeLastAudioError() {return sampler().lastError();}

std::string NativeSamplerEngine::nativeLastTextError() {const auto s=sampler().textError();return  std::string(s.c_str());}

bool NativeSamplerEngine::nativeSaveSet(const std::string& path) {return sampler().saveSet((path))?true:false;}

bool NativeSamplerEngine::nativeSetSetName(const std::string& name) {return sampler().setSetName((name))?true:false;}

bool NativeSamplerEngine::nativeWriteProgram(int bank, int page, int slot, int upper, const std::string& name) {return sampler().writeCurrentProgram(makeAddress(bank,page,slot),upper,(name))?true:false;}

bool NativeSamplerEngine::nativeUpdateProgramBasic(int bank, int page, int slot, bool mono, bool legato, float portamentoSec) {return sampler().updateProgramBasic(makeAddress(bank,page,slot),mono,legato,portamentoSec)?true:false;}

bool NativeSamplerEngine::nativeAddProgramLayer(int bank, int page, int slot, int multisampleId, const std::string& name) {return sampler().addProgramLayer(makeAddress(bank,page,slot),static_cast<std::uint32_t>(std::max(0,multisampleId)),(name))?true:false;}

bool NativeSamplerEngine::nativeRemoveProgramLayer(int bank, int page, int slot, int layer) {return sampler().removeProgramLayer(makeAddress(bank,page,slot),layer)?true:false;}

bool NativeSamplerEngine::nativeMoveProgramLayer(int bank, int page, int slot, int fromLayer, int toLayer) {return sampler().moveProgramLayer(makeAddress(bank,page,slot),fromLayer,toLayer)?true:false;}

bool NativeSamplerEngine::nativeAssignProgramMultisample(int bank, int page, int slot, int layer, int multisampleId) {return sampler().assignProgramMultisample(makeAddress(bank,page,slot),layer,static_cast<std::uint32_t>(std::max(0,multisampleId)))?true:false;}

bool NativeSamplerEngine::nativeUpdateProgramLayerBasic(int bank, int page, int slot, int layer, bool enabled, int keyLow, int keyHigh, int velocityLow, int velocityHigh, int velocityFadeIn, int velocityFadeOut, int transpose, float tuneCents, float levelDb, float pan, float delaySec, bool damperEnabled) {return sampler().updateProgramLayerBasic(makeAddress(bank,page,slot),layer,enabled,keyLow,keyHigh,velocityLow,velocityHigh,velocityFadeIn,velocityFadeOut,transpose,tuneCents,levelDb,pan,delaySec,damperEnabled)?true:false;}

bool NativeSamplerEngine::nativeUpdateProgramAmpEnvelope(int bank, int page, int slot, int layer, float attack, float decay, float sustain, float release) {return sampler().updateProgramAmpEnvelope(makeAddress(bank,page,slot),layer,attack,decay,sustain,release)?true:false;}

bool NativeSamplerEngine::nativeUpdateProgramPitch(int bank, int page, int slot, int layer, float amountCents, float attack, float decay, float sustain, float release) {return sampler().updateProgramPitch(makeAddress(bank,page,slot),layer,amountCents,attack,decay,sustain,release)?true:false;}

bool NativeSamplerEngine::nativeUpdateProgramFilter(int bank, int page, int slot, int layer, int mode, float cutoffHz, float resonance, float keyTrack, float velocityAmount, float envelopeAmount, float lfoAmount, float attack, float decay, float sustain, float release) {return sampler().updateProgramFilter(makeAddress(bank,page,slot),layer,mode,cutoffHz,resonance,keyTrack,velocityAmount,envelopeAmount,lfoAmount,attack,decay,sustain,release)?true:false;}

bool NativeSamplerEngine::nativeUpdateProgramLfo(int bank, int page, int slot, int layer, int lfoIndex, int wave, float frequencyHz, float delaySec, float fadeSec, bool keySync, float pitchCents, float filterOctaves, float ampDepth) {return sampler().updateProgramLfo(makeAddress(bank,page,slot),layer,lfoIndex,wave,frequencyHz,delaySec,fadeSec,keySync,pitchCents,filterOctaves,ampDepth)?true:false;}

bool NativeSamplerEngine::nativeWriteCombi(int bank, int page, int slot, const std::string& name) {return sampler().writeCurrentCombi(makeAddress(bank,page,slot),(name))?true:false;}

bool NativeSamplerEngine::nativeUpdateUpperMain(int upper, bool enabled, bool solo, bool mute, float levelDb, float pan, int keyLow, int keyHigh, int voiceMode) {return sampler().updateUpperMain(upper,enabled,solo,mute,levelDb,pan,keyLow,keyHigh,voiceMode)?true:false;}

bool NativeSamplerEngine::nativeUpdateUpperTune(int upper, int octave, int transpose, float fineCents, int pitchBendRange, float portamentoSec) {return sampler().updateUpperTune(upper,octave,transpose,fineCents,pitchBendRange,portamentoSec)?true:false;}

bool NativeSamplerEngine::nativeUpdateUpperRange(int upper, int velocityLow, int velocityHigh) {return sampler().updateUpperRange(upper,velocityLow,velocityHigh)?true:false;}

bool NativeSamplerEngine::nativeUpdateUpperControl(int upper, bool breath, bool expression, bool aftertouch, bool damper, int midiChannel) {return sampler().updateUpperControl(upper,breath,expression,aftertouch,damper,midiChannel)?true:false;}

bool NativeSamplerEngine::nativeUpdateUpperTone(int upper, float attack, float decay, float sustain, float release, float cutoff, float resonance, float lfoRate, float lfoDepth, float eqLow, float eqMid, float eqHigh) {return sampler().updateUpperTone(upper,attack,decay,sustain,release,cutoff,resonance,lfoRate,lfoDepth,eqLow,eqMid,eqHigh)?true:false;}

bool NativeSamplerEngine::nativeSetUpperToneParam(int upper, int param, float value) {return sampler().setUpperToneParam(upper,param,value)?true:false;}

std::vector<float> NativeSamplerEngine::nativeUpperState(int upper) {return (sampler().upperState(upper));}

std::string NativeSamplerEngine::nativeUpperSoundName(int upper) {const auto s=sampler().upperSoundName(upper);return  std::string(s.c_str());}

std::string NativeSamplerEngine::nativeCombiName() {const auto s=sampler().combiName();return  std::string(s.c_str());}

std::vector<int> NativeSamplerEngine::nativeCombiCatalogSlots() {return (sampler().combiCatalogSlots());}

std::vector<std::string> NativeSamplerEngine::nativeCombiCatalogNames() {return (sampler().combiCatalogNames());}

std::vector<int> NativeSamplerEngine::nativeSoundCatalogAddresses() {return (sampler().soundCatalogAddresses());}

std::vector<std::string> NativeSamplerEngine::nativeSoundCatalogNames() {return (sampler().soundCatalogNames());}

bool NativeSamplerEngine::nativeUpdateUpperFxSends(int upper, float send1, float send2) {return sampler().updateUpperFxSends(upper,send1,send2)?true:false;}

bool NativeSamplerEngine::nativeUpdateUpperControllerRoute(int upper, int route, int source, int destination, int cc, float amount, bool bipolar) {return sampler().updateUpperControllerRoute(upper,route,source,destination,cc,amount,bipolar)?true:false;}

bool NativeSamplerEngine::nativeUpdateCombiFx(int slot, int type, float wet, float timeMs, float feedback, float rateHz, float depth, float tone) {return sampler().updateCombiFx(slot,type,wet,timeMs,feedback,rateHz,depth,tone)?true:false;}

bool NativeSamplerEngine::nativeUpdateCombiFxRouting(int routing) {return sampler().updateCombiFxRouting(routing)?true:false;}

bool NativeSamplerEngine::nativeSetUpperParam(int upper, int id, float value) {return sampler().setUpperParam(upper,id,value)?true:false;}

std::vector<float> NativeSamplerEngine::nativeUpperParams(int upper) {return (sampler().upperParams(upper));}

bool NativeSamplerEngine::nativeSetLayerParam(int upper, int layer, int id, float value) {return sampler().setLayerParam(upper,layer,id,value)?true:false;}

bool NativeSamplerEngine::nativeSetLayerSound(int upper, int layer, int slot) {return sampler().setLayerSound(upper,layer,slot)?true:false;}

std::vector<float> NativeSamplerEngine::nativeLayerParams(int upper, int layer) {return (sampler().layerParams(upper,layer));}

std::string NativeSamplerEngine::nativeLayerName(int upper, int layer) {return  std::string(sampler().layerName(upper,layer).c_str());}

bool NativeSamplerEngine::nativeSetFxParam(int unit, int id, float value) {return sampler().setFxParam(unit,id,value)?true:false;}

std::vector<float> NativeSamplerEngine::nativeFxParams(int unit) {return (sampler().fxParams(unit));}

bool NativeSamplerEngine::nativeSetSoundSynthParam(int upper, int sound, int id, float value) {return sampler().setSoundSynthParam(upper,sound,id,value)?true:false;}
bool NativeSamplerEngine::nativeSetSoundWaveParam(int upper, int sound, int id, float value) {return sampler().setSoundWaveParam(upper,sound,id,value)?true:false;}
std::vector<float> NativeSamplerEngine::nativeSoundWaveParams(int upper, int sound) {return (sampler().soundWaveParams(upper,sound));}

std::vector<float> NativeSamplerEngine::nativeSoundSynthParams(int upper, int sound) {return (sampler().soundSynthParams(upper,sound));}

std::vector<float> NativeSamplerEngine::nativeAnalyzerFrame(int upper, bool after) {return (sampler().analyzerFrame(upper,after));}

std::vector<float> NativeSamplerEngine::nativeCombiFxState() {return (sampler().combiFxState());}

void NativeSamplerEngine::nativeStartScan(int mode) {sampler().startScan(static_cast<int>(mode));}

std::vector<int> NativeSamplerEngine::nativeScanInfo() {    const auto v = sampler().scanInfo();
    return std::vector<int>(v.begin(), v.end());
}

void NativeSamplerEngine::nativeSetTerca(int upperMask, int root, int cell) {sampler().setTerca(static_cast<int>(upperMask),static_cast<int>(root),static_cast<int>(cell));}

void NativeSamplerEngine::nativeSetScaleUppers(int upperMask) {sampler().setScaleUppers(static_cast<int>(upperMask));}

std::vector<float> NativeSamplerEngine::nativeGlobalState() {return (sampler().globalState());}

bool NativeSamplerEngine::nativeWriteGlobal() {return sampler().writeGlobal()?true:false;}

bool NativeSamplerEngine::nativeUpdateGlobal(float tune, int transpose, float gain, float low, float mid, float high, bool limiter, float ceiling, int velocityCurve, int breathCc, int expressionCc, int damperCc, bool pitchBend, bool aftertouch) {return sampler().updateGlobal(tune,transpose,gain,low,mid,high,limiter,ceiling,velocityCurve,breathCc,expressionCc,damperCc,pitchBend,aftertouch)?true:false;}

bool NativeSamplerEngine::nativeUpdateGlobalAdvanced(int scaleRoot, const std::vector<float>& scaleOffsets, int midiChannelMask, bool filterNotes, bool filterCc, bool filterPitchBend, bool filterAftertouch, float breathMin, float breathMax, float breathCurve, float expressionMin, float expressionMax, float expressionCurve, bool damperReverse) {
    if (scaleOffsets.size() < 12U) return false;
    std::array<float,12> offsets{};
    for (std::size_t i = 0; i < offsets.size(); ++i) offsets[i] = scaleOffsets[i];
    return sampler().updateGlobalAdvanced(scaleRoot, offsets, static_cast<std::uint16_t>(midiChannelMask & 0xFFFF), filterNotes, filterCc, filterPitchBend, filterAftertouch, breathMin, breathMax, breathCurve, expressionMin, expressionMax, expressionCurve, damperReverse);
}

bool NativeSamplerEngine::nativeWriteList(int bank, int page, int slot, const std::string& listName, const std::vector<int>& numbers, const std::vector<std::string>& names, const std::vector<int>& combiAddresses) {
    const std::size_t count = numbers.size();
    if (names.size() != count || combiAddresses.size() != count * 3U) return false;
    SetList list;
    list.name = listName;
    list.entries.reserve(count);
    for (std::size_t i = 0; i < count; ++i) {
        ListEntry e;
        e.number = static_cast<std::uint16_t>(std::clamp(numbers[i], 0, 65535));
        e.name = names[i];
        e.combiBank = static_cast<std::uint16_t>(std::clamp(combiAddresses[i * 3U], 0, 65535));
        e.combiPage = static_cast<std::uint16_t>(std::clamp(combiAddresses[i * 3U + 1U], 0, 65535));
        e.combiSlot = static_cast<std::uint16_t>(std::clamp(combiAddresses[i * 3U + 2U], 0, 65535));
        list.entries.push_back(std::move(e));
    }
    return sampler().writeList(makeAddress(bank, page, slot), list);
}

bool NativeSamplerEngine::nativeSetListEntry(int lb, int lp, int ls, int index, int number, const std::string& name, int cb, int cp, int cs) {return sampler().setListEntry(makeAddress(lb,lp,ls),index,number,(name),makeAddress(cb,cp,cs))?true:false;}

bool NativeSamplerEngine::nativeInsertListEntry(int lb, int lp, int ls, int index, int number, const std::string& name, int cb, int cp, int cs) {return sampler().insertListEntry(makeAddress(lb,lp,ls),index,number,(name),makeAddress(cb,cp,cs))?true:false;}

bool NativeSamplerEngine::nativeRemoveListEntry(int lb, int lp, int ls, int index) {return sampler().removeListEntry(makeAddress(lb,lp,ls),index)?true:false;}

bool NativeSamplerEngine::nativeMoveListEntry(int lb, int lp, int ls, int fromIndex, int toIndex) {return sampler().moveListEntry(makeAddress(lb,lp,ls),fromIndex,toIndex)?true:false;}

bool NativeSamplerEngine::nativeMoveList(int fb, int fp, int fs, int tb, int tp, int ts, bool overwrite) {return sampler().moveList(makeAddress(fb,fp,fs),makeAddress(tb,tp,ts),overwrite)?true:false;}

bool NativeSamplerEngine::nativeSetActiveListEntry(int lb, int lp, int ls, int index) {return sampler().setActiveListEntry(makeAddress(lb,lp,ls),index)?true:false;}

bool NativeSamplerEngine::nativeActivateListEntry(int lb, int lp, int ls, int index) {return sampler().activateListEntry(makeAddress(lb,lp,ls),index)?true:false;}

int NativeSamplerEngine::nativeActiveListEntry(int lb, int lp, int ls) {return static_cast<int>(sampler().activeListEntry(makeAddress(lb,lp,ls)));}

std::vector<int> NativeSamplerEngine::nativeListEntryNumbers(int lb, int lp, int ls) {return (sampler().listEntryNumbers(makeAddress(lb,lp,ls)));}

std::vector<std::string> NativeSamplerEngine::nativeListEntryNames(int lb, int lp, int ls) {    return sampler().listEntryNames(makeAddress(lb, lp, ls));
}

std::vector<int> NativeSamplerEngine::nativeListEntryCombiAddresses(int lb, int lp, int ls) {return (sampler().listEntryCombiAddresses(makeAddress(lb,lp,ls)));}

bool NativeSamplerEngine::nativeActivateProgram(int bank, int page, int slot, int upper) {return sampler().activateProgram(makeAddress(bank,page,slot),upper)?true:false;}

bool NativeSamplerEngine::nativeAssignUpperSound(int bank, int page, int slot, int upper) {return sampler().activateProgram(makeAddress(bank,page,slot),upper)?true:false;}

bool NativeSamplerEngine::nativeClearUpperSound(int upper) {return sampler().clearUpperSound(upper)?true:false;}

bool NativeSamplerEngine::nativeActivateCombi(int bank, int page, int slot) {return sampler().activateCombi(makeAddress(bank,page,slot))?true:false;}

bool NativeSamplerEngine::nativeClearProgram(int bank, int page, int slot) {return sampler().clearProgram(makeAddress(bank,page,slot))?true:false;}

bool NativeSamplerEngine::nativeClearCombi(int bank, int page, int slot) {return sampler().clearCombi(makeAddress(bank,page,slot))?true:false;}

bool NativeSamplerEngine::nativeClearList(int bank, int page, int slot) {return sampler().clearList(makeAddress(bank,page,slot))?true:false;}

void NativeSamplerEngine::setBackends(std::unique_ptr<AudioOutput> audio, std::unique_ptr<MidiInput> midi) {
    if (audio) sampler().setAudioOutput(std::move(audio));
    if (midi) sampler().setMidiInput(std::move(midi));
}
std::string NativeSamplerEngine::audioDeviceName() { return sampler().audioDeviceName(); }
std::vector<std::string> NativeSamplerEngine::midiSourceNames() { return sampler().midiSourceNames(); }

} // namespace silveton::host
