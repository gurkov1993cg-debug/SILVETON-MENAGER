// SILVETON_MAC_VIEW_V1 - WRITE / COPY / MOVE, Korg style (tablet SilvetonSamplerView.kt lines 2335-2580)
#include "silveton/ui/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui {

namespace {
std::string pad3(long long v) { return fmtZeroPad(v, 3); }
} // namespace

void SilvetonSamplerView::openWrite(WriteTarget target, bool append) {
    writeMode = WriteMode::WRITE;
    writeSource = -1;
    writeList = sampler.listItems(0, 0, 0);
    writeBlends.clear();
    for (const auto& kv : sampler.combiCatalog()) writeBlends[kv.first] = kv.second;
    writeName = sampler.combiName();
    selectWriteTarget(target, append);
    writeOpen = true;
    invalidate();
}

/** COPY / MOVE a LIST position to any position 1..200 chosen on the same screen. */
void SilvetonSamplerView::openPositionPicker(WriteMode mode, int source) {
    writeMode = mode;
    writeSource = source;
    writeTarget = WriteTarget::LIST;
    writeList = sampler.listItems(0, 0, 0);
    writeBlends.clear();
    for (const auto& kv : sampler.combiCatalog()) writeBlends[kv.first] = kv.second;
    writeName = writeListName(source).value_or("");
    writeSelected = firstFreeListPosition(source);
    writePage = writeSelected >= 0 ? writeSelected / 10 : source / 10;
    writeOpen = true;
    invalidate();
}

std::optional<std::string> SilvetonSamplerView::writeListName(int pos) {
    if (pos < 0 || pos >= static_cast<int>(writeList.size())) return std::nullopt;
    const ListItem& it = writeList[static_cast<std::size_t>(pos)];
    if (sampler.isEmptyListItem(it)) return std::nullopt;
    return it.name;
}

int SilvetonSamplerView::firstFreeListPosition(int after) {
    for (int k = 0; k < 200; ++k) {
        const int pos = (after + 1 + k) % 200;
        if (pos != writeSource && !writeListName(pos)) return pos;
    }
    return -1;
}

void SilvetonSamplerView::selectWriteTarget(WriteTarget target, bool append) {
    writeTarget = target;
    if (target == WriteTarget::LIST) {
        if (!append && writeListName(loadedFromList)) {
            writeSelected = loadedFromList;
        } else {
            writeSelected = -1;
            for (int i = 0; i < 200; ++i) if (!writeListName(i)) { writeSelected = i; break; }
        }
    } else {
        const std::optional<int> own = editingCombiSlot;
        if (!append && own && *own >= 1 && *own <= 500) {
            writeSelected = *own - 1;
        } else {
            int first = 0;
            for (int s = 1; s <= 500; ++s) if (writeBlends.count(s) == 0) { first = s; break; }
            writeSelected = first - 1;
        }
    }
    writePage = writeSelected >= 0 ? writeSelected / 10 : 0;
}

std::optional<std::string> SilvetonSamplerView::writeOccupiedName(int pos) {
    if (writeTarget == WriteTarget::LIST) return writeListName(pos);
    const auto it = writeBlends.find(pos + 1);
    if (it == writeBlends.end()) return std::nullopt;
    return it->second;
}

void SilvetonSamplerView::drawWriteScreen(Canvas& c) {
    fill(c, RectF(0.0F, 0.0F, DESIGN_W, DESIGN_H), 0.0F, Color::argb(170, 0, 0, 0));
    // Modal background: swallows touches outside the panel.
    hit(RectF(0.0F, 0.0F, DESIGN_W, DESIGN_H), [](float, float) {});
    const RectF p(150.0F, 30.0F, 1290.0F, 770.0F);
    board(c, p);
    const bool picking = writeMode != WriteMode::WRITE;
    const std::string title = writeMode == WriteMode::WRITE ? "WRITE" : (writeMode == WriteMode::COPY ? "COPY" : "MOVE");
    text(c, title, p.left + 30.0F, p.top + 50.0F, 28.0F, C_VALUE, Opt().monoBold().spacing(0.1F));
    text(c, picking ? "Избери къде да отиде. Заета позиция може да се презапише, другите не мърдат."
                    : "Избери място. Заетите позиции могат да се презапишат.",
         p.left + 32.0F, p.top + 76.0F, 13.0F, C_KNOB_LABEL, Opt().maxW(p.width() - 360.0F));

    if (!picking) {
        const RectF tl(p.right - 300.0F, p.top + 22.0F, p.right - 160.0F, p.top + 64.0F);
        const RectF tb(p.right - 150.0F, p.top + 22.0F, p.right - 30.0F, p.top + 64.0F);
        segKey(c, tl, "ЛИСТ", writeTarget == WriteTarget::LIST);
        segKey(c, tb, "BLENDS", writeTarget == WriteTarget::BLEND);
        hit(tl, [this](float, float) { if (writeTarget != WriteTarget::LIST) selectWriteTarget(WriteTarget::LIST, false); });
        hit(tb, [this](float, float) { if (writeTarget != WriteTarget::BLEND) selectWriteTarget(WriteTarget::BLEND, false); });
    }

    text(c, picking ? "ОТ" : "ИМЕ", p.left + 30.0F, p.top + 127.0F, 12.0F, C_SECTION_TITLE, Opt().spacing(0.25F));
    const RectF nameR(p.left + 90.0F, p.top + 92.0F, p.right - 180.0F, p.top + 148.0F);
    lcd(c, nameR);
    const std::string nameText = picking ? pad3(writeSource + 1) + "  " + writeName : writeName;
    text(c, nameText, nameR.left + 16.0F, nameR.centerY() + 10.0F, 28.0F, C_LCD, Opt().mono().maxW(nameR.width() - 32.0F));
    if (!picking) {
        const RectF renR(p.right - 166.0F, p.top + 98.0F, p.right - 30.0F, p.top + 142.0F);
        lightKey(c, renR, "RENAME");
        const auto rename = [this]() { showTextPage("RENAME", writeName, [this](const std::string& v) { writeName = v; }); };
        hit(nameR, [rename](float, float) { rename(); });
        hit(renR, [rename](float, float) { rename(); });
    }

    const bool listTarget = writeTarget == WriteTarget::LIST;
    const int pages = listTarget ? 20 : 50;
    const int perRow = listTarget ? 20 : 25;
    const int rows = (pages + perRow - 1) / perRow;
    const float keyH = rows == 1 ? 44.0F : 34.0F;
    const float keyGap = 5.0F;
    const float kx0 = p.left + 30.0F;
    const float kx1 = p.right - 30.0F;
    const float keysTop = p.top + 166.0F;
    const float keyW = (kx1 - kx0 - static_cast<float>(perRow - 1) * keyGap) / static_cast<float>(perRow);
    for (int k = 0; k < pages; ++k) {
        const float row = static_cast<float>(k / perRow);
        const float col = static_cast<float>(k % perRow);
        const RectF kr(kx0 + col * (keyW + keyGap), keysTop + row * (keyH + keyGap),
                       kx0 + col * (keyW + keyGap) + keyW, keysTop + row * (keyH + keyGap) + keyH);
        segKey(c, kr, std::to_string(k + 1), k == writePage, 12.0F, writeSelected >= 0 && writeSelected / 10 == k);
        hit(kr, [this, k](float, float) { writePage = k; });
    }
    const float keysBottom = keysTop + static_cast<float>(rows) * keyH + static_cast<float>(rows - 1) * keyGap;

    const float gridTop = keysBottom + 14.0F;
    const float gridBottom = p.bottom - 92.0F;
    const float gap = 8.0F;
    const float cellH = (gridBottom - gridTop - 4.0F * gap) / 5.0F;
    const float cellW = (kx1 - kx0 - gap) / 2.0F;
    for (int j = 0; j < 10; ++j) {
        const int pos = writePage * 10 + j;
        const float col = static_cast<float>(j % 2);
        const float row = static_cast<float>(j / 2);
        const RectF cell(kx0 + col * (cellW + gap), gridTop + row * (cellH + gap),
                         kx0 + col * (cellW + gap) + cellW, gridTop + row * (cellH + gap) + cellH);
        const bool isSource = picking && pos == writeSource;
        const bool usable = !isSource && (listTarget ? pos < 200 : pos < 500);
        writeCell(c, cell, pos + 1, writeOccupiedName(pos), usable, pos == writeSelected, isSource);
        if (usable) hit(cell, [this, pos](float, float) { writeSelected = pos; });
    }

    const std::string label = listTarget ? "ЛИСТ" : "BLEND";
    const std::optional<std::string> selName = writeSelected >= 0 ? writeOccupiedName(writeSelected) : std::nullopt;
    const std::string action = writeMode == WriteMode::WRITE ? "ЗАПИС" : (writeMode == WriteMode::COPY ? "КОПИРАНЕ" : "МЕСТЕНЕ");
    std::string info;
    if (writeSelected < 0) info = "Избери позиция";
    else if (selName) info = action + ", ПРЕЗАПИС:  " + label + " " + pad3(writeSelected + 1) + "  „" + *selName + "“";
    else info = action + ":  " + label + " " + pad3(writeSelected + 1) + "  (свободна)";
    text(c, info, p.left + 30.0F, p.bottom - 38.0F, 17.0F, selName ? C_VALUE : C_LCD_OK, Opt().bold().maxW(760.0F));

    const RectF cancel(p.right - 330.0F, p.bottom - 70.0F, p.right - 190.0F, p.bottom - 22.0F);
    const RectF write(p.right - 178.0F, p.bottom - 70.0F, p.right - 30.0F, p.bottom - 22.0F);
    lightKey(c, cancel, "CANCEL", true, 14.0F);
    hit(cancel, [this](float, float) { writeOpen = false; });
    accentKey(c, write, title, writeSelected >= 0);
    if (writeSelected >= 0) hit(write, [this](float, float) { confirmWrite(); });
}

void SilvetonSamplerView::writeCell(Canvas& c, const RectF& r, int number, const std::optional<std::string>& name, bool usable, bool selected, bool source) {
    if (selected) fill(c, RectF(r.left - 3.0F, r.top - 3.0F, r.right + 3.0F, r.bottom + 3.0F), 12.0F, C_ACCENT);
    fill(c, r, 10.0F, source ? Color::rgb(96, 84, 64) : (!usable ? Color::rgb(58, 61, 66) : (selected ? Color::WHITE : C_STRIP)));
    if (usable && isDown(r)) fill(c, r, 10.0F, Color::argb(30, 0, 0, 0));
    const RectF box(r.left + 10.0F, r.centerY() - 18.0F, r.left + 80.0F, r.centerY() + 18.0F);
    lcd(c, box, 7.0F);
    text(c, pad3(number), box.centerX(), box.centerY() + 7.0F, 19.0F, (usable || source) ? C_LCD : C_LCD_DIM, Opt().center().mono());
    const float textX = r.left + 94.0F;
    if (source) {
        text(c, name ? *name : std::string(), textX, r.centerY() + 7.0F, 19.0F, Color::WHITE, Opt().bold().maxW(r.width() - 94.0F - 110.0F));
        text(c, "ИЗТОЧНИК", r.right - 14.0F, r.centerY() + 5.0F, 11.0F, C_LCD_OK, Opt().right().bold().spacing(0.15F));
    } else if (!usable) {
        text(c, "—", textX, r.centerY() + 7.0F, 18.0F, Color::rgb(120, 124, 130));
    } else if (name) {
        text(c, *name, textX, r.centerY() + 7.0F, 19.0F, C_INK, Opt().bold().maxW(r.width() - 94.0F - 96.0F));
        text(c, "ЗАЕТО", r.right - 14.0F, r.centerY() + 5.0F, 11.0F, C_ACCENT_DARK, Opt().right().bold().spacing(0.15F));
    } else {
        text(c, "— свободна —", textX, r.centerY() + 7.0F, 17.0F, C_EMPTY_TEXT);
        text(c, "СВОБОДНО", r.right - 14.0F, r.centerY() + 5.0F, 11.0F, C_FREE, Opt().right().bold().spacing(0.15F));
    }
}

void SilvetonSamplerView::confirmWrite() {
    const int pos = writeSelected;
    if (pos < 0) return;
    std::string name = trimmed(writeName);
    if (name.empty()) name = sampler.combiName();
    const WriteMode mode = writeMode;
    const WriteTarget target = writeTarget;
    const int source = writeSource;
    std::function<void()> runIt;
    if (mode == WriteMode::COPY) runIt = [this, source, pos]() { doCopyOrMove(false, source, pos); };
    else if (mode == WriteMode::MOVE) runIt = [this, source, pos]() { doCopyOrMove(true, source, pos); };
    else if (target == WriteTarget::LIST) runIt = [this, pos, name]() { doWriteList(pos, name); };
    else runIt = [this, pos, name]() { doWriteBlend(pos + 1, name); };
    const std::optional<std::string> old = writeOccupiedName(pos);
    if (!old) { runIt(); return; }
    const std::string incoming = mode == WriteMode::WRITE ? name : writeName;
    const std::string label = target == WriteTarget::LIST ? "ЛИСТ" : "BLEND";
    std::string extra;
    if (target == WriteTarget::BLEND) {
        std::string users;
        for (std::size_t i = 0; i < writeList.size(); ++i) {
            const ListItem& it = writeList[i];
            if (it.combiBank == 0 && it.combiPage == 0 && it.combiSlot == pos + 1) {
                if (!users.empty()) users += ", ";
                users += pad3(static_cast<long long>(i) + 1);
            }
        }
        if (!users.empty()) extra = "\nИзползва се и в ЛИСТ: " + users;
    }
    showConfirm("ПРЕЗАПИС  " + label + " " + pad3(pos + 1), "„" + *old + "“ ще бъде заменен с „" + incoming + "“." + extra, "ПРЕЗАПИШИ", runIt, "CANCEL");
}

void SilvetonSamplerView::doWriteList(int pos, const std::string& name) {
    const int index = sampler.writeCombiToList(pos, name);
    if (index < 0) { invalidate(); return; }
    refreshListCache();
    const std::optional<ListItem> item = realListItem(index);
    if (item && item->combiBank == 0 && item->combiPage == 0) editingCombiSlot = item->combiSlot;
    loadedFromList = index;
    listFollowedActive = cachedActiveListEntry;
    listPage = std::clamp(index / LIST_PER_PAGE, 0, LIST_PAGES - 1);
    cachedCombiName = sampler.combiName();
    refreshAllUppers();
    refreshFx();
    writeOpen = false;
    page_ = Page::LIST;
    flash("ЗАПИСАНО: ЛИСТ " + pad3(index + 1));
}

void SilvetonSamplerView::doWriteBlend(int slot, const std::string& name) {
    if (!sampler.writeCombiSlot(slot, name)) { invalidate(); return; }
    editingCombiSlot = slot;
    loadedFromList = -1;
    cachedCombiName = sampler.combiName();
    refreshAllUppers();
    refreshFx();
    refreshListCache();
    writeOpen = false;
    flash("ЗАПИСАНО: BLEND " + pad3(slot));
}

void SilvetonSamplerView::doCopyOrMove(bool move, int from, int to) {
    const bool ok = move ? sampler.moveListEntryTo(from, to) : sampler.copyListEntryTo(from, to);
    if (!ok) { invalidate(); return; }
    if (move && loadedFromList == from) loadedFromList = to;
    else if (loadedFromList == to) loadedFromList = -1;
    refreshListCache();
    listFollowedActive = realListItem(cachedActiveListEntry) ? cachedActiveListEntry : -1;
    listPage = std::clamp(to / LIST_PER_PAGE, 0, LIST_PAGES - 1);
    writeOpen = false;
    page_ = Page::LIST;
    flash(std::string(move ? "ПРЕМЕСТЕНО: ЛИСТ " : "КОПИРАНО: ЛИСТ ") + pad3(to + 1));
}

} // namespace silveton::ui
