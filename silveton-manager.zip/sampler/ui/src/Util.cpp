// SILVETON_MAC_GFX_V1 - UTF-8 helpers and the PNG writer.
#include "FontInternal.h"

#include <cstdio>

namespace silveton::ui {

int utf8Length(const std::string& s) {
    int n = 0;
    for (const char ch : s) if ((static_cast<unsigned char>(ch) & 0xC0U) != 0x80U) ++n;
    return n;
}

std::string utf8Substring(const std::string& s, int from, int to) {
    const auto cps = detail::decodeUtf8(s);
    const auto f = static_cast<std::size_t>(std::max(0, from));
    const auto t = static_cast<std::size_t>(std::max(0, to));
    return detail::encodeUtf8(cps, f, t);
}

std::string utf8Prefix(const std::string& s, int codePoints) { return utf8Substring(s, 0, codePoints); }

std::string utf8Upper(const std::string& s) {
    auto cps = detail::decodeUtf8(s);
    for (auto& c : cps) {
        if (c >= 'a' && c <= 'z') c -= 32U;
        else if (c >= 0xE0U && c <= 0xFEU && c != 0xF7U) c -= 32U;           // Latin-1 letters
        else if (c >= 0x430U && c <= 0x44FU) c -= 32U;                       // Cyrillic а..я
        else if (c >= 0x450U && c <= 0x45FU) c -= 80U;                       // Cyrillic ѐ..џ
    }
    return detail::encodeUtf8(cps, 0U, cps.size());
}

namespace {

std::uint32_t crc32(const unsigned char* data, std::size_t n, std::uint32_t crc = 0U) {
    static std::uint32_t table[256];
    static bool ready = false;
    if (!ready) {
        for (std::uint32_t i = 0U; i < 256U; ++i) {
            std::uint32_t c = i;
            for (int k = 0; k < 8; ++k) c = (c & 1U) != 0U ? (0xEDB88320U ^ (c >> 1U)) : (c >> 1U);
            table[i] = c;
        }
        ready = true;
    }
    crc = ~crc;
    for (std::size_t i = 0U; i < n; ++i) crc = table[(crc ^ data[i]) & 0xFFU] ^ (crc >> 8U);
    return ~crc;
}

void put32(std::vector<unsigned char>& v, std::uint32_t x) {
    v.push_back(static_cast<unsigned char>(x >> 24U));
    v.push_back(static_cast<unsigned char>(x >> 16U));
    v.push_back(static_cast<unsigned char>(x >> 8U));
    v.push_back(static_cast<unsigned char>(x));
}

void chunk(std::vector<unsigned char>& out, const char* type, const std::vector<unsigned char>& body) {
    put32(out, static_cast<std::uint32_t>(body.size()));
    std::vector<unsigned char> tb(type, type + 4);
    tb.insert(tb.end(), body.begin(), body.end());
    out.insert(out.end(), tb.begin(), tb.end());
    put32(out, crc32(tb.data(), tb.size()));
}

bool writePngPixels(const std::string& path, int w, int h, const std::uint32_t* px) {
    if (w <= 0 || h <= 0) return false;
    // raw scanlines: filter byte 0 + RGB, over an opaque black background
    std::vector<unsigned char> raw;
    raw.reserve(static_cast<std::size_t>(h) * (static_cast<std::size_t>(w) * 3U + 1U));
    for (int y = 0; y < h; ++y) {
        raw.push_back(0);
        for (int x = 0; x < w; ++x) {
            const std::uint32_t p = px[static_cast<std::size_t>(y) * static_cast<std::size_t>(w) + static_cast<std::size_t>(x)];
            raw.push_back(static_cast<unsigned char>((p >> 16U) & 255U));
            raw.push_back(static_cast<unsigned char>((p >> 8U) & 255U));
            raw.push_back(static_cast<unsigned char>(p & 255U));
        }
    }
    // zlib stream with stored (uncompressed) blocks
    std::vector<unsigned char> z{0x78, 0x01};
    std::size_t pos = 0U;
    while (pos < raw.size()) {
        const std::size_t n = std::min<std::size_t>(65535U, raw.size() - pos);
        const bool last = pos + n >= raw.size();
        z.push_back(last ? 1 : 0);
        z.push_back(static_cast<unsigned char>(n & 255U));
        z.push_back(static_cast<unsigned char>(n >> 8U));
        z.push_back(static_cast<unsigned char>(~n & 255U));
        z.push_back(static_cast<unsigned char>((~n >> 8U) & 255U));
        z.insert(z.end(), raw.begin() + static_cast<std::ptrdiff_t>(pos), raw.begin() + static_cast<std::ptrdiff_t>(pos + n));
        pos += n;
    }
    std::uint32_t a = 1U, b = 0U;
    for (const unsigned char c : raw) { a = (a + c) % 65521U; b = (b + a) % 65521U; }
    put32(z, (b << 16U) | a);

    std::vector<unsigned char> out{0x89, 'P', 'N', 'G', 0x0D, 0x0A, 0x1A, 0x0A};
    std::vector<unsigned char> ihdr;
    put32(ihdr, static_cast<std::uint32_t>(w));
    put32(ihdr, static_cast<std::uint32_t>(h));
    ihdr.push_back(8); ihdr.push_back(2); ihdr.push_back(0); ihdr.push_back(0); ihdr.push_back(0);
    chunk(out, "IHDR", ihdr);
    chunk(out, "IDAT", z);
    chunk(out, "IEND", {});
    std::FILE* f = std::fopen(path.c_str(), "wb");
    if (f == nullptr) return false;
    const bool ok = std::fwrite(out.data(), 1U, out.size(), f) == out.size();
    std::fclose(f);
    return ok;
}

} // namespace

bool writePng(const std::string& path, const Canvas& canvas) { return writePngPixels(path, canvas.width(), canvas.height(), canvas.pixels()); }
bool writePng(const std::string& path, const Image& image) { return writePngPixels(path, image.width, image.height, image.pixels.data()); }

} // namespace silveton::ui
