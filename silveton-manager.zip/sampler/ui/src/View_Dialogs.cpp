// SILVETON_MAC_VIEW_V1 - dialogs: the tablet's Android dialogs as modal overlays (tablet SilvetonSamplerView.kt lines 2932-3261)
#include "silveton/ui/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui {

namespace {
constexpr ColorInt D_BACK = Color::argb(194, 0, 0, 0);               // setDimAmount(0.76)
constexpr ColorInt D_CARD = Color::rgb(20, 24, 29);
constexpr ColorInt D_CARD_EDGE = Color::rgb(68, 84, 102);
constexpr ColorInt D_KEY = Color::rgb(44, 50, 58);
constexpr ColorInt D_KEY_EDGE = Color::rgb(78, 88, 100);
constexpr ColorInt D_SUB = Color::rgb(135, 151, 168);
constexpr ColorInt D_LABEL = Color::rgb(158, 170, 184);
constexpr ColorInt D_FIELD = Color::rgb(31, 36, 43);
constexpr ColorInt D_FIELD_EDGE = Color::rgb(72, 87, 104);
constexpr ColorInt D_SELECTED = Color::rgb(52, 168, 96);      // SILVETON_SERIOUS_V1: chosen = green, like every "on"
constexpr ColorInt D_SELECTED_TEXT = Color::WHITE;
constexpr ColorInt D_MESSAGE = Color::rgb(214, 220, 228);

void strokeRound(Canvas& c, const RectF& r, float radius, ColorInt color, float w) {
    Paint p;
    p.style = Style::Stroke;
    p.strokeWidth = w;
    p.color = color;
    c.drawRoundRect(RectF(r.left + w * 0.5F, r.top + w * 0.5F, r.right - w * 0.5F, r.bottom - w * 0.5F), radius, radius, p);
}

RectF intersect(const RectF& a, const RectF& b) {
    return RectF(std::max(a.left, b.left), std::max(a.top, b.top), std::min(a.right, b.right), std::min(a.bottom, b.bottom));
}

float clampF(float v, float lo, float hi) { return std::min(std::max(v, lo), hi); }
} // namespace

// ---------------------------------------------------------------- public entry points
void SilvetonSamplerView::keyDown(Key key) {
    if (dialogIsOpen()) dialogKey(key);
}

void SilvetonSamplerView::typeText(const std::string& utf8) {
    if (dialogIsOpen()) dialogType(utf8);
}

void SilvetonSamplerView::wheel(float rawX, float rawY, float dy) {
    const float x = (rawX - uiOffsetX) / uiScale;
    const float y = (rawY - uiOffsetY) / uiScale;
    if (dialogIsOpen()) dialogWheel(x, y, dy);
}

// ---------------------------------------------------------------- stack
void SilvetonSamplerView::closeDialog(const std::shared_ptr<Dialog>& d) {
    const auto it = std::find(dialogStack.begin(), dialogStack.end(), d);
    if (it != dialogStack.end()) dialogStack.erase(it);
    invalidate();
}

void SilvetonSamplerView::dialogFire(const std::shared_ptr<Dialog>& d, const std::function<void()>& action) {
    const std::shared_ptr<Dialog> keep = d;
    closeDialog(keep);
    if (action) action();
    invalidate();
}

void SilvetonSamplerView::dialogCancel(const std::shared_ptr<Dialog>& d) {
    if (d->kind == Dialog::Kind::Wait || !d->cancelable) return;
    const std::shared_ptr<Dialog> keep = d;
    closeDialog(keep);
    if (keep->onCancel) keep->onCancel();
    invalidate();
}

// ---------------------------------------------------------------- small helpers
std::vector<std::string> SilvetonSamplerView::wrapLines(const std::string& s, float size, Face face, float maxW) {
    std::vector<std::string> out;
    for (const std::string& para : splitChar(s, '\n')) {
        if (para.empty()) { out.emplace_back(); continue; }
        std::string cur;
        auto pushLong = [&](std::string w) {
            while (textWidth(w, size, face) > maxW) {
                const int n = utf8Length(w);
                int k = n;
                while (k > 1 && textWidth(utf8Prefix(w, k), size, face) > maxW) --k;
                if (k >= n) break;
                out.push_back(utf8Prefix(w, k));
                w = utf8Substring(w, k, n);
            }
            cur = w;
        };
        for (const std::string& word : splitChar(para, ' ')) {
            if (cur.empty()) {
                if (textWidth(word, size, face) > maxW) pushLong(word); else cur = word;
            } else {
                const std::string trial = cur + " " + word;
                if (textWidth(trial, size, face) <= maxW) {
                    cur = trial;
                } else {
                    out.push_back(cur);
                    cur.clear();
                    if (textWidth(word, size, face) > maxW) pushLong(word); else cur = word;
                }
            }
        }
        out.push_back(cur);
    }
    return out;
}

void SilvetonSamplerView::dialogCard(Canvas& c, const RectF& r) {
    shadow(c, r, 16.0F, 6.0F, 120);
    fill(c, r, 16.0F, D_CARD);
    strokeRound(c, r, 16.0F, D_CARD_EDGE, 1.0F);
}

void SilvetonSamplerView::dialogKeyCap(Canvas& c, const RectF& r, const std::string& label, bool selected, float size, bool pressed, bool leftAligned) {
    fill(c, r, 10.0F, selected ? D_SELECTED : D_KEY);
    strokeRound(c, r, 10.0F, D_KEY_EDGE, 1.0F);
    if (pressed) fill(c, r, 10.0F, Color::argb(90, 0, 0, 0));
    const ColorInt col = selected ? D_SELECTED_TEXT : Color::WHITE;
    if (leftAligned) text(c, label, r.left + 14.0F, r.centerY() + size * 0.36F, size, col, Opt().bold().maxW(r.width() - 28.0F));
    else text(c, label, r.centerX(), r.centerY() + size * 0.36F, size, col, Opt().center().bold().maxW(r.width() - 16.0F));
}

void SilvetonSamplerView::dialogHeadText(Canvas& c, const RectF& card, float top, float titleSize, const std::string& title, const std::string& subtitle) {
    text(c, title, card.left + 28.0F, top + titleSize * 0.95F, titleSize, Color::WHITE, Opt().bold().maxW(card.width() - 56.0F));
    if (!subtitle.empty()) {
        const float size = 13.0F;
        float y = top + titleSize * 1.2F + 4.0F + 12.0F;
        for (const std::string& line : wrapLines(subtitle, size, Face::Regular, card.width() - 56.0F)) {
            text(c, line, card.left + 28.0F, y, size, D_SUB);
            y += 17.0F;
        }
    }
}

// The buttons at the bottom, right aligned (left to right as in the list).
void SilvetonSamplerView::dialogButtonRow(Canvas& c, const std::shared_ptr<Dialog>& d, const RectF& card, float top) {
    float right = card.right - 28.0F;
    for (int i = static_cast<int>(d->buttons.size()) - 1; i >= 0; --i) {
        const DialogButton& b = d->buttons[static_cast<std::size_t>(i)];
        const float w = std::max(120.0F, textWidth(b.label, 15.0F, Face::Bold) + 44.0F);
        const RectF r(right - w, top, right, top + 48.0F);
        const bool primary = i == static_cast<int>(d->buttons.size()) - 1 && d->buttons.size() > 1;
        // the main key is green; a key that deletes something is red, so the hand stops before it
        const bool destructive = b.label.find("DELETE") != std::string::npos || b.label.find("ИЗТРИЙ") != std::string::npos || b.label.find("МАХНИ") != std::string::npos;
        fill(c, r, 10.0F, primary ? (destructive ? Color::rgb(198, 52, 44) : D_SELECTED) : D_KEY);
        strokeRound(c, r, 10.0F, primary ? (destructive ? Color::rgb(140, 28, 22) : Color::rgb(30, 118, 64)) : D_KEY_EDGE, 1.0F);
        if (isDown(r)) fill(c, r, 10.0F, Color::argb(90, 0, 0, 0));
        text(c, b.label, r.centerX(), r.centerY() + 5.5F, 15.0F, Color::WHITE, Opt().center().bold().maxW(w - 16.0F));
        const std::function<void()> act = b.action;
        hit(r, [this, d, act](float, float) { dialogFire(d, act); });
        right -= w + 8.0F;
    }
}

// ---------------------------------------------------------------- draw
void SilvetonSamplerView::drawDialogs(Canvas& c) {
    if (dialogStack.empty()) return;
    const std::shared_ptr<Dialog> d = dialogStack.back();
    fill(c, RectF(0.0F, 0.0F, DESIGN_W, DESIGN_H), 0.0F, D_BACK);
    // a click outside the card = cancel (as on the tablet), except the pages where typed work could be lost
    const bool outsideCancels = d->cancelable && d->kind != Dialog::Kind::Wait && d->kind != Dialog::Kind::Text && d->kind != Dialog::Kind::Number;
    hit(RectF(0.0F, 0.0F, DESIGN_W, DESIGN_H), [this, d, outsideCancels](float, float) { if (outsideCancels) dialogCancel(d); });
    switch (d->kind) {
        case Dialog::Kind::Message:
        case Dialog::Kind::Wait: drawDialogMessage(c, d); break;
        case Dialog::Kind::Items:
        case Dialog::Kind::Multi: drawDialogList(c, d); break;
        case Dialog::Kind::Grid: drawDialogGrid(c, d); break;
        case Dialog::Kind::Text:
        case Dialog::Kind::Number: drawDialogEditor(c, d); break;
    }
}

void SilvetonSamplerView::drawDialogMessage(Canvas& c, const std::shared_ptr<Dialog>& d) {
    const float w = 640.0F;
    const std::vector<std::string> lines = wrapLines(d->message, 16.0F, Face::Regular, w - 56.0F);
    const float h = 24.0F + 30.0F + 14.0F + static_cast<float>(lines.size()) * 23.0F + 22.0F + (d->buttons.empty() ? 0.0F : 48.0F + 22.0F) + 24.0F;
    const RectF card((DESIGN_W - w) * 0.5F, (DESIGN_H - h) * 0.5F, (DESIGN_W + w) * 0.5F, (DESIGN_H + h) * 0.5F);
    dialogCard(c, card);
    hit(card, [](float, float) {});
    text(c, d->title, card.left + 28.0F, card.top + 24.0F + 22.0F, 22.0F, Color::WHITE, Opt().bold().maxW(w - 56.0F));
    float y = card.top + 24.0F + 30.0F + 14.0F + 16.0F;
    for (const std::string& line : lines) {
        text(c, line, card.left + 28.0F, y, 16.0F, D_MESSAGE);
        y += 23.0F;
    }
    if (d->kind == Dialog::Kind::Wait) {
        // a small moving bar so that you see the program is working
        const RectF bar(card.left + 28.0F, card.bottom - 40.0F, card.right - 28.0F, card.bottom - 32.0F);
        fill(c, bar, 4.0F, Color::rgb(40, 46, 54));
        const float t = static_cast<float>((nowMs() % 1400)) / 1400.0F;
        const float bw = bar.width() * 0.25F;
        const float x0 = bar.left + (bar.width() - bw) * (0.5F - 0.5F * std::cos(t * 6.2831853F));
        fill(c, RectF(x0, bar.top, x0 + bw, bar.bottom), 4.0F, C_ACCENT);
    } else {
        dialogButtonRow(c, d, card, card.bottom - 24.0F - 48.0F);
    }
}

void SilvetonSamplerView::drawDialogList(Canvas& c, const std::shared_ptr<Dialog>& d) {
    const bool multi = d->kind == Dialog::Kind::Multi;
    const float w = multi ? 780.0F : 560.0F;
    const float rowH = multi ? 46.0F : 56.0F;
    const int n = static_cast<int>(d->items.size());
    const int visible = std::min(n, multi ? 9 : 8);
    const int maxScroll = std::max(0, n - visible);
    d->scroll = std::clamp(d->scroll, 0, maxScroll);
    const float listH = static_cast<float>(visible) * rowH;
    const float h = 24.0F + 30.0F + 14.0F + listH + 22.0F + 48.0F + 24.0F;
    const RectF card((DESIGN_W - w) * 0.5F, (DESIGN_H - h) * 0.5F, (DESIGN_W + w) * 0.5F, (DESIGN_H + h) * 0.5F);
    dialogCard(c, card);
    hit(card, [](float, float) {});
    text(c, d->title, card.left + 28.0F, card.top + 24.0F + 22.0F, multi ? 19.0F : 22.0F, Color::WHITE, Opt().bold().maxW(w - 56.0F));
    const float listTop = card.top + 24.0F + 30.0F + 14.0F;
    const bool scrolls = n > visible;
    const RectF list(card.left + 20.0F, listTop, card.right - 20.0F - (scrolls ? 52.0F : 0.0F), listTop + listH);
    for (int i = 0; i < visible; ++i) {
        const int idx = d->scroll + i;
        const RectF row(list.left, list.top + static_cast<float>(i) * rowH, list.right, list.top + static_cast<float>(i + 1) * rowH);
        if (i > 0) line(c, row.left + 8.0F, row.top, row.right - 8.0F, row.top, Color::argb(36, 255, 255, 255), 1.0F);
        if (isDown(row)) fill(c, row, 6.0F, Color::argb(36, 255, 255, 255));
        const std::string& label = d->items[static_cast<std::size_t>(idx)];
        if (multi) {
            const bool on = idx < static_cast<int>(d->checked.size()) && d->checked[static_cast<std::size_t>(idx)];
            const RectF box(row.left + 14.0F, row.centerY() - 13.0F, row.left + 40.0F, row.centerY() + 13.0F);
            fill(c, box, 5.0F, on ? C_ACCENT : D_FIELD);
            strokeRound(c, box, 5.0F, on ? C_ACCENT : D_KEY_EDGE, 1.5F);
            if (on) {
                line(c, box.left + 6.0F, box.centerY() + 1.0F, box.left + 11.5F, box.bottom - 7.0F, Color::WHITE, 3.0F);
                line(c, box.left + 11.5F, box.bottom - 7.0F, box.right - 5.0F, box.top + 7.0F, Color::WHITE, 3.0F);
            }
            text(c, label, row.left + 54.0F, row.centerY() + 5.5F, 15.0F, Color::WHITE, Opt().maxW(row.width() - 68.0F));
            hit(row, [this, d, idx](float, float) {
                if (idx < static_cast<int>(d->checked.size())) d->checked[static_cast<std::size_t>(idx)] = !d->checked[static_cast<std::size_t>(idx)];
                invalidate();
            });
        } else {
            text(c, label, row.left + 16.0F, row.centerY() + 6.0F, 17.0F, Color::WHITE, Opt().maxW(row.width() - 32.0F));
            const std::function<void(int)> pick = d->onItem;
            hit(row, [this, d, pick, idx](float, float) { dialogFire(d, [pick, idx] { if (pick) pick(idx); }); });
        }
    }
    if (scrolls) {
        const RectF up(list.right + 8.0F, list.top, list.right + 52.0F, list.top + 44.0F);
        const RectF down(list.right + 8.0F, list.bottom - 44.0F, list.right + 52.0F, list.bottom);
        dialogKeyCap(c, up, "▲", false, 14.0F, isDown(up));
        dialogKeyCap(c, down, "▼", false, 14.0F, isDown(down));
        hit(up, [this, d](float, float) { d->scroll = std::max(0, d->scroll - 1); invalidate(); });
        hit(down, [this, d, maxScroll](float, float) { d->scroll = std::min(maxScroll, d->scroll + 1); invalidate(); });
        const RectF track(up.centerX() - 3.0F, up.bottom + 8.0F, up.centerX() + 3.0F, down.top - 8.0F);
        fill(c, track, 3.0F, Color::rgb(40, 46, 54));
        const float th = std::max(24.0F, track.height() * static_cast<float>(visible) / static_cast<float>(n));
        const float ty = track.top + (track.height() - th) * (maxScroll > 0 ? static_cast<float>(d->scroll) / static_cast<float>(maxScroll) : 0.0F);
        fill(c, RectF(track.left, ty, track.right, ty + th), 3.0F, D_KEY_EDGE);
    }
    dialogButtonRow(c, d, card, card.bottom - 24.0F - 48.0F);
}

void SilvetonSamplerView::drawDialogGrid(Canvas& c, const std::shared_ptr<Dialog>& d) {
    const int perPage = 20;
    const int count = static_cast<int>(d->gridItems.size());
    const int pages = std::max(1, (count + perPage - 1) / perPage);
    d->gridPage = std::clamp(d->gridPage, 0, pages - 1);
    const float w = DESIGN_W * 0.92F;
    const float pad = 20.0F;
    const float cellH = 64.0F;
    const float h = 16.0F + 52.0F + 10.0F + 52.0F + 10.0F + 5.0F * (cellH + 8.0F) + 16.0F;
    const RectF card((DESIGN_W - w) * 0.5F, (DESIGN_H - h) * 0.5F, (DESIGN_W + w) * 0.5F, (DESIGN_H + h) * 0.5F);
    dialogCard(c, card);
    hit(card, [](float, float) {});
    const float innerL = card.left + pad;
    const float innerR = card.right - pad;
    // head: title and the keys on the right
    const float headTop = card.top + 16.0F;
    float right = innerR;
    {
        const float cw = std::max(110.0F, textWidth("CANCEL", 16.0F, Face::Bold) + 28.0F);
        const RectF r(right - cw, headTop, right, headTop + 52.0F);
        dialogKeyCap(c, r, "CANCEL", false, 16.0F, isDown(r));
        hit(r, [this, d](float, float) { dialogFire(d, nullptr); });
        right -= cw + 8.0F;
    }
    if (d->hasExtra) {
        const float cw = std::max(110.0F, textWidth(d->gridExtra, 16.0F, Face::Bold) + 28.0F);
        const RectF r(right - cw, headTop, right, headTop + 52.0F);
        dialogKeyCap(c, r, d->gridExtra, false, 16.0F, isDown(r));
        const std::function<void(int)> pick = d->onPick;
        hit(r, [this, d, pick](float, float) { dialogFire(d, [pick] { if (pick) pick(-1); }); });
        right -= cw + 8.0F;
    }
    text(c, d->title, innerL, headTop + 34.0F, 22.0F, Color::WHITE, Opt().bold().maxW(right - innerL - 12.0F));

    // page keys (a strip that can be wider than the card: arrows and the wheel move it)
    const float pageTop = headTop + 52.0F + 10.0F;
    std::vector<float> keyW(static_cast<std::size_t>(pages));
    float total = 0.0F;
    for (int pg = 0; pg < pages; ++pg) {
        keyW[static_cast<std::size_t>(pg)] = std::max(56.0F, textWidth(std::to_string(pg + 1), 15.0F, Face::Bold) + 28.0F);
        total += keyW[static_cast<std::size_t>(pg)] + 8.0F;
    }
    const bool overflow = total > innerR - innerL;
    const float viewL = overflow ? innerL + 48.0F : innerL;
    const float viewR = overflow ? innerR - 48.0F : innerR;
    const float maxScroll = std::max(0.0F, total - (viewR - viewL));
    if (d->followPage) {
        float x0 = 0.0F;
        for (int pg = 0; pg < d->gridPage; ++pg) x0 += keyW[static_cast<std::size_t>(pg)] + 8.0F;
        const float x1 = x0 + keyW[static_cast<std::size_t>(d->gridPage)] + 8.0F;
        if (x0 < d->pageScroll) d->pageScroll = x0;
        if (x1 > d->pageScroll + (viewR - viewL)) d->pageScroll = x1 - (viewR - viewL);
        d->followPage = false;
    }
    d->pageScroll = clampF(d->pageScroll, 0.0F, maxScroll);
    const RectF view(viewL, pageTop, viewR, pageTop + 52.0F);
    if (overflow) {
        const RectF left(innerL, pageTop, innerL + 40.0F, pageTop + 52.0F);
        const RectF rightK(innerR - 40.0F, pageTop, innerR, pageTop + 52.0F);
        dialogKeyCap(c, left, "‹", false, 22.0F, isDown(left));
        dialogKeyCap(c, rightK, "›", false, 22.0F, isDown(rightK));
        hit(left, [this, d](float, float) { d->pageScroll = std::max(0.0F, d->pageScroll - 260.0F); invalidate(); });
        hit(rightK, [this, d, maxScroll](float, float) { d->pageScroll = std::min(maxScroll, d->pageScroll + 260.0F); invalidate(); });
    }
    c.save();
    c.clipRect(RectF(view.left - 1.0F, view.top - 2.0F, view.right + 1.0F, view.bottom + 2.0F));
    float x = viewL - d->pageScroll;
    for (int pg = 0; pg < pages; ++pg) {
        const float kw = keyW[static_cast<std::size_t>(pg)];
        const RectF r(x + 4.0F, pageTop, x + 4.0F + kw, pageTop + 52.0F);
        x += kw + 8.0F;
        if (r.right < view.left || r.left > view.right) continue;
        dialogKeyCap(c, r, std::to_string(pg + 1), pg == d->gridPage, 15.0F, isDown(r));
        const RectF hitR = intersect(r, view);
        if (!hitR.isEmpty()) hit(hitR, [this, d, pg](float, float) { d->gridPage = pg; invalidate(); });
    }
    c.restore();

    // the 4 x 5 grid
    const float gridTop = pageTop + 52.0F + 10.0F;
    const float cellW = (innerR - innerL) / 4.0F;
    for (int row = 0; row < 5; ++row) {
        for (int col = 0; col < 4; ++col) {
            const int idx = d->gridPage * perPage + row * 4 + col;
            if (idx >= count) continue;
            const RectF r(innerL + static_cast<float>(col) * cellW + 4.0F, gridTop + static_cast<float>(row) * (cellH + 8.0F) + 4.0F,
                          innerL + static_cast<float>(col + 1) * cellW - 4.0F, gridTop + static_cast<float>(row) * (cellH + 8.0F) + 4.0F + cellH);
            const bool sel = idx == d->gridCurrent;
            const auto& item = d->gridItems[static_cast<std::size_t>(idx)];
            const std::string label = item.first + "  " + item.second;
            fill(c, r, 10.0F, sel ? D_SELECTED : D_KEY);
            strokeRound(c, r, 10.0F, D_KEY_EDGE, 1.0F);
            if (isDown(r)) fill(c, r, 10.0F, Color::argb(90, 0, 0, 0));
            const ColorInt col2 = sel ? D_SELECTED_TEXT : Color::WHITE;
            const float availW = r.width() - 28.0F;
            std::vector<std::string> lines = wrapLines(label, 16.0F, Face::Bold, availW);
            if (lines.size() == 1U) {
                text(c, lines[0], r.left + 14.0F, r.centerY() + 16.0F * 0.36F, 16.0F, col2, Opt().bold().maxW(availW));
            } else {
                std::string second = lines[1];
                if (lines.size() > 2U) {
                    // the rest does not fit in two lines: the second line ends with "…"
                    std::string rest = lines[1];
                    for (std::size_t k = 2U; k < lines.size(); ++k) rest += " " + lines[k];
                    second = rest;
                }
                text(c, lines[0], r.left + 14.0F, r.centerY() - 2.0F, 16.0F, col2, Opt().bold().maxW(availW));
                text(c, second, r.left + 14.0F, r.centerY() + 17.0F, 16.0F, col2, Opt().bold().maxW(availW));
            }
            const std::function<void(int)> pick = d->onPick;
            hit(r, [this, d, pick, idx](float, float) { dialogFire(d, [pick, idx] { if (pick) pick(idx); }); });
        }
    }
}

void SilvetonSamplerView::drawDialogEditor(Canvas& c, const std::shared_ptr<Dialog>& d) {
    const bool number = d->kind == Dialog::Kind::Number;
    const float w = DESIGN_W * 0.78F;
    const float bodyH = number ? (76.0F + 100.0F) : (31.0F + 56.0F);
    const float keyboardH = softKeyboardHeight(*d);   // 0 when the real keyboard is used
    const float h = 22.0F + 30.0F + 34.0F + bodyH + keyboardH + 20.0F + 48.0F + 22.0F;
    const RectF card((DESIGN_W - w) * 0.5F, (DESIGN_H - h) * 0.5F, (DESIGN_W + w) * 0.5F, (DESIGN_H + h) * 0.5F);
    dialogCard(c, card);
    hit(card, [](float, float) {});
    dialogHeadText(c, card, card.top + 22.0F, 25.0F, d->title, d->subtitle);
    float y = card.top + 22.0F + 30.0F + 34.0F;
    RectF field;
    if (number) {
        field = RectF(card.left + 28.0F, y, card.right - 28.0F, y + 76.0F);
        y += 76.0F;
    } else {
        text(c, "NAME", card.left + 28.0F, y + 10.0F + 12.0F, 12.0F, D_LABEL);
        y += 31.0F;
        field = RectF(card.left + 28.0F, y, card.right - 28.0F, y + 56.0F);
        y += 56.0F;
    }
    fill(c, field, 10.0F, D_FIELD);
    strokeRound(c, field, 10.0F, D_FIELD_EDGE, 1.0F);
    const float size = number ? 40.0F : 22.0F;
    const Face face = number ? Face::Bold : Face::Regular;
    const float innerW = field.width() - 36.0F;
    const float textW = textWidth(d->value, size, face);
    const int len = utf8Length(d->value);
    d->cursor = std::clamp(d->cursor, 0, len);
    const float cursorOff = textWidth(utf8Prefix(d->value, d->cursor), size, face);
    float startX = field.centerX() - textW * 0.5F;
    if (textW > innerW) startX = field.left + 18.0F - std::max(0.0F, cursorOff - innerW + 8.0F);
    const float baseline = field.centerY() + size * 0.36F;
    c.save();
    c.clipRect(RectF(field.left + 4.0F, field.top + 2.0F, field.right - 4.0F, field.bottom - 2.0F));
    if (d->selectAll && len > 0) fill(c, RectF(startX - 2.0F, field.centerY() - size * 0.62F, startX + textW + 2.0F, field.centerY() + size * 0.62F), 4.0F, Color::argb(110, 70, 160, 235));
    text(c, d->value, startX, baseline, size, Color::WHITE, Opt().face(face));
    if (!d->selectAll && (nowMs() / 500) % 2 == 0) {
        const float cx = startX + cursorOff;
        line(c, cx, field.centerY() - size * 0.62F, cx, field.centerY() + size * 0.62F, Color::WHITE, 2.0F);
    }
    c.restore();
    // click in the field = put the cursor there
    hit(field, [this, d, startX, size, face, len](float x, float) {
        d->selectAll = false;
        int best = 0;
        float bestDist = 1e9F;
        for (int k = 0; k <= len; ++k) {
            const float px = startX + textWidth(utf8Prefix(d->value, k), size, face);
            const float dist = std::fabs(px - x);
            if (dist < bestDist) { bestDist = dist; best = k; }
        }
        d->cursor = best;
        invalidate();
    });
    if (number) {
        const float keysTop = y + 12.0F;
        const float half = (field.width() - 16.0F) * 0.5F;
        for (int k = 0; k < 2; ++k) {
            const RectF r(field.left + (k == 0 ? 0.0F : half + 16.0F), keysTop, field.left + (k == 0 ? half : half * 2.0F + 16.0F), keysTop + 84.0F);
            d->stepRect[k] = r;
            const bool pressed = d->repeatDir == (k == 0 ? -1 : 1);
            fill(c, r, 14.0F, D_KEY);
            strokeRound(c, r, 14.0F, D_KEY_EDGE, 1.0F);
            if (pressed) fill(c, r, 14.0F, Color::argb(100, 0, 0, 0));
            text(c, k == 0 ? "−" : "+", r.centerX(), r.centerY() + 40.0F * 0.36F, 40.0F, Color::WHITE, Opt().center().bold());
            hit(r, [](float, float) {});   // the press itself is handled by dialogPointerHook (hold = repeat)
        }
    }
    if (keyboardH > 0.0F) {
        const float bodyEnd = field.bottom + (number ? 100.0F : 0.0F);
        drawSoftKeyboard(c, d, RectF(field.left, bodyEnd + 10.0F, field.right, bodyEnd + keyboardH));
    } else {
        d->kbKeys.clear();
    }
    dialogButtonRow(c, d, card, card.bottom - 22.0F - 48.0F);
}

// ---------------------------------------------------------------- on-screen keyboard
namespace {
constexpr float KB_GAP = 8.0F;
constexpr float KB_ROW_TEXT = 58.0F;
constexpr float KB_ROW_NUMBER = 64.0F;

// the capital of a lower case letter (ASCII and the Cyrillic of the Bulgarian alphabet)
std::string capitalOf(const std::string& ch) {
    if (ch.size() == 1U && ch[0] >= 'a' && ch[0] <= 'z') return std::string(1U, static_cast<char>(ch[0] - 'a' + 'A'));
    if (ch.size() == 2U) {
        const auto b0 = static_cast<unsigned char>(ch[0]);
        const auto b1 = static_cast<unsigned char>(ch[1]);
        if (b0 == 0xD0U && b1 >= 0xB0U && b1 <= 0xBFU) return std::string{static_cast<char>(0xD0), static_cast<char>(b1 - 0x20U)};   // а-п
        if (b0 == 0xD1U && b1 >= 0x80U && b1 <= 0x8FU) return std::string{static_cast<char>(0xD0), static_cast<char>(b1 + 0x20U)};   // р-я
    }
    return ch;
}

} // namespace

float SilvetonSamplerView::softKeyboardHeight(const Dialog& d) const {
    if (!softKeyboard_) return 0.0F;
    if (d.kind == Dialog::Kind::Number) return 10.0F + 2.0F * KB_ROW_NUMBER + KB_GAP;
    if (d.kind == Dialog::Kind::Text) return 10.0F + 5.0F * KB_ROW_TEXT + 4.0F * KB_GAP;
    return 0.0F;
}

bool SilvetonSamplerView::kbShifted(const Dialog& d) const {
    if (d.kbCaps) return true;
    if (d.kbShiftOff) return false;
    if (d.kbShift) return true;
    // the tablet's TYPE_TEXT_FLAG_CAP_SENTENCES: a capital at the start and after ". "
    if (d.selectAll || d.cursor <= 0) return true;
    const std::string before = utf8Prefix(d.value, d.cursor);
    return before.size() >= 2U && before[before.size() - 1U] == ' ' && (before[before.size() - 2U] == '.' || before[before.size() - 2U] == '!' || before[before.size() - 2U] == '?');
}

void SilvetonSamplerView::drawSoftKeyboard(Canvas& c, const std::shared_ptr<Dialog>& d, const RectF& area) {
    d->kbKeys.clear();
    struct Cell { std::string label; KbKey::Act act; float weight; };
    std::vector<std::vector<Cell>> rows;
    float offsets[5] = {0, 0, 0, 0, 0};
    float rowH = KB_ROW_TEXT;
    const float units = 11.0F;
    auto ch = [](const std::string& g) { return Cell{g, KbKey::Act::Char, 1.0F}; };
    auto rowOf = [&](const std::vector<std::string>& glyphs) {
        std::vector<Cell> r;
        for (const std::string& g : glyphs) r.push_back(ch(g));
        return r;
    };
    const bool shifted = kbShifted(*d);
    if (d->kind == Dialog::Kind::Number) {
        rowH = KB_ROW_NUMBER;
        rows.push_back(rowOf({"1", "2", "3", "4", "5", "6", "7", "8", "9", "0"}));
        std::vector<Cell> second;
        if (d->numMin < 0.0F) second.push_back(Cell{"±", KbKey::Act::Sign, 1.5F});
        if (d->numDec > 0) second.push_back(Cell{".", KbKey::Act::Char, 1.5F});
        second.push_back(Cell{"DELETE", KbKey::Act::Backspace, 1.5F});
        second.push_back(Cell{"ИЗЧИСТИ", KbKey::Act::Clear, 2.5F});
        rows.push_back(second);
    } else {
        rows.push_back(rowOf({"1", "2", "3", "4", "5", "6", "7", "8", "9", "0"}));
        offsets[0] = 0.5F;
        if (d->kbLang == 0) {
            rows.push_back(rowOf({"q", "w", "e", "r", "t", "y", "u", "i", "o", "p"}));
            offsets[1] = 0.5F;
            rows.push_back(rowOf({"a", "s", "d", "f", "g", "h", "j", "k", "l"}));
            offsets[2] = 1.0F;
            std::vector<Cell> r3{Cell{"SHIFT", KbKey::Act::Shift, 1.5F}};
            for (const char* g : {"z", "x", "c", "v", "b", "n", "m"}) r3.push_back(ch(g));
            r3.push_back(Cell{"DELETE", KbKey::Act::Backspace, 1.5F});
            rows.push_back(r3);
            offsets[3] = 0.5F;
        } else {   // БДС: у е и ш щ к с д з ц / ь я а о ж г т н в м ч / ю й ъ ф х п р л б
            rows.push_back(rowOf({"у", "е", "и", "ш", "щ", "к", "с", "д", "з", "ц"}));
            offsets[1] = 0.5F;
            rows.push_back(rowOf({"ь", "я", "а", "о", "ж", "г", "т", "н", "в", "м", "ч"}));
            std::vector<Cell> r3{Cell{"SHIFT", KbKey::Act::Shift, 1.0F}};
            for (const char* g : {"ю", "й", "ъ", "ф", "х", "п", "р", "л", "б"}) r3.push_back(ch(g));
            r3.push_back(Cell{"DELETE", KbKey::Act::Backspace, 1.0F});
            rows.push_back(r3);
        }
        std::vector<Cell> r4;
        r4.push_back(Cell{d->kbLang == 0 ? "EN" : "БГ", KbKey::Act::Language, 1.5F});
        r4.push_back(ch("-"));
        r4.push_back(ch(","));
        r4.push_back(Cell{" ", KbKey::Act::Space, 4.5F});
        r4.push_back(ch("."));
        r4.push_back(Cell{"ИЗЧИСТИ", KbKey::Act::Clear, 1.5F});
        rows.push_back(r4);
        offsets[4] = 0.25F;
    }
    // widths: the full line is 11 units (digit rows 10 units + a half unit on both sides)
    const float unit = (area.width() - 10.0F * KB_GAP) / units;
    for (std::size_t row = 0U; row < rows.size(); ++row) {
        float x = area.left + offsets[row] * (unit + KB_GAP);
        if (d->kind == Dialog::Kind::Number) {
            // the number keypad: its own widths, centred (ten digits over the full width, the second line 60 % of it)
            float total = 0.0F;
            for (const Cell& cell : rows[row]) total += cell.weight;
            const float count = static_cast<float>(rows[row].size());
            const float lineW = row == 0U ? area.width() : area.width() * 0.6F;
            const float wide = row == 0U ? (lineW - 9.0F * KB_GAP) / 10.0F : (lineW - (count - 1.0F) * KB_GAP) / total;
            x = area.left + (area.width() - lineW) * 0.5F;
            const float top = area.top + static_cast<float>(row) * (rowH + KB_GAP);
            for (const Cell& cell : rows[row]) {
                const float w = row == 0U ? wide : cell.weight * wide;
                KbKey k;
                k.rect = RectF(x, top, x + w, top + rowH);
                k.act = cell.act;
                k.label = cell.label;
                k.output = cell.label;
                d->kbKeys.push_back(k);
                x += w + KB_GAP;
            }
            continue;
        }
        const float top = area.top + static_cast<float>(row) * (rowH + KB_GAP);
        for (const Cell& cell : rows[row]) {
            const float w = cell.weight * unit + (cell.weight - 1.0F) * KB_GAP;
            KbKey k;
            k.rect = RectF(x, top, x + w, top + rowH);
            k.act = cell.act;
            k.label = cell.label;
            k.output = cell.label;
            if (cell.act == KbKey::Act::Char && shifted) {
                k.label = capitalOf(cell.label);
                k.output = k.label;
            }
            d->kbKeys.push_back(k);
            x += w + KB_GAP;
        }
    }
    for (std::size_t i = 0U; i < d->kbKeys.size(); ++i) {
        const KbKey& k = d->kbKeys[i];
        const bool special = k.act != KbKey::Act::Char && k.act != KbKey::Act::Space;
        const bool lit = k.act == KbKey::Act::Shift && (d->kbCaps || shifted);
        fill(c, k.rect, 10.0F, lit ? D_SELECTED : D_KEY);
        strokeRound(c, k.rect, 10.0F, D_KEY_EDGE, 1.0F);
        if (static_cast<int>(i) == d->kbPressed) fill(c, k.rect, 10.0F, Color::argb(100, 0, 0, 0));
        const float size = k.act == KbKey::Act::Clear ? 13.0F : (d->kind == Dialog::Kind::Number ? 28.0F : (special ? 22.0F : 24.0F));
        const ColorInt col = lit ? D_SELECTED_TEXT : (special ? Color::rgb(200, 206, 214) : Color::WHITE);
        if (k.act == KbKey::Act::Shift) {
            // arrow up (filled when a capital is on), a bar under it for caps lock
            const float cx = k.rect.centerX();
            const float cy = k.rect.centerY() - (d->kbCaps ? 3.0F : 0.0F);
            Path arrow;
            arrow.moveTo(cx, cy - 12.0F);
            arrow.lineTo(cx + 12.0F, cy);
            arrow.lineTo(cx + 5.5F, cy);
            arrow.lineTo(cx + 5.5F, cy + 11.0F);
            arrow.lineTo(cx - 5.5F, cy + 11.0F);
            arrow.lineTo(cx - 5.5F, cy);
            arrow.lineTo(cx - 12.0F, cy);
            arrow.close();
            Paint ap;
            ap.antiAlias = true;
            ap.color = col;
            ap.style = lit ? Style::Fill : Style::Stroke;
            ap.strokeWidth = 2.4F;
            c.drawPath(arrow, ap);
            if (d->kbCaps) line(c, cx - 8.0F, cy + 17.0F, cx + 8.0F, cy + 17.0F, col, 3.0F);
        } else if (k.act == KbKey::Act::Backspace) {
            // the label of a delete key: a tag pointing left with a cross
            const float cx = k.rect.centerX();
            const float cy = k.rect.centerY();
            Path tag;
            tag.moveTo(cx - 17.0F, cy);
            tag.lineTo(cx - 8.0F, cy - 11.0F);
            tag.lineTo(cx + 16.0F, cy - 11.0F);
            tag.lineTo(cx + 16.0F, cy + 11.0F);
            tag.lineTo(cx - 8.0F, cy + 11.0F);
            tag.close();
            Paint tp;
            tp.antiAlias = true;
            tp.color = col;
            tp.style = Style::Stroke;
            tp.strokeWidth = 2.4F;
            c.drawPath(tag, tp);
            line(c, cx - 1.0F, cy - 5.0F, cx + 9.0F, cy + 5.0F, col, 2.4F);
            line(c, cx - 1.0F, cy + 5.0F, cx + 9.0F, cy - 5.0F, col, 2.4F);
        } else if (k.act != KbKey::Act::Space) {
            text(c, k.label, k.rect.centerX(), k.rect.centerY() + size * 0.36F, size, col, Opt().center().bold().maxW(k.rect.width() - 8.0F));
        }
    }
}

int SilvetonSamplerView::kbKeyAt(const Dialog& d, float x, float y) const {
    for (std::size_t i = 0U; i < d.kbKeys.size(); ++i) {
        // the gaps between the keys belong to the nearest key: a finger does not fall through
        const RectF& r = d.kbKeys[i].rect;
        const RectF grown(r.left - KB_GAP * 0.5F, r.top - KB_GAP * 0.5F, r.right + KB_GAP * 0.5F, r.bottom + KB_GAP * 0.5F);
        if (grown.contains(x, y)) return static_cast<int>(i);
    }
    return -1;
}

void SilvetonSamplerView::kbPress(const std::shared_ptr<Dialog>& d, int index) {
    if (index < 0 || index >= static_cast<int>(d->kbKeys.size())) return;
    const KbKey key = d->kbKeys[static_cast<std::size_t>(index)];
    switch (key.act) {
        case KbKey::Act::Char:
            dialogType(key.output);
            d->kbShift = false;
            d->kbShiftOff = false;
            break;
        case KbKey::Act::Space:
            dialogType(" ");
            d->kbShift = false;
            d->kbShiftOff = false;
            break;
        case KbKey::Act::Backspace:
            dialogKey(Key::Backspace);
            break;
        case KbKey::Act::Shift: {
            const std::int64_t now = nowMs();
            if (d->kbCaps) {
                d->kbCaps = false; d->kbShift = false; d->kbShiftOff = true;
            } else if (now - d->kbShiftTapMs < 400) {
                d->kbCaps = true; d->kbShift = false; d->kbShiftOff = false;
            } else if (kbShifted(*d)) {
                d->kbShift = false; d->kbShiftOff = true;
            } else {
                d->kbShift = true; d->kbShiftOff = false;
            }
            d->kbShiftTapMs = now;
            break;
        }
        case KbKey::Act::Language:
            d->kbLang = d->kbLang == 0 ? 1 : 0;
            break;
        case KbKey::Act::Clear:
            d->value.clear();
            d->cursor = 0;
            d->selectAll = false;
            break;
        case KbKey::Act::Sign: {
            if (!d->value.empty() && d->value[0] == '-') {
                d->value.erase(0, 1);
                d->cursor = std::max(0, d->cursor - 1);
            } else {
                d->value.insert(0, "-");
                d->cursor += 1;
            }
            d->selectAll = false;
            break;
        }
    }
    invalidate();
}

// ---------------------------------------------------------------- number page logic
std::string SilvetonSamplerView::numberFormat(const Dialog& d, float value) {
    if (d.numDec <= 0) return toStr(static_cast<long long>(std::nearbyint(value)));
    return trimmed(fmtFixed(static_cast<double>(value), d.numDec));
}

float SilvetonSamplerView::numberTyped(const Dialog& d) const {
    const std::string t = replaceAll(d.value, ",", ".");
    const std::optional<float> v = toFloatOrNull(t);
    return std::clamp(v ? *v : d.numCurrent, d.numMin, d.numMax);
}

void SilvetonSamplerView::numberSetText(Dialog& d, float value) {
    d.value = numberFormat(d, std::clamp(value, d.numMin, d.numMax));
    d.cursor = utf8Length(d.value);
    d.selectAll = false;
}

void SilvetonSamplerView::numberPreview(Dialog& d, float value) {
    if (!d.numLive) return;
    const float v = std::clamp(value, d.numMin, d.numMax);
    if (d.previewed && v == d.lastPreview) return;
    d.lastPreview = v;
    d.previewed = true;
    if (d.numDone) d.numDone(v);
    invalidate();
}

void SilvetonSamplerView::numberStepOnce(Dialog& d, int dir, float mult) {
    const float v = std::clamp(numberTyped(d) + static_cast<float>(dir) * d.numStep * mult, d.numMin, d.numMax);
    numberSetText(d, v);
    numberPreview(d, v);
}

// The - / + keys: first step at once, after 420 ms it repeats every 70 ms, faster the longer you hold (see tickDialogs).
bool SilvetonSamplerView::dialogPointerHook(PointerAction action, float x, float y) {
    if (dialogStack.empty()) return false;
    const std::shared_ptr<Dialog> d = dialogStack.back();
    // the on-screen keyboard: a key works at once when the finger touches it (hold the delete key = repeat)
    if (!d->kbKeys.empty() && (d->kind == Dialog::Kind::Text || d->kind == Dialog::Kind::Number)) {
        switch (action) {
            case PointerAction::Down: {
                const int hitKey = kbKeyAt(*d, x, y);
                if (hitKey >= 0) {
                    d->kbPressed = hitKey;
                    kbPress(d, hitKey);
                    if (d->kbKeys[static_cast<std::size_t>(hitKey)].act == KbKey::Act::Backspace) {
                        d->kbBackHeld = true;
                        d->kbBackCount = 0;
                        d->kbNextBackMs = nowMs() + 420;
                    }
                    invalidate();
                    return true;
                }
                break;
            }
            case PointerAction::Move:
                if (d->kbPressed >= 0) return true;
                break;
            case PointerAction::Up:
            case PointerAction::Cancel:
                if (d->kbPressed >= 0) {
                    d->kbPressed = -1;
                    d->kbBackHeld = false;
                    invalidate();
                    return true;
                }
                break;
        }
    }
    if (d->kind != Dialog::Kind::Number) return false;
    switch (action) {
        case PointerAction::Down:
            for (int k = 0; k < 2; ++k) {
                if (d->stepRect[k].contains(x, y)) {
                    d->repeatDir = k == 0 ? -1 : 1;
                    d->repeatCount = 0;
                    d->nextRepeatMs = nowMs() + 420;
                    numberStepOnce(*d, d->repeatDir, 1.0F);
                    invalidate();
                    return true;
                }
            }
            return false;
        case PointerAction::Move:
            return d->repeatDir != 0;
        case PointerAction::Up:
        case PointerAction::Cancel:
            if (d->repeatDir != 0) {
                d->repeatDir = 0;
                invalidate();
                return true;
            }
            return false;
    }
    return false;
}

void SilvetonSamplerView::tickDialogs(std::int64_t now) {
    if (dialogStack.empty()) return;
    const std::shared_ptr<Dialog> d = dialogStack.back();
    if (d->kind == Dialog::Kind::Number && d->repeatDir != 0 && now >= d->nextRepeatMs) {
        d->repeatCount++;
        const float mult = d->repeatCount > 40 ? 100.0F : (d->repeatCount > 15 ? 10.0F : 1.0F);
        numberStepOnce(*d, d->repeatDir, mult);
        d->nextRepeatMs = now + 70;
        invalidate();
    }
    if (d->kbBackHeld && d->kbPressed >= 0 && now >= d->kbNextBackMs) {
        d->kbBackCount++;
        dialogKey(Key::Backspace);
        d->kbNextBackMs = now + (d->kbBackCount > 12 ? 40 : 70);
        invalidate();
    }
    if (d->kind == Dialog::Kind::Wait && d->workDone.load(std::memory_order_acquire)) {
        const std::function<void()> done = d->completion;
        closeDialog(d);
        if (done) done();
        invalidate();
    }
}

// ---------------------------------------------------------------- keyboard and wheel
void SilvetonSamplerView::dialogKey(Key key) {
    if (dialogStack.empty()) return;
    const std::shared_ptr<Dialog> d = dialogStack.back();
    if (d->kind == Dialog::Kind::Wait) return;
    if (key == Key::Escape) {
        dialogCancel(d);
        return;
    }
    const bool editor = d->kind == Dialog::Kind::Text || d->kind == Dialog::Kind::Number;
    if (key == Key::Enter) {
        if ((editor || d->kind == Dialog::Kind::Message) && !d->buttons.empty()) {
            const std::function<void()> act = d->buttons.back().action;
            dialogFire(d, act);
        }
        return;
    }
    if (editor) {
        const int len = utf8Length(d->value);
        switch (key) {
            case Key::Backspace:
                if (d->selectAll) { d->value.clear(); d->cursor = 0; d->selectAll = false; }
                else if (d->cursor > 0) { d->value = utf8Substring(d->value, 0, d->cursor - 1) + utf8Substring(d->value, d->cursor, len); --d->cursor; }
                break;
            case Key::Delete:
                if (d->selectAll) { d->value.clear(); d->cursor = 0; d->selectAll = false; }
                else if (d->cursor < len) d->value = utf8Substring(d->value, 0, d->cursor) + utf8Substring(d->value, d->cursor + 1, len);
                break;
            case Key::Left: d->cursor = d->selectAll ? 0 : std::max(0, d->cursor - 1); d->selectAll = false; break;
            case Key::Right: d->cursor = d->selectAll ? len : std::min(len, d->cursor + 1); d->selectAll = false; break;
            case Key::Up:
            case Key::Down:
                if (d->kind == Dialog::Kind::Number) numberStepOnce(*d, key == Key::Up ? 1 : -1, 1.0F);
                break;
            default: break;
        }
        invalidate();
        return;
    }
    if (d->kind == Dialog::Kind::Items || d->kind == Dialog::Kind::Multi) {
        if (key == Key::Up) d->scroll = std::max(0, d->scroll - 1);
        if (key == Key::Down) d->scroll += 1;   // clamped when drawn
        invalidate();
        return;
    }
    if (d->kind == Dialog::Kind::Grid) {
        if (key == Key::Left || key == Key::Up) { d->gridPage = std::max(0, d->gridPage - 1); d->followPage = true; }
        if (key == Key::Right || key == Key::Down) { d->gridPage += 1; d->followPage = true; }   // clamped when drawn
        invalidate();
    }
}

void SilvetonSamplerView::dialogType(const std::string& utf8) {
    if (dialogStack.empty()) return;
    const std::shared_ptr<Dialog> d = dialogStack.back();
    if (d->kind != Dialog::Kind::Text && d->kind != Dialog::Kind::Number) return;
    // keep only printable letters; the number page only takes digits, one point, a minus at the front
    std::string clean;
    for (std::size_t i = 0U; i < utf8.size();) {
        const auto b = static_cast<unsigned char>(utf8[i]);
        if (b < 0x20U || b == 0x7FU) { ++i; continue; }                                  // control characters
        if (b == 0xEFU && i + 2U < utf8.size()) {                                          // U+F700..U+F8FF: Mac function keys
            const auto b2 = static_cast<unsigned char>(utf8[i + 1U]);
            if (b2 >= 0x9CU && b2 <= 0xA3U) { i += 3U; continue; }
        }
        clean += utf8[i];
        ++i;
    }
    if (clean.empty()) return;
    if (d->kind == Dialog::Kind::Number) {
        std::string filtered;
        for (const char ch : clean) {
            if ((ch >= '0' && ch <= '9')) filtered += ch;
            else if (ch == '.' || ch == ',') filtered += '.';
            else if (ch == '-' && d->numMin < 0.0F) filtered += '-';
        }
        clean = filtered;
        if (clean.empty()) return;
    }
    if (d->selectAll) { d->value.clear(); d->cursor = 0; d->selectAll = false; }
    if (d->kind == Dialog::Kind::Number) {
        // a second point or a minus in the middle is not a number: drop it
        std::string ok;
        for (const char ch : clean) {
            std::string trial = utf8Prefix(d->value, d->cursor) + ok + ch;
            const bool minusOk = ch != '-' || trial.size() == 1U;
            const bool pointOk = ch != '.' || (d->value.find('.') == std::string::npos && ok.find('.') == std::string::npos);
            if (minusOk && pointOk) ok += ch;
        }
        clean = ok;
        if (clean.empty()) return;
    }
    const int len = utf8Length(d->value);
    d->value = utf8Prefix(d->value, d->cursor) + clean + utf8Substring(d->value, d->cursor, len);
    d->cursor += utf8Length(clean);
    invalidate();
}

void SilvetonSamplerView::dialogWheel(float x, float y, float dy) {
    if (dialogStack.empty()) return;
    const std::shared_ptr<Dialog> d = dialogStack.back();
    d->wheelAcc += dy;
    int steps = 0;
    while (d->wheelAcc >= 24.0F) { ++steps; d->wheelAcc -= 24.0F; }
    while (d->wheelAcc <= -24.0F) { --steps; d->wheelAcc += 24.0F; }
    if (steps == 0) return;
    if (d->kind == Dialog::Kind::Items || d->kind == Dialog::Kind::Multi) {
        d->scroll = std::max(0, d->scroll + steps);   // clamped when drawn
    } else if (d->kind == Dialog::Kind::Grid) {
        const float pageRowTop = DESIGN_H * 0.5F;   // the page strip is the upper part of the card: scroll the strip there
        (void)pageRowTop;
        if (y < 150.0F) d->pageScroll = std::max(0.0F, d->pageScroll + static_cast<float>(steps) * 120.0F);
        else { d->gridPage = std::max(0, d->gridPage + (steps > 0 ? 1 : -1)); d->followPage = true; }
    }
    (void)x;
    invalidate();
}

// ---------------------------------------------------------------- the Android calls
void SilvetonSamplerView::showMessage(const std::string& title, const std::string& message, const std::string& okLabel) {
    auto d = std::make_shared<Dialog>();
    d->kind = Dialog::Kind::Message;
    d->title = title;
    d->message = message;
    d->buttons.push_back({okLabel, nullptr});
    dialogStack.push_back(d);
    invalidate();
}

void SilvetonSamplerView::showConfirm(const std::string& title, const std::string& message, const std::string& positiveLabel,
                                      std::function<void()> onPositive, const std::string& negativeLabel) {
    auto d = std::make_shared<Dialog>();
    d->kind = Dialog::Kind::Message;
    d->title = title;
    d->message = message;
    d->buttons.push_back({negativeLabel, nullptr});
    d->buttons.push_back({positiveLabel, std::move(onPositive)});
    dialogStack.push_back(d);
    invalidate();
}

void SilvetonSamplerView::showItems(const std::string& title, const std::vector<std::string>& items, std::function<void(int)> onItem,
                                    const std::string& negativeLabel) {
    auto d = std::make_shared<Dialog>();
    d->kind = Dialog::Kind::Items;
    d->title = title;
    d->items = items;
    d->onItem = std::move(onItem);
    d->buttons.push_back({negativeLabel, nullptr});
    dialogStack.push_back(d);
    invalidate();
}

void SilvetonSamplerView::showMultiChoice(const std::string& title, const std::vector<std::string>& labels,
                                          std::function<void(const std::vector<bool>&)> onPositive, const std::string& positiveLabel,
                                          const std::string& negativeLabel) {
    auto d = std::make_shared<Dialog>();
    d->kind = Dialog::Kind::Multi;
    d->title = title;
    d->items = labels;
    d->checked.assign(labels.size(), false);
    const std::weak_ptr<Dialog> weak = d;
    d->buttons.push_back({negativeLabel, nullptr});
    d->buttons.push_back({positiveLabel, [weak, onPositive] {
        if (const auto dd = weak.lock()) { if (onPositive) onPositive(dd->checked); }
    }});
    dialogStack.push_back(d);
    invalidate();
}

void SilvetonSamplerView::showWait(const std::string& title, const std::string& message, std::function<std::function<void()>()> work) {
    auto d = std::make_shared<Dialog>();
    d->kind = Dialog::Kind::Wait;
    d->title = title;
    d->message = message;
    d->cancelable = false;
    Dialog* raw = d.get();
    d->worker = std::thread([raw, work = std::move(work)] {
        std::function<void()> completion;
        try {
            if (work) completion = work();
        } catch (...) {
        }
        raw->completion = std::move(completion);
        raw->workDone.store(true, std::memory_order_release);
    });
    dialogStack.push_back(d);
    invalidate();
}

void SilvetonSamplerView::showGridPicker(const std::string& title, const std::vector<std::pair<std::string, std::string>>& items, int current,
                                         const std::optional<std::string>& extra, std::function<void(int)> pick) {
    auto d = std::make_shared<Dialog>();
    d->kind = Dialog::Kind::Grid;
    d->title = title;
    d->gridItems = items;
    d->gridCurrent = current;
    d->hasExtra = extra.has_value();
    if (extra) d->gridExtra = *extra;
    d->onPick = std::move(pick);
    d->gridPage = current >= 0 ? current / 20 : 0;
    d->followPage = true;
    dialogStack.push_back(d);
    invalidate();
}

void SilvetonSamplerView::showEditorPage(const std::shared_ptr<Dialog>& d, const std::string& title, const std::string& subtitle,
                                         const std::string& applyLabel, std::function<void()> onApply) {
    d->title = title;
    d->subtitle = subtitle;
    d->buttons.clear();
    d->buttons.push_back({"CANCEL", d->onCancel});
    d->buttons.push_back({applyLabel, std::move(onApply)});
    dialogStack.push_back(d);
    invalidate();
}

void SilvetonSamplerView::showTextPage(const std::string& title, const std::string& current, std::function<void(const std::string&)> done) {
    auto d = std::make_shared<Dialog>();
    d->kind = Dialog::Kind::Text;
    d->value = current;
    d->cursor = utf8Length(current);
    d->selectAll = true;   // the name is selected, so typing replaces it
    const std::weak_ptr<Dialog> weak = d;
    showEditorPage(d, title, "Edit the name and confirm.", "APPLY", [this, weak, done = std::move(done)] {
        const auto dd = weak.lock();
        if (!dd) return;
        const std::string value = trimmed(dd->value);
        if (!value.empty() && done) done(value);
        invalidate();
    });
}

void SilvetonSamplerView::showNumber(const std::string& title, float current, float minV, float maxV, int decimals, std::function<void(float)> done,
                                     bool live, std::function<void()> restore) {
    auto d = std::make_shared<Dialog>();
    d->kind = Dialog::Kind::Number;
    d->numMin = minV;
    d->numMax = maxV;
    d->numCurrent = current;
    d->lastPreview = current;
    d->numLive = live;
    d->numDone = done;
    d->numRestore = restore;
    // SILVETON_FINE_KNOBS_V1: every value can be set to the hundredth; only small whole-number ranges stay whole.
    d->numDec = (decimals > 0 || maxV - minV >= 50.0F) ? 2 : decimals;
    const int scale = d->numDec <= 0 ? 1 : (d->numDec == 1 ? 10 : 100);
    d->numStep = 1.0F / static_cast<float>(scale);
    numberSetText(*d, std::clamp(current, minV, maxV));
    const std::string range = numberFormat(*d, minV) + " … " + numberFormat(*d, maxV);
    const std::string subtitle = live ? "−  /  +  : една стъпка.  Задръж = по-бързо.  Чуваш веднага.   (" + range + ")" : range;
    const std::weak_ptr<Dialog> weak = d;
    d->onCancel = [this, weak, done, restore] {
        const auto dd = weak.lock();
        if (!dd) return;
        dd->repeatDir = 0;
        if (dd->previewed) {
            if (restore) restore();
            else if (done) done(std::clamp(dd->numCurrent, dd->numMin, dd->numMax));
            invalidate();
        }
    };
    showEditorPage(d, title, subtitle, "APPLY", [this, weak, done] {
        const auto dd = weak.lock();
        if (!dd) return;
        dd->repeatDir = 0;
        const float value = numberTyped(*dd);
        if (done) done(value);
        invalidate();
    });
}

// ---------------------------------------------------------------- pickers of the COMBI page (tablet lines 2932-2987)
void SilvetonSamplerView::showBlendPicker() {
    const std::vector<std::pair<int, std::string>> blends = sampler.combiCatalog();
    if (blends.empty()) {
        showMessage("BLENDS", "Няма записани COMBI / BLEND позиции в заредената банка.");
        return;
    }
    std::vector<std::pair<std::string, std::string>> items;
    items.reserve(blends.size());
    for (const auto& b : blends) items.emplace_back(fmtZeroPad(b.first, 3), isBlank(b.second) ? "COMBI " + std::to_string(b.first) : b.second);
    // Open on the blend that is loaded now, not on position 1.
    int current = -1;
    if (editingCombiSlot) {
        for (std::size_t i = 0U; i < blends.size(); ++i) if (blends[i].first == *editingCombiSlot) { current = static_cast<int>(i); break; }
    }
    showGridPicker("BLENDS  1–500", items, current, std::nullopt, [this, blends](int index) {
        if (index < 0 || index >= static_cast<int>(blends.size())) return;
        const auto& item = blends[static_cast<std::size_t>(index)];
        if (sampler.activateCombiAddress(0, 0, item.first)) {
            editingCombiSlot = item.first;
            loadedFromList = -1;
            page_ = Page::COMBI;
            cachedCombiName = sampler.combiName();
            refreshAllUppers();
            refreshFx();
            invalidate();
        }
    });
}

void SilvetonSamplerView::showSoundPicker(int upper) {
    const std::vector<SoundItem> sounds = sampler.soundCatalog();
    if (sounds.empty()) {
        std::string detail = sampler.bankLoadError();
        if (isBlank(detail)) detail = "SILVETON_BANK.sv не е заредена или няма SOUND позиции.";
        showMessage("BANK HAS NO SOUNDS", detail);
        return;
    }
    // Open on this Upper's own sound (e.g. position 53), not on position 1.
    const std::optional<SoundItem>& picked = lastPickedSound[static_cast<std::size_t>(upper)];
    std::optional<std::string> currentName;
    if (upperStates[static_cast<std::size_t>(upper)]) currentName = upperStates[static_cast<std::size_t>(upper)]->soundName;
    else if (const auto s = sampler.upperState(upper)) currentName = s->soundName;
    int current = -1;
    if (picked && currentName && picked->name == *currentName) {
        for (std::size_t i = 0U; i < sounds.size(); ++i) {
            if (sounds[i].bank == picked->bank && sounds[i].page == picked->page && sounds[i].slot == picked->slot) { current = static_cast<int>(i); break; }
        }
    }
    if (current < 0 && currentName && *currentName != "EMPTY") {
        for (std::size_t i = 0U; i < sounds.size(); ++i) if (sounds[i].name == *currentName) { current = static_cast<int>(i); break; }
    }
    std::vector<std::pair<std::string, std::string>> items;
    items.reserve(sounds.size());
    for (const auto& s : sounds) items.emplace_back(fmtZeroPad(s.slot, 3), s.name);
    showGridPicker("UPPER " + std::to_string(upper + 1) + " — SOUND", items, current, std::string("EMPTY"), [this, upper, sounds](int index) {
        if (index < 0) {
            sampler.clearUpperSound(upper);
            lastPickedSound[static_cast<std::size_t>(upper)].reset();
        } else {
            sampler.assignUpperSound(upper, sounds[static_cast<std::size_t>(index)]);
            lastPickedSound[static_cast<std::size_t>(upper)] = sounds[static_cast<std::size_t>(index)];
        }
        mirrorSound(upper, -1, index < 0 ? std::nullopt : std::optional<SoundItem>(sounds[static_cast<std::size_t>(index)]));
        refreshUpper(upper);
        invalidate();
    });
}

} // namespace silveton::ui
