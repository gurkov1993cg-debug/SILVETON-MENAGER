// SILVETON_MAC_VIEW_V1 - the COMBI page: strips, editor, TUNE / RANGE / CONTROL / TONE / PORTA / FX (tablet lines 927-1700)
#include "silveton/ui/SilvetonSamplerView.h"

#include <algorithm>
#include <cmath>

namespace silveton::ui {

namespace {
// Kotlin's kotlin.math.ln / exp on a Float compute in double and round back to float.
float lnf(float x) { return static_cast<float>(std::log(static_cast<double>(x))); }
float expf_(float x) { return static_cast<float>(std::exp(static_cast<double>(x))); }
int rnd(float v) { return static_cast<int>(std::nearbyint(v)); }   // kotlin.math.round(x).toInt()
float rndf(float v) { return std::nearbyint(v); }
const float kStartQuick[5] = {0.0F, 10.0F, 25.0F, 60.0F, 120.0F};
std::string msText(float v) {
    if (v <= 0.0F) return "OFF";
    if (v < 1000.0F) return fmtFixed(static_cast<double>(v), 2) + " ms";
    return fmtFixed(static_cast<double>(v / 1000.0F), 2) + " s";
}
} // namespace

std::string SilvetonSamplerView::tabName(UpperTab t) {
    switch (t) {
        case UpperTab::TUNE: return "TUNE";
        case UpperTab::RANGE: return "RANGE";
        case UpperTab::CONTROL: return "CONTROL";
        case UpperTab::TONE: return "TONE";
        case UpperTab::FX: return "FX";
        case UpperTab::PORTA: return "VOICE";
        case UpperTab::EQ: return "EQ";
        case UpperTab::WAVE: return "WAVE";
    }
    return "";
}

SilvetonSamplerView::UpperState SilvetonSamplerView::currentUpper(const UpperState& fallback) const {
    const auto& cur = upperStates[static_cast<std::size_t>(selectedUpper_)];
    return cur ? *cur : fallback;
}

// ---------------------------------------------------------------- the page
void SilvetonSamplerView::drawCombi(Canvas& c) {
    if (picker) { drawPicker(c, picker); return; }
    if (tab == UpperTab::EQ) { drawEqPage(c); return; }
    const std::vector<std::pair<float, float>> meters = frameUpperMeters;
    const float stripW = (1214.0F - 6.0F * 8.0F) / 7.0F;
    for (int i = 0; i < 7; ++i) {
        auto& slot = upperStates[static_cast<std::size_t>(i)];
        if (!slot) slot = sampler.upperState(i);
        if (!slot) continue;
        const UpperState state = *slot;
        const float left = 112.0F + static_cast<float>(i) * (stripW + 8.0F);
        const std::pair<float, float> meter = static_cast<std::size_t>(i) < meters.size() ? meters[static_cast<std::size_t>(i)] : std::pair<float, float>(0.0F, 0.0F);
        drawUpperStrip(c, RectF(left, 108.0F, left + stripW, 468.0F), i, state, meter);
    }
    if (markMode) {
        for (int i = 0; i < 7; ++i) {
            const float left = 112.0F + static_cast<float>(i) * (stripW + 8.0F);
            hit(RectF(left, 108.0F, left + stripW, 468.0F), [this, i](float, float) { marked[static_cast<std::size_t>(i)] = !marked[static_cast<std::size_t>(i)]; invalidate(); });
        }
    }
    drawUpperEditor(c);
    if (dropUpper >= 0 && dropUpper <= 6) drawUpperMenu(c, dropUpper, 112.0F + static_cast<float>(dropUpper) * (stripW + 8.0F), stripW);
}

// SILVETON_UPPER_MENU_V1: the drop-down list of one Upper - ОСНОВЕН and L1..L4 with their sounds.
void SilvetonSamplerView::drawUpperMenu(Canvas& c, int i, float left, float w) {
    hit(RectF(0.0F, 0.0F, 1340.0F, 800.0F), [this](float, float) { dropUpper = -1; invalidate(); });   // anywhere else closes
    const RectF r(left + 4.0F, 140.0F, left + w - 4.0F, 140.0F + 6.0F + 5.0F * 38.0F + 6.0F);
    shadow(c, r, 10.0F, 3.0F, 90);
    fill(c, r, 10.0F, Color::WHITE);
    paint.style = Style::Stroke;
    paint.strokeWidth = 2.0F;
    paint.color = Color::rgb(90, 94, 100);
    paint.shader = nullptr;
    c.drawRoundRect(r, 10.0F, 10.0F, paint);
    paint.style = Style::Fill;
    const std::optional<UpperState> s = upperStates[static_cast<std::size_t>(i)];
    for (int k = 0; k <= 4; ++k) {
        const RectF row(r.left + 4.0F, r.top + 6.0F + static_cast<float>(k) * 38.0F, r.right - 4.0F, r.top + 6.0F + static_cast<float>(k) * 38.0F + 34.0F);
        const bool on = stripSound[static_cast<std::size_t>(i)] == k;
        const std::string label = k == 0 ? "ОСНОВЕН" : "L" + std::to_string(k);
        const bool has = k == 0 ? !(!s || s->soundName == "EMPTY" || isBlank(s->soundName)) : layerSlot(i, k - 1) > 0;
        std::string name;
        if (k == 0) {
            name = has ? s->soundName : "— празен —";
        } else if (has) {
            name = sampler.layerName(i, k - 1);
            if (isBlank(name)) name = "L" + std::to_string(k);
        } else {
            name = "— празен —";
        }
        if (on) fill(c, row, 6.0F, C_ACCENT);
        text(c, label, row.left + 8.0F, row.top + 22.0F, 11.0F, on ? Color::WHITE : Color::rgb(60, 66, 74), Opt().bold());
        text(c, name, row.right - 6.0F, row.top + 22.0F, 11.0F, on ? Color::rgb(226, 244, 232) : (has ? Color::rgb(90, 95, 105) : Color::rgb(150, 155, 162)),
             Opt().right().maxW(row.width() - 70.0F));
        hit(row, [this, i, k, has](float, float) {
            stripSound[static_cast<std::size_t>(i)] = k;
            selectedUpper_ = i;
            editSound = k;
            dropUpper = -1;
            if (!has) openPicker(i, k - 1);   // an empty place: choose its sound straight away
            invalidate();
        });
    }
}

void SilvetonSamplerView::drawUpperStrip(Canvas& c, const RectF& r, int i, const UpperState& s, std::pair<float, float> meter) {
    const bool selected = i == selectedUpper_;
    // SILVETON_UPPER_MENU_V1: the strip shows ОСНОВЕН or the layer chosen from its drop-down key
    const int ls = std::clamp(stripSound[static_cast<std::size_t>(i)], 0, 4);
    const bool layerView = ls > 0;
    const bool lHas = layerView && layerSlot(i, ls - 1) > 0;
    const std::vector<float> lp = layerView ? lParams(i, ls - 1) : std::vector<float>();
    const bool empty = layerView ? !lHas : (s.soundName == "EMPTY" || isBlank(s.soundName));
    const bool live = layerView ? (lHas && layerOn(i, ls - 1) && s.enabled) : (s.enabled && !empty);
    std::string shownName;
    if (layerView) {
        if (lHas) {
            shownName = sampler.layerName(i, ls - 1);
            if (isBlank(shownName)) shownName = "L" + std::to_string(ls);
        } else {
            shownName = "EMPTY";
        }
    } else {
        shownName = s.soundName;
    }
    const float shownPan = layerView ? getOr(lp, 2, 0.0F) : s.pan;
    const float shownLevel = layerView ? getOr(lp, 1, 0.0F) : s.levelDb;
    const int shownLow = layerView ? static_cast<int>(getOr(lp, 6, 0.0F)) : s.keyLow;
    const int shownHigh = layerView ? static_cast<int>(getOr(lp, 7, 127.0F)) : s.keyHigh;
    const float L = r.left;
    const float T = r.top;
    const float W = r.width();

    // Any free spot of the strip selects this UPPER (registered first = lowest priority).
    hit(r, [this, i](float, float) { selectedUpper_ = i; });

    if (selected) {
        fill(c, RectF(r.left - 3.0F, r.top - 3.0F, r.right + 3.0F, r.bottom + 3.0F), 15.0F, C_ACCENT);
    } else if (marked[static_cast<std::size_t>(i)]) {
        fill(c, RectF(r.left - 3.0F, r.top - 3.0F, r.right + 3.0F, r.bottom + 3.0F), 15.0F, C_MARK);
    } else {
        shadow(c, r, 12.0F, 2.0F, 55);
    }
    fill(c, r, 12.0F, selected ? C_STRIP_SEL : C_STRIP);
    line(c, L + 12.0F, T + 1.0F, r.right - 12.0F, T + 1.0F, darkTheme ? Color::rgb(72, 76, 86) : Color::WHITE, 1.0F);

    // SILVETON_UPPER_MENU_V1: drop-down key "UPPER n ▾" / "UPPER n · L2 ▾"
    const RectF menuR(L + 6.0F, T + 5.0F, r.right - 24.0F, T + 29.0F);
    stripToggle(c, menuR, layerView ? "UPPER " + std::to_string(i + 1) + " · L" + std::to_string(ls) + " ▾" : "UPPER " + std::to_string(i + 1) + " ▾", layerView, C_AMBER, 11.0F);
    hit(menuR, [this, i](float, float) { selectedUpper_ = i; dropUpper = dropUpper == i ? -1 : i; invalidate(); });
    led(c, r.right - 13.0F, T + 17.0F, live, 5.0F, true);
    // SILVETON_SOUND_FIELD_V1: the sound of the strip is a big field (up to 2 lines); a tap anywhere on it opens the sound picker
    const RectF nameR(L + 6.0F, T + 33.0F, r.right - 6.0F, T + 77.0F);
    fill(c, nameR, 8.0F, darkTheme ? Color::rgb(60, 64, 72) : Color::rgb(186, 190, 197));
    fill(c, RectF(nameR.left + 1.0F, nameR.top + 1.0F, nameR.right - 1.0F, nameR.bottom - 1.0F), 7.0F, darkTheme ? Color::rgb(22, 24, 28) : Color::rgb(222, 224, 229));
    soundNameText(c, nameR, empty ? "EMPTY" : shownName, empty ? C_EMPTY_TEXT : C_INK);
    hit(nameR, [this, i, ls](float, float) { selectedUpper_ = i; openPicker(i, ls - 1); });
    if (marked[static_cast<std::size_t>(i)] && selected) {
        paint.style = Style::Stroke;
        paint.strokeWidth = 3.0F;
        paint.color = C_MARK;
        paint.shader = nullptr;
        c.drawRoundRect(RectF(r.left + 2.0F, r.top + 2.0F, r.right - 2.0F, r.bottom - 2.0F), 11.0F, 11.0F, paint);
        paint.style = Style::Fill;
    }

    // ON / SOLO / MUTE - big keys (SILVETON_GUI_V3)
    const float tgW = (W - 16.0F - 8.0F) / 3.0F;
    for (int k = 0; k < 3; ++k) {
        const RectF tr(L + 8.0F + static_cast<float>(k) * (tgW + 4.0F), T + 82.0F, L + 8.0F + static_cast<float>(k) * (tgW + 4.0F) + tgW, T + 120.0F);
        const bool on = k == 0 ? (layerView ? (lHas && layerOn(i, ls - 1)) : s.enabled) : (k == 1 ? s.solo : s.mute);
        const std::string label = k == 0 ? "ON" : (k == 1 ? "SOLO" : "MUTE");
        const ColorInt onColor = k == 0 ? C_AMBER : (k == 1 ? C_SOLO : C_MUTE);
        stripToggle(c, tr, label, on, onColor, k == 0 ? 15.0F : 11.0F);
        hit(tr, [this, i, s, k, layerView, lHas, ls, empty](float, float) {
            const auto& slot = upperStates[static_cast<std::size_t>(i)];
            UpperState cur = slot ? *slot : s;
            if (k == 0) {
                if (layerView) {
                    if (lHas) setLParam(i, ls - 1, 0, layerOn(i, ls - 1) ? 0.0F : 1.0F);
                    else openPicker(i, ls - 1);
                } else if (!empty) {
                    cur.enabled = !cur.enabled;
                    commitMain(i, cur);
                }
            } else if (k == 1) {
                cur.solo = !cur.solo;
                commitMain(i, cur);
            } else {
                cur.mute = !cur.mute;
                commitMain(i, cur);
            }
            invalidate();
        });
    }

    // PAN knob: drag the whole row, long press = number, double tap = centre.
    drawKnob(c, L + 29.0F, T + 147.0F, 19.0F, (shownPan + 1.0F) * 0.5F, true, false);
    text(c, "PAN", L + 58.0F, T + 142.0F, 11.0F, C_LABEL_GREY, Opt().spacing(0.2F));
    text(c, panText(shownPan), L + 58.0F, T + 160.0F, 14.0F, C_INK, Opt().monoBold());
    const std::function<void(float)> setPan = [this, i, s, layerView, ls](float nv) {
        if (layerView) { setLParam(i, ls - 1, 2, nv); return; }
        const auto& slot = upperStates[static_cast<std::size_t>(i)];
        UpperState cur = slot ? *slot : s;
        cur.pan = nv;
        commitMain(i, cur);
    };
    knobHit(RectF(L, T + 126.0F, r.right, T + 170.0F), shownPan, -1.0F, 1.0F, 0.01F, 160.0F, setPan,
            [this, i, layerView, ls, shownPan, setPan] {
                showNumber(layerView ? "UPPER " + std::to_string(i + 1) + " L" + std::to_string(ls) + " PAN" : "UPPER " + std::to_string(i + 1) + " PAN",
                           shownPan, -1.0F, 1.0F, 2, [setPan](float nv) { setPan(nv); });
            },
            [setPan] { setPan(0.0F); });

    // LEVEL fader with L/R meters.
    const float trackL = L + 52.0F;
    const float trackR = L + 68.0F;
    const float trackTop = T + 178.0F;
    const float trackBot = T + 282.0F;   // SILVETON_STRIP_V5: POLY / MONO / LEGATO moved to the VOICE page - the fader takes their room
    const float travel = trackBot - trackTop;
    const std::pair<const char*, float> scale[3] = {{"+12", 1.0F}, {"0", 2.0F / 3.0F}, {"-60", 0.0F}};
    for (const auto& sc : scale) text(c, sc.first, L + 8.0F, trackBot - sc.second * travel + 4.0F, 11.0F, C_SCALE, Opt().mono());
    fill(c, RectF(trackL, trackTop, trackR, trackBot), 6.0F, C_TRACK_LIGHT);
    paint.style = Style::Fill;
    paint.color = Color::BLACK;
    paint.shader = linearGradient(trackL, 0.0F, trackR, 0.0F, Color::argb(70, 0, 0, 0), Color::argb(0, 0, 0, 0), TileMode::Clamp);
    c.drawRoundRect(RectF(trackL, trackTop, trackR, trackBot), 6.0F, 6.0F, paint);
    paint.shader = nullptr;
    stripMeter(c, RectF(L + 92.0F, trackTop, L + 103.0F, trackBot), meter.first);
    stripMeter(c, RectF(L + 109.0F, trackTop, L + 120.0F, trackBot), meter.second);
    faderCap(c, (trackL + trackR) * 0.5F, trackBot - faderT(shownLevel) * travel, true);
    text(c, dbText(shownLevel), r.centerX(), T + 306.0F, 14.0F, C_INK, Opt().center().monoBold());
    const std::function<void(float)> setLevel = [this, i, s, layerView, ls](float nv) {
        if (layerView) { setLParam(i, ls - 1, 1, nv); return; }
        const auto& slot = upperStates[static_cast<std::size_t>(i)];
        UpperState cur = slot ? *slot : s;
        cur.levelDb = nv;
        commitMain(i, cur);
    };
    const std::function<void()> exactLevel = [this, i, layerView, ls, shownLevel, setLevel] {
        showNumber(layerView ? "UPPER " + std::to_string(i + 1) + " L" + std::to_string(ls) + " LEVEL dB" : "UPPER " + std::to_string(i + 1) + " LEVEL dB",
                   shownLevel, -60.0F, 12.0F, 1, [setLevel](float nv) { setLevel(nv); });
    };
    const std::function<void()> resetLevel = [setLevel] { setLevel(0.0F); };
    faderHit(RectF(L + 26.0F, T + 172.0F, r.right - 4.0F, T + 292.0F), shownLevel, travel, setLevel, exactLevel, resetLevel);
    hit(RectF(L, T + 292.0F, r.right, T + 312.0F), [exactLevel](float, float) { exactLevel(); }, resetLevel);

    // T = TERCA, Q = quarter tone (SILVETON_TERCA_V1 / SILVETON_SCALE_V1), then the key range.
    const float tqW = 40.0F;
    const RectF tR(L + 8.0F, T + 316.0F, L + 8.0F + tqW, T + 354.0F);
    const RectF qR(tR.right + 4.0F, T + 316.0F, tR.right + 4.0F + tqW, T + 354.0F);
    // SILVETON_TQ_LIST_V1: lit = on; dim = chosen here but switched off on LIST.
    stripToggle(c, tR, "T", sampler.tercaOn(i) || sampler.tercaChosen(i), sampler.tercaOn(i) ? C_AMBER : C_LCD_DIM, 18.0F);
    stripToggle(c, qR, "Q", sampler.quarterOn(i) || sampler.quarterChosen(i), sampler.quarterOn(i) ? C_AMBER : C_LCD_DIM, 18.0F);
    hit(tR, [this, i](float, float) { toggleTercaLinked(i); invalidate(); });
    hit(qR, [this, i](float, float) { toggleQuarterLinked(i); invalidate(); });
    const RectF rangeR(qR.right + 4.0F, T + 316.0F, r.right - 8.0F, T + 354.0F);
    // SILVETON_RANGE_KEY_V1: the split key shows the key range of this Upper; a tap opens its RANGE page
    // (KEY RANGE is set there like the VELOCITY RANGE); double tap = whole keyboard.
    lightKey(c, rangeR, noteName(shownLow) + "–" + noteName(shownHigh), true, 11.0F, 6.0F);
    hit(rangeR,
        [this, i, ls](float, float) {
            selectedUpper_ = i;
            if (sampler.keyScanUpper() == i) sampler.cancelKeyScan();
            editSound = ls;
            tab = UpperTab::RANGE;   // ls = 0 for the main sound, 1..4 for a layer
            invalidate();
        },
        [this, i, s, layerView, ls] {
            if (layerView) {
                setLParam(i, ls - 1, 6, 0.0F);
                setLParam(i, ls - 1, 7, 127.0F);
            } else {
                sampler.cancelKeyScan();
                const auto& slot = upperStates[static_cast<std::size_t>(i)];
                UpperState cur = slot ? *slot : s;
                cur.keyLow = 0;
                cur.keyHigh = 127;
                commitMain(i, cur);
            }
        });

    if (!live) {
        // Switched-off / empty UPPER: veil it, controls stay usable.
        fill(c, r, 12.0F, darkTheme ? Color::argb(120, 30, 32, 37) : Color::argb(92, 220, 221, 225));
    }
}

void SilvetonSamplerView::drawUpperEditor(Canvas& c) {
    if (!upperStates[static_cast<std::size_t>(selectedUpper_)]) return;
    const UpperState s = *upperStates[static_cast<std::size_t>(selectedUpper_)];
    const int u = selectedUpper_;
    // SILVETON_MENU_V5: ONE row of pages, always in the same order, the open page lit:
    //   TUNE  RANGE  TONE  WAVE   (the sound the strip shows: ОСНОВЕН or a layer)  |  VOICE  EQ  CTRL  FX   (the whole UPPER)
    // The first key names the sound being edited and opens the strip's drop-down list (ОСНОВЕН / L1..L4).
    const int ss = std::clamp(stripSound[static_cast<std::size_t>(u)], 0, 4);
    if (editSound != ss) editSound = ss;
    const bool soundPage = tab == UpperTab::TUNE || tab == UpperTab::RANGE || tab == UpperTab::TONE || tab == UpperTab::WAVE;
    float x = 112.0F;
    {
        const RectF rr(x, 478.0F, x + 150.0F, 514.0F);
        const std::string who = ss == 0 ? "UPPER " + std::to_string(u + 1) + " · ОСНОВЕН ▾" : "UPPER " + std::to_string(u + 1) + " · L" + std::to_string(ss) + " ▾";
        lightKey(c, rr, who, soundPage, 11.0F, 7.0F);
        hit(rr, [this, u](float, float) { dropUpper = dropUpper == u ? -1 : u; invalidate(); });
        x += 158.0F;
    }
    for (const UpperTab t : tabsFor(editSound)) {
        if (t == UpperTab::PORTA) {   // the pages of the whole UPPER start here
            x += 8.0F;
            line(c, x, 484.0F, x, 508.0F, Color::argb(90, 0, 0, 0), 1.0F);
            x += 9.0F;
        }
        const std::string name = t == UpperTab::CONTROL ? "CTRL" : tabName(t);
        const float tw = textWidth(name, 13.0F, Face::Bold, 0.15F) + 22.0F;
        const RectF rr(x, 478.0F, x + tw, 514.0F);
        const bool on = tab == t;
        if (on) {
            fillV(c, RectF(rr.left, rr.top, rr.right, rr.bottom + 1.0F), 8.0F, lighten(C_ACCENT, 20), C_ACCENT);
            paint.shader = nullptr;
            paint.style = Style::Fill;
            paint.color = C_ACCENT;
            c.drawRect(RectF(rr.left, rr.centerY(), rr.right, rr.bottom + 1.0F), paint);
        } else {
            paint.shader = nullptr;
            paint.style = Style::Fill;
            paint.color = C_TAB;
            c.drawRoundRect(rr, 8.0F, 8.0F, paint);
            c.drawRect(RectF(rr.left, rr.centerY(), rr.right, rr.bottom + 1.0F), paint);
            if (isDown(rr)) fill(c, rr, 8.0F, Color::argb(40, 0, 0, 0));
        }
        text(c, name, rr.centerX(), rr.top + 23.0F, 13.0F, on ? Color::WHITE : C_TAB_TEXT, Opt().center().bold().spacing(0.15F));
        hit(rr, [this, t](float, float) { tab = t; });
        x += tw + 4.0F;
    }

    // SILVETON_MARK_LINK_V1: МАРКИРАЙ (tap the strips to mark Uppers) and ЛИНК (marked Uppers follow every change)
    const RectF mkR(876.0F, 478.0F, 1000.0F, 514.0F);
    const long markedCount = std::count(marked.begin(), marked.end(), true);
    stripToggle(c, mkR, markedCount > 0 ? "МАРКИРАЙ · " + std::to_string(markedCount) : "МАРКИРАЙ", markMode, C_MARK, 11.0F);
    hit(mkR,
        [this](float, float) {
            markMode = !markMode;
            if (markMode) flash("ДОКОСВАЙ ЛЕНТИТЕ НА УПЕРИТЕ, КОИТО ИСКАШ ДА МАРКИРАШ");
            invalidate();
        },
        [this] {
            marked.fill(false);
            flash("МАРКИРОВКАТА Е ИЗЧИСТЕНА");
            invalidate();
        });
    const RectF lkR(1006.0F, 478.0F, 1070.0F, 514.0F);
    stripToggle(c, lkR, "ЛИНК", linkOn, C_MARK, 11.0F);
    hit(lkR, [this](float, float) {
        linkOn = !linkOn;
        flash(linkOn ? "ЛИНК ВКЛ: МАРКИРАНИТЕ УПЕРИ СЛЕДВАТ" : "ЛИНК ИЗКЛ");
        invalidate();
    });

    // COPY / PASTE all settings of an Upper (portamento .. FX).
    const RectF copyR(1076.0F, 478.0F, 1196.0F, 512.0F);
    const RectF pasteR(1202.0F, 478.0F, 1326.0F, 512.0F);
    lightKey(c, copyR, "COPY U" + std::to_string(selectedUpper_ + 1), true, 12.0F, 7.0F);
    lightKey(c, pasteR, copiedClip ? "PASTE U" + std::to_string(copiedClip->from + 1) : std::string("PASTE"), copiedClip.has_value(), 12.0F, 7.0F);
    hit(copyR, [this](float, float) { copyUpper(selectedUpper_); });
    hit(pasteR, [this](float, float) { pasteUpper(selectedUpper_); });

    board(c, RectF(112.0F, 514.0F, 1326.0F, 786.0F), true);
    const RectF sec(128.0F, 530.0F, 1310.0F, 770.0F);
    switch (tab) {
        case UpperTab::TUNE: if (editSound == 0) drawTune(c, sec, s); else drawLayerTune(c, sec, u, editSound - 1); break;
        case UpperTab::RANGE: if (editSound == 0) drawRange(c, sec, s); else drawLayerRange(c, sec, u, editSound - 1); break;
        case UpperTab::CONTROL: drawControl(c, sec, s); break;
        case UpperTab::TONE: drawToneV2(c, sec, u, editSound); break;
        case UpperTab::WAVE: drawWave(c, sec, u, editSound); break;
        case UpperTab::FX: drawUpperFx(c, sec, s); break;
        case UpperTab::PORTA: drawPorta(c, sec, s); break;
        case UpperTab::EQ: break;   // drawn full screen by drawCombi
    }
}

// ---------------------------------------------------------------- SILVETON_LAYERS_V1 pages
void SilvetonSamplerView::drawLayerTune(Canvas& c, const RectF& sec, int u, int l) {
    section(c, sec, "LAYER " + std::to_string(l + 1) + " · ЗВУК, НИВО, ВИСОЧИНА");
    const std::vector<float> p = lParams(u, l);
    const int slot = layerSlot(u, l);
    const std::string name = slot > 0 ? fmtZeroPad(slot, 3) + " " + lName(u, l) : "— НЯМА ЗВУК —";
    const RectF nameR(sec.left + 16.0F, sec.top + 40.0F, sec.left + 420.0F, sec.top + 84.0F);
    lcd(c, nameR, 8.0F);
    text(c, name, nameR.left + 14.0F, nameR.top + 30.0F, 18.0F, slot > 0 ? C_LCD : C_LCD_DIM, Opt().mono().maxW(nameR.width() - 28.0F));
    hit(nameR, [this, u, l](float, float) { openPicker(u, l); });
    const RectF onR(sec.left + 432.0F, sec.top + 40.0F, sec.left + 540.0F, sec.top + 84.0F);
    stripToggle(c, onR, "LAYER ON", slot > 0 && layerOn(u, l), C_LCD_OK, 12.0F);
    hit(onR, [this, u, l, slot](float, float) {
        if (slot > 0) setLParam(u, l, 0, layerOn(u, l) ? 0.0F : 1.0F);
        else openPicker(u, l);
    });
    const RectF offR(sec.left + 552.0F, sec.top + 40.0F, sec.left + 660.0F, sec.top + 84.0F);
    lightKey(c, offR, "МАХНИ", slot > 0, 12.0F);
    hit(offR, [this, u, l, slot](float, float) {
        if (slot > 0) {
            sampler.setLayerSound(u, l, 0);
            dropParamCaches(u);
            mirrorSound(u, l, std::nullopt);
            invalidate();
        }
    });
    const float cy = 672.0F;
    struct Item { const char* label; int id; float lo; float hi; float step; };
    const Item items[5] = {{"LEVEL", 1, -60.0F, 12.0F, 0.1F}, {"PAN", 2, -1.0F, 1.0F, 0.01F}, {"OCTAVE", 4, -3.0F, 3.0F, 1.0F},
                           {"TRANSPOSE", 3, -12.0F, 12.0F, 1.0F}, {"FINE", 5, -100.0F, 100.0F, 1.0F}};
    for (int k = 0; k < 5; ++k) {
        const Item it = items[k];
        const float v = getOr(p, it.id, 0.0F);
        const float cx = sec.left + 115.0F + static_cast<float>(k) * 230.0F;
        std::string shown;
        switch (it.id) {
            case 1: shown = dbText(v); break;
            case 2: shown = panText(v); break;
            case 5: shown = std::to_string(rnd(v)) + " c"; break;
            default: shown = signed_(rnd(v)); break;
        }
        knobControl(c, cx, cy, 30.0F, v, it.lo, it.hi, it.step, 260.0F, it.id != 1, shown, it.label, 200.0F,
                    [this, u, l, it](float nv) { setLParam(u, l, it.id, it.step >= 1.0F ? rndf(nv) : nv); },
                    [this, u, l, it, v] {
                        showNumber("LAYER " + std::to_string(l + 1) + " " + it.label, v, it.lo, it.hi, it.step >= 1.0F ? 0 : 2,
                                   [this, u, l, it](float nv) { setLParam(u, l, it.id, nv); });
                    },
                    [this, u, l, it] { setLParam(u, l, it.id, 0.0F); });
    }
}

void SilvetonSamplerView::drawLayerRange(Canvas& c, const RectF& sec, int u, int l) {
    const std::vector<float> p = lParams(u, l);
    const float halfW = (sec.width() - 12.0F) / 2.0F;
    const RectF vel(sec.left, sec.top, sec.left + halfW, sec.bottom);
    const int lo = static_cast<int>(getOr(p, 8, 1.0F));
    const int hi = static_cast<int>(getOr(p, 9, 127.0F));
    const std::string ln = std::to_string(l + 1);
    rangeHalf(c, vel, "LAYER " + ln + " · VELOCITY RANGE", "МИН", "МАКС", lo, hi, 1, 127, [](int v) { return std::to_string(v); },
              "Влачи краищата · Докосни числото = точна стойност · Двоен допир = 1–127",
              [this, u, l](int a, int b) { setLParam(u, l, 8, static_cast<float>(a)); setLParam(u, l, 9, static_cast<float>(b)); },
              [this, u, l, lo, hi, ln] {
                  showNumber("LAYER " + ln + " VEL МИН", static_cast<float>(lo), 1.0F, 127.0F, 0,
                             [this, u, l, hi](float v) { setLParam(u, l, 8, std::min(rndf(v), static_cast<float>(hi))); });
              },
              [this, u, l, lo, hi, ln] {
                  showNumber("LAYER " + ln + " VEL МАКС", static_cast<float>(hi), 1.0F, 127.0F, 0,
                             [this, u, l, lo](float v) { setLParam(u, l, 9, std::max(rndf(v), static_cast<float>(lo))); });
              },
              [this, u, l] { setLParam(u, l, 8, 1.0F); setLParam(u, l, 9, 127.0F); });
    const RectF key(vel.right + 12.0F, sec.top, sec.right, sec.bottom);
    const int kl = static_cast<int>(getOr(p, 6, 0.0F));
    const int kh = static_cast<int>(getOr(p, 7, 127.0F));
    rangeHalf(c, key, "LAYER " + ln + " · KEY RANGE · ОБХВАТ", "ОТ", "ДО", kl, kh, 0, 127, [](int v) { return noteName(v); },
              "Влачи краищата · Докосни нотите = точна стойност · Двоен допир = цялата",
              [this, u, l](int a, int b) { setLParam(u, l, 6, static_cast<float>(a)); setLParam(u, l, 7, static_cast<float>(b)); },
              [this, u, l, kl, kh, ln] {
                  showNumber("LAYER " + ln + " КЛАВИШ ОТ (0 = C-1 · 60 = C4)", static_cast<float>(kl), 0.0F, 127.0F, 0,
                             [this, u, l, kh](float v) { setLParam(u, l, 6, std::min(rndf(v), static_cast<float>(kh))); });
              },
              [this, u, l, kl, kh, ln] {
                  showNumber("LAYER " + ln + " КЛАВИШ ДО (0 = C-1 · 60 = C4)", static_cast<float>(kh), 0.0F, 127.0F, 0,
                             [this, u, l, kl](float v) { setLParam(u, l, 7, std::max(rndf(v), static_cast<float>(kl))); });
              },
              [this, u, l] { setLParam(u, l, 6, 0.0F); setLParam(u, l, 7, 127.0F); }, true);
}

// ---------------------------------------------------------------- SILVETON_TONE_V2 page
void SilvetonSamplerView::drawToneV2(Canvas& c, const RectF& sec, int u, int sound) {
    if (!upperStates[static_cast<std::size_t>(u)]) return;
    const UpperState s = *upperStates[static_cast<std::size_t>(u)];
    const float unit = sec.width() / 12.0F;
    auto cx = [&](int k) { return sec.left + unit * (static_cast<float>(k) + 0.5F); };
    const float r1 = 588.0F;
    const float r2 = 692.0F;
    const float rad = 20.0F;
    const float hw = unit - 4.0F;
    // the six legacy values: basic sound = the Upper's TONE, a layer = its own
    auto legacy = [&](int k) -> float {
        if (sound == 0) return toneValue(s, static_cast<TonePar>(k));
        const float v = getOr(lParams(u, sound - 1), 10 + k, -1.0F);
        if (v >= 0.0F) return v;
        const float defaults[6] = {5.0F, 80.0F, 1.0F, 120.0F, 20000.0F, 0.0F};
        return defaults[k];
    };
    const std::function<void(int, float)> setLegacy = [this, u, sound](int k, float v) {
        if (sound == 0) setTone(static_cast<TonePar>(k), v);
        else setLParam(u, sound - 1, 10 + k, v);
    };
    secTitle(c, sec, "TONE · " + soundLabel(sound) + " · допир на числото = точно · двоен допир = нула");
    // row 1: ATTACK DECAY SUSTAIN RELEASE | START END | CUTOFF RESON F.ENV F.TIME | HI-PASS | MOD WHEEL
    const char* envNames[6] = {"ATTACK", "DECAY", "SUSTAIN", "RELEASE", "CUTOFF", "RESON"};
    const int envCols[6] = {0, 1, 2, 3, 6, 7};
    for (int k = 0; k < 6; ++k) {
        const TonePar p = static_cast<TonePar>(k);
        const float v = legacy(k);
        const ToneRange range = toneRange(p);
        const bool pct = k == 2 || k == 5;
        const std::string nm = envNames[k];
        knobControl(c, cx(envCols[k]), r1, rad, toneToNorm(p, v), 0.0F, 1.0F, 0.002F, 260.0F, false, toneText(p, v), nm, hw,
                    [setLegacy, k, p](float nv) { setLegacy(k, toneFromNorm(p, nv)); },
                    [this, setLegacy, k, nm, pct, v, range] {
                        showNumber(nm, pct ? v * 100.0F : v, range.lo, range.hi, range.decimals,
                                   [setLegacy, k, pct](float nv) { setLegacy(k, pct ? nv / 100.0F : nv); }, true, [setLegacy, k, v] { setLegacy(k, v); });
                    },
                    [setLegacy, k] { setLegacy(k, -1.0F); });
    }
    // START / END (ms into the sample)
    const char* seLabels[2] = {"START", "END"};
    for (int k = 0; k < 2; ++k) {
        const int id = k;
        const std::string label = seLabels[k];
        const float v = toneX(u, sound, id);
        const float maxV = id == 0 ? 2000.0F : 60000.0F;
        const float norm = lnf(std::clamp(v, 0.0F, maxV) + 1.0F) / lnf(maxV + 1.0F);
        knobControl(c, cx(4 + k), r1, rad, norm, 0.0F, 1.0F, 0.002F, 300.0F, false, msText(v), label, hw,
                    [this, u, sound, id, maxV](float nv) { setToneX(u, sound, id, rndf(expf_(std::clamp(nv, 0.0F, 1.0F) * lnf(maxV + 1.0F)) - 1.0F)); },
                    [this, u, sound, id, label, v, maxV] {
                        showNumber("SAMPLE " + label + " ms", v, 0.0F, maxV, 0, [this, u, sound, id](float x) { setToneX(u, sound, id, x); });
                    },
                    [this, u, sound, id] { setToneX(u, sound, id, 0.0F); });
    }
    // FILTER ENV amount (octaves) + time
    {
        const float v = toneX(u, sound, 2);
        knobControl(c, cx(8), r1, rad, v, -8.0F, 8.0F, 0.05F, 280.0F, true, fmtFixed(static_cast<double>(v), 2) + " oct", "F.ENV", hw,
                    [this, u, sound](float nv) { setToneX(u, sound, 2, nv); },
                    [this, u, sound, v] { showNumber("FILTER ENV (октави)", v, -8.0F, 8.0F, 2, [this, u, sound](float x) { setToneX(u, sound, 2, x); }); },
                    [this, u, sound] { setToneX(u, sound, 2, 0.0F); });
        const float t = toneX(u, sound, 3);
        const float norm = lnf(std::clamp(t, 1.0F, 20000.0F)) / lnf(20000.0F);
        knobControl(c, cx(9), r1, rad, norm, 0.0F, 1.0F, 0.002F, 260.0F, false, msText(t), "F.TIME", hw,
                    [this, u, sound](float nv) { setToneX(u, sound, 3, rndf(std::clamp(expf_(std::clamp(nv, 0.0F, 1.0F) * lnf(20000.0F)), 1.0F, 20000.0F))); },
                    [this, u, sound, t] { showNumber("FILTER ENV TIME ms", t, 1.0F, 20000.0F, 0, [this, u, sound](float x) { setToneX(u, sound, 3, x); }); },
                    [this, u, sound] { setToneX(u, sound, 3, 120.0F); });
        const float hp = toneX(u, sound, 6);
        const float hn = hp < 10.0F ? 0.0F : lnf(hp / 10.0F) / lnf(400.0F);
        knobControl(c, cx(10), r1, rad, hn, 0.0F, 1.0F, 0.002F, 260.0F, false, hp < 10.0F ? "OFF" : fmtFixed(static_cast<double>(hp), 2) + " Hz", "HI-PASS", hw,
                    [this, u, sound](float nv) {
                        setToneX(u, sound, 6, nv <= 0.002F ? 0.0F : rndf(10.0F * static_cast<float>(std::pow(400.0, static_cast<double>(nv)))));
                    },
                    [this, u, sound, hp] { showNumber("HIGH-PASS Hz (0 = OFF)", hp, 0.0F, 4000.0F, 0, [this, u, sound](float x) { setToneX(u, sound, 6, x); }); },
                    [this, u, sound] { setToneX(u, sound, 6, 0.0F); });
        const bool wheelOn = toneX(u, sound, 11) >= 0.5F;
        const RectF wr(cx(11) - hw / 2.0F + 2.0F, r1 - 24.0F, cx(11) + hw / 2.0F - 2.0F, r1 + 24.0F);
        stripToggle(c, wr, "MOD\nWHEEL", wheelOn, C_AMBER, 11.0F);
        text(c, "ВИБРАТО ОТ", cx(11), r1 + 56.0F, 11.0F, C_KNOB_LABEL, Opt().center().spacing(0.1F).maxW(hw));
        hit(wr, [this, u, sound, wheelOn](float, float) { setToneX(u, sound, 11, wheelOn ? 0.0F : 1.0F); });
    }
    // row 2: VEL->LEV VEL->CUT | quick START keys | LFO RATE DEPTH DELAY FADE | EQ LOW MID HIGH
    {
        const float vl = toneX(u, sound, 4);
        knobControl(c, cx(0), r2, rad, vl, 0.0F, 1.0F, 0.01F, 250.0F, false, fmtFixed(static_cast<double>(vl * 100.0F), 2) + " %", "VEL→LEVEL", hw,
                    [this, u, sound](float nv) { setToneX(u, sound, 4, nv); },
                    [this, u, sound, vl] { showNumber("VEL→LEVEL %", vl * 100.0F, 0.0F, 100.0F, 0, [this, u, sound](float x) { setToneX(u, sound, 4, x / 100.0F); }); },
                    [this, u, sound] { setToneX(u, sound, 4, 1.0F); });
        const float vc = toneX(u, sound, 5);
        knobControl(c, cx(1), r2, rad, vc, 0.0F, 8.0F, 0.05F, 250.0F, false, fmtFixed(static_cast<double>(vc), 2) + " oct", "VEL→CUTOFF", hw,
                    [this, u, sound](float nv) { setToneX(u, sound, 5, nv); },
                    [this, u, sound, vc] { showNumber("VEL→CUTOFF (октави)", vc, 0.0F, 8.0F, 2, [this, u, sound](float x) { setToneX(u, sound, 5, x); }); },
                    [this, u, sound] { setToneX(u, sound, 5, 0.0F); });
        // quick SAMPLE START like Korg M3 OSC Start Offset: OFF 1 2 3 4
        const float st = toneX(u, sound, 0);
        const float qx0 = cx(2) - hw / 2.0F + 2.0F;
        const float qw = (2.0F * unit - 8.0F) / 5.0F;
        for (int k = 0; k < 5; ++k) {
            const RectF qr(qx0 + static_cast<float>(k) * qw, r2 - 22.0F, qx0 + static_cast<float>(k + 1) * qw - 3.0F, r2 + 22.0F);
            stripToggle(c, qr, k == 0 ? std::string("OFF") : std::to_string(k), std::fabs(st - kStartQuick[k]) < 0.5F, C_AMBER, 11.0F);
            hit(qr, [this, u, sound, k](float, float) { setToneX(u, sound, 0, kStartQuick[k]); });
        }
        text(c, "START: OFF · 10 · 25 · 60 · 120 ms", qx0 + (2.0F * unit - 8.0F) / 2.0F, r2 + 56.0F, 11.0F, C_KNOB_LABEL, Opt().center().spacing(0.02F).maxW(2.0F * unit - 6.0F));
        struct Lfo { const char* label; int id; float lo; float hi; float step; };
        const Lfo lfo[4] = {{"RATE", 7, 0.1F, 20.0F, 0.05F}, {"DEPTH", 8, 0.0F, 200.0F, 1.0F}, {"DELAY", 9, 0.0F, 5000.0F, 10.0F}, {"FADE", 10, 0.0F, 5000.0F, 10.0F}};
        for (int k = 0; k < 4; ++k) {
            const Lfo f = lfo[k];
            const float v = toneX(u, sound, f.id);
            std::string shown;
            if (f.id == 7) shown = fmtFixed(static_cast<double>(v), 2) + " Hz";
            else if (f.id == 8) shown = std::to_string(rnd(v)) + " c";
            else shown = msText(v);
            knobControl(c, cx(4 + k), r2, rad, v, f.lo, f.hi, f.step, 260.0F, false, shown, std::string("LFO ") + f.label, hw,
                        [this, u, sound, f](float nv) { setToneX(u, sound, f.id, nv); },
                        [this, u, sound, f, v] {
                            showNumber(std::string("ВИБРАТО ") + f.label, v, f.lo, f.hi, f.id == 7 ? 1 : 0, [this, u, sound, f](float x) { setToneX(u, sound, f.id, x); });
                        },
                        [this, u, sound, f] { setToneX(u, sound, f.id, f.id == 7 ? 5.5F : (f.id == 10 ? 300.0F : 0.0F)); });
        }
        const std::pair<const char*, int> eqs[3] = {{"LOW", 12}, {"MID", 13}, {"HIGH", 14}};
        for (int k = 0; k < 3; ++k) {
            const std::string label = eqs[k].first;
            const int id = eqs[k].second;
            const float v = toneX(u, sound, id);
            knobControl(c, cx(8 + k), r2, rad, v, -18.0F, 18.0F, 0.1F, 300.0F, true, fmtFixed(static_cast<double>(v), 2) + " dB", "EQ " + label, hw,
                        [this, u, sound, id](float nv) { setToneX(u, sound, id, nv); },
                        [this, u, sound, id, label, v] { showNumber("EQ " + label + " dB", v, -18.0F, 18.0F, 1, [this, u, sound, id](float x) { setToneX(u, sound, id, x); }); },
                        [this, u, sound, id] { setToneX(u, sound, id, 0.0F); });
        }
        // SILVETON_EVEN_DECAY_LIVE_V1 (the Manager's copy): ЗАТИХВАНЕ of the whole Upper - every frequency dies away in this
        // time (to -60 dB) or faster; OFF = as recorded. Turn it: OFF, then 30 ms ... 3 s.
        const float dm = getOr(uParams(u), 49, 0.0F);
        const float dn = dm < 30.0F ? 0.0F : 0.05F + 0.95F * lnf(std::clamp(dm, 30.0F, 3000.0F) / 30.0F) / lnf(100.0F);
        knobControl(c, cx(11), r2, rad, dn, 0.0F, 1.0F, 0.002F, 260.0F, false, dm < 30.0F ? std::string("OFF") : msText(dm), "ЗАТИХВАНЕ", hw,
                    [this, u](float nv) {
                        const float ms = nv < 0.03F ? 0.0F : rndf(30.0F * expf_(std::clamp((nv - 0.05F) / 0.95F, 0.0F, 1.0F) * lnf(100.0F)));
                        setUParam(u, 49, ms);
                    },
                    [this, u, dm] { showNumber("ЗАТИХВАНЕ ms (0 = OFF)", dm, 0.0F, 3000.0F, 0, [this, u](float x) { setUParam(u, 49, x >= 30.0F ? x : 0.0F); }); },
                    [this, u] { setUParam(u, 49, 0.0F); });
    }
}


// ---------------------------------------------------------------- SILVETON_TRANSWAVE_V1 page
namespace {
// defaults of the wave ids (0 mode 1 frames 2 pos 3 start 4 span 5 smooth 6 source 7 amount 8 time ms 9 rate Hz 10..17 slots)
float waveDefault(int id) {
    static const float d[10] = {0.0F, 16.0F, 0.0F, 0.0F, 1.0F, 1.0F, 0.0F, 0.5F, 1500.0F, 0.5F};
    return id >= 0 && id < 10 ? d[id] : 0.0F;
}
} // namespace

std::vector<float> SilvetonSamplerView::wParams(int u, int sound) {
    auto& slot = waveParamsCache[static_cast<std::size_t>(u)][static_cast<std::size_t>(std::clamp(sound, 0, 4))];
    if (!slot) slot = sampler.soundWaveParams(u, sound);
    return *slot;
}

float SilvetonSamplerView::waveP(int u, int sound, int id) {
    const std::vector<float> a = wParams(u, sound);
    return id >= 0 && id < static_cast<int>(a.size()) ? a[static_cast<std::size_t>(id)] : waveDefault(id);
}

void SilvetonSamplerView::setWaveP(int u, int sound, int id, float v) {
    setWavePOne(u, sound, id, v);
    for (const int t : linkTargets(u)) setWavePOne(t, sound, id, v);
}

void SilvetonSamplerView::setWavePOne(int u, int sound, int id, float v) {
    auto& slot = waveParamsCache[static_cast<std::size_t>(u)][static_cast<std::size_t>(std::clamp(sound, 0, 4))];
    auto a = wParams(u, sound);
    if (id < static_cast<int>(a.size())) a[static_cast<std::size_t>(id)] = v;
    slot = a;
    if (!sampler.setSoundWaveParam(u, sound, id, v)) slot.reset();
    invalidate();
}

void SilvetonSamplerView::drawWave(Canvas& c, const RectF& sec, int u, int sound) {
    const float unit = sec.width() / 12.0F;
    auto cx = [&](int k) { return sec.left + unit * (static_cast<float>(k) + 0.5F); };
    const float r1 = 592.0F;
    const float r2 = 696.0F;
    const float rad = 20.0F;
    const float hw = unit - 4.0F;
    const int mode = std::clamp(rnd(waveP(u, sound, 0)), 0, 2);
    const int source = std::clamp(rnd(waveP(u, sound, 6)), 0, 6);
    secTitle(c, sec, "WAVE · " + soundLabel(sound));

    // row 1: MODE | POSITION START SMOOTH | SPAN FRAMES (AUTO) | the frames (MULTI)
    const char* modeNames[3] = {"OFF", "AUTO", "MULTI"};
    for (int k = 0; k < 3; ++k) {
        const RectF kr(cx(k) - hw / 2.0F + 2.0F, r1 - 24.0F, cx(k) + hw / 2.0F - 2.0F, r1 + 24.0F);
        stripToggle(c, kr, modeNames[k], mode == k, C_AMBER, 13.0F);
        hit(kr, [this, u, sound, k](float, float) { setWaveP(u, sound, 0, static_cast<float>(k)); });
    }
    text(c, "РЕЖИМ", cx(1), r1 + 56.0F, 11.0F, C_KNOB_LABEL, Opt().center().spacing(0.1F).maxW(3.0F * unit));

    auto pctKnob = [&](int col, float row, int id, const std::string& label, float lo, float hi, float minPct) {
        const float v = waveP(u, sound, id);
        knobControl(c, cx(col), row, rad, v, lo, hi, 0.005F, 260.0F, lo < 0.0F, std::to_string(rnd(v * 100.0F)) + " %", label, hw,
                    [this, u, sound, id](float nv) { setWaveP(u, sound, id, nv); },
                    [this, u, sound, id, label, v, lo, hi, minPct] {
                        showNumber(label + " %", v * 100.0F, std::max(lo * 100.0F, minPct), hi * 100.0F, 0, [this, u, sound, id](float x) { setWaveP(u, sound, id, x / 100.0F); });
                    },
                    [this, u, sound, id] { setWaveP(u, sound, id, waveDefault(id)); });
    };
    pctKnob(3, r1, 2, "POSITION", 0.0F, 1.0F, 0.0F);
    pctKnob(4, r1, 3, "START", 0.0F, 1.0F, 0.0F);
    pctKnob(5, r1, 5, "SMOOTH", 0.0F, 1.0F, 0.0F);
    if (mode == 2) {
        text(c, "МНОГО: кадрите са", cx(6) + unit * 0.5F, r1 - 8.0F, 11.0F, C_HINT, Opt().center().maxW(2.0F * unit));
        text(c, "избраните звукове", cx(6) + unit * 0.5F, r1 + 8.0F, 11.0F, C_HINT, Opt().center().maxW(2.0F * unit));
    } else {
        pctKnob(6, r1, 4, "SPAN", 0.0F, 1.0F, 2.0F);
        const float fr = waveP(u, sound, 1);
        knobControl(c, cx(7), r1, rad, fr, 2.0F, 32.0F, 1.0F, 260.0F, false, std::to_string(rnd(fr)), "FRAMES", hw,
                    [this, u, sound](float nv) { setWaveP(u, sound, 1, std::round(nv)); },
                    [this, u, sound, fr] { showNumber("FRAMES (кадри)", fr, 2.0F, 32.0F, 0, [this, u, sound](float x) { setWaveP(u, sound, 1, x); }); },
                    [this, u, sound] { setWaveP(u, sound, 1, waveDefault(1)); });
    }

    // row 2: what moves the position | AMOUNT | TIME / RATE
    const char* srcNames[7] = {"OFF", "ENV", "LFO", "VEL", "WHEEL", "AFTER", "NOTE"};
    const float kw = (6.0F * unit - 6.0F) / 7.0F;
    for (int k = 0; k < 7; ++k) {
        const RectF kr(sec.left + 2.0F + static_cast<float>(k) * (kw + 1.0F), r2 - 24.0F, sec.left + 2.0F + static_cast<float>(k) * (kw + 1.0F) + kw, r2 + 24.0F);
        stripToggle(c, kr, srcNames[k], source == k, C_AMBER, 11.0F);
        hit(kr, [this, u, sound, k](float, float) { setWaveP(u, sound, 6, static_cast<float>(k)); });
    }
    text(c, "ПОЗИЦИЯТА СЕ ДВИЖИ ОТ", sec.left + 3.0F * unit, r2 + 56.0F, 11.0F, C_KNOB_LABEL, Opt().center().spacing(0.1F).maxW(6.0F * unit));
    {
        const float am = waveP(u, sound, 7);
        knobControl(c, cx(6), r2, rad, am, -1.0F, 1.0F, 0.01F, 260.0F, true, (am > 0.004F ? "+" : std::string()) + std::to_string(rnd(am * 100.0F)) + " %", "AMOUNT", hw,
                    [this, u, sound](float nv) { setWaveP(u, sound, 7, nv); },
                    [this, u, sound, am] { showNumber("AMOUNT %", am * 100.0F, -100.0F, 100.0F, 0, [this, u, sound](float x) { setWaveP(u, sound, 7, x / 100.0F); }); },
                    [this, u, sound] { setWaveP(u, sound, 7, waveDefault(7)); });
    }
    if (source == 1) {
        const float t = waveP(u, sound, 8);
        const float norm = lnf(std::clamp(t, 10.0F, 20000.0F) / 10.0F) / lnf(2000.0F);
        knobControl(c, cx(7), r2, rad, norm, 0.0F, 1.0F, 0.002F, 260.0F, false, msText(t), "TIME", hw,
                    [this, u, sound](float nv) { setWaveP(u, sound, 8, rndf(10.0F * expf_(std::clamp(nv, 0.0F, 1.0F) * lnf(2000.0F)))); },
                    [this, u, sound, t] { showNumber("ВРЕМЕ ms", t, 10.0F, 20000.0F, 0, [this, u, sound](float x) { setWaveP(u, sound, 8, x); }); },
                    [this, u, sound] { setWaveP(u, sound, 8, waveDefault(8)); });
    } else if (source == 2) {
        const float r = waveP(u, sound, 9);
        const float norm = lnf(std::clamp(r, 0.02F, 30.0F) / 0.02F) / lnf(1500.0F);
        knobControl(c, cx(7), r2, rad, norm, 0.0F, 1.0F, 0.002F, 260.0F, false, fmtFixed(static_cast<double>(r), 2) + " Hz", "RATE", hw,
                    [this, u, sound](float nv) { setWaveP(u, sound, 9, 0.02F * expf_(std::clamp(nv, 0.0F, 1.0F) * lnf(1500.0F))); },
                    [this, u, sound, r] { showNumber("СКОРОСТ Hz", r, 0.02F, 30.0F, 2, [this, u, sound](float x) { setWaveP(u, sound, 9, x); }); },
                    [this, u, sound] { setWaveP(u, sound, 9, waveDefault(9)); });
    } else {
        text(c, source == 0 ? "ръчно" : "—", cx(7), r2 + 6.0F, 12.0F, C_HINT, Opt().center().maxW(hw));
    }

    // the right side: the frames of MULTI, or a short word about AUTO
    const float gx = sec.left + 8.0F * unit;
    if (mode == 2) {
        text(c, "ЗВУЦИ-КАДРИ  (допир = избор · дълго = изчисти)", gx + 2.0F * unit, r1 - 36.0F, 11.0F, C_KNOB_LABEL, Opt().center().spacing(0.05F).maxW(4.0F * unit));
        const std::vector<SoundItem> catalog = sampler.soundCatalog();
        for (int k = 0; k < 8; ++k) {
            const float col = static_cast<float>(k % 4);
            const float row = k < 4 ? r1 : r2;
            const RectF kr(gx + col * unit + 2.0F, row - 24.0F, gx + (col + 1.0F) * unit - 2.0F, row + 24.0F);
            const int slot = rnd(waveP(u, sound, 10 + k));
            std::string name = "—";
            if (slot > 0) {
                name = "#" + std::to_string(slot);
                for (const auto& it : catalog) if (it.slot == slot) { name = it.name; break; }
            }
            stripToggle(c, kr, std::to_string(k + 1) + " " + name, slot > 0, C_AMBER, 11.0F);
            hit(kr, [this, u, sound, k](float, float) { openPicker(u, kWavePickerBase + sound * 8 + k); },
                [this, u, sound, k] { setWaveP(u, sound, 10 + k, 0.0F); });
        }
    } else {
        text(c, mode == 1 ? "АВТО: семплът на звука се реже на кадри" : "TRANSWAVE е изключен", gx + 2.0F * unit, r1 - 6.0F, 12.0F, C_HINT, Opt().center().maxW(4.0F * unit));
        text(c, mode == 1 ? "START / SPAN / FRAMES казват откъде и колко" : "избери AUTO или MULTI", gx + 2.0F * unit, r1 + 12.0F, 11.0F, C_HINT, Opt().center().maxW(4.0F * unit));
    }
}

// ---------------------------------------------------------------- SILVETON_PORTA_MODES_V1 page
void SilvetonSamplerView::drawPorta(Canvas& c, const RectF& sec, const UpperState& s) {
    const int u = selectedUpper_;
    const std::vector<float> p = uParams(u);
    const bool kronos = getOr(p, 42, 0.0F) >= 0.5F;
    // SILVETON_MENU_V5: everything about how the UPPER plays its notes, in one place:
    // POLY / MONO / LEGATO, the portamento (SILVETON or KRONOS) and the pitch bend range.
    section(c, sec, "VOICE · UPPER " + std::to_string(u + 1) + " · POLY / MONO / LEGATO · PORTAMENTO · PITCH BEND");
    const float X = sec.left;
    for (int k = 0; k < 3; ++k) {
        const RectF mr(X + 16.0F, 572.0F + static_cast<float>(k) * 50.0F, X + 136.0F, 614.0F + static_cast<float>(k) * 50.0F);
        stripToggle(c, mr, k == 0 ? "POLY" : (k == 1 ? "MONO" : "LEGATO"), s.voiceMode == k, C_AMBER, 13.0F);
        hit(mr, [this, s, k](float, float) { UpperState cur = currentUpper(s); cur.voiceMode = k; commitMain(selectedUpper_, cur); invalidate(); });
    }
    line(c, X + 152.0F, 572.0F, X + 152.0F, 722.0F, Color::argb(60, 255, 255, 255), 1.0F);

    const RectF mA(X + 170.0F, sec.top + 40.0F, X + 330.0F, sec.top + 84.0F);
    const RectF mB(X + 338.0F, sec.top + 40.0F, X + 498.0F, sec.top + 84.0F);
    stripToggle(c, mA, "SILVETON", !kronos, C_AMBER, 13.0F);
    stripToggle(c, mB, "KRONOS", kronos, C_AMBER, 13.0F);
    hit(mA, [this, u](float, float) { setUParam(u, 42, 0.0F); });
    hit(mB, [this, u](float, float) { setUParam(u, 42, 1.0F); });
    const float cy = darkTheme ? 674.0F : 664.0F;   // the dark theme prints the knob names above the knobs
    if (!kronos) {
        // SILVETON_PORTA_UI_ROUTE_V2: TIME is a TUNE parameter, not a TONE parameter.
        const float porta = portamentoUiValue(s.portamentoSec);
        auto setPorta = [this, s](float v) { UpperState n = currentUpper(s); n.portamentoSec = portamentoSecondsFromUi(v); commitTune(n); };
        knobControl(c, X + 265.0F, cy, 30.0F, porta, 0.0F, 100.0F, 1.0F, 300.0F, false,
                    porta <= 0.0F ? std::string("OFF") : fmtFixed(static_cast<double>(porta), 2) + " ms", "PORTAMENTO TIME", 190.0F,
                    setPorta,
                    [this, porta, setPorta] { showNumber("PORTAMENTO TIME ms (0 = OFF)", porta, 0.0F, 100.0F, 0, setPorta); },
                    [this, s] { UpperState n = currentUpper(s); n.portamentoSec = 0.0F; commitTune(n); });
        const float bal = static_cast<float>(sampler.portaBalance());
        knobControl(c, X + 465.0F, cy, 30.0F, bal, 3.0F, 40.0F, 1.0F, 300.0F, false, std::to_string(static_cast<int>(bal)), "BALANCE", 190.0F,
                    [this](float nv) { sampler.setPortaBalance(rnd(nv)); },
                    [this, bal] { showNumber("PORTA BALANCE (мекота)", bal, 3.0F, 40.0F, 0, [this](float x) { sampler.setPortaBalance(rnd(x)); }); },
                    [this] { sampler.setPortaBalance(11); });
        const float nearV = static_cast<float>(sampler.portaNear());
        knobControl(c, X + 665.0F, cy, 30.0F, nearV, 0.0F, 400.0F, 1.0F, 300.0F, false, fmtFixed(static_cast<double>(nearV), 2) + " ms", "TIME СЪСЕДНИ", 190.0F,
                    [this](float nv) { sampler.setPortaNear(rnd(nv)); },
                    [this, nearV] { showNumber("TIME СЪСЕДНИ ТОНОВЕ ms", nearV, 0.0F, 400.0F, 0, [this](float x) { sampler.setPortaNear(rnd(x)); }); },
                    [this] { sampler.setPortaNear(90); });
        text(c, "Меко влизане · чисто достигане точно в TIME · BALANCE задава мекотата", X + 170.0F, sec.bottom - 12.0F, 11.0F, C_HINT, Opt().maxW(600.0F));
    } else {
        const float t = getOr(p, 45, 40.0F);
        knobControl(c, X + 265.0F, cy, 30.0F, t, 0.0F, 127.0F, 1.0F, 300.0F, false, t <= 0.0F ? std::string("OFF") : std::to_string(static_cast<int>(t)), "TIME 0–127", 190.0F,
                    [this, u](float nv) { setUParam(u, 45, rndf(nv)); },
                    [this, u, t] { showNumber("KRONOS PORTA TIME (0 = OFF)", t, 0.0F, 127.0F, 0, [this, u](float x) { setUParam(u, 45, rndf(x)); }); },
                    [this, u] { setUParam(u, 45, 0.0F); });
        const bool fing = getOr(p, 43, 0.0F) >= 0.5F;
        const RectF fr(X + 400.0F, cy - 24.0F, X + 580.0F, cy + 24.0F);
        stripToggle(c, fr, "FINGERED", fing, C_AMBER, 13.0F);
        hit(fr, [this, u, fing](float, float) { setUParam(u, 43, fing ? 0.0F : 1.0F); });
        text(c, "само докато държиш клавиш", X + 490.0F, cy + 48.0F, 11.0F, C_KNOB_LABEL, Opt().center());
        const bool rate = getOr(p, 44, 0.0F) >= 0.5F;
        const RectF rA(X + 600.0F, cy - 24.0F, X + 700.0F, cy + 24.0F);
        const RectF rB(X + 706.0F, cy - 24.0F, X + 806.0F, cy + 24.0F);
        stripToggle(c, rA, "TIME", !rate, C_AMBER, 13.0F);
        stripToggle(c, rB, "RATE", rate, C_AMBER, 13.0F);
        hit(rA, [this, u](float, float) { setUParam(u, 44, 0.0F); });
        hit(rB, [this, u](float, float) { setUParam(u, 44, 1.0F); });
        text(c, rate ? "RATE: времето е за една октава" : "TIME: едно и също време за всеки интервал", X + 703.0F, cy + 48.0F, 11.0F, C_KNOB_LABEL, Opt().center());
        text(c, "Меко, стегнато преливане · TIME / RATE", X + 170.0F, sec.bottom - 12.0F, 11.0F, C_HINT, Opt().maxW(600.0F));
    }
    // PITCH BEND RANGE of this Upper
    line(c, X + 830.0F, 572.0F, X + 830.0F, 722.0F, Color::argb(60, 255, 255, 255), 1.0F);
    const float bend = getOr(p, 48, static_cast<float>(s.pitchBendRange));
    knobControl(c, X + 910.0F, cy, 30.0F, bend, 0.0F, 24.0F, 1.0F, 300.0F, false, std::to_string(static_cast<int>(bend)) + " st", "PITCH BEND", 150.0F,
                [this, u](float nv) { setUParam(u, 48, rndf(nv)); refreshUpper(u); },
                [this, u, bend] { showNumber("PITCH BEND RANGE (полутонове)", bend, 0.0F, 24.0F, 0, [this, u](float x) { setUParam(u, 48, rndf(x)); refreshUpper(u); }); },
                [this, u] { setUParam(u, 48, 2.0F); refreshUpper(u); });
    const int bends[3] = {2, 7, 12};
    for (int k = 0; k < 3; ++k) {
        const int v = bends[k];
        const RectF br(X + 990.0F + static_cast<float>(k) * 72.0F, cy - 22.0F, X + 1054.0F + static_cast<float>(k) * 72.0F, cy + 22.0F);
        stripToggle(c, br, std::to_string(v), static_cast<int>(bend) == v, C_AMBER, 14.0F);
        hit(br, [this, u, v](float, float) { setUParam(u, 48, static_cast<float>(v)); refreshUpper(u); });
    }
}

// PORTAMENTO TIME like the SILVETON keyboard processor: 0 = OFF, 1..100 ms (linear, the same total time for every interval).
float SilvetonSamplerView::portamentoUiValue(float seconds) {
    if (seconds <= 0.0F) return 0.0F;
    return std::clamp(seconds * 1000.0F, 1.0F, 100.0F);
}

float SilvetonSamplerView::portamentoSecondsFromUi(float value) {
    const float ms = rndf(std::clamp(value, 0.0F, 100.0F));
    return ms <= 0.0F ? 0.0F : ms / 1000.0F;
}

void SilvetonSamplerView::drawTune(Canvas& c, const RectF& sec, const UpperState& s) {
    // SILVETON_MENU_V5: only the pitch of the sound lives here; PORTAMENTO and PITCH BEND are on the VOICE page (once).
    section(c, sec, "TUNE · ВИСОЧИНА НА ЗВУКА");
    const float cy = 644.0F;
    const float cx[3] = {sec.left + sec.width() / 6.0F, sec.left + sec.width() / 2.0F, sec.left + sec.width() * 5.0F / 6.0F};

    // SILVETON_GUI_V3: OCTAVE and TRANSPOSE on - / + keys; both keys together = 0.
    stepper(c, RectF(cx[0] - 100.0F, 560.0F, cx[0] + 100.0F, 726.0F), "ОКТАВА", signed_(s.octave),
            [this, s] { UpperState cur = currentUpper(s); cur.octave = std::max(cur.octave - 1, -4); commitTune(cur); },
            [this, s] { UpperState cur = currentUpper(s); cur.octave = std::min(cur.octave + 1, 4); commitTune(cur); },
            [this, s] { UpperState cur = currentUpper(s); cur.octave = 0; commitTune(cur); });
    stepper(c, RectF(cx[1] - 100.0F, 560.0F, cx[1] + 100.0F, 726.0F), "ТРАНСПОНИРАНЕ", signed_(s.transpose),
            [this, s] { UpperState cur = currentUpper(s); cur.transpose = std::max(cur.transpose - 1, -12); commitTune(cur); },
            [this, s] { UpperState cur = currentUpper(s); cur.transpose = std::min(cur.transpose + 1, 12); commitTune(cur); },
            [this, s] { UpperState cur = currentUpper(s); cur.transpose = 0; commitTune(cur); });

    // SILVETON_TUNE_RANGES_V1: -1200..+1200 cents (one octave each way).
    knobControl(c, cx[2], cy, 42.0F, s.fineCents, -1200.0F, 1200.0F, 1.0F, 600.0F, true, fmtFixed(static_cast<double>(s.fineCents), 2) + " ct", "ФИНА НАСТРОЙКА",
                [this, s](float nv) { UpperState n = currentUpper(s); n.fineCents = nv; commitTune(n); },
                [this, s] {
                    showNumber("ФИНА НАСТРОЙКА ct", s.fineCents, -1200.0F, 1200.0F, 0, [this, s](float nv) { UpperState n = currentUpper(s); n.fineCents = nv; commitTune(n); });
                },
                [this, s] { UpperState n = currentUpper(s); n.fineCents = 0.0F; commitTune(n); });

    hintLine(c, sec);
}

void SilvetonSamplerView::hintLine(Canvas& c, const RectF& sec) {
    text(c, "Влачи копчето нагоре/надясно · Докосни стойността = въвеждане на число · Двоен допир = по подразбиране", sec.left + 16.0F, sec.bottom - 12.0F, 11.0F, C_HINT,
         Opt().spacing(0.03F).maxW(sec.width() - 32.0F));
}

void SilvetonSamplerView::drawRange(Canvas& c, const RectF& sec, const UpperState& s) {
    const float halfW = (sec.width() - 12.0F) / 2.0F;
    const RectF vel(sec.left, sec.top, sec.left + halfW, sec.bottom);
    rangeHalf(c, vel, "VELOCITY RANGE · СИЛА НА УДАРА", "МИН", "МАКС", s.velocityLow, s.velocityHigh, 1, 127, [](int v) { return std::to_string(v); },
              "Влачи краищата · Докосни числото = точна стойност · Двоен допир = 1–127",
              [this, s](int lo, int hi) { UpperState n = currentUpper(s); n.velocityLow = lo; n.velocityHigh = hi; commitRange(n); },
              [this, s] {
                  showNumber("VELOCITY МИН", static_cast<float>(s.velocityLow), 1.0F, 127.0F, 0, [this, s](float x) {
                      UpperState n = currentUpper(s);
                      n.velocityLow = std::min(rnd(x), n.velocityHigh);
                      commitRange(n);
                  });
              },
              [this, s] {
                  showNumber("VELOCITY МАКС", static_cast<float>(s.velocityHigh), 1.0F, 127.0F, 0, [this, s](float x) {
                      UpperState n = currentUpper(s);
                      n.velocityHigh = std::max(rnd(x), n.velocityLow);
                      commitRange(n);
                  });
              },
              [this, s] { UpperState n = currentUpper(s); n.velocityLow = 1; n.velocityHigh = 127; commitRange(n); });

    // SILVETON_RANGE_KEY_V1: KEY RANGE is set exactly like the VELOCITY RANGE (bar with two handles, numbers, double tap = reset).
    const RectF key(vel.right + 12.0F, sec.top, sec.right, sec.bottom);
    rangeHalf(c, key, "KEY RANGE · ОБХВАТ", "ОТ", "ДО", s.keyLow, s.keyHigh, 0, 127, [](int v) { return noteName(v); },
              "Влачи краищата · Докосни нотите = точна стойност · Двоен допир = цялата",
              [this, s](int lo, int hi) { UpperState n = currentUpper(s); n.keyLow = lo; n.keyHigh = hi; commitMain(selectedUpper_, n); },
              [this, s] {
                  showNumber("КЛАВИШ ОТ (0 = C-1 · 60 = C4)", static_cast<float>(s.keyLow), 0.0F, 127.0F, 0, [this, s](float x) {
                      UpperState n = currentUpper(s);
                      n.keyLow = std::min(rnd(x), n.keyHigh);
                      commitMain(selectedUpper_, n);
                  });
              },
              [this, s] {
                  showNumber("КЛАВИШ ДО (0 = C-1 · 60 = C4)", static_cast<float>(s.keyHigh), 0.0F, 127.0F, 0, [this, s](float x) {
                      UpperState n = currentUpper(s);
                      n.keyHigh = std::max(rnd(x), n.keyLow);
                      commitMain(selectedUpper_, n);
                  });
              },
              [this, s] { sampler.cancelKeyScan(); UpperState n = currentUpper(s); n.keyLow = 0; n.keyHigh = 127; commitMain(selectedUpper_, n); },
              true, selectedUpper_);
}

// One half of a RANGE page: title, bar with two handles, the two numbers at the sides (tap = exact value, double tap = reset).
void SilvetonSamplerView::rangeHalf(Canvas& c, const RectF& half, const std::string& title, const std::string& lowLabel, const std::string& highLabel,
                                    int lo, int hi, int minV, int maxV, const std::function<std::string(int)>& fmt, const std::string& hint,
                                    std::function<void(int, int)> onRange, std::function<void()> exactLow, std::function<void()> exactHigh,
                                    std::function<void()> reset, bool keyboard, int scanUpper) {
    section(c, half, title);
    // SILVETON_KEY_SCAN_V1: quick key - tap, then press a key on the piano: this Upper plays up to it. Tap again = cancel.
    if (scanUpper >= 0 && scanUpper <= 6) {
        const RectF sr(half.right - 168.0F, half.top + 10.0F, half.right - 14.0F, half.top + 44.0F);
        const bool scanning = sampler.keyScanUpper() == scanUpper;
        const bool blink = scanning && (nowMs() / 300) % 2 == 0;
        stripToggle(c, sr, scanning ? "НАТИСНИ КЛАВИШ…" : "SCAN КЛАВИШ", scanning, blink ? C_ACCENT : C_AMBER, 12.0F);
        if (scanning) postInvalidateDelayed(150);
        hit(sr, [this, scanning, scanUpper](float, float) {
            if (scanning) sampler.cancelKeyScan(); else sampler.startKeyScan(scanUpper);
            invalidate();
        });
    }
    const RectF bar(half.left + 110.0F, 640.0F, half.right - 110.0F, 652.0F);
    drawRangeBar(c, bar, static_cast<float>(lo), static_cast<float>(hi), static_cast<float>(minV), static_cast<float>(maxV));
    registerSmoothRange(RectF(bar.left, bar.top - 26.0F, bar.right, bar.bottom + 26.0F), static_cast<float>(minV), static_cast<float>(maxV), 1.0F,
                        static_cast<float>(lo), static_cast<float>(hi), [onRange](float a, float b) { onRange(rnd(a), rnd(b)); });
    text(c, lowLabel, half.left + 55.0F, 616.0F, 11.0F, C_KNOB_LABEL, Opt().center().spacing(0.2F));
    text(c, fmt(lo), half.left + 55.0F, 656.0F, 28.0F, C_VALUE, Opt().center().mono().maxW(100.0F));
    text(c, highLabel, half.right - 55.0F, 616.0F, 11.0F, C_KNOB_LABEL, Opt().center().spacing(0.2F));
    text(c, fmt(hi), half.right - 55.0F, 656.0F, 28.0F, C_VALUE, Opt().center().mono().maxW(100.0F));
    hit(RectF(half.left, 596.0F, bar.left - 4.0F, 700.0F), [exactLow](float, float) { exactLow(); }, reset);
    hit(RectF(bar.right + 4.0F, 596.0F, half.right, 700.0F), [exactHigh](float, float) { exactHigh(); }, reset);
    if (keyboard) drawMiniKeyboard(c, RectF(half.left + 20.0F, 692.0F, half.right - 20.0F, 728.0F), lo, hi);
    text(c, hint, half.left + 16.0F, half.bottom - 12.0F, 11.0F, C_HINT, Opt().maxW(half.width() - 32.0F));
}

void SilvetonSamplerView::drawControl(Canvas& c, const RectF& sec, const UpperState& s) {
    section(c, sec, "CONTROL · КОНТРОЛЕРИ НА UPPER");
    const float colW = (sec.width() - 32.0F) / 5.0F;
    struct Item { const char* name; const char* cc; bool on; };
    const Item items[4] = {{"BREATH", "CC2", s.breath}, {"EXPRESSION", "CC11", s.expression}, {"AFTERTOUCH", "PRESSURE", s.aftertouch}, {"DAMPER", "CC64", s.damper}};
    for (int k = 0; k < 4; ++k) {
        const float cx = sec.left + 16.0F + colW * (static_cast<float>(k) + 0.5F);
        const RectF key(cx - 92.0F, 584.0F, cx + 92.0F, 694.0F);
        switchKey(c, key, items[k].name, items[k].cc, items[k].on);
        hit(key, [this, s, k](float, float) {
            UpperState cur = currentUpper(s);
            switch (k) {
                case 0: cur.breath = !cur.breath; break;
                case 1: cur.expression = !cur.expression; break;
                case 2: cur.aftertouch = !cur.aftertouch; break;
                default: cur.damper = !cur.damper; break;
            }
            commitControl(cur);
        });
    }
    const float cx = sec.left + 16.0F + colW * 4.5F;
    knobControl(c, cx, 626.0F, 38.0F, static_cast<float>(s.midiChannel + 1), 1.0F, 16.0F, 1.0F, 220.0F, false, "CH " + std::to_string(s.midiChannel + 1), "MIDI КАНАЛ",
                [this, s](float nv) { UpperState n = currentUpper(s); n.midiChannel = static_cast<int>(nv) - 1; commitControl(n); },
                [this, s] {
                    showNumber("MIDI Channel", static_cast<float>(s.midiChannel + 1), 1.0F, 16.0F, 0, [this, s](float x) {
                        UpperState n = currentUpper(s);
                        n.midiChannel = static_cast<int>(x) - 1;
                        commitControl(n);
                    });
                },
                [this, s] { UpperState n = currentUpper(s); n.midiChannel = 0; commitControl(n); });
    text(c, "Докосни бутона = ВКЛ/ИЗКЛ", sec.left + 16.0F, sec.bottom - 12.0F, 11.0F, C_HINT);
}

// ---------------------------------------------------------------- TONE helpers
float SilvetonSamplerView::toneValue(const UpperState& s, TonePar p) {
    switch (p) {
        case TonePar::ATTACK: return s.toneAttackMs;
        case TonePar::DECAY: return s.toneDecayMs;
        case TonePar::SUSTAIN: return s.toneSustain;
        case TonePar::RELEASE: return s.toneReleaseMs;
        case TonePar::CUTOFF: return s.toneCutoffHz;
        case TonePar::RESONANCE: return s.toneResonance;
    }
    return 0.0F;
}

float SilvetonSamplerView::toneToNorm(TonePar p, float v) {
    switch (p) {
        case TonePar::ATTACK:
        case TonePar::DECAY:
        case TonePar::RELEASE: return lnf(std::clamp(v, 0.0F, 20000.0F) + 1.0F) / lnf(20001.0F);
        case TonePar::SUSTAIN:
        case TonePar::RESONANCE: return std::clamp(v, 0.0F, 1.0F);
        case TonePar::CUTOFF: return lnf(std::clamp(v, 20.0F, 20000.0F) / 20.0F) / lnf(1000.0F);
    }
    return 0.0F;
}

float SilvetonSamplerView::toneFromNorm(TonePar p, float t) {
    const float n = std::clamp(t, 0.0F, 1.0F);
    switch (p) {
        case TonePar::ATTACK:
        case TonePar::DECAY:
        case TonePar::RELEASE: return rndf(std::clamp(expf_(n * lnf(20001.0F)) - 1.0F, 0.0F, 20000.0F));
        case TonePar::SUSTAIN:
        case TonePar::RESONANCE: return rndf(n * 1000.0F) / 1000.0F;
        case TonePar::CUTOFF: return n >= 0.999F ? 20000.0F : rndf(20.0F * static_cast<float>(std::pow(1000.0, static_cast<double>(n))));
    }
    return 0.0F;
}

std::string SilvetonSamplerView::toneText(TonePar p, float v) {
    switch (p) {
        case TonePar::ATTACK:
        case TonePar::DECAY:
        case TonePar::RELEASE:
            return v < 1000.0F ? std::to_string(rnd(v)) + " ms" : fmtFixed(static_cast<double>(v / 1000.0F), 2) + " s";
        case TonePar::SUSTAIN:
        case TonePar::RESONANCE: return fmtFixed(static_cast<double>(v * 100.0F), 2) + " %";
        case TonePar::CUTOFF:
            if (v >= 19900.0F) return "OPEN";
            if (v < 1000.0F) return std::to_string(rnd(v)) + " Hz";
            return fmtFixed(static_cast<double>(v / 1000.0F), 2) + " kHz";
    }
    return "";
}

SilvetonSamplerView::ToneRange SilvetonSamplerView::toneRange(TonePar p) {
    switch (p) {
        case TonePar::ATTACK:
        case TonePar::DECAY:
        case TonePar::RELEASE: return {0.0F, 20000.0F, 0};
        case TonePar::SUSTAIN:
        case TonePar::RESONANCE: return {0.0F, 100.0F, 0};
        case TonePar::CUTOFF: return {20.0F, 20000.0F, 0};
    }
    return {0.0F, 1.0F, 0};
}

void SilvetonSamplerView::setTone(TonePar p, float value) {
    const auto& slot = upperStates[static_cast<std::size_t>(selectedUpper_)];
    if (!slot) return;
    UpperState cur = *slot;
    sampler.setUpperTone(selectedUpper_, static_cast<int>(p), value);
    for (const int t : linkTargets(selectedUpper_)) {   // ЛИНК: same value on the marked ones
        sampler.setUpperTone(t, static_cast<int>(p), value);
        refreshUpper(t);
    }
    if (value < 0.0F) {
        const auto fresh = sampler.upperState(selectedUpper_);
        upperStates[static_cast<std::size_t>(selectedUpper_)] = fresh ? *fresh : cur;
        return;
    }
    const int bit = cur.toneSet | (1 << static_cast<int>(p));
    switch (p) {
        case TonePar::ATTACK: cur.toneAttackMs = value; break;
        case TonePar::DECAY: cur.toneDecayMs = value; break;
        case TonePar::SUSTAIN: cur.toneSustain = value; break;
        case TonePar::RELEASE: cur.toneReleaseMs = value; break;
        case TonePar::CUTOFF: cur.toneCutoffHz = value; break;
        case TonePar::RESONANCE: cur.toneResonance = value; break;
    }
    cur.toneSet = bit;
    upperStates[static_cast<std::size_t>(selectedUpper_)] = cur;
}

// ---------------------------------------------------------------- FX page of the Upper
void SilvetonSamplerView::drawUpperFx(Canvas& c, const RectF& sec, const UpperState& s) {
    section(c, sec, "FX · ИЗПРАЩАНЕ КЪМ ЕФЕКТИТЕ · INSERT");
    const int u = selectedUpper_;
    const std::vector<float> p = uParams(u);
    for (int n = 1; n <= 4; ++n) {
        const float value = n == 1 ? s.fxSend1 : (n == 2 ? s.fxSend2 : (n == 3 ? getOr(p, 46, 0.0F) : getOr(p, 47, 0.0F)));
        const std::function<void(float)> apply = [this, s, u, n](float nv) {
            if (n == 1) { UpperState x = currentUpper(s); x.fxSend1 = nv; commitUpperFx(x); }
            else if (n == 2) { UpperState x = currentUpper(s); x.fxSend2 = nv; commitUpperFx(x); }
            else if (n == 3) setUParam(u, 46, nv);
            else setUParam(u, 47, nv);
        };
        const int fxType = static_cast<int>(getOr(fxP(n - 1), 0, 0.0F));
        knobControl(c, sec.left + 90.0F + static_cast<float>(n - 1) * 180.0F, 640.0F, 36.0F, value, 0.0F, 1.0F, 0.01F, 250.0F, false,
                    fmtFixed(static_cast<double>(value * 100.0F), 2) + " %", "FX" + std::to_string(n) + " · " + effectName(fxType), 170.0F,
                    apply,
                    [this, n, value, apply] {
                        showNumber("FX" + std::to_string(n) + " SEND %", value * 100.0F, 0.0F, 100.0F, 0, [apply](float pct) { apply(std::clamp(pct / 100.0F, 0.0F, 1.0F)); });
                    },
                    [apply] { apply(0.0F); });
    }
    const std::vector<float> ins = fxP(4 + u);
    const RectF insR(sec.left + 760.0F, sec.top + 60.0F, sec.right - 16.0F, sec.top + 120.0F);
    lcd(c, insR, 8.0F);
    text(c, "INSERT U" + std::to_string(u + 1), insR.left + 14.0F, insR.top + 22.0F, 11.0F, C_LCD_DIM, Opt().mono().spacing(0.2F));
    const int insType = static_cast<int>(getOr(ins, 0, 0.0F));
    text(c, effectName(insType) + (insType != 0 ? "   MIX " + fmtFixed(static_cast<double>(getOr(ins, 1, 0.0F) * 100.0F), 2) + " %" : std::string()), insR.left + 14.0F, insR.top + 48.0F, 20.0F,
         C_LCD, Opt().mono().maxW(insR.width() - 28.0F));
    hit(insR, [this, u](float, float) { fxUnitFocus = 4 + u; page_ = Page::EFFECTS; refreshFx(); });
    const RectF open(sec.left + 760.0F, sec.top + 136.0F, sec.right - 16.0F, sec.top + 184.0F);
    lightKey(c, open, "ОТВОРИ ЕФЕКТИТЕ (FX1–FX4 · INSERT)");
    hit(open, [this](float, float) { fxUnitFocus = 0; page_ = Page::EFFECTS; refreshFx(); });
    hintLine(c, sec);
}

} // namespace silveton::ui
