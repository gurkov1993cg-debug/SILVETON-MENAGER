#pragma once
// Private to the drawing layer: letters as outlines, and their widths.
#include "silveton/ui/Gfx.h"

#include <cstdint>
#include <string>
#include <vector>

namespace silveton::ui::detail {

// One letter: its outline in font units (y up; contours as x,y pairs, all closed) and its advance.
struct GlyphOutline {
    std::vector<std::vector<float>> contours;
    float advance{0.0F};
    float unitsPerEm{2048.0F};
};

struct ShapedGlyph {
    const GlyphOutline* outline{nullptr};
    float scale{1.0F};     // pixels per font unit at the requested size
    float advancePx{0.0F}; // advance in pixels (without letter spacing)
};

// Splits the UTF-8 text into letters and looks up the outline of each in the font (with fallback fonts for symbols).
std::vector<ShapedGlyph> shapeText(const std::string& utf8, Face face, float sizePx);

// Decodes UTF-8 into code points (invalid bytes become U+FFFD).
std::vector<std::uint32_t> decodeUtf8(const std::string& s);
std::string encodeUtf8(const std::vector<std::uint32_t>& cps, std::size_t from, std::size_t to);

} // namespace silveton::ui::detail
