# SILVETON MANAGER — INFO / SOUND 001–500 update

Date: 2026-10-05

## Implemented

- Permanent SILVETON SOUND/INFO position range: 001…500.
- Each finished blend has a unique persistent `SoundDefinition::position`.
- Bank Organizer exposes `INFO Pos` and validates 1…500.
- Duplicate positions are rejected.
- Automatic import assigns the first free SOUND position.
- The 501st SOUND is rejected when all 500 positions are occupied.
- `.sv` format minor version is 1.1 and stores SOUND position in existing record padding so legacy field offsets remain unchanged.
- Stable uint32 SampleID and MultisampleID are serialized in `.sv` record padding and validated by the reader.
- Layer/zone records also carry their stable target IDs in addition to legacy indices.
- KSC import is transactional at collection level: missing referenced external KMP/KSF stops that collection import instead of silently skipping it.
- KSC sample deduplication uses audio hash plus metadata/audio equality and remaps zones to a shared sample.
- Uncompressed 8-bit KSF is converted to PCM16; 16-bit KSF remains PCM16; original sample rate is retained.
- Existing Bank/Page/Slot organization remains available independently of permanent SOUND position.

## Verification performed in this environment

CMake portable core build succeeded.

CTest result:
- silveton_manager_core — PASS
- silveton_sample_editor_regions — PASS
- silveton_sound_editor — PASS
- silveton_media_paths — PASS
- silveton_object_manager — PASS
- silveton_sample_converter — PASS

Result: 6/6 PASS.

Tests include filling SOUND positions to exactly 500 and proving a 501st creation is rejected, stable ID/.sv round-trip, 8-bit KSF -> PCM16 conversion, and KSC dedup/remapping.

## macOS build note

The portable C++ core is compiled and tested here. The AppKit Objective-C++ GUI target requires macOS/Xcode and therefore must be compiled by the project's Codemagic/Xcode macOS build environment.
