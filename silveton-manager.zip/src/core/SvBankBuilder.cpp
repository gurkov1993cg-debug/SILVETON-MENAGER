#include "silveton/manager/SvBankBuilder.h"

#include "silveton/manager/SampleHash.h"
#include "silveton/manager/SvBankFormat.h"
#include "silveton/manager/SvBankReader.h"

#include <algorithm>
#include <array>
#include <cerrno>
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <limits>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

namespace silveton::manager {
namespace {

std::uint64_t alignUp(std::uint64_t value, std::uint64_t alignment) noexcept {
    if (alignment == 0U) return value;
    const std::uint64_t mask = alignment - 1U;
    return (value + mask) & ~mask;
}

bool toU32(std::size_t value, std::uint32_t& out) noexcept {
    if (value > static_cast<std::size_t>(std::numeric_limits<std::uint32_t>::max())) return false;
    out = static_cast<std::uint32_t>(value);
    return true;
}

class StringTable {
public:
    StringTable() { bytes_.push_back(0U); offsets_.emplace(std::string{}, 0U); }

    std::uint32_t add(const std::string& text) {
        const auto found = offsets_.find(text);
        if (found != offsets_.end()) return found->second;
        const auto offset = static_cast<std::uint32_t>(bytes_.size());
        bytes_.insert(bytes_.end(), text.begin(), text.end());
        bytes_.push_back(0U);
        offsets_.emplace(text, offset);
        return offset;
    }

    const std::vector<std::uint8_t>& bytes() const noexcept { return bytes_; }

private:
    std::vector<std::uint8_t> bytes_;
    std::unordered_map<std::string, std::uint32_t> offsets_;
};

// One stored copy of audio: the first project sample that carries these bytes.
struct UniqueAudio {
    std::uint64_t hash{0};
    std::size_t sampleIndex{0};
    std::uint64_t offset{0};
    std::uint64_t size{0};
};

bool sameAudio(const ImportedSample& a, const ImportedSample& b) noexcept {
    return a.sampleRate == b.sampleRate && a.channels == b.channels && a.encoding == b.encoding &&
           a.bitsPerSample == b.bitsPerSample && a.audioData == b.audioData;
}

void appendSection(std::vector<std::uint8_t>& file, SvSectionDesc& section,
                   const std::vector<std::uint8_t>& data, std::uint64_t alignment) {
    const std::uint64_t aligned = alignUp(file.size(), alignment);
    if (aligned > file.size()) file.resize(static_cast<std::size_t>(aligned), 0U);
    section.offset = static_cast<std::uint64_t>(file.size());
    section.size = static_cast<std::uint64_t>(data.size());
    file.insert(file.end(), data.begin(), data.end());
}

// Streaming SHA-256 (same result as sha256() in SvBankFormat, fed in pieces).
class Sha256Stream {
public:
    void update(const std::uint8_t* data, std::size_t size) noexcept {
        total_ += size;
        while (size > 0U) {
            const std::size_t take = std::min(size, 64U - fill_);
            std::memcpy(block_.data() + fill_, data, take);
            fill_ += take; data += take; size -= take;
            if (fill_ == 64U) { compress(); fill_ = 0U; }
        }
    }
    std::array<std::uint8_t, 32> finish() noexcept {
        const std::uint64_t bits = total_ * 8U;
        const std::uint8_t one = 0x80U;
        update(&one, 1U);
        const std::uint8_t zero = 0U;
        while (fill_ != 56U) update(&zero, 1U);
        std::uint8_t len[8];
        for (unsigned i = 0U; i < 8U; ++i) len[7U - i] = static_cast<std::uint8_t>((bits >> (i * 8U)) & 0xFFU);
        total_ -= 9U;   // padding is not part of the message length
        update(len, 8U);
        std::array<std::uint8_t, 32> out{};
        for (std::size_t i = 0U; i < 8U; ++i) {
            out[i * 4U] = static_cast<std::uint8_t>((h_[i] >> 24U) & 0xFFU);
            out[i * 4U + 1U] = static_cast<std::uint8_t>((h_[i] >> 16U) & 0xFFU);
            out[i * 4U + 2U] = static_cast<std::uint8_t>((h_[i] >> 8U) & 0xFFU);
            out[i * 4U + 3U] = static_cast<std::uint8_t>(h_[i] & 0xFFU);
        }
        return out;
    }

private:
    static std::uint32_t rotr(std::uint32_t x, std::uint32_t n) noexcept { return (x >> n) | (x << (32U - n)); }
    void compress() noexcept {
        static constexpr std::array<std::uint32_t, 64> k{{
            0x428a2f98U,0x71374491U,0xb5c0fbcfU,0xe9b5dba5U,0x3956c25bU,0x59f111f1U,0x923f82a4U,0xab1c5ed5U,
            0xd807aa98U,0x12835b01U,0x243185beU,0x550c7dc3U,0x72be5d74U,0x80deb1feU,0x9bdc06a7U,0xc19bf174U,
            0xe49b69c1U,0xefbe4786U,0x0fc19dc6U,0x240ca1ccU,0x2de92c6fU,0x4a7484aaU,0x5cb0a9dcU,0x76f988daU,
            0x983e5152U,0xa831c66dU,0xb00327c8U,0xbf597fc7U,0xc6e00bf3U,0xd5a79147U,0x06ca6351U,0x14292967U,
            0x27b70a85U,0x2e1b2138U,0x4d2c6dfcU,0x53380d13U,0x650a7354U,0x766a0abbU,0x81c2c92eU,0x92722c85U,
            0xa2bfe8a1U,0xa81a664bU,0xc24b8b70U,0xc76c51a3U,0xd192e819U,0xd6990624U,0xf40e3585U,0x106aa070U,
            0x19a4c116U,0x1e376c08U,0x2748774cU,0x34b0bcb5U,0x391c0cb3U,0x4ed8aa4aU,0x5b9cca4fU,0x682e6ff3U,
            0x748f82eeU,0x78a5636fU,0x84c87814U,0x8cc70208U,0x90befffaU,0xa4506cebU,0xbef9a3f7U,0xc67178f2U}};
        std::array<std::uint32_t, 64> w{};
        for (std::size_t i = 0U; i < 16U; ++i) {
            const std::size_t j = i * 4U;
            w[i] = (static_cast<std::uint32_t>(block_[j]) << 24U) | (static_cast<std::uint32_t>(block_[j + 1U]) << 16U) |
                   (static_cast<std::uint32_t>(block_[j + 2U]) << 8U) | static_cast<std::uint32_t>(block_[j + 3U]);
        }
        for (std::size_t i = 16U; i < 64U; ++i) {
            const std::uint32_t s0 = rotr(w[i - 15U], 7U) ^ rotr(w[i - 15U], 18U) ^ (w[i - 15U] >> 3U);
            const std::uint32_t s1 = rotr(w[i - 2U], 17U) ^ rotr(w[i - 2U], 19U) ^ (w[i - 2U] >> 10U);
            w[i] = w[i - 16U] + s0 + w[i - 7U] + s1;
        }
        std::uint32_t a = h_[0], b = h_[1], c = h_[2], d = h_[3], e = h_[4], f = h_[5], g = h_[6], hh = h_[7];
        for (std::size_t i = 0U; i < 64U; ++i) {
            const std::uint32_t s1 = rotr(e, 6U) ^ rotr(e, 11U) ^ rotr(e, 25U);
            const std::uint32_t ch = (e & f) ^ ((~e) & g);
            const std::uint32_t temp1 = hh + s1 + ch + k[i] + w[i];
            const std::uint32_t s0 = rotr(a, 2U) ^ rotr(a, 13U) ^ rotr(a, 22U);
            const std::uint32_t maj = (a & b) ^ (a & c) ^ (b & c);
            const std::uint32_t temp2 = s0 + maj;
            hh = g; g = f; f = e; e = d + temp1; d = c; c = b; b = a; a = temp1 + temp2;
        }
        h_[0] += a; h_[1] += b; h_[2] += c; h_[3] += d; h_[4] += e; h_[5] += f; h_[6] += g; h_[7] += hh;
    }
    std::array<std::uint32_t, 8> h_{{0x6a09e667U,0xbb67ae85U,0x3c6ef372U,0xa54ff53aU,0x510e527fU,0x9b05688cU,0x1f83d9abU,0x5be0cd19U}};
    std::array<std::uint8_t, 64> block_{};
    std::size_t fill_{0U};
    std::uint64_t total_{0U};
};

bool validateProject(const BankProject& project, std::string& error) {
    if (project.sounds.size() > static_cast<std::size_t>(kMaxSoundPosition)) {
        error = "SILVETON bank supports at most 500 SOUND positions.";
        return false;
    }

    std::unordered_set<std::uint32_t> sampleIds;
    for (std::size_t i = 0; i < project.samples.size(); ++i) {
        if (!project.samples[i].valid()) {
            error = "Invalid sample at index " + std::to_string(i);
            return false;
        }
        const std::uint32_t id = project.samples[i].sampleId;
        if (id == 0U) {
            error = "SampleID 0 is invalid at sample index " + std::to_string(i);
            return false;
        }
        if (!sampleIds.insert(id).second) {
            error = "Duplicate SampleID " + std::to_string(id);
            return false;
        }
    }

    std::unordered_set<std::uint32_t> multisampleIds;
    for (std::size_t mi = 0; mi < project.multisamples.size(); ++mi) {
        const auto& ms = project.multisamples[mi];
        if (ms.multisampleId == 0U) {
            error = "MultisampleID 0 is invalid at multisample index " + std::to_string(mi);
            return false;
        }
        if (!multisampleIds.insert(ms.multisampleId).second) {
            error = "Duplicate MultisampleID " + std::to_string(ms.multisampleId);
            return false;
        }
        if (ms.zones.empty()) {
            error = "Multisample has no zones at index " + std::to_string(mi);
            return false;
        }
        for (const auto& z : ms.zones) {
            if (z.sampleIndex >= project.samples.size() || z.keyLow > z.keyHigh ||
                z.velocityLow == 0U || z.velocityLow > z.velocityHigh) {
                error = "Invalid zone in multisample index " + std::to_string(mi);
                return false;
            }
        }
    }
    std::unordered_set<std::uint16_t> soundPositions;
    for (std::size_t si = 0; si < project.sounds.size(); ++si) {
        const auto& sound = project.sounds[si];
        if (sound.position < kMinSoundPosition || sound.position > kMaxSoundPosition) {
            error = "SOUND slot must be between 1 and 500.";
            return false;
        }
        if (!soundPositions.insert(sound.position).second) {
            error = "Duplicate SOUND slot " + std::to_string(sound.position);
            return false;
        }
        if (sound.layers.empty()) {
            error = "SOUND has no layers at index " + std::to_string(si);
            return false;
        }
        for (const auto& layer : sound.layers) {
            if (layer.multisampleIndex >= project.multisamples.size() || layer.keyLow > layer.keyHigh ||
                layer.velocityLow == 0U || layer.velocityLow > layer.velocityHigh) {
                error = "Invalid SOUND layer at sound index " + std::to_string(si);
                return false;
            }
        }
    }
    return true;
}



// Everything about the bank except the audio bytes themselves.
struct Plan {
    SvBankHeader header{};
    StringTable strings;
    std::vector<std::uint8_t> soundBytes, layerBytes, multisampleBytes, sampleBytes, zoneBytes;
    std::vector<UniqueAudio> audio;        // in file order
    std::uint64_t audioSize{0U};
    SvBuildStats stats{};
    std::uint64_t fileSize{0U};            // with the audio
    std::uint64_t audioOffset{0U};
};

bool makePlan(const BankProject& project, Plan& plan, std::string& error) {
    if (!validateProject(project, error)) return false;

    std::uint32_t soundCount = 0U, multisampleCount = 0U, sampleCount = 0U;
    if (!toU32(project.sounds.size(), soundCount) || !toU32(project.multisamples.size(), multisampleCount) ||
        !toU32(project.samples.size(), sampleCount)) {
        error = "Bank object count exceeds format limits";
        return false;
    }
    SvBankHeader& header = plan.header;
    header.bankNameOffset = plan.strings.add(project.name);
    header.soundCount = soundCount;
    header.multisampleCount = multisampleCount;
    header.sampleCount = sampleCount;

    std::uint32_t layerCursor = 0U;
    for (std::size_t soundIndex = 0U; soundIndex < project.sounds.size(); ++soundIndex) {
        const auto& sound = project.sounds[soundIndex];
        SvSoundRecord record{};
        record.nameOffset = plan.strings.add(sound.name);
        record.firstLayer = layerCursor;
        if (!toU32(sound.layers.size(), record.layerCount)) { error = "SOUND layer count exceeds format limits"; return false; }
        record.soundSlotId = sound.position;
        record.category = sound.category;
        appendSoundRecord(plan.soundBytes, record);
        for (const auto& layer : sound.layers) {
            SvSoundLayerRecord lr{};
            lr.multisampleId = project.multisamples[layer.multisampleIndex].multisampleId;
            lr.enabled = layer.enabled ? 1U : 0U;
            lr.keyLow = layer.keyLow; lr.keyHigh = layer.keyHigh; lr.velocityLow = layer.velocityLow; lr.velocityHigh = layer.velocityHigh;
            lr.transposeSemitones = layer.transposeSemitones; lr.tuneCents = layer.tuneCents; lr.levelDb = layer.levelDb; lr.pan = layer.pan;
            appendSoundLayerRecord(plan.layerBytes, lr);
            ++layerCursor;
        }
    }
    header.soundLayerCount = layerCursor;

    std::uint32_t zoneCursor = 0U;
    for (std::size_t multisampleIndex = 0U; multisampleIndex < project.multisamples.size(); ++multisampleIndex) {
        const auto& ms = project.multisamples[multisampleIndex];
        SvMultisampleRecord record{};
        record.nameOffset = plan.strings.add(ms.name);
        record.multisampleId = ms.multisampleId;
        record.sourceIdentityOffset = plan.strings.add(ms.sourceIdentity);
        record.firstZone = zoneCursor;
        if (!toU32(ms.zones.size(), record.zoneCount)) { error = "Zone count exceeds format limits"; return false; }
        appendMultisampleRecord(plan.multisampleBytes, record);
        for (const auto& zone : ms.zones) {
            SvZoneRecord zr{};
            zr.sampleId = project.samples[zone.sampleIndex].sampleId;
            zr.keyLow = zone.keyLow; zr.keyHigh = zone.keyHigh; zr.velocityLow = zone.velocityLow; zr.velocityHigh = zone.velocityHigh;
            zr.rootKey = zone.rootKey; zr.transposeSemitones = zone.transposeSemitones;
            zr.flags = static_cast<std::uint8_t>((zone.oneShot ? 1U : 0U) | (zone.reverse ? 2U : 0U) | (zone.nonTranspose ? 4U : 0U));
            zr.sourcePanRaw = zone.sourcePanRaw; zr.sourceLevelRaw = zone.sourceLevelRaw; zr.sourceFilterRaw = zone.sourceFilterRaw;
            zr.tuneCents = zone.tuneCents; zr.gainDb = zone.gainDb; zr.pan = zone.pan;
            appendZoneRecord(plan.zoneBytes, zr);
            ++zoneCursor;
        }
    }
    header.zoneCount = zoneCursor;

    // audio: one copy per distinct recording, referenced by every sample that carries the same bytes
    std::unordered_map<std::uint64_t, std::vector<std::size_t>> hashBuckets;
    for (std::size_t sampleIndex = 0U; sampleIndex < project.samples.size(); ++sampleIndex) {
        const auto& sample = project.samples[sampleIndex];
        const std::uint64_t hash = hashSampleAudio(sample);
        plan.stats.audioBytesBeforeDedup += static_cast<std::uint64_t>(sample.audioData.size());
        std::size_t uniqueIndex = std::numeric_limits<std::size_t>::max();
        const auto bucket = hashBuckets.find(hash);
        if (bucket != hashBuckets.end()) {
            for (const auto candidate : bucket->second) {
                if (sameAudio(project.samples[plan.audio[candidate].sampleIndex], sample)) { uniqueIndex = candidate; break; }
            }
        }
        if (uniqueIndex == std::numeric_limits<std::size_t>::max()) {
            UniqueAudio entry{};
            entry.hash = hash;
            entry.sampleIndex = sampleIndex;
            entry.offset = plan.audioSize;
            entry.size = static_cast<std::uint64_t>(sample.audioData.size());
            plan.audioSize += entry.size;
            uniqueIndex = plan.audio.size();
            plan.audio.push_back(entry);
            hashBuckets[hash].push_back(uniqueIndex);
        }
        const auto& audio = plan.audio[uniqueIndex];
        SvSampleRecord sr{};
        sr.nameOffset = plan.strings.add(sample.name);
        sr.sampleId = sample.sampleId;
        sr.sourceIdentityOffset = plan.strings.add(sample.sourceIdentity);
        sr.sampleRate = sample.sampleRate; sr.channels = sample.channels;
        sr.encoding = static_cast<std::uint8_t>(sample.encoding); sr.bitsPerSample = sample.bitsPerSample; sr.rootKey = sample.rootKey;
        sr.loopEnabled = sample.loop.enabled ? 1U : 0U; sr.fineTuneCents = sample.fineTuneCents; sr.totalFrames = sample.totalFrames;
        sr.loopStart = sample.loop.startFrame; sr.loopEnd = sample.loop.endFrame; sr.loopCrossfadeFrames = sample.loop.crossfadeFrames;
        sr.audioOffset = audio.offset; sr.audioSize = audio.size; sr.audioHash = hash;
        appendSampleRecord(plan.sampleBytes, sr);
    }

    plan.stats.soundCount = header.soundCount;
    plan.stats.multisampleCount = header.multisampleCount;
    plan.stats.sampleCount = header.sampleCount;
    plan.stats.zoneCount = header.zoneCount;
    plan.stats.uniqueAudioPayloadCount = static_cast<std::uint32_t>(plan.audio.size());
    plan.stats.audioBytesAfterDedup = plan.audioSize;
    return true;
}

// Lays out the small sections (everything before the audio) exactly like appendSection does.
std::vector<std::uint8_t> layoutSections(Plan& plan) {
    std::vector<std::uint8_t> file(kSvBankHeaderSize, 0U);
    SvBankHeader& header = plan.header;
    appendSection(file, header.sections[static_cast<std::size_t>(SvSection::Sounds)], plan.soundBytes, 16U);
    appendSection(file, header.sections[static_cast<std::size_t>(SvSection::SoundLayers)], plan.layerBytes, 16U);
    appendSection(file, header.sections[static_cast<std::size_t>(SvSection::Multisamples)], plan.multisampleBytes, 16U);
    appendSection(file, header.sections[static_cast<std::size_t>(SvSection::Samples)], plan.sampleBytes, 16U);
    appendSection(file, header.sections[static_cast<std::size_t>(SvSection::Zones)], plan.zoneBytes, 16U);
    appendSection(file, header.sections[static_cast<std::size_t>(SvSection::Strings)], plan.strings.bytes(), 16U);
    const std::uint64_t aligned = alignUp(file.size(), 4096U);
    if (aligned > file.size()) file.resize(static_cast<std::size_t>(aligned), 0U);
    auto& audioSection = header.sections[static_cast<std::size_t>(SvSection::Audio)];
    audioSection.offset = static_cast<std::uint64_t>(file.size());
    audioSection.size = plan.audioSize;
    plan.audioOffset = audioSection.offset;
    plan.fileSize = audioSection.offset + plan.audioSize;
    header.fileSize = plan.fileSize;
    return file;   // header bytes still zero
}

} // namespace

SvBuildResult SvBankBuilder::build(const BankProject& project) {
    SvBuildResult result{};
    Plan plan;
    if (!makePlan(project, plan, result.error)) return result;
    std::vector<std::uint8_t> file = layoutSections(plan);
    file.reserve(static_cast<std::size_t>(plan.fileSize));
    for (const UniqueAudio& a : plan.audio) {
        const auto& data = project.samples[a.sampleIndex].audioData;
        file.insert(file.end(), data.begin(), data.end());
    }
    plan.header.payloadSha256 = sha256(file.data() + kSvBankHeaderSize, file.size() - kSvBankHeaderSize);
    const auto headerBytes = serializeHeader(plan.header);
    std::copy(headerBytes.begin(), headerBytes.end(), file.begin());
    result.stats = plan.stats;
    result.bytes = std::move(file);
    return result;
}

bool SvBankBuilder::writeAtomic(const std::string& path, const BankProject& project, SvBuildStats& stats, std::string& error,
                                const SvBuildProgress& progress) {
    auto report = [&](double fraction, const std::string& text) -> bool { return !progress || progress(fraction, text); };
    if (!report(0.0, "Preparing")) { error = "Stopped"; return false; }
    Plan plan;
    if (!makePlan(project, plan, error)) return false;
    std::vector<std::uint8_t> head = layoutSections(plan);

    const std::string temp = path + ".tmp";
    {
        std::ofstream out(temp, std::ios::binary | std::ios::trunc);
        if (!out) { error = "Cannot create temporary bank file: " + temp; return false; }
        Sha256Stream sha;
        // sections (the header itself is written at the end, it is not part of the hash)
        out.write(reinterpret_cast<const char*>(head.data()), static_cast<std::streamsize>(head.size()));
        sha.update(head.data() + kSvBankHeaderSize, head.size() - kSvBankHeaderSize);
        // audio straight from the project, one recording at a time
        std::uint64_t done = 0U;
        for (std::size_t i = 0U; i < plan.audio.size(); ++i) {
            const auto& sample = project.samples[plan.audio[i].sampleIndex];
            const auto& data = sample.audioData;
            if (!data.empty()) {
                out.write(reinterpret_cast<const char*>(data.data()), static_cast<std::streamsize>(data.size()));
                sha.update(data.data(), data.size());
            }
            if (!out) { error = "Failed while writing temporary bank file"; (void)std::remove(temp.c_str()); return false; }
            done += static_cast<std::uint64_t>(data.size());
            const double f = plan.audioSize > 0U ? static_cast<double>(done) / static_cast<double>(plan.audioSize) : 1.0;
            if (!report(0.05 + 0.6 * f, "Writing " + sample.name)) { (void)std::remove(temp.c_str()); error = "Stopped"; return false; }
        }
        plan.header.payloadSha256 = sha.finish();
        const auto headerBytes = serializeHeader(plan.header);
        out.seekp(0);
        out.write(reinterpret_cast<const char*>(headerBytes.data()), static_cast<std::streamsize>(headerBytes.size()));
        out.flush();
        if (!out) { error = "Failed while flushing temporary bank file"; (void)std::remove(temp.c_str()); return false; }
    }

    // read back what landed on the disk and check it against the header
    {
        std::ifstream in(temp, std::ios::binary);
        if (!in) { error = "Cannot read back the written bank"; (void)std::remove(temp.c_str()); return false; }
        std::vector<std::uint8_t> headerBytes(kSvBankHeaderSize);
        if (!in.read(reinterpret_cast<char*>(headerBytes.data()), static_cast<std::streamsize>(headerBytes.size()))) {
            error = "Written bank is truncated"; (void)std::remove(temp.c_str()); return false;
        }
        SvBankHeader check{};
        std::string headerError;
        if (!deserializeHeader(headerBytes.data(), headerBytes.size(), check, headerError)) {
            error = "Written bank header is damaged: " + headerError; (void)std::remove(temp.c_str()); return false;
        }
        Sha256Stream sha;
        std::vector<std::uint8_t> chunk(1U << 20U);
        std::uint64_t total = 0U;
        while (in) {
            in.read(reinterpret_cast<char*>(chunk.data()), static_cast<std::streamsize>(chunk.size()));
            const std::streamsize got = in.gcount();
            if (got <= 0) break;
            sha.update(chunk.data(), static_cast<std::size_t>(got));
            total += static_cast<std::uint64_t>(got);
            const double f = plan.fileSize > kSvBankHeaderSize ? static_cast<double>(total) / static_cast<double>(plan.fileSize - kSvBankHeaderSize) : 1.0;
            if (!report(0.65 + 0.33 * std::min(1.0, f), "Checking the written file")) { (void)std::remove(temp.c_str()); error = "Stopped"; return false; }
        }
        if (total + kSvBankHeaderSize != plan.fileSize || check.fileSize != plan.fileSize) {
            error = "Written bank has the wrong size (disk full?)"; (void)std::remove(temp.c_str()); return false;
        }
        if (sha.finish() != check.payloadSha256) {
            error = "Written bank does not match (disk error?)"; (void)std::remove(temp.c_str()); return false;
        }
    }

    if (std::rename(temp.c_str(), path.c_str()) != 0) {
        const int firstError = errno;
        if (std::remove(path.c_str()) == 0 && std::rename(temp.c_str(), path.c_str()) == 0) {
            stats = plan.stats;
            error.clear();
            (void)report(1.0, "Done");
            return true;
        }
        const int finalError = errno != 0 ? errno : firstError;
        (void)std::remove(temp.c_str());
        error = "Atomic bank replacement failed: " + std::string(std::strerror(finalError));
        return false;
    }
    stats = plan.stats;
    error.clear();
    (void)report(1.0, "Done");
    return true;
}

} // namespace silveton::manager
