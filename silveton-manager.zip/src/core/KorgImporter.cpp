#include "silveton/manager/KorgImporter.h"
#include "silveton/manager/SampleHash.h"

#include <algorithm>
#include <array>
#include <cctype>
#include <cstdint>
#include <dirent.h>
#include <fstream>
#include <limits>
#include <limits.h>
#include <sstream>
#include <stdlib.h>
#include <string>
#include <sys/stat.h>
#include <utility>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace silveton::manager {
namespace {

std::uint32_t be32(const std::uint8_t* p) noexcept {
    return (static_cast<std::uint32_t>(p[0]) << 24U) |
           (static_cast<std::uint32_t>(p[1]) << 16U) |
           (static_cast<std::uint32_t>(p[2]) << 8U) |
           static_cast<std::uint32_t>(p[3]);
}

std::uint32_t be24(const std::uint8_t* p) noexcept {
    return (static_cast<std::uint32_t>(p[0]) << 16U) |
           (static_cast<std::uint32_t>(p[1]) << 8U) |
           static_cast<std::uint32_t>(p[2]);
}

bool readAll(const std::string& path, std::vector<std::uint8_t>& out, std::string& error) {
    std::ifstream f(path, std::ios::binary | std::ios::ate);
    if (!f) { error = "Cannot open Korg file: " + path; return false; }
    const std::streamsize size = f.tellg();
    if (size <= 0) { error = "Korg file is empty: " + path; return false; }
    f.seekg(0, std::ios::beg);
    out.resize(static_cast<std::size_t>(size));
    if (!f.read(reinterpret_cast<char*>(out.data()), size)) {
        error = "Failed to read Korg file: " + path;
        return false;
    }
    return true;
}

std::string fixedString(const std::uint8_t* p, std::size_t n) {
    std::size_t len = 0U;
    while (len < n && p[len] != 0U) ++len;
    while (len > 0U && p[len - 1U] == static_cast<std::uint8_t>(' ')) --len;
    return std::string(reinterpret_cast<const char*>(p), len);
}

std::string trim(const std::string& s) {
    std::size_t first = 0U;
    while (first < s.size() && std::isspace(static_cast<unsigned char>(s[first])) != 0) ++first;
    std::size_t last = s.size();
    while (last > first && std::isspace(static_cast<unsigned char>(s[last - 1U])) != 0) --last;
    return s.substr(first, last - first);
}

struct Chunk {
    std::array<char, 4> id{};
    const std::uint8_t* data{nullptr};
    std::size_t size{0U};
};

bool idIs(const Chunk& c, const char* id) noexcept {
    return c.id[0] == id[0] && c.id[1] == id[1] && c.id[2] == id[2] && c.id[3] == id[3];
}

bool parseChunks(const std::vector<std::uint8_t>& bytes, std::vector<Chunk>& chunks, std::string& error) {
    std::size_t pos = 0U;
    while (pos + 8U <= bytes.size()) {
        Chunk chunk{};
        for (std::size_t i = 0U; i < 4U; ++i) chunk.id[i] = static_cast<char>(bytes[pos + i]);
        chunk.size = static_cast<std::size_t>(be32(bytes.data() + pos + 4U));
        const std::size_t payload = pos + 8U;
        if (payload > bytes.size() || chunk.size > bytes.size() - payload) {
            error = "Corrupt Korg chunk size";
            return false;
        }
        chunk.data = bytes.data() + payload;
        chunks.push_back(chunk);
        pos = payload + chunk.size;
    }
    if (pos != bytes.size()) {
        error = "Trailing bytes after final Korg chunk";
        return false;
    }
    if (chunks.empty()) {
        error = "Korg file contains no chunks";
        return false;
    }
    return true;
}

const Chunk* findChunk(const std::vector<Chunk>& chunks, const char* id) noexcept {
    for (const auto& chunk : chunks) if (idIs(chunk, id)) return &chunk;
    return nullptr;
}

std::string normalizeSeparators(std::string path) {
    std::replace(path.begin(), path.end(), '\\', '/');
    return path;
}

bool isAbsolutePath(const std::string& path) noexcept {
    if (path.empty()) return false;
    if (path[0] == '/') return true;
    return path.size() >= 3U && std::isalpha(static_cast<unsigned char>(path[0])) != 0 && path[1] == ':' &&
           (path[2] == '/' || path[2] == '\\');
}

std::string parentPath(const std::string& input) {
    const std::string path = normalizeSeparators(input);
    const auto pos = path.find_last_of('/');
    if (pos == std::string::npos) return ".";
    if (pos == 0U) return "/";
    return path.substr(0U, pos);
}

std::string fileName(const std::string& input) {
    const std::string path = normalizeSeparators(input);
    const auto pos = path.find_last_of('/');
    return pos == std::string::npos ? path : path.substr(pos + 1U);
}

std::string stemName(const std::string& input) {
    const std::string name = fileName(input);
    const auto dot = name.find_last_of('.');
    if (dot == std::string::npos || dot == 0U) return name;
    return name.substr(0U, dot);
}

std::string joinPath(const std::string& baseInput, const std::string& childInput) {
    const std::string child = normalizeSeparators(childInput);
    if (isAbsolutePath(child)) return child;
    std::string base = normalizeSeparators(baseInput);
    if (base.empty() || base == ".") return child;
    while (base.size() > 1U && base.back() == '/') base.pop_back();
    return base + "/" + child;
}

bool fileExists(const std::string& path) noexcept {
    struct stat info {};
    return ::stat(path.c_str(), &info) == 0 && S_ISREG(info.st_mode);
}

std::string sourceIdentityFor(const std::string& path) {
#if defined(__APPLE__) || defined(__unix__)
    char resolved[PATH_MAX];
    if (::realpath(path.c_str(), resolved) != nullptr) return std::string(resolved);
#endif
    return normalizeSeparators(path);
}

std::string resolveRelativeInsensitive(const std::string& baseInput, const std::string& relativeInput);
bool findFileRecursive(const std::string& directory, const std::string& targetName, unsigned depth, std::string& found);

std::string ksfPathFor(const std::string& kmpPath, const std::string& filename) {
    const std::string parent = parentPath(kmpPath);
    const std::string direct = joinPath(parent, filename);
    if (fileExists(direct)) return direct;

    const std::string directInsensitive = resolveRelativeInsensitive(parent, filename);
    if (!directInsensitive.empty()) return directInsensitive;

    const std::string nestedRoot = joinPath(parent, stemName(kmpPath));
    const std::string nested = joinPath(nestedRoot, filename);
    if (fileExists(nested)) return nested;
    const std::string nestedInsensitive = resolveRelativeInsensitive(nestedRoot, filename);
    if (!nestedInsensitive.empty()) return nestedInsensitive;

    // Some Korg sets keep the KSF files one directory deeper or use a
    // directory name which does not exactly match the KMP stem.  Use a
    // bounded filename search as a last resort, after the deterministic
    // Korg locations above have been tried.
    std::string recursive;
    if (findFileRecursive(parent, fileName(filename), 4U, recursive)) return recursive;
    return direct;
}

std::string lowerExtension(const std::string& path) {
    const std::string name = fileName(path);
    const auto dot = name.find_last_of('.');
    std::string ext = dot == std::string::npos ? std::string{} : name.substr(dot);
    std::transform(ext.begin(), ext.end(), ext.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    return ext;
}


std::string asciiLower(std::string value) {
    std::transform(value.begin(), value.end(), value.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    return value;
}

bool asciiEqualInsensitive(const std::string& a, const std::string& b) {
    return asciiLower(a) == asciiLower(b);
}

bool startsWithInsensitive(const std::string& value, const std::string& prefix) {
    if (value.size() < prefix.size()) return false;
    for (std::size_t i = 0U; i < prefix.size(); ++i) {
        const auto lhs = static_cast<unsigned char>(value[i]);
        const auto rhs = static_cast<unsigned char>(prefix[i]);
        if (std::tolower(lhs) != std::tolower(rhs)) return false;
    }
    return true;
}

bool endsWithInsensitive(const std::string& value, const std::string& suffix) {
    if (value.size() < suffix.size()) return false;
    return asciiEqualInsensitive(value.substr(value.size() - suffix.size()), suffix);
}

std::string stripUtf8Bom(std::string line) {
    if (line.size() >= 3U &&
        static_cast<unsigned char>(line[0]) == 0xEFU &&
        static_cast<unsigned char>(line[1]) == 0xBBU &&
        static_cast<unsigned char>(line[2]) == 0xBFU) {
        line.erase(0U, 3U);
    }
    return line;
}

void appendUtf8(std::string& out, std::uint32_t cp) {
    if (cp <= 0x7FU) {
        out.push_back(static_cast<char>(cp));
    } else if (cp <= 0x7FFU) {
        out.push_back(static_cast<char>(0xC0U | (cp >> 6U)));
        out.push_back(static_cast<char>(0x80U | (cp & 0x3FU)));
    } else if (cp <= 0xFFFFU) {
        out.push_back(static_cast<char>(0xE0U | (cp >> 12U)));
        out.push_back(static_cast<char>(0x80U | ((cp >> 6U) & 0x3FU)));
        out.push_back(static_cast<char>(0x80U | (cp & 0x3FU)));
    } else if (cp <= 0x10FFFFU) {
        out.push_back(static_cast<char>(0xF0U | (cp >> 18U)));
        out.push_back(static_cast<char>(0x80U | ((cp >> 12U) & 0x3FU)));
        out.push_back(static_cast<char>(0x80U | ((cp >> 6U) & 0x3FU)));
        out.push_back(static_cast<char>(0x80U | (cp & 0x3FU)));
    }
}

std::string decodeKscText(const std::vector<std::uint8_t>& bytes) {
    if (bytes.empty()) return {};
    std::size_t offset = 0U;
    bool utf16 = false;
    bool littleEndian = true;
    if (bytes.size() >= 2U && bytes[0] == 0xFFU && bytes[1] == 0xFEU) {
        utf16 = true;
        littleEndian = true;
        offset = 2U;
    } else if (bytes.size() >= 2U && bytes[0] == 0xFEU && bytes[1] == 0xFFU) {
        utf16 = true;
        littleEndian = false;
        offset = 2U;
    } else if (bytes.size() >= 4U && bytes[1] == 0U && bytes[3] == 0U) {
        utf16 = true;
        littleEndian = true;
    } else if (bytes.size() >= 4U && bytes[0] == 0U && bytes[2] == 0U) {
        utf16 = true;
        littleEndian = false;
    }

    if (!utf16) {
        std::string text(reinterpret_cast<const char*>(bytes.data()), bytes.size());
        return stripUtf8Bom(std::move(text));
    }

    std::string out;
    out.reserve(bytes.size() / 2U);
    auto unitAt = [&](std::size_t pos) -> std::uint16_t {
        if (littleEndian) {
            return static_cast<std::uint16_t>(static_cast<std::uint16_t>(bytes[pos]) |
                                              static_cast<std::uint16_t>(static_cast<std::uint16_t>(bytes[pos + 1U]) << 8U));
        }
        return static_cast<std::uint16_t>(static_cast<std::uint16_t>(bytes[pos + 1U]) |
                                          static_cast<std::uint16_t>(static_cast<std::uint16_t>(bytes[pos]) << 8U));
    };
    for (std::size_t pos = offset; pos + 1U < bytes.size(); pos += 2U) {
        const std::uint16_t u = unitAt(pos);
        if (u >= 0xD800U && u <= 0xDBFFU && pos + 3U < bytes.size()) {
            const std::uint16_t low = unitAt(pos + 2U);
            if (low >= 0xDC00U && low <= 0xDFFFU) {
                const std::uint32_t cp = 0x10000U +
                    ((static_cast<std::uint32_t>(u) - 0xD800U) << 10U) +
                    (static_cast<std::uint32_t>(low) - 0xDC00U);
                appendUtf8(out, cp);
                pos += 2U;
                continue;
            }
        }
        if (u != 0U) appendUtf8(out, u);
    }
    return out;
}

std::string unquote(std::string value) {
    value = trim(value);
    if (value.size() >= 2U) {
        const char first = value.front();
        const char last = value.back();
        if ((first == '"' && last == '"') || (first == '\'' && last == '\'')) {
            value = value.substr(1U, value.size() - 2U);
        }
    }
    return trim(value);
}

bool pathExists(const std::string& path) noexcept {
    struct stat info {};
    return ::stat(path.c_str(), &info) == 0;
}

bool directoryExists(const std::string& path) noexcept {
    struct stat info {};
    return ::stat(path.c_str(), &info) == 0 && S_ISDIR(info.st_mode);
}

std::string findChildInsensitive(const std::string& directory, const std::string& name) {
    DIR* dir = ::opendir(directory.c_str());
    if (dir == nullptr) return {};
    std::string result;
    while (const struct dirent* entry = ::readdir(dir)) {
        const std::string childName(entry->d_name);
        if (childName == "." || childName == "..") continue;
        if (asciiEqualInsensitive(childName, name)) {
            result = joinPath(directory, childName);
            break;
        }
    }
    ::closedir(dir);
    return result;
}

std::vector<std::string> splitPath(const std::string& input) {
    const std::string path = normalizeSeparators(input);
    std::vector<std::string> parts;
    std::size_t start = 0U;
    while (start <= path.size()) {
        const auto slash = path.find('/', start);
        const std::size_t end = slash == std::string::npos ? path.size() : slash;
        if (end > start) parts.push_back(path.substr(start, end - start));
        if (slash == std::string::npos) break;
        start = slash + 1U;
    }
    return parts;
}

std::string resolveRelativeInsensitive(const std::string& baseInput, const std::string& relativeInput) {
    const std::string relative = normalizeSeparators(relativeInput);
    if (relative.empty()) return {};
    if (isAbsolutePath(relative)) {
        if (fileExists(relative)) return relative;
        return {};
    }

    std::string current = normalizeSeparators(baseInput);
    if (!directoryExists(current)) return {};
    for (const auto& part : splitPath(relative)) {
        if (part == ".") continue;
        if (part == "..") {
            current = parentPath(current);
            continue;
        }
        const std::string exact = joinPath(current, part);
        if (pathExists(exact)) {
            current = exact;
            continue;
        }
        const std::string insensitive = findChildInsensitive(current, part);
        if (insensitive.empty()) return {};
        current = insensitive;
    }
    return fileExists(current) ? current : std::string{};
}

bool findFileRecursive(const std::string& directory,
                       const std::string& targetName,
                       unsigned depth,
                       std::string& found) {
    if (depth == 0U || !directoryExists(directory)) return false;
    DIR* dir = ::opendir(directory.c_str());
    if (dir == nullptr) return false;

    std::vector<std::string> subdirs;
    bool matched = false;
    while (const struct dirent* entry = ::readdir(dir)) {
        const std::string name(entry->d_name);
        if (name == "." || name == "..") continue;
        const std::string candidate = joinPath(directory, name);
        struct stat info {};
        if (::lstat(candidate.c_str(), &info) != 0) continue;
        if (S_ISREG(info.st_mode) && asciiEqualInsensitive(name, targetName)) {
            found = candidate;
            matched = true;
            break;
        }
        if (S_ISDIR(info.st_mode)) subdirs.push_back(candidate);
    }
    ::closedir(dir);
    if (matched) return true;

    for (const auto& subdir : subdirs) {
        if (findFileRecursive(subdir, targetName, depth - 1U, found)) return true;
    }
    return false;
}

void collectFilesRecursive(const std::string& directory,
                           const std::string& extension,
                           unsigned depth,
                           std::vector<std::string>& out) {
    if (depth == 0U || !directoryExists(directory)) return;
    DIR* dir = ::opendir(directory.c_str());
    if (dir == nullptr) return;
    std::vector<std::string> subdirs;
    while (const struct dirent* entry = ::readdir(dir)) {
        const std::string name(entry->d_name);
        if (name == "." || name == "..") continue;
        const std::string candidate = joinPath(directory, name);
        struct stat info {};
        if (::lstat(candidate.c_str(), &info) != 0) continue;
        if (S_ISREG(info.st_mode) && lowerExtension(name) == extension) out.push_back(candidate);
        else if (S_ISDIR(info.st_mode)) subdirs.push_back(candidate);
    }
    ::closedir(dir);
    std::sort(subdirs.begin(), subdirs.end());
    for (const auto& subdir : subdirs) collectFilesRecursive(subdir, extension, depth - 1U, out);
}

std::string resolveKscEntry(const std::string& kscPath, const std::string& rawEntry) {
    const std::string entry = normalizeSeparators(unquote(rawEntry));
    if (entry.empty()) return {};
    if (isAbsolutePath(entry)) return fileExists(entry) ? entry : std::string{};

    const std::string base = parentPath(kscPath);
    const std::string direct = joinPath(base, entry);
    if (fileExists(direct)) return direct;

    const std::string insensitive = resolveRelativeInsensitive(base, entry);
    if (!insensitive.empty()) return insensitive;

    const std::string collectionDir = joinPath(base, stemName(kscPath));
    if (directoryExists(collectionDir)) {
        const std::string nested = joinPath(collectionDir, entry);
        if (fileExists(nested)) return nested;
        const std::string nestedInsensitive = resolveRelativeInsensitive(collectionDir, entry);
        if (!nestedInsensitive.empty()) return nestedInsensitive;
    }

    std::string recursive;
    if (findFileRecursive(base, fileName(entry), 5U, recursive)) return recursive;
    return {};
}

void appendKmpToCollection(KorgCollectionResult& out, KorgImportResult imported) {
    const std::uint32_t sampleBase = static_cast<std::uint32_t>(out.samples.size());
    for (auto& zone : imported.multisample.zones) zone.sampleIndex += sampleBase;
    for (auto& sample : imported.samples) out.samples.push_back(std::move(sample));
    out.multisamples.push_back(std::move(imported.multisample));
    out.warnings.insert(out.warnings.end(), imported.warnings.begin(), imported.warnings.end());
}

void appendCollection(KorgCollectionResult& out, KorgCollectionResult nested) {
    const std::uint32_t sampleBase = static_cast<std::uint32_t>(out.samples.size());
    for (auto& multisample : nested.multisamples) {
        for (auto& zone : multisample.zones) zone.sampleIndex += sampleBase;
        out.multisamples.push_back(std::move(multisample));
    }
    for (auto& sample : nested.samples) out.samples.push_back(std::move(sample));
    out.warnings.insert(out.warnings.end(), nested.warnings.begin(), nested.warnings.end());
}

bool identicalSampleForDedup(const ImportedSample& a, const ImportedSample& b) noexcept {
    return a.sampleRate == b.sampleRate && a.channels == b.channels && a.encoding == b.encoding &&
           a.bitsPerSample == b.bitsPerSample && a.rootKey == b.rootKey && a.fineTuneCents == b.fineTuneCents &&
           a.totalFrames == b.totalFrames && a.loop.enabled == b.loop.enabled && a.loop.startFrame == b.loop.startFrame &&
           a.loop.endFrame == b.loop.endFrame && a.loop.crossfadeFrames == b.loop.crossfadeFrames && a.audioData == b.audioData;
}

void deduplicateCollectionSamples(KorgCollectionResult& collection) {
    if (collection.samples.empty()) return;
    std::unordered_map<std::uint64_t, std::vector<std::uint32_t>> buckets;
    std::vector<ImportedSample> unique;
    unique.reserve(collection.samples.size());
    std::vector<std::uint32_t> remap(collection.samples.size(), 0U);

    for (std::size_t oldIndex = 0U; oldIndex < collection.samples.size(); ++oldIndex) {
        auto& sample = collection.samples[oldIndex];
        const std::uint64_t hash = hashSampleAudio(sample);
        std::uint32_t mapped = std::numeric_limits<std::uint32_t>::max();
        const auto found = buckets.find(hash);
        if (found != buckets.end()) {
            for (const std::uint32_t candidate : found->second) {
                if (identicalSampleForDedup(unique[candidate], sample)) { mapped = candidate; break; }
            }
        }
        if (mapped == std::numeric_limits<std::uint32_t>::max()) {
            mapped = static_cast<std::uint32_t>(unique.size());
            sample.sampleId = mapped + 1U;
            unique.push_back(std::move(sample));
            buckets[hash].push_back(mapped);
        }
        remap[oldIndex] = mapped;
    }

    for (auto& multisample : collection.multisamples) {
        for (auto& zone : multisample.zones) {
            if (zone.sampleIndex < remap.size()) zone.sampleIndex = remap[zone.sampleIndex];
        }
    }
    collection.samples = std::move(unique);
    for (std::size_t i = 0U; i < collection.multisamples.size(); ++i) {
        collection.multisamples[i].multisampleId = static_cast<std::uint32_t>(i + 1U);
    }
}

} // namespace

float KorgImporter::normalizedPan(std::uint8_t raw) noexcept {
    if (raw == 64U) return 0.0F;
    if (raw < 64U) return static_cast<float>(static_cast<int>(raw) - 64) / 64.0F;
    return static_cast<float>(static_cast<int>(raw) - 64) / 63.0F;
}

KorgSampleResult KorgImporter::loadKsf(const std::string& path) {
    std::vector<std::uint8_t> bytes;
    std::string error;
    if (!readAll(path, bytes, error)) return {{}, error};

    std::vector<Chunk> chunks;
    if (!parseChunks(bytes, chunks, error)) return {{}, error};
    const Chunk* smp = findChunk(chunks, "SMP1");
    const Chunk* smd = findChunk(chunks, "SMD1");
    if (smp == nullptr || smp->size < 32U || smd == nullptr || smd->size < 12U) {
        return {{}, "KSF requires SMP1(32) and SMD1 chunks"};
    }

    const std::uint32_t sampleRate = be32(smd->data);
    const auto loopTune = static_cast<std::int8_t>(smd->data[5U]);
    const std::uint8_t channels = smd->data[6U];
    const std::uint8_t bitDepth = smd->data[7U];
    const std::uint32_t samplePoints = be32(smd->data + 8U);
    if (sampleRate == 0U || channels == 0U || channels > 2U || (bitDepth != 8U && bitDepth != 16U)) {
        return {{}, "Manager KSF import supports uncompressed 8-bit or 16-bit mono/stereo PCM"};
    }

    const std::uint64_t sourceBytesPerSample = bitDepth == 8U ? 1U : 2U;
    const std::uint64_t expectedBytes = static_cast<std::uint64_t>(samplePoints) * channels * sourceBytesPerSample;
    if (smd->size != 12U + expectedBytes) {
        return {{}, "Compressed, divided, or malformed KSF data is not supported"};
    }

    const std::uint32_t modernStart = be32(smp->data + 16U);
    const bool oldLayout = smp->data[16U] <= 3U && modernStart > samplePoints;
    std::uint32_t start = 0U;
    std::uint32_t loopStart = 0U;
    std::uint32_t loopEnd = 0U;
    if (oldLayout) {
        start = be24(smp->data + 17U);
        loopStart = be32(smp->data + 24U);
        loopEnd = be32(smp->data + 28U);
    } else {
        start = modernStart;
        loopStart = be32(smp->data + 24U);
        loopEnd = be32(smp->data + 28U);
    }
    if (start >= samplePoints) start = 0U;

    ImportedSample out{};
    out.name = fixedString(smp->data, 16U);
    out.sourcePath = path;
    out.sourceIdentity = sourceIdentityFor(path);
    out.sampleRate = sampleRate;
    out.channels = channels;
    out.encoding = AudioEncoding::Pcm16LE;
    out.bitsPerSample = 16U;
    out.fineTuneCents = static_cast<float>(loopTune);
    out.totalFrames = static_cast<std::uint64_t>(samplePoints - start);

    const std::size_t sourceBytesPerFrame = static_cast<std::size_t>(channels) * static_cast<std::size_t>(sourceBytesPerSample);
    const std::uint8_t* sourcePcm = smd->data + 12U + static_cast<std::size_t>(start) * sourceBytesPerFrame;
    const std::size_t outputSampleCount = static_cast<std::size_t>(out.totalFrames) * channels;
    out.audioData.resize(outputSampleCount * 2U);
    if (bitDepth == 16U) {
        for (std::size_t i = 0U; i < outputSampleCount; ++i) {
            out.audioData[i * 2U] = sourcePcm[i * 2U + 1U];
            out.audioData[i * 2U + 1U] = sourcePcm[i * 2U];
        }
    } else {
        for (std::size_t i = 0U; i < outputSampleCount; ++i) {
            const auto source = static_cast<std::int8_t>(sourcePcm[i]);
            const std::int16_t expanded = static_cast<std::int16_t>(source) * 256;
            const std::uint16_t bits = static_cast<std::uint16_t>(expanded);
            out.audioData[i * 2U] = static_cast<std::uint8_t>(bits & 0xFFU);
            out.audioData[i * 2U + 1U] = static_cast<std::uint8_t>((bits >> 8U) & 0xFFU);
        }
    }

    if (loopStart >= start) loopStart -= start; else loopStart = 0U;
    if (loopEnd >= start) loopEnd -= start; else loopEnd = 0U;
    if (loopEnd > loopStart && static_cast<std::uint64_t>(loopEnd) <= out.totalFrames) {
        out.loop.enabled = true;
        out.loop.startFrame = loopStart;
        out.loop.endFrame = loopEnd;
    }

    if (!out.valid()) return {{}, "Decoded KSF sample failed validation"};
    return {std::move(out), {}};
}

KorgImportResult KorgImporter::loadKmp(const std::string& path) {
    std::vector<std::uint8_t> bytes;
    std::string error;
    if (!readAll(path, bytes, error)) return {{}, {}, error, {}};

    std::vector<Chunk> chunks;
    if (!parseChunks(bytes, chunks, error)) return {{}, {}, error, {}};
    const Chunk* msp = findChunk(chunks, "MSP1");
    const Chunk* rlp = findChunk(chunks, "RLP1");
    if (msp == nullptr || msp->size < 18U || rlp == nullptr) {
        return {{}, {}, "KMP requires MSP1 and RLP1 chunks", {}};
    }

    const std::uint8_t regionCount = msp->data[16U];
    if (regionCount == 0U || rlp->size < static_cast<std::size_t>(regionCount) * 18U) {
        return {{}, {}, "KMP RLP1 region count/size mismatch", {}};
    }

    KorgImportResult out{};
    out.multisample.name = fixedString(msp->data, 16U);
    out.multisample.sourceIdentity = sourceIdentityFor(path);
    const std::string kmpPath = path;
    std::uint8_t lowKey = 0U;

    for (std::uint8_t i = 0U; i < regionCount; ++i) {
        const std::uint8_t* r = rlp->data + static_cast<std::size_t>(i) * 18U;
        const std::uint8_t originalRaw = r[0U];
        const bool nonTranspose = (originalRaw & 0x80U) != 0U;
        const std::uint8_t originalKey = static_cast<std::uint8_t>(originalRaw & 0x7FU);
        const std::uint8_t topKey = static_cast<std::uint8_t>(std::min<int>(127, r[1U]));
        const auto tune = static_cast<std::int8_t>(r[2U]);
        const auto level = static_cast<std::int8_t>(r[3U]);
        const std::uint8_t panRaw = r[4U];
        const auto cutoff = static_cast<std::int8_t>(r[5U]);
        const std::string filename = fixedString(r + 6U, 12U);

        if (filename.empty() || filename == "SKIPPEDSAMPL" || filename.rfind("INTERNAL", 0U) == 0U) {
            out.warnings.push_back("Skipped KMP region with unavailable sample: " + filename);
            lowKey = topKey < 127U ? static_cast<std::uint8_t>(topKey + 1U) : 127U;
            continue;
        }

        const auto sampleResult = loadKsf(ksfPathFor(kmpPath, filename));
        if (!sampleResult.ok()) {
            out.error = fileName(path) + " zone " + std::to_string(static_cast<unsigned int>(i) + 1U) +
                        " KSF " + filename + ": " + sampleResult.error;
            return out;
        }

        const std::uint32_t sampleIndex = static_cast<std::uint32_t>(out.samples.size());
        out.samples.push_back(sampleResult.sample);
        ImportedZone zone{};
        zone.sampleIndex = sampleIndex;
        zone.keyLow = lowKey;
        zone.keyHigh = std::max(lowKey, topKey);
        zone.rootKey = originalKey;
        zone.tuneCents = static_cast<float>(tune);
        zone.nonTranspose = nonTranspose;
        zone.sourceLevelRaw = level;
        zone.sourceFilterRaw = cutoff;
        zone.sourcePanRaw = panRaw;
        zone.pan = normalizedPan(panRaw);
        zone.gainDb = 0.0F;
        out.multisample.zones.push_back(zone);
        lowKey = topKey < 127U ? static_cast<std::uint8_t>(topKey + 1U) : 127U;
    }

    if (out.multisample.zones.empty()) {
        out.error = "KMP contained no loadable external KSF regions";
    }
    return out;
}

std::vector<std::string> KorgImporter::parseKsc(const std::string& path, std::string& error) {
    std::vector<std::uint8_t> bytes;
    if (!readAll(path, bytes, error)) return {};
    const std::string text = decodeKscText(bytes);
    if (text.empty()) {
        error = "KSC file contains no readable text";
        return {};
    }

    std::vector<std::string> entries;
    std::istringstream stream(text);
    std::string line;
    bool sawHeader = false;
    bool firstLine = true;
    while (std::getline(stream, line)) {
        if (firstLine) {
            line = stripUtf8Bom(std::move(line));
            firstLine = false;
        }
        if (!line.empty() && line.back() == '\r') line.pop_back();
        line = trim(line);
        if (line.empty()) continue;

        if (line[0] == '#') {
            if (startsWithInsensitive(line, "#korg script version")) sawHeader = true;
            continue;
        }
        if (startsWithInsensitive(line, "korg script version")) {
            sawHeader = true;
            continue;
        }

        line = unquote(line);
        if (line.empty()) continue;
        const std::string ext = lowerExtension(line);
        if (ext == ".kmp" || ext == ".ksf" || ext == ".ksc") entries.push_back(line);
    }

    // KSC 1.0 is a filename list.  Some real-world sets contain only
    // comments/metadata in the index while the actual editable KMP files are
    // kept in the standard same-name directory.  The loader handles that
    // directory as a fallback, so an empty filename list is not a parser
    // failure as long as the file itself was readable.
    if (!sawHeader && entries.empty()) {
        error = "KSC header is missing and no KMP/KSF entries were found";
        return {};
    }
    error.clear();
    return entries;
}

namespace {

KorgCollectionResult loadKscRecursive(const std::string& path,
                                      std::unordered_set<std::string>& visitedKsc,
                                      std::unordered_set<std::string>& visitedResources,
                                      unsigned depth) {
    KorgCollectionResult out{};
    if (depth > 16U) {
        out.error = "KSC nesting is too deep";
        return out;
    }

    const std::string kscIdentity = sourceIdentityFor(path);
    if (!visitedKsc.insert(kscIdentity).second) {
        out.warnings.push_back("Skipped already loaded KSC: " + fileName(path));
        return out;
    }

    std::string error;
    const auto entries = KorgImporter::parseKsc(path, error);
    if (!error.empty()) { out.error = error; return out; }

    if (entries.empty() && endsWithInsensitive(stemName(path), "_userbank")) {
        const std::string stem = stemName(path);
        const std::string baseStem = stem.substr(0U, stem.size() - std::string("_userbank").size());
        const std::string siblingName = baseStem + ".KSC";
        const std::string sibling = resolveRelativeInsensitive(parentPath(path), siblingName);
        if (!sibling.empty() && sourceIdentityFor(sibling) != kscIdentity) {
            auto companion = loadKscRecursive(sibling, visitedKsc, visitedResources, depth + 1U);
            if (companion.ok()) return companion;
            out.warnings.insert(out.warnings.end(), companion.warnings.begin(), companion.warnings.end());
        }
    }

    std::unordered_set<std::string> standaloneSampleIdentities;
    for (const auto& entry : entries) {
        const std::string resolved = resolveKscEntry(path, entry);
        if (resolved.empty()) {
            out.error = "KSC resource not found: " + entry;
            return out;
        }

        const std::string ext = lowerExtension(resolved);
        const std::string identity = sourceIdentityFor(resolved);
        if (ext == ".kmp") {
            if (visitedResources.find(identity) != visitedResources.end()) continue;
            auto imported = KorgImporter::loadKmp(resolved);
            if (!imported.ok()) {
                out.error = fileName(resolved) + ": " + imported.error;
                return out;
            }
            visitedResources.insert(identity);
            appendKmpToCollection(out, std::move(imported));
        } else if (ext == ".ksf") {
            if (visitedResources.find(identity) != visitedResources.end()) continue;
            auto sample = KorgImporter::loadKsf(resolved);
            if (!sample.ok()) {
                out.error = fileName(resolved) + ": " + sample.error;
                return out;
            }
            visitedResources.insert(identity);
            if (!standaloneSampleIdentities.insert(sample.sample.sourceIdentity).second) continue;
            const std::uint32_t sampleIndex = static_cast<std::uint32_t>(out.samples.size());
            ImportedMultisample ms{};
            ms.name = sample.sample.name.empty() ? stemName(resolved) : sample.sample.name;
            ms.sourceIdentity = std::string("KSF:") + sample.sample.sourceIdentity;
            ImportedZone zone{};
            zone.sampleIndex = sampleIndex;
            zone.rootKey = sample.sample.rootKey;
            ms.zones.push_back(zone);
            out.samples.push_back(std::move(sample.sample));
            out.multisamples.push_back(std::move(ms));
        } else if (ext == ".ksc") {
            auto nested = loadKscRecursive(resolved, visitedKsc, visitedResources, depth + 1U);
            if (!nested.ok()) {
                out.error = fileName(resolved) + ": " + nested.error;
                out.warnings.insert(out.warnings.end(), nested.warnings.begin(), nested.warnings.end());
                return out;
            }
            appendCollection(out, std::move(nested));
        }
    }

    if (out.multisamples.empty()) {
        // Official KSC 1.0 sets normally keep KMP files in a directory with
        // the same base name as the KSC.  If the textual index is empty or
        // uses metadata that we cannot directly resolve, load the editable
        // KMP files from that directory instead of rejecting the collection.
        const std::string base = parentPath(path);
        std::vector<std::string> roots;
        roots.push_back(joinPath(base, stemName(path)));
        const std::string stem = stemName(path);
        if (endsWithInsensitive(stem, "_userbank")) {
            const std::string editableStem = stem.substr(0U, stem.size() - std::string("_userbank").size());
            roots.push_back(joinPath(base, editableStem));
        }

        std::vector<std::string> fallbackKmps;
        for (const auto& root : roots) collectFilesRecursive(root, ".kmp", 6U, fallbackKmps);
        std::sort(fallbackKmps.begin(), fallbackKmps.end());
        fallbackKmps.erase(std::unique(fallbackKmps.begin(), fallbackKmps.end()), fallbackKmps.end());
        for (const auto& fallbackKmp : fallbackKmps) {
            const std::string identity = sourceIdentityFor(fallbackKmp);
            if (visitedResources.find(identity) != visitedResources.end()) continue;
            auto imported = KorgImporter::loadKmp(fallbackKmp);
            if (!imported.ok()) {
                out.error = fileName(fallbackKmp) + ": " + imported.error;
                return out;
            }
            visitedResources.insert(identity);
            appendKmpToCollection(out, std::move(imported));
        }
    }

    if (out.multisamples.empty()) {
        if (entries.empty()) out.error = "KSC contains no loadable KMP resources and no editable KMP files were found in its collection folder";
        else out.error = "KSC contained no loadable KMP/KSF resources";
    }
    return out;
}

} // namespace

KorgCollectionResult KorgImporter::loadKsc(const std::string& path) {
    std::unordered_set<std::string> visitedKsc;
    std::unordered_set<std::string> visitedResources;
    auto result = loadKscRecursive(path, visitedKsc, visitedResources, 0U);
    if (result.ok()) deduplicateCollectionSamples(result);
    return result;
}

} // namespace silveton::manager
