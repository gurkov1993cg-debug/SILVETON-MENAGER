// SILVETON_PROCESSING_V2 (2 x tone match per KMP, soft peak limiter, low memory)
#include "silveton/manager/SampleProcessing.h"
#include "silveton/manager/SampleConverter.h"
#include "silveton/manager/SpectrumAnalyzer.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <complex>
#include <limits>
#include <map>
#include <thread>
#include <tuple>

namespace silveton::manager {
namespace {

constexpr double kPi = 3.14159265358979323846;
constexpr std::uint32_t kTargetRate = 48000U;

struct Work {
    std::size_t index{0U};
    ImportedSample sample;           // working copy
    std::vector<double> values;      // interleaved -1..+1
    bool changed{false};
    int group{-1};                   // KMP / multisample (tone matching)
    int instrument{-1};              // multisample (normalize per instrument)
    double f0{0.0};
    std::vector<float> curve;       // tone colour (1 octave smoothing), dB on SpectrumAnalyzer points
    std::vector<double> weight;     // which points are comparable
    std::vector<double> tone;       // total tone correction so far (dB per point)
    double peak{0.0};
    double crestDb{0.0};            // peak against the loudest 400 ms (for the limiter)
    double limitDb{0.0};            // how much the limiter takes off the peaks
    AudioEncoding finalEncoding{AudioEncoding::Pcm24LE};
};

// ---- SILVETON_TONE_MATCH_V2: every tone of one KMP is matched to the KMP's average curve.

constexpr double kEnvelopeOctaves = 1.0;   // wide smoothing: the tone colour, not single harmonics

// Average power per FFT bin of the mono mix (same analysis as the ANALYZER).
std::vector<float> averagePower(const Work& w) {
    const std::size_t ch = w.sample.channels;
    const std::size_t frames = w.values.size() / ch;
    std::vector<float> mono(frames);
    for (std::size_t f = 0; f < frames; ++f) {
        double m = 0.0;
        for (std::size_t c = 0; c < ch; ++c) m += w.values[f * ch + c];
        mono[f] = static_cast<float>(m / static_cast<double>(ch));
    }
    const std::size_t n = SpectrumAnalyzer::kFftSize;
    const std::size_t hop = n / 4U;
    std::vector<double> sum(n / 2U + 1U, 0.0);
    std::size_t used = 0U;
    const std::size_t blocks = frames > n ? (frames - n) / hop + 1U : 1U;
    const std::size_t step = blocks > 300U ? (blocks + 299U) / 300U : 1U;
    for (std::size_t b = 0; b < blocks; b += step) {
        const std::vector<float> p = SpectrumAnalyzer::powerAt(mono, static_cast<std::uint64_t>(b * hop + n));
        for (std::size_t k = 0; k < sum.size(); ++k) sum[k] += p[k];
        ++used;
    }
    std::vector<float> out(sum.size());
    for (std::size_t k = 0; k < sum.size(); ++k) out[k] = static_cast<float>(sum[k] / static_cast<double>(std::max<std::size_t>(1U, used)));
    return out;
}

// Which points of the curve can be compared for this tone (above its fundamental, below Nyquist,
// not lost in noise). Weight 0..1 with a soft half octave start below the fundamental.
std::vector<double> validWeights(const std::vector<float>& curve, double f0, double rate) {
    std::vector<double> wgt(curve.size(), 0.0);
    float top = SpectrumAnalyzer::kFloorDb;
    for (float v : curve) top = std::max(top, v);
    for (std::size_t i = 0; i < curve.size(); ++i) {
        const double hz = SpectrumAnalyzer::pointHz(i);
        if (hz > 0.45 * rate || curve[i] < top - 60.0F) continue;
        const double oct = std::log2(hz / f0);
        wgt[i] = std::clamp((oct + 0.5) / 0.5, 0.0, 1.0);
    }
    return wgt;
}

// Zero phase EQ: magnitude in dB on the log points -> filter, sample stays exactly in time.
void applyCurve(Work& w, const std::vector<double>& gainDb) {
    const std::size_t taps = 4096U;          // filter length
    const std::size_t fft = 8192U;
    const double rate = static_cast<double>(w.sample.sampleRate);
    // magnitude on the FFT grid
    std::vector<std::complex<double>> h(fft);
    const double lastIndex = static_cast<double>(SpectrumAnalyzer::kPoints - 1U);
    for (std::size_t k = 0; k <= fft / 2U; ++k) {
        const double hz = std::max(20.0, static_cast<double>(k) * rate / static_cast<double>(fft));
        double pos = std::log(hz / 20.0) / std::log(1000.0) * lastIndex;
        pos = std::clamp(pos, 0.0, lastIndex);
        const std::size_t i0 = static_cast<std::size_t>(pos);
        const std::size_t i1 = std::min(i0 + 1U, SpectrumAnalyzer::kPoints - 1U);
        const double t = pos - static_cast<double>(i0);
        const double db = gainDb[i0] * (1.0 - t) + gainDb[i1] * t;
        const double mag = std::pow(10.0, db / 20.0);
        h[k] = mag;
        if (k > 0U && k < fft / 2U) h[fft - k] = mag;
    }
    // inverse FFT (real, symmetric) -> centred, windowed impulse
    auto fftInPlace = [](std::vector<std::complex<double>>& a, bool inverse) {
        const std::size_t n = a.size();
        for (std::size_t i = 1U, j = 0U; i < n; ++i) {
            std::size_t bit = n >> 1U;
            for (; (j & bit) != 0U; bit >>= 1U) j ^= bit;
            j ^= bit;
            if (i < j) std::swap(a[i], a[j]);
        }
        for (std::size_t len = 2U; len <= n; len <<= 1U) {
            const double ang = (inverse ? 2.0 : -2.0) * kPi / static_cast<double>(len);
            const std::complex<double> wl(std::cos(ang), std::sin(ang));
            for (std::size_t i = 0U; i < n; i += len) {
                std::complex<double> wv(1.0, 0.0);
                for (std::size_t q = 0U; q < len / 2U; ++q) {
                    const std::complex<double> u = a[i + q];
                    const std::complex<double> v = a[i + q + len / 2U] * wv;
                    a[i + q] = u + v;
                    a[i + q + len / 2U] = u - v;
                    wv *= wl;
                }
            }
        }
        if (inverse) for (auto& x : a) x /= static_cast<double>(n);
    };
    fftInPlace(h, true);
    std::vector<double> kernel(taps);
    for (std::size_t i = 0; i < taps; ++i) {
        const std::ptrdiff_t lag = static_cast<std::ptrdiff_t>(i) - static_cast<std::ptrdiff_t>(taps / 2U);
        const std::size_t src = static_cast<std::size_t>((lag + static_cast<std::ptrdiff_t>(fft)) % static_cast<std::ptrdiff_t>(fft));
        const double win = 0.5 - 0.5 * std::cos(2.0 * kPi * (static_cast<double>(i) + 0.5) / static_cast<double>(taps));
        kernel[i] = h[src].real() * win;
    }
    std::vector<std::complex<double>> kf(fft);
    for (std::size_t i = 0; i < taps; ++i) kf[i] = kernel[i];
    fftInPlace(kf, false);

    // overlap-add per channel, output shifted back by taps/2 (no delay)
    const std::size_t ch = w.sample.channels;
    const std::size_t frames = w.values.size() / ch;
    const std::size_t block = fft - taps;
    const std::size_t half = taps / 2U;
    for (std::size_t c = 0; c < ch; ++c) {
        std::vector<double> out(frames + taps, 0.0);
        std::vector<std::complex<double>> buf(fft);
        for (std::size_t start = 0; start < frames; start += block) {
            std::fill(buf.begin(), buf.end(), std::complex<double>(0.0, 0.0));
            const std::size_t len = std::min(block, frames - start);
            for (std::size_t i = 0; i < len; ++i) buf[i] = w.values[(start + i) * ch + c];
            fftInPlace(buf, false);
            for (std::size_t i = 0; i < fft; ++i) buf[i] *= kf[i];
            fftInPlace(buf, true);
            for (std::size_t i = 0; i < fft && start + i < out.size(); ++i) out[start + i] += buf[i].real();
        }
        for (std::size_t f = 0; f < frames; ++f) w.values[f * ch + c] = out[f + half];
    }
}

double peakOf(const std::vector<double>& v) {
    double p = 0.0;
    for (double x : v) p = std::max(p, std::fabs(x));
    return p;
}

// Peak against the RMS of the loudest 400 ms, in dB.
double crestOf(const Work& w) {
    const std::size_t ch = w.sample.channels;
    const std::size_t frames = w.values.size() / ch;
    if (frames == 0U) return 0.0;
    const std::size_t win = std::max<std::size_t>(1U, std::min<std::size_t>(frames, w.sample.sampleRate * 2U / 5U));
    double sum = 0.0, best = 0.0;
    std::vector<double> e(frames);
    for (std::size_t f = 0; f < frames; ++f) {
        double m = 0.0;
        for (std::size_t c = 0; c < ch; ++c) m += w.values[f * ch + c] * w.values[f * ch + c];
        e[f] = m / static_cast<double>(ch);
    }
    for (std::size_t f = 0; f < frames; ++f) {
        sum += e[f];
        if (f >= win) sum -= e[f - win];
        if (f + 1U >= win) best = std::max(best, sum);
    }
    if (frames < win) best = sum;
    const double rms = std::sqrt(std::max(best, 1e-20) / static_cast<double>(win));
    const double pk = peakOf(w.values);
    return pk > 1e-9 ? 20.0 * std::log10(pk / rms) : 0.0;
}

// Soft (rounded) peak limiter, offline, no delay: takes `reductionDb` off the highest peaks.
// Soft knee 3 dB, 2 ms look-ahead with S-shaped gain, 60 ms release, stereo linked.
void softLimit(Work& w, double reductionDb) {
    const std::size_t ch = w.sample.channels;
    const std::size_t frames = w.values.size() / ch;
    if (frames < 8U || reductionDb < 0.05) return;
    const double peak = peakOf(w.values);
    if (peak < 1e-9) return;
    const double threshold = peak * std::pow(10.0, -reductionDb / 20.0);
    const double knee = 3.0;
    std::vector<double> g(frames, 1.0);
    for (std::size_t f = 0; f < frames; ++f) {
        double a = 0.0;
        for (std::size_t c = 0; c < ch; ++c) a = std::max(a, std::fabs(w.values[f * ch + c]));
        if (a <= 1e-12) continue;
        const double over = 20.0 * std::log10(a / threshold);
        double red = 0.0;
        if (over > knee / 2.0) red = over;
        else if (over > -knee / 2.0) red = (over + knee / 2.0) * (over + knee / 2.0) / (2.0 * knee);
        g[f] = std::pow(10.0, -red / 20.0);
    }
    const std::size_t W = std::max<std::size_t>(2U, w.sample.sampleRate / 500U);  // 2 ms
    // 1. hold the lowest gain over +-W (so the smoothing below never lets a peak through)
    std::vector<double> m(frames);
    {
        std::vector<std::size_t> dq(frames + 2U * W + 2U);
        std::size_t head = 0, tail = 0;
        std::size_t next = 0;
        for (std::size_t f = 0; f < frames; ++f) {
            const std::size_t hi = std::min(frames - 1U, f + W);
            while (next <= hi) {
                while (tail > head && g[dq[tail - 1U]] >= g[next]) --tail;
                dq[tail++] = next++;
            }
            const std::size_t lo = f >= W ? f - W : 0U;
            while (dq[head] < lo) ++head;
            m[f] = g[dq[head]];
        }
    }
    // 2. smooth release (60 ms)
    const double rel = 1.0 - std::exp(-1.0 / (0.060 * static_cast<double>(w.sample.sampleRate)));
    for (std::size_t f = 1; f < frames; ++f) m[f] = std::min(m[f], m[f - 1U] + (1.0 - m[f - 1U]) * rel);
    // 3. two centred box averages of W -> rounded S-shaped gain
    auto box = [&](std::vector<double>& v) {
        std::vector<double> out(frames);
        const std::size_t half = W / 2U;
        double acc = 0.0;
        std::vector<double> pre(frames + 1U, 0.0);
        for (std::size_t f = 0; f < frames; ++f) pre[f + 1U] = pre[f] + v[f];
        for (std::size_t f = 0; f < frames; ++f) {
            const std::size_t lo = f >= half ? f - half : 0U;
            const std::size_t hi = std::min(frames, f + half + 1U);
            acc = (pre[hi] - pre[lo]) / static_cast<double>(hi - lo);
            out[f] = acc;
        }
        v.swap(out);
    };
    box(m);
    box(m);
    for (std::size_t f = 0; f < frames; ++f)
        for (std::size_t c = 0; c < ch; ++c) w.values[f * ch + c] *= m[f];
}

void scale(std::vector<double>& v, double g) {
    for (double& x : v) x *= g;
}

// Runs fn(i) for i in 0..n-1 on several threads; the calling thread reports progress.
template <typename Fn>
void parallelFor(std::size_t n, unsigned threads, const std::atomic<bool>* cancel,
                 const std::function<void(std::size_t)>& tick, Fn fn) {
    std::atomic<std::size_t> next{0U};
    std::atomic<std::size_t> done{0U};
    auto worker = [&]() {
        for (;;) {
            if (cancel != nullptr && cancel->load()) return;
            const std::size_t i = next.fetch_add(1U);
            if (i >= n) return;
            fn(i);
            done.fetch_add(1U);
        }
    };
    std::vector<std::thread> pool;
    const unsigned count = static_cast<unsigned>(std::max<std::size_t>(1U, std::min<std::size_t>(threads, n)));
    for (unsigned t = 0; t < count; ++t) pool.emplace_back(worker);
    while (done.load() < n) {
        if (cancel != nullptr && cancel->load()) break;
        tick(done.load());
        std::this_thread::sleep_for(std::chrono::milliseconds(40));
    }
    for (auto& t : pool) t.join();
    tick(done.load());
}

// Arithmetic mean curve per KMP -> correction for every tone (adds to w.tone, total kept within +-lim).
std::size_t matchTone(std::vector<Work>& work, double lim, std::vector<bool>& changedNow) {
    const std::size_t P = SpectrumAnalyzer::kPoints;
    const std::size_t n = work.size();
    changedNow.assign(n, false);
    std::vector<std::vector<double>> norm(n);
    std::map<int, int> members;
    for (std::size_t k = 0; k < n; ++k) {
        const Work& w = work[k];
        if (w.group < 0 || w.curve.size() != P) continue;
        double sw = 0.0, sv = 0.0;
        for (std::size_t i = 0; i < P; ++i) { sw += w.weight[i]; sv += w.weight[i] * w.curve[i]; }
        if (sw < 8.0) continue;  // almost nothing to compare (very high tone)
        norm[k].resize(P);
        for (std::size_t i = 0; i < P; ++i) norm[k][i] = static_cast<double>(w.curve[i]) - sv / sw;
        members[w.group] += 1;
    }
    std::map<int, std::pair<std::vector<double>, std::vector<double>>> mean;  // sum, weight
    for (std::size_t k = 0; k < n; ++k) {
        if (norm[k].empty() || members[work[k].group] < 2) continue;
        auto& m = mean[work[k].group];
        if (m.first.empty()) { m.first.assign(P, 0.0); m.second.assign(P, 0.0); }
        for (std::size_t i = 0; i < P; ++i) { m.first[i] += work[k].weight[i] * norm[k][i]; m.second[i] += work[k].weight[i]; }
    }
    std::size_t matched = 0U;
    for (std::size_t k = 0; k < n; ++k) {
        Work& w = work[k];
        const auto m = mean.find(w.group);
        if (norm[k].empty() || m == mean.end()) continue;
        ++matched;
        std::vector<double> c(P, 0.0);
        for (std::size_t i = 0; i < P; ++i) {
            if (w.weight[i] <= 0.0 || m->second.second[i] < 1e-9) continue;
            c[i] = (m->second.first[i] / m->second.second[i]) - norm[k][i];
        }
        double sw = 0.0, sc = 0.0;
        for (std::size_t i = 0; i < P; ++i) { sw += w.weight[i]; sc += w.weight[i] * c[i]; }
        const double avg = sw > 0.0 ? sc / sw : 0.0;
        if (w.tone.size() != P) w.tone.assign(P, 0.0);
        std::vector<double> step(P, 0.0);
        for (std::size_t i = 0; i < P; ++i) {
            const double total = std::clamp(w.tone[i] + (c[i] - avg) * w.weight[i], -lim, lim);  // total stays fine
            step[i] = total - w.tone[i];
        }
        std::vector<double> sm(P, 0.0);
        const int r = 6;  // ~1/4 octave, no sharp edges
        for (std::size_t i = 0; i < P; ++i) {
            double a2 = 0.0; int cnt = 0;
            for (int d = -r; d <= r; ++d) {
                const long j = static_cast<long>(i) + d;
                if (j < 0 || j >= static_cast<long>(P)) continue;
                a2 += step[static_cast<std::size_t>(j)]; ++cnt;
            }
            sm[i] = a2 / cnt;
        }
        double biggest = 0.0;
        for (double v : sm) biggest = std::max(biggest, std::fabs(v));
        if (biggest >= 0.1) {
            for (std::size_t i = 0; i < P; ++i) w.tone[i] += sm[i];
            w.curve.clear();
            w.weight.assign(sm.begin(), sm.end());  // reuse: the step to apply now
            changedNow[k] = true;
        }
    }
    return matched;
}

void measureTone(Work& w) {
    w.curve = SpectrumAnalyzer::toCurve(averagePower(w), w.sample.sampleRate, kEnvelopeOctaves);
    w.weight = validWeights(w.curve, w.f0, static_cast<double>(w.sample.sampleRate));
}

} // namespace

bool SampleProcessor::process(BankProject& project,
                              const std::vector<std::size_t>& onlySamples,
                              const SampleProcessingOptions& options,
                              const SampleProcessingProgress& progress,
                              const std::atomic<bool>* cancel,
                              SampleProcessingReport& report,
                              std::string& error) {
    report = SampleProcessingReport{};
    error.clear();
    if (!options.convertTo48k && !options.evenTone && !options.normalize && !options.softLimiter) {
        error = "No function is switched ON.";
        return false;
    }

    std::vector<std::size_t> indexes = onlySamples;
    if (indexes.empty()) {
        for (std::size_t i = 0; i < project.samples.size(); ++i) indexes.push_back(i);
    }
    std::sort(indexes.begin(), indexes.end());
    indexes.erase(std::unique(indexes.begin(), indexes.end()), indexes.end());
    indexes.erase(std::remove_if(indexes.begin(), indexes.end(),
                                 [&](std::size_t i) { return i >= project.samples.size() || !project.samples[i].valid(); }),
                  indexes.end());
    if (indexes.empty()) {
        error = "There are no samples to process.";
        return false;
    }

    unsigned threads = options.threads;
    if (threads == 0U) threads = std::max(1U, std::thread::hardware_concurrency());
    threads = std::min(threads, 8U);  // memory: every thread holds one decoded sample

    // Every KMP (multisample) alone: first zone that uses the sample decides.
    std::map<std::size_t, std::pair<int, int>> where;  // sample -> (multisample, root)
    for (std::size_t m = 0; m < project.multisamples.size(); ++m) {
        for (const ImportedZone& z : project.multisamples[m].zones) {
            if (where.count(z.sampleIndex) == 0U) where[z.sampleIndex] = {static_cast<int>(m), static_cast<int>(z.rootKey)};
        }
    }

    const std::size_t n = indexes.size();
    std::vector<Work> work(n);
    for (std::size_t k = 0; k < n; ++k) {
        Work& w = work[k];
        w.index = indexes[k];
        int root = project.samples[w.index].rootKey;
        const auto it = where.find(w.index);
        if (it != where.end()) {
            w.group = it->second.first;
            w.instrument = it->second.first;
            root = it->second.second;
        }
        w.f0 = 440.0 * std::pow(2.0, (static_cast<double>(root) - 69.0) / 12.0);
        w.finalEncoding = project.samples[w.index].encoding;
    }

    const double lim = std::max(0.0, options.maxToneCorrectionDb);
    const double stages = 5.0;
    auto stageTick = [&](double stage, const char* text) {
        return std::function<void(std::size_t)>([&, stage, text](std::size_t d) {
            if (progress) progress(std::min(1.0, (stage + static_cast<double>(d) / static_cast<double>(n)) / stages), text);
        });
    };
    auto stopped = [&]() { return cancel != nullptr && cancel->load(); };
    std::vector<std::string> errors(n);
    // Intermediate audio is kept as 32 bit float (no clipping, little memory).
    auto keepFloat = [](Work& w) {
        w.sample.audioData = SampleConverter::encodeSamples(w.values, AudioEncoding::Float32LE, false);
        w.sample.encoding = AudioEncoding::Float32LE;
        w.sample.bitsPerSample = 32U;
        w.values.clear();
        w.values.shrink_to_fit();
    };

    // 1. read (+ 48 kHz), measure tone and crest
    parallelFor(n, threads, cancel, stageTick(0.0, "Reading / 48 kHz / analysing"), [&](std::size_t k) {
        Work& w = work[k];
        const ImportedSample& src = project.samples[w.index];
        if (options.convertTo48k && src.sampleRate != kTargetRate) {
            SampleConversionOptions co;
            co.sampleRate = kTargetRate;
            co.dither = true;
            ImportedSample out;
            if (SampleConverter::convert(src, co, out, errors[k])) { w.sample = std::move(out); w.changed = true; }
            else w.sample = src;
        } else {
            w.sample = src;
        }
        w.values = SampleConverter::decode(w.sample);
        if (options.evenTone && w.group >= 0) measureTone(w);
        if (options.softLimiter && w.group >= 0) w.crestDb = crestOf(w);
        w.peak = peakOf(w.values);
        w.values.clear();
        w.values.shrink_to_fit();
    });
    if (stopped()) { report.cancelled = true; return true; }
    for (std::size_t k = 0; k < n; ++k) {
        if (!errors[k].empty()) { error = project.samples[work[k].index].name + ": " + errors[k]; return false; }
        if (work[k].changed) ++report.converted;
    }

    // 2 + 3. tone: match to the KMP mean, analyse AGAIN, fine second match
    std::vector<bool> toned(n, false);
    for (int pass = 0; pass < 2 && options.evenTone; ++pass) {
        std::vector<bool> now;
        const std::size_t matched = matchTone(work, lim, now);
        if (pass == 0) report.skipped = n - matched;  // not in a KMP, alone in its KMP, or too high to compare
        parallelFor(n, threads, cancel, stageTick(1.0 + pass, pass == 0 ? "Tone: matching every KMP to its average curve" : "Tone: second analysis + fine match"), [&](std::size_t k) {
            Work& w = work[k];
            if (!now[k]) return;  // already on the curve: keeps its analysis for the second pass
            w.values = SampleConverter::decode(w.sample);
            applyCurve(w, w.weight);            // the step computed by matchTone
            if (pass == 0) measureTone(w);      // analysis again for the second pass
            else { w.curve.clear(); w.weight.clear(); }
            w.peak = peakOf(w.values);
            if (options.softLimiter && w.group >= 0) w.crestDb = crestOf(w);
            keepFloat(w);
            w.changed = true;
        });
        if (stopped()) { report.cancelled = true; return true; }
        for (std::size_t k = 0; k < n; ++k) if (now[k]) toned[k] = true;
    }
    for (Work& w : work) { w.curve.clear(); w.curve.shrink_to_fit(); w.weight.clear(); w.weight.shrink_to_fit(); w.tone.clear(); w.tone.shrink_to_fit(); }
    for (bool t : toned) if (t) ++report.toneAdjusted;

    // limiter amounts: per KMP every tone's peaks come down to the KMP's typical (median) crest, max 3 dB
    if (options.softLimiter) {
        std::map<int, std::vector<double>> crests;
        for (const Work& w : work) if (w.group >= 0 && w.crestDb > 0.0) crests[w.group].push_back(w.crestDb);
        for (auto& c : crests) std::sort(c.second.begin(), c.second.end());
        for (Work& w : work) {
            const auto c = crests.find(w.group);
            if (c == crests.end() || c->second.size() < 2U) continue;
            const double median = c->second[c->second.size() / 2U];
            w.limitDb = std::clamp(w.crestDb - median, 0.0, options.maxLimitDb);
            if (w.limitDb < 0.1) w.limitDb = 0.0;
        }
    }

    // 4. soft limiter
    parallelFor(n, threads, cancel, stageTick(3.0, "Soft peak limiter"), [&](std::size_t k) {
        Work& w = work[k];
        if (w.limitDb <= 0.0) return;
        w.values = SampleConverter::decode(w.sample);
        softLimit(w, w.limitDb);
        w.peak = peakOf(w.values);
        keepFloat(w);
        w.changed = true;
    });
    if (stopped()) { report.cancelled = true; return true; }
    for (const Work& w : work) if (w.limitDb > 0.0) ++report.limited;

    // 5. gains (-6 dB) and write back in the original format
    const double target = std::pow(10.0, options.normalizeDb / 20.0);
    std::vector<double> gain(n, 1.0);
    if (options.normalize) {
        std::map<int, double> instPeak;
        if (options.normalizePerInstrument) {
            for (const Work& w : work) if (w.instrument >= 0) instPeak[w.instrument] = std::max(instPeak[w.instrument], w.peak);
        }
        for (std::size_t k = 0; k < n; ++k) {
            double p = work[k].peak;
            if (options.normalizePerInstrument && work[k].instrument >= 0) p = instPeak[work[k].instrument];
            if (p < 1e-6) continue;
            gain[k] = target / p;
        }
    } else {
        for (std::size_t k = 0; k < n; ++k) if (work[k].peak > 0.999) gain[k] = 0.999 / work[k].peak;  // never clip
    }
    parallelFor(n, threads, cancel, stageTick(4.0, "Writing"), [&](std::size_t k) {
        Work& w = work[k];
        const bool gained = std::fabs(gain[k] - 1.0) > 1e-9;
        const bool isFloatTemp = w.sample.encoding != w.finalEncoding;
        if (!gained && !isFloatTemp) return;  // nothing more to do (maybe only converted)
        w.values = SampleConverter::decode(w.sample);
        if (gained) scale(w.values, gain[k]);
        w.sample.audioData = SampleConverter::encodeSamples(w.values, w.finalEncoding, true);
        w.sample.encoding = w.finalEncoding;
        w.sample.bitsPerSample = w.finalEncoding == AudioEncoding::Pcm16LE ? 16U : (w.finalEncoding == AudioEncoding::Pcm24LE ? 24U : 32U);
        w.values.clear();
        w.values.shrink_to_fit();
        w.changed = true;
    });
    if (stopped()) { report.cancelled = true; return true; }
    if (options.normalize) for (std::size_t k = 0; k < n; ++k) if (std::fabs(gain[k] - 1.0) > 1e-9) ++report.normalized;

    // 6. commit only when everything is done
    for (Work& w : work) {
        if (w.changed) project.samples[w.index] = std::move(w.sample);
    }
    if (progress) progress(1.0, "Done");
    return true;
}

} // namespace silveton::manager
