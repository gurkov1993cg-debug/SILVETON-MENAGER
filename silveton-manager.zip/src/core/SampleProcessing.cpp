// SILVETON_PROCESSING_V1
#include "silveton/manager/SampleProcessing.h"
#include "silveton/manager/SampleConverter.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <limits>
#include <map>
#include <thread>
#include <tuple>

namespace silveton::manager {
namespace {

constexpr double kPi = 3.14159265358979323846;
constexpr std::uint32_t kTargetRate = 48000U;

struct Biquad {
    double b0{1.0}, b1{0.0}, b2{0.0}, a1{0.0}, a2{0.0};
    double z1{0.0}, z2{0.0};
    double run(double x) noexcept {
        const double y = b0 * x + z1;
        z1 = b1 * x - a1 * y + z2;
        z2 = b2 * x - a2 * y;
        return y;
    }
    void reset() noexcept { z1 = z2 = 0.0; }
};

Biquad makeFilter(int type, double rate, double hz, double gainDb) {
    // RBJ cookbook. type 0 = lowpass, 1 = highpass, 2 = high shelf (S = 1)
    const double w = 2.0 * kPi * hz / rate;
    const double cw = std::cos(w);
    const double sw = std::sin(w);
    double b0 = 1.0, b1 = 0.0, b2 = 0.0, a0 = 1.0, a1 = 0.0, a2 = 0.0;
    if (type == 0 || type == 1) {
        const double alpha = sw / (2.0 * 0.70710678118654752);
        if (type == 0) { b0 = (1.0 - cw) / 2.0; b1 = 1.0 - cw; b2 = b0; }
        else { b0 = (1.0 + cw) / 2.0; b1 = -(1.0 + cw); b2 = b0; }
        a0 = 1.0 + alpha; a1 = -2.0 * cw; a2 = 1.0 - alpha;
    } else {
        const double A = std::pow(10.0, gainDb / 40.0);
        const double alpha = sw / 2.0 * std::sqrt(2.0);
        const double sa = 2.0 * std::sqrt(A) * alpha;
        b0 = A * ((A + 1.0) + (A - 1.0) * cw + sa);
        b1 = -2.0 * A * ((A - 1.0) + (A + 1.0) * cw);
        b2 = A * ((A + 1.0) + (A - 1.0) * cw - sa);
        a0 = (A + 1.0) - (A - 1.0) * cw + sa;
        a1 = 2.0 * ((A - 1.0) - (A + 1.0) * cw);
        a2 = (A + 1.0) - (A - 1.0) * cw - sa;
    }
    Biquad f;
    f.b0 = b0 / a0; f.b1 = b1 / a0; f.b2 = b2 / a0; f.a1 = a1 / a0; f.a2 = a2 / a0;
    return f;
}

struct Work {
    std::size_t index{0U};
    ImportedSample sample;           // working copy
    std::vector<double> values;      // interleaved -1..+1
    bool changed{false};
    int group{-1};                   // multisample + velocity group (tone)
    int instrument{-1};              // multisample (normalize per instrument)
    double f0{0.0};
    double brightness{std::numeric_limits<double>::quiet_NaN()};
    double peak{0.0};
};

// Upper harmonics against fundamental + 2nd harmonic, in dB. NaN = cannot measure.
double measureBrightness(const Work& w) {
    const double rate = static_cast<double>(w.sample.sampleRate);
    const double f0 = w.f0;
    if (f0 < 20.0 || 4.0 * f0 >= 0.40 * rate) return std::numeric_limits<double>::quiet_NaN();
    const std::size_t ch = w.sample.channels;
    const std::size_t frames = w.values.size() / ch;
    if (frames < 256U) return std::numeric_limits<double>::quiet_NaN();
    Biquad lo1 = makeFilter(0, rate, 2.5 * f0, 0.0), lo2 = lo1;
    Biquad hi1 = makeFilter(1, rate, 4.0 * f0, 0.0), hi2 = hi1;
    Biquad top = makeFilter(0, rate, std::min(12.0 * f0, 0.45 * rate), 0.0);
    const std::size_t skip = frames / 20U;  // leave the attack out
    double eLow = 0.0, eHigh = 0.0;
    for (std::size_t f = 0; f < frames; ++f) {
        double m = 0.0;
        for (std::size_t c = 0; c < ch; ++c) m += w.values[f * ch + c];
        m /= static_cast<double>(ch);
        const double l = lo2.run(lo1.run(m));
        const double h = top.run(hi2.run(hi1.run(m)));
        if (f >= skip) { eLow += l * l; eHigh += h * h; }
    }
    if (eLow < 1e-12 || eHigh < 1e-14) return std::numeric_limits<double>::quiet_NaN();
    return 10.0 * std::log10(eHigh / eLow);
}

void applyShelf(Work& w, double gainDb) {
    const double rate = static_cast<double>(w.sample.sampleRate);
    const double corner = std::min(3.0 * w.f0, 0.45 * rate);
    const std::size_t ch = w.sample.channels;
    const std::size_t frames = w.values.size() / ch;
    for (std::size_t c = 0; c < ch; ++c) {
        Biquad f = makeFilter(2, rate, corner, gainDb);
        for (std::size_t i = 0; i < frames; ++i) {
            double& v = w.values[i * ch + c];
            v = f.run(v);
        }
    }
}

double peakOf(const std::vector<double>& v) {
    double p = 0.0;
    for (double x : v) p = std::max(p, std::fabs(x));
    return p;
}

void scale(std::vector<double>& v, double g) {
    for (double& x : v) x *= g;
}

// Runs fn(i) for i in 0..n-1 on several threads; the calling thread reports progress.
template <typename Fn>
void parallelFor(std::size_t n, unsigned threads, const std::atomic<bool>* cancel,
                 const std::function<void(std::size_t)>& tick, Fn fn) {
    std::atomic<std::size_t> next{0U};
    std::atomic<std::size_t> done{0U};
    auto worker = [&]() {
        for (;;) {
            if (cancel != nullptr && cancel->load()) return;
            const std::size_t i = next.fetch_add(1U);
            if (i >= n) return;
            fn(i);
            done.fetch_add(1U);
        }
    };
    std::vector<std::thread> pool;
    const unsigned count = static_cast<unsigned>(std::max<std::size_t>(1U, std::min<std::size_t>(threads, n)));
    for (unsigned t = 0; t < count; ++t) pool.emplace_back(worker);
    while (done.load() < n) {
        if (cancel != nullptr && cancel->load()) break;
        tick(done.load());
        std::this_thread::sleep_for(std::chrono::milliseconds(40));
    }
    for (auto& t : pool) t.join();
    tick(done.load());
}

} // namespace

bool SampleProcessor::process(BankProject& project,
                              const std::vector<std::size_t>& onlySamples,
                              const SampleProcessingOptions& options,
                              const SampleProcessingProgress& progress,
                              const std::atomic<bool>* cancel,
                              SampleProcessingReport& report,
                              std::string& error) {
    report = SampleProcessingReport{};
    error.clear();
    if (!options.convertTo48k && !options.evenTone && !options.normalize) {
        error = "No function is switched ON.";
        return false;
    }

    std::vector<std::size_t> indexes = onlySamples;
    if (indexes.empty()) {
        for (std::size_t i = 0; i < project.samples.size(); ++i) indexes.push_back(i);
    }
    std::sort(indexes.begin(), indexes.end());
    indexes.erase(std::unique(indexes.begin(), indexes.end()), indexes.end());
    indexes.erase(std::remove_if(indexes.begin(), indexes.end(),
                                 [&](std::size_t i) { return i >= project.samples.size() || !project.samples[i].valid(); }),
                  indexes.end());
    if (indexes.empty()) {
        error = "There are no samples to process.";
        return false;
    }

    unsigned threads = options.threads;
    if (threads == 0U) threads = std::max(1U, std::thread::hardware_concurrency());

    // Group samples: first zone that uses the sample decides.
    std::map<std::size_t, std::tuple<int, int, int>> where;  // sample -> (multisample, velLow, root)
    std::map<std::tuple<int, int, int>, int> groupIds;
    for (std::size_t m = 0; m < project.multisamples.size(); ++m) {
        for (const ImportedZone& z : project.multisamples[m].zones) {
            const std::size_t s = z.sampleIndex;
            if (where.count(s) == 0U) where[s] = std::make_tuple(static_cast<int>(m), static_cast<int>(z.velocityLow) * 256 + z.velocityHigh, static_cast<int>(z.rootKey));
        }
    }

    std::vector<Work> work(indexes.size());
    for (std::size_t k = 0; k < indexes.size(); ++k) {
        Work& w = work[k];
        w.index = indexes[k];
        int root = project.samples[w.index].rootKey;
        const auto it = where.find(w.index);
        if (it != where.end()) {
            const int ms = std::get<0>(it->second);
            const int vel = std::get<1>(it->second);
            root = std::get<2>(it->second);
            w.instrument = ms;
            const auto key = std::make_tuple(ms, vel, 0);
            auto g = groupIds.find(key);
            if (g == groupIds.end()) g = groupIds.emplace(key, static_cast<int>(groupIds.size())).first;
            w.group = g->second;
        }
        w.f0 = 440.0 * std::pow(2.0, (static_cast<double>(root) - 69.0) / 12.0);
    }

    const std::size_t n = work.size();
    const double total = 3.0 * static_cast<double>(n);
    auto stageTick = [&](double base, const char* text) {
        return std::function<void(std::size_t)>([&, base, text](std::size_t d) {
            if (progress) progress(std::min(1.0, (base + static_cast<double>(d)) / total), text);
        });
    };
    std::vector<std::string> errors(n);

    // 1. decode (+ convert to 48 kHz)
    parallelFor(n, threads, cancel, stageTick(0.0, "Reading / 48 kHz"), [&](std::size_t k) {
        Work& w = work[k];
        const ImportedSample& src = project.samples[w.index];
        if (options.convertTo48k && src.sampleRate != kTargetRate) {
            SampleConversionOptions co;
            co.sampleRate = kTargetRate;
            co.dither = true;
            ImportedSample out;
            if (SampleConverter::convert(src, co, out, errors[k])) {
                w.sample = std::move(out);
                w.changed = true;
            } else {
                w.sample = src;
            }
        } else {
            w.sample = src;
        }
        w.values = SampleConverter::decode(w.sample);
        w.peak = peakOf(w.values);
        if (options.evenTone) w.brightness = measureBrightness(w);
    });
    if (cancel != nullptr && cancel->load()) { report.cancelled = true; return true; }
    for (std::size_t k = 0; k < n; ++k) {
        if (!errors[k].empty()) { error = project.samples[work[k].index].name + ": " + errors[k]; return false; }
        if (work[k].changed) ++report.converted;
    }

    // 2. tone evening: every measured sample moves to the average of its group
    std::vector<double> toneDb(n, 0.0);
    if (options.evenTone) {
        std::map<int, std::pair<double, int>> sums;
        for (const Work& w : work) {
            if (w.group >= 0 && std::isfinite(w.brightness)) {
                sums[w.group].first += w.brightness;
                sums[w.group].second += 1;
            }
        }
        const double lim = std::max(0.0, options.maxToneCorrectionDb);
        for (std::size_t k = 0; k < n; ++k) {
            const Work& w = work[k];
            const auto s = sums.find(w.group);
            if (w.group < 0 || !std::isfinite(w.brightness) || s == sums.end() || s->second.second < 2) {
                ++report.skipped;
                continue;
            }
            const double target = s->second.first / s->second.second;
            toneDb[k] = std::clamp(target - w.brightness, -lim, lim);
        }
    }

    // 3. apply tone, measure peaks again
    parallelFor(n, threads, cancel, stageTick(static_cast<double>(n), "Tone"), [&](std::size_t k) {
        Work& w = work[k];
        if (std::fabs(toneDb[k]) >= 0.05) {
            applyShelf(w, toneDb[k]);
            w.peak = peakOf(w.values);
            w.changed = true;
        }
    });
    if (cancel != nullptr && cancel->load()) { report.cancelled = true; return true; }
    for (double t : toneDb) if (std::fabs(t) >= 0.05) ++report.toneAdjusted;

    // 4. gains
    const double target = std::pow(10.0, options.normalizeDb / 20.0);
    std::vector<double> gain(n, 1.0);
    if (options.normalize) {
        std::map<int, double> instPeak;
        if (options.normalizePerInstrument) {
            for (const Work& w : work) if (w.instrument >= 0) instPeak[w.instrument] = std::max(instPeak[w.instrument], w.peak);
        }
        for (std::size_t k = 0; k < n; ++k) {
            const Work& w = work[k];
            double p = w.peak;
            if (options.normalizePerInstrument && w.instrument >= 0) p = instPeak[w.instrument];
            if (p < 1e-6) continue;  // silence stays silence
            gain[k] = target / p;
        }
    } else {
        // tone change must never clip
        for (std::size_t k = 0; k < n; ++k) if (work[k].peak > 0.999) gain[k] = 0.999 / work[k].peak;
    }

    // 5. encode back
    parallelFor(n, threads, cancel, stageTick(2.0 * static_cast<double>(n), "Writing"), [&](std::size_t k) {
        Work& w = work[k];
        if (std::fabs(gain[k] - 1.0) > 1e-9) { scale(w.values, gain[k]); w.changed = true; }
        if (w.changed && !(w.index < project.samples.size() && w.sample.sampleRate != project.samples[w.index].sampleRate && std::fabs(gain[k] - 1.0) <= 1e-9 && std::fabs(toneDb[k]) < 0.05)) {
            w.sample.audioData = SampleConverter::encodeSamples(w.values, w.sample.encoding, true);
        }
        w.values.clear();
        w.values.shrink_to_fit();
    });
    if (cancel != nullptr && cancel->load()) { report.cancelled = true; return true; }
    if (options.normalize) for (std::size_t k = 0; k < n; ++k) if (std::fabs(gain[k] - 1.0) > 1e-9) ++report.normalized;

    // 6. commit only when everything is done
    for (Work& w : work) {
        if (w.changed) project.samples[w.index] = std::move(w.sample);
    }
    if (progress) progress(1.0, "Done");
    return true;
}

} // namespace silveton::manager
