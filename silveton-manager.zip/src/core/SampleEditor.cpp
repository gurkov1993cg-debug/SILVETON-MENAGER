#include "silveton/manager/SampleEditor.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <limits>

namespace silveton::manager {
namespace {

std::size_t bytesPerSample(AudioEncoding encoding) noexcept {
    switch (encoding) {
        case AudioEncoding::Pcm16LE: return 2U;
        case AudioEncoding::Pcm24LE: return 3U;
        case AudioEncoding::Float32LE: return 4U;
    }
    return 0U;
}

std::size_t frameBytes(const ImportedSample& sample) noexcept {
    return static_cast<std::size_t>(sample.channels) * bytesPerSample(sample.encoding);
}

float readScalar(const std::uint8_t* p, AudioEncoding encoding) noexcept {
    switch (encoding) {
        case AudioEncoding::Pcm16LE: {
            const std::uint16_t raw = static_cast<std::uint16_t>(p[0]) |
                                      static_cast<std::uint16_t>(static_cast<std::uint16_t>(p[1]) << 8U);
            const std::int16_t value = static_cast<std::int16_t>(raw);
            return value < 0 ? static_cast<float>(value) / 32768.0F
                             : static_cast<float>(value) / 32767.0F;
        }
        case AudioEncoding::Pcm24LE: {
            std::int32_t value = static_cast<std::int32_t>(p[0]) |
                                 (static_cast<std::int32_t>(p[1]) << 8) |
                                 (static_cast<std::int32_t>(p[2]) << 16);
            if ((value & 0x00800000) != 0) value |= static_cast<std::int32_t>(0xFF000000U);
            return value < 0 ? static_cast<float>(value) / 8388608.0F
                             : static_cast<float>(value) / 8388607.0F;
        }
        case AudioEncoding::Float32LE: {
            const std::uint32_t raw = static_cast<std::uint32_t>(p[0]) |
                                      (static_cast<std::uint32_t>(p[1]) << 8U) |
                                      (static_cast<std::uint32_t>(p[2]) << 16U) |
                                      (static_cast<std::uint32_t>(p[3]) << 24U);
            float value = 0.0F;
            std::memcpy(&value, &raw, sizeof(value));
            return std::isfinite(value) ? value : 0.0F;
        }
    }
    return 0.0F;
}

float clampAudio(float value) noexcept {
    return std::max(-1.0F, std::min(1.0F, value));
}

void writeScalar(std::uint8_t* p, AudioEncoding encoding, float input) noexcept {
    const float value = clampAudio(input);
    switch (encoding) {
        case AudioEncoding::Pcm16LE: {
            std::int32_t quantized = 0;
            if (value <= -1.0F) quantized = -32768;
            else if (value >= 1.0F) quantized = 32767;
            else if (value < 0.0F) quantized = static_cast<std::int32_t>(std::lround(static_cast<double>(value) * 32768.0));
            else quantized = static_cast<std::int32_t>(std::lround(static_cast<double>(value) * 32767.0));
            const std::uint16_t raw = static_cast<std::uint16_t>(static_cast<std::int16_t>(quantized));
            p[0] = static_cast<std::uint8_t>(raw & 0xFFU);
            p[1] = static_cast<std::uint8_t>((raw >> 8U) & 0xFFU);
            break;
        }
        case AudioEncoding::Pcm24LE: {
            std::int32_t quantized = 0;
            if (value <= -1.0F) quantized = -8388608;
            else if (value >= 1.0F) quantized = 8388607;
            else if (value < 0.0F) quantized = static_cast<std::int32_t>(std::lround(static_cast<double>(value) * 8388608.0));
            else quantized = static_cast<std::int32_t>(std::lround(static_cast<double>(value) * 8388607.0));
            const std::uint32_t raw = static_cast<std::uint32_t>(quantized) & 0x00FFFFFFU;
            p[0] = static_cast<std::uint8_t>(raw & 0xFFU);
            p[1] = static_cast<std::uint8_t>((raw >> 8U) & 0xFFU);
            p[2] = static_cast<std::uint8_t>((raw >> 16U) & 0xFFU);
            break;
        }
        case AudioEncoding::Float32LE: {
            std::uint32_t raw = 0U;
            std::memcpy(&raw, &value, sizeof(raw));
            p[0] = static_cast<std::uint8_t>(raw & 0xFFU);
            p[1] = static_cast<std::uint8_t>((raw >> 8U) & 0xFFU);
            p[2] = static_cast<std::uint8_t>((raw >> 16U) & 0xFFU);
            p[3] = static_cast<std::uint8_t>((raw >> 24U) & 0xFFU);
            break;
        }
    }
}

bool editable(const ImportedSample& sample, std::string& error) {
    if (!sample.valid()) {
        error = "Sample data is invalid";
        return false;
    }
    if (bytesPerSample(sample.encoding) == 0U) {
        error = "Unsupported sample encoding";
        return false;
    }
    return true;
}

float frameValue(const ImportedSample& sample, std::uint64_t frame) noexcept {
    if (!sample.valid() || frame >= sample.totalFrames || sample.channels == 0U) return 0.0F;
    const std::size_t bps = bytesPerSample(sample.encoding);
    const std::size_t fb = frameBytes(sample);
    const std::size_t offset = static_cast<std::size_t>(frame) * fb;
    float sum = 0.0F;
    for (std::uint16_t channel = 0U; channel < sample.channels; ++channel) {
        sum += readScalar(sample.audioData.data() + offset + static_cast<std::size_t>(channel) * bps, sample.encoding);
    }
    return sum / static_cast<float>(sample.channels);
}

void multiplyFrames(ImportedSample& sample,
                    std::uint64_t firstFrame,
                    std::uint64_t frameCount,
                    float (*gainForIndex)(std::uint64_t, std::uint64_t)) noexcept {
    const std::size_t bps = bytesPerSample(sample.encoding);
    const std::size_t fb = frameBytes(sample);
    for (std::uint64_t i = 0U; i < frameCount; ++i) {
        const float gain = gainForIndex(i, frameCount);
        const std::size_t frameOffset = static_cast<std::size_t>(firstFrame + i) * fb;
        for (std::uint16_t channel = 0U; channel < sample.channels; ++channel) {
            std::uint8_t* scalar = sample.audioData.data() + frameOffset + static_cast<std::size_t>(channel) * bps;
            writeScalar(scalar, sample.encoding, readScalar(scalar, sample.encoding) * gain);
        }
    }
}

float fadeInGain(std::uint64_t index, std::uint64_t count) noexcept {
    if (count <= 1U) return 0.0F;
    return static_cast<float>(static_cast<double>(index) / static_cast<double>(count - 1U));
}

float fadeOutGain(std::uint64_t index, std::uint64_t count) noexcept {
    if (count <= 1U) return 0.0F;
    return static_cast<float>(static_cast<double>((count - 1U) - index) / static_cast<double>(count - 1U));
}

} // namespace

bool SampleEditor::trim(ImportedSample& sample,
                        std::uint64_t startFrame,
                        std::uint64_t endFrame,
                        std::string& error) {
    error.clear();
    if (!editable(sample, error)) return false;
    if (startFrame >= endFrame || endFrame > sample.totalFrames) {
        error = "Trim range must satisfy start < end <= total frames";
        return false;
    }

    const std::size_t fb = frameBytes(sample);
    const std::size_t byteStart = static_cast<std::size_t>(startFrame) * fb;
    const std::size_t byteEnd = static_cast<std::size_t>(endFrame) * fb;
    std::vector<std::uint8_t> trimmed(sample.audioData.begin() + static_cast<std::ptrdiff_t>(byteStart),
                                      sample.audioData.begin() + static_cast<std::ptrdiff_t>(byteEnd));
    sample.audioData.swap(trimmed);
    sample.totalFrames = endFrame - startFrame;

    if (sample.loop.enabled) {
        if (sample.loop.startFrame >= startFrame && sample.loop.endFrame <= endFrame) {
            sample.loop.startFrame -= startFrame;
            sample.loop.endFrame -= startFrame;
            const std::uint64_t loopLength = sample.loop.endFrame - sample.loop.startFrame;
            if (static_cast<std::uint64_t>(sample.loop.crossfadeFrames) * 2U > loopLength) {
                sample.loop.crossfadeFrames = static_cast<std::uint32_t>(loopLength / 2U);
            }
        } else {
            sample.loop = {};
        }
    }

    return sample.valid();
}

// SILVETON_ATTACK_V1 - find where the hit begins
SampleEditor::AttackPoint SampleEditor::findAttack(const ImportedSample& sample) noexcept {
    AttackPoint out{};
    std::string ignored;
    if (!editable(sample, ignored) || sample.totalFrames < 64U || sample.sampleRate == 0U) return out;

    const double rate = static_cast<double>(sample.sampleRate);
    const std::size_t n = static_cast<std::size_t>(sample.totalFrames);
    const std::size_t smooth = std::max<std::size_t>(4U, static_cast<std::size_t>(rate * 0.001));   // 1 ms

    // the loudness around every frame, and the loudest point of the whole sample
    std::vector<float> env(n, 0.0F);
    double running = 0.0;
    for (std::size_t i = 0U; i < n; ++i) {
        running += std::fabs(static_cast<double>(frameValue(sample, i)));
        if (i >= smooth) running -= std::fabs(static_cast<double>(frameValue(sample, i - smooth)));
        env[i] = static_cast<float>(running / static_cast<double>(std::min(i + 1U, smooth)));
    }
    float top = 0.0F;
    for (float v : env) top = std::max(top, v);
    if (top <= 1e-7F) return out;

    // the hit: the first place that is clearly loud
    const float hitLevel = top * 0.02F;        // about -34 dB below the loudest point
    std::size_t hit = n;
    for (std::size_t i = 0U; i < n; ++i) {
        if (env[i] >= hitLevel) { hit = i; break; }
    }
    if (hit >= n) return out;

    // what the quiet in front actually sounds like: hiss counts as quiet, not as the sound
    float floorLevel = 0.0F;
    if (hit > 64U) {
        std::vector<float> before(env.begin(), env.begin() + static_cast<std::ptrdiff_t>(hit));
        std::nth_element(before.begin(), before.begin() + static_cast<std::ptrdiff_t>(before.size() / 2U), before.end());
        floorLevel = before[before.size() / 2U];
    }
    // walk back to where the rise starts, so nothing of the attack itself is lost
    const float footLevel = std::max({top * 0.002F, floorLevel * 3.0F, 1.0F / 32768.0F});   // -54 dB, or just above the hiss
    std::size_t foot = hit;
    while (foot > 0U && env[foot] > footLevel) --foot;
    const std::size_t margin = static_cast<std::size_t>(rate * 0.001);
    std::size_t start = foot > margin ? foot - margin : 0U;
    if (start > 0U) start = static_cast<std::size_t>(nearestZeroCrossing(sample, start, static_cast<std::uint64_t>(rate * 0.001)));
    if (start >= hit) start = foot;

    out.found = true;
    out.startFrame = static_cast<std::uint64_t>(start);
    out.leadInSeconds = static_cast<double>(start) / rate;
    out.riseSeconds = static_cast<double>(hit - foot) / rate;
    out.hasLateStart = out.leadInSeconds > 0.002;    // more than two milliseconds of nothing in front
    return out;
}

bool SampleEditor::cutOut(ImportedSample& sample,
                          std::uint64_t startFrame,
                          std::uint64_t endFrame,
                          std::string& error) {
    error.clear();
    if (!editable(sample, error)) return false;
    if (startFrame >= endFrame || endFrame > sample.totalFrames) {
        error = "Cut range must satisfy start < end <= total frames";
        return false;
    }
    if (endFrame - startFrame >= sample.totalFrames) {
        error = "The whole sample cannot be cut away";
        return false;
    }

    const std::size_t fb = frameBytes(sample);
    const std::size_t byteStart = static_cast<std::size_t>(startFrame) * fb;
    const std::size_t byteEnd = static_cast<std::size_t>(endFrame) * fb;
    sample.audioData.erase(sample.audioData.begin() + static_cast<std::ptrdiff_t>(byteStart),
                           sample.audioData.begin() + static_cast<std::ptrdiff_t>(byteEnd));
    const std::uint64_t removed = endFrame - startFrame;
    sample.totalFrames -= removed;

    if (sample.loop.enabled) {
        if (sample.loop.endFrame <= startFrame) {
            // the loop is before the cut: nothing moves
        } else if (sample.loop.startFrame >= endFrame) {
            sample.loop.startFrame -= removed;
            sample.loop.endFrame -= removed;
        } else {
            sample.loop = {};   // the cut goes through the loop
        }
    }

    return sample.valid();
}

// SILVETON_PITCHCURVE_V1 ------------------------------------------------------------------------------

// The clean curve the drawing is pulled towards: c + a * e^(-t/T), t from 0 at the start to 1 at the end.
// T is searched over a fixed ladder; for each T, a and c are the exact least-squares solution, so the result
// is the same every time and does not depend on where the drawing started.
void SampleEditor::shapeCurve(std::vector<float>& curve, float amount) noexcept {
    const std::size_t n = curve.size();
    if (n < 3U) return;
    const float k = std::min(1.0F, std::max(0.0F, amount));
    if (k <= 0.0F) return;

    double bestError = std::numeric_limits<double>::max();
    std::vector<float> best(n, 0.0F);
    for (int step = 0; step <= 40; ++step) {
        const double tau = 0.01 * std::pow(200.0, static_cast<double>(step) / 40.0);   // 0.01 ... 2.0
        double sumE = 0.0, sumEE = 0.0, sumY = 0.0, sumEY = 0.0;
        for (std::size_t i = 0U; i < n; ++i) {
            const double t = static_cast<double>(i) / static_cast<double>(n - 1U);
            const double e = std::exp(-t / tau);
            const double y = static_cast<double>(curve[i]);
            sumE += e; sumEE += e * e; sumY += y; sumEY += e * y;
        }
        const double count = static_cast<double>(n);
        const double det = sumEE * count - sumE * sumE;
        if (std::fabs(det) < 1e-12) continue;
        const double a = (sumEY * count - sumE * sumY) / det;
        const double c = (sumEE * sumY - sumE * sumEY) / det;
        double error = 0.0;
        std::vector<float> fit(n, 0.0F);
        for (std::size_t i = 0U; i < n; ++i) {
            const double t = static_cast<double>(i) / static_cast<double>(n - 1U);
            const double v = c + a * std::exp(-t / tau);
            fit[i] = static_cast<float>(v);
            const double d = v - static_cast<double>(curve[i]);
            error += d * d;
        }
        if (error < bestError) { bestError = error; best.swap(fit); }
    }
    if (bestError == std::numeric_limits<double>::max()) return;
    for (std::size_t i = 0U; i < n; ++i) {
        curve[i] = (1.0F - k) * curve[i] + k * best[i];
    }
}

namespace {

// one value of the curve at a point between its points (straight line between neighbours)
float curveAt(const std::vector<float>& curve, double position01) noexcept {
    if (curve.empty()) return 0.0F;
    if (curve.size() == 1U) return curve.front();
    const double x = std::min(1.0, std::max(0.0, position01)) * static_cast<double>(curve.size() - 1U);
    const std::size_t i = static_cast<std::size_t>(x);
    if (i + 1U >= curve.size()) return curve.back();
    const double f = x - static_cast<double>(i);
    return static_cast<float>(curve[i] * (1.0 - f) + curve[i + 1U] * f);
}

// one channel value at a position between frames (Catmull-Rom, the same shape the sampler uses)
float sampleAt(const ImportedSample& sample, double position, std::uint16_t channel) noexcept {
    const std::size_t bps = bytesPerSample(sample.encoding);
    const std::size_t fb = frameBytes(sample);
    const std::int64_t i = static_cast<std::int64_t>(std::floor(position));
    const double f = position - static_cast<double>(i);
    const std::int64_t last = static_cast<std::int64_t>(sample.totalFrames) - 1;
    auto value = [&](std::int64_t frame) -> double {
        const std::int64_t clamped = std::min(last, std::max<std::int64_t>(0, frame));
        return static_cast<double>(readScalar(sample.audioData.data() + static_cast<std::size_t>(clamped) * fb +
                                              static_cast<std::size_t>(channel) * bps, sample.encoding));
    };
    const double p0 = value(i - 1), p1 = value(i), p2 = value(i + 1), p3 = value(i + 2);
    const double a = 2.0 * p1;
    const double b = p2 - p0;
    const double c = 2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3;
    const double d = -p0 + 3.0 * p1 - 3.0 * p2 + p3;
    const double v = 0.5 * (a + b * f + c * f * f + d * f * f * f);
    return static_cast<float>(std::min(1.0, std::max(-1.0, v)));
}

} // namespace

bool SampleEditor::applyPitchCurve(ImportedSample& sample,
                                   const std::vector<float>& curve,
                                   std::string& error) {
    error.clear();
    if (!editable(sample, error)) return false;
    if (curve.size() < 2U) { error = "The pitch curve has no points"; return false; }
    if (sample.totalFrames < 4U) { error = "The sample is too short for a pitch curve"; return false; }

    bool flat = true;
    for (float v : curve) {
        if (!std::isfinite(v)) { error = "The pitch curve has a bad value"; return false; }
        if (std::fabs(v) > 0.001F) flat = false;
    }
    if (flat) return true;   // nothing to do, and nothing is touched

    const std::size_t fb = frameBytes(sample);
    const std::size_t bps = bytesPerSample(sample.encoding);
    const double total = static_cast<double>(sample.totalFrames);

    // where the reading head stands after every written frame; it moves by 2^(semitones/12) each time
    std::vector<std::uint8_t> out;
    out.reserve(sample.audioData.size());
    std::vector<std::uint8_t> frame(fb, 0U);
    const std::uint64_t maxFrames = sample.totalFrames * 8U;   // the limit below keeps this reachable
    double position = 0.0;
    std::uint64_t written = 0U;
    std::uint64_t loopStartOut = 0U, loopEndOut = 0U;
    bool loopStartSeen = false, loopEndSeen = false;
    const bool hadLoop = sample.loop.enabled;

    while (position < total - 1.0 && written < maxFrames) {
        if (hadLoop && !loopStartSeen && position >= static_cast<double>(sample.loop.startFrame)) { loopStartOut = written; loopStartSeen = true; }
        if (hadLoop && !loopEndSeen && position >= static_cast<double>(sample.loop.endFrame)) { loopEndOut = written; loopEndSeen = true; }
        for (std::uint16_t channel = 0U; channel < sample.channels; ++channel) {
            writeScalar(frame.data() + static_cast<std::size_t>(channel) * bps, sample.encoding,
                        sampleAt(sample, position, channel));
        }
        out.insert(out.end(), frame.begin(), frame.end());
        ++written;
        const float semitones = std::min(kPitchCurveLimitSemitones,
                                         std::max(-kPitchCurveLimitSemitones, curveAt(curve, position / total)));
        position += std::pow(2.0, static_cast<double>(semitones) / 12.0);
    }
    if (written < 2U) { error = "The pitch curve leaves nothing of the sample"; return false; }

    sample.audioData.swap(out);
    sample.totalFrames = written;
    if (hadLoop) {
        if (!loopEndSeen) loopEndOut = written;
        if (loopStartSeen && loopEndOut > loopStartOut) {
            sample.loop.startFrame = loopStartOut;
            sample.loop.endFrame = loopEndOut;
            const std::uint64_t length = loopEndOut - loopStartOut;
            if (static_cast<std::uint64_t>(sample.loop.crossfadeFrames) * 2U > length) {
                sample.loop.crossfadeFrames = static_cast<std::uint32_t>(length / 2U);
            }
        } else {
            sample.loop = {};
        }
    }
    return sample.valid();
}

bool SampleEditor::setLoop(ImportedSample& sample,
                           bool enabled,
                           std::uint64_t startFrame,
                           std::uint64_t endFrame,
                           std::uint32_t crossfadeFrames,
                           std::string& error) {
    error.clear();
    if (!editable(sample, error)) return false;
    if (!enabled) {
        sample.loop = {};
        return true;
    }
    if (startFrame >= endFrame || endFrame > sample.totalFrames) {
        error = "Loop range must satisfy start < end <= total frames";
        return false;
    }
    const std::uint64_t loopLength = endFrame - startFrame;
    if (static_cast<std::uint64_t>(crossfadeFrames) * 2U > loopLength) {
        error = "Loop crossfade cannot exceed half of the loop length";
        return false;
    }
    sample.loop.enabled = true;
    sample.loop.startFrame = startFrame;
    sample.loop.endFrame = endFrame;
    sample.loop.crossfadeFrames = crossfadeFrames;
    return true;
}

bool SampleEditor::applyLoopCrossfade(ImportedSample& sample,
                                      std::uint32_t crossfadeFrames,
                                      std::string& error) {
    error.clear();
    if (!editable(sample, error)) return false;
    if (!sample.loop.enabled) {
        error = "Loop crossfade requires an enabled loop";
        return false;
    }
    if (sample.loop.startFrame >= sample.loop.endFrame || sample.loop.endFrame > sample.totalFrames) {
        error = "Configured loop range is invalid";
        return false;
    }
    if (crossfadeFrames == 0U) {
        error = "Loop crossfade length must be greater than zero";
        return false;
    }

    const std::uint64_t loopLength = sample.loop.endFrame - sample.loop.startFrame;
    if (static_cast<std::uint64_t>(crossfadeFrames) * 2U > loopLength) {
        error = "Loop crossfade cannot exceed half of the loop length";
        return false;
    }

    const std::size_t bps = bytesPerSample(sample.encoding);
    const std::size_t fb = frameBytes(sample);
    const std::uint64_t fadeFrames = static_cast<std::uint64_t>(crossfadeFrames);
    const std::uint64_t tailStart = sample.loop.endFrame - fadeFrames;
    const std::uint64_t headStart = sample.loop.startFrame;

    for (std::uint64_t i = 0U; i < fadeFrames; ++i) {
        const float headMix = static_cast<float>(static_cast<double>(i + 1U) / static_cast<double>(fadeFrames));
        const float tailMix = 1.0F - headMix;
        const std::size_t tailOffset = static_cast<std::size_t>(tailStart + i) * fb;
        const std::size_t headOffset = static_cast<std::size_t>(headStart + i) * fb;

        for (std::uint16_t channel = 0U; channel < sample.channels; ++channel) {
            const std::size_t channelOffset = static_cast<std::size_t>(channel) * bps;
            std::uint8_t* tailScalar = sample.audioData.data() + tailOffset + channelOffset;
            const std::uint8_t* headScalar = sample.audioData.data() + headOffset + channelOffset;
            const float blended = readScalar(tailScalar, sample.encoding) * tailMix +
                                  readScalar(headScalar, sample.encoding) * headMix;
            writeScalar(tailScalar, sample.encoding, blended);
        }
    }

    // The first crossfadeFrames from the old loop head are now represented in
    // the overlap at the loop tail. Advancing the loop start prevents those
    // frames from being played a second time after the wrap.
    sample.loop.startFrame += fadeFrames;
    sample.loop.crossfadeFrames = 0U;
    return true;
}

bool SampleEditor::reverse(ImportedSample& sample, std::string& error) {
    error.clear();
    if (!editable(sample, error)) return false;

    const std::size_t fb = frameBytes(sample);
    std::array<std::uint8_t, 8U> temporary{};
    if (fb > temporary.size()) {
        error = "Sample frame size is unsupported";
        return false;
    }

    for (std::uint64_t left = 0U, right = sample.totalFrames - 1U; left < right; ++left, --right) {
        std::uint8_t* leftPtr = sample.audioData.data() + static_cast<std::size_t>(left) * fb;
        std::uint8_t* rightPtr = sample.audioData.data() + static_cast<std::size_t>(right) * fb;
        std::copy(leftPtr, leftPtr + fb, temporary.begin());
        std::copy(rightPtr, rightPtr + fb, leftPtr);
        std::copy(temporary.begin(), temporary.begin() + static_cast<std::ptrdiff_t>(fb), rightPtr);
    }

    if (sample.loop.enabled) {
        const std::uint64_t oldStart = sample.loop.startFrame;
        const std::uint64_t oldEnd = sample.loop.endFrame;
        sample.loop.startFrame = sample.totalFrames - oldEnd;
        sample.loop.endFrame = sample.totalFrames - oldStart;
    }
    return true;
}

bool SampleEditor::applyGainDb(ImportedSample& sample,
                               float gainDb,
                               std::string& error) {
    error.clear();
    if (!editable(sample, error)) return false;
    if (!std::isfinite(gainDb) || gainDb < -120.0F || gainDb > 60.0F) {
        error = "Gain must be finite and between -120 dB and +60 dB";
        return false;
    }

    const float gain = static_cast<float>(std::pow(10.0, static_cast<double>(gainDb) / 20.0));
    const std::size_t bps = bytesPerSample(sample.encoding);
    for (std::size_t offset = 0U; offset < sample.audioData.size(); offset += bps) {
        std::uint8_t* scalar = sample.audioData.data() + offset;
        writeScalar(scalar, sample.encoding, readScalar(scalar, sample.encoding) * gain);
    }
    return true;
}

bool SampleEditor::normalize(ImportedSample& sample,
                             float targetPeakDb,
                             std::string& error) {
    error.clear();
    if (!editable(sample, error)) return false;
    if (!std::isfinite(targetPeakDb) || targetPeakDb < -120.0F || targetPeakDb > 0.0F) {
        error = "Normalize target must be finite and between -120 dBFS and 0 dBFS";
        return false;
    }

    const float peak = peakLinear(sample);
    if (!(peak > 0.0F)) {
        error = "Cannot normalize a silent sample";
        return false;
    }
    const float target = static_cast<float>(std::pow(10.0, static_cast<double>(targetPeakDb) / 20.0));
    const float gain = target / peak;
    const std::size_t bps = bytesPerSample(sample.encoding);
    for (std::size_t offset = 0U; offset < sample.audioData.size(); offset += bps) {
        std::uint8_t* scalar = sample.audioData.data() + offset;
        writeScalar(scalar, sample.encoding, readScalar(scalar, sample.encoding) * gain);
    }
    return true;
}

bool SampleEditor::fadeIn(ImportedSample& sample,
                          std::uint64_t fadeFrames,
                          std::string& error) {
    error.clear();
    if (!editable(sample, error)) return false;
    if (fadeFrames == 0U || fadeFrames > sample.totalFrames) {
        error = "Fade-in length must be between 1 and total frames";
        return false;
    }
    multiplyFrames(sample, 0U, fadeFrames, fadeInGain);
    return true;
}

bool SampleEditor::fadeOut(ImportedSample& sample,
                           std::uint64_t fadeFrames,
                           std::string& error) {
    error.clear();
    if (!editable(sample, error)) return false;
    if (fadeFrames == 0U || fadeFrames > sample.totalFrames) {
        error = "Fade-out length must be between 1 and total frames";
        return false;
    }
    multiplyFrames(sample, sample.totalFrames - fadeFrames, fadeFrames, fadeOutGain);
    return true;
}

bool SampleEditor::setRootKey(ImportedSample& sample,
                              std::uint8_t rootKey,
                              std::string& error) noexcept {
    error.clear();
    if (rootKey > 127U) {
        error = "Root key must be 0..127";
        return false;
    }
    sample.rootKey = rootKey;
    return true;
}

bool SampleEditor::setFineTuneCents(ImportedSample& sample,
                                    float cents,
                                    std::string& error) noexcept {
    error.clear();
    if (!std::isfinite(cents) || cents < -100.0F || cents > 100.0F) {
        error = "Fine tune must be finite and between -100 and +100 cents";
        return false;
    }
    sample.fineTuneCents = cents;
    return true;
}

float SampleEditor::peakLinear(const ImportedSample& sample) noexcept {
    if (!sample.valid()) return 0.0F;
    const std::size_t bps = bytesPerSample(sample.encoding);
    if (bps == 0U) return 0.0F;
    float peak = 0.0F;
    for (std::size_t offset = 0U; offset < sample.audioData.size(); offset += bps) {
        peak = std::max(peak, std::fabs(readScalar(sample.audioData.data() + offset, sample.encoding)));
    }
    return peak;
}

std::uint64_t SampleEditor::nearestZeroCrossing(const ImportedSample& sample,
                                                std::uint64_t frame,
                                                std::uint64_t searchRadiusFrames) noexcept {
    if (!sample.valid() || sample.totalFrames < 2U) return 0U;
    const std::uint64_t target = std::min(frame, sample.totalFrames - 1U);
    const std::uint64_t first = target > searchRadiusFrames ? target - searchRadiusFrames : 1U;
    const std::uint64_t last = std::min(sample.totalFrames - 1U, target + searchRadiusFrames);

    std::uint64_t best = target;
    std::uint64_t bestDistance = std::numeric_limits<std::uint64_t>::max();
    float bestMagnitude = std::numeric_limits<float>::max();

    for (std::uint64_t current = std::max<std::uint64_t>(1U, first); current <= last; ++current) {
        const float previous = frameValue(sample, current - 1U);
        const float value = frameValue(sample, current);
        const bool crossing = (previous <= 0.0F && value >= 0.0F) || (previous >= 0.0F && value <= 0.0F);
        if (!crossing) continue;
        const std::uint64_t distance = current > target ? current - target : target - current;
        const float magnitude = std::fabs(previous) + std::fabs(value);
        if (distance < bestDistance || (distance == bestDistance && magnitude < bestMagnitude)) {
            best = current;
            bestDistance = distance;
            bestMagnitude = magnitude;
        }
    }
    return best;
}

bool SampleEditor::buildWaveformWithCurve(const ImportedSample& sample,
                                          const std::vector<float>& curve,
                                          std::uint64_t startFrame,
                                          std::uint64_t endFrame,
                                          std::size_t pointCount,
                                          std::vector<WaveformPoint>& points,
                                          std::uint64_t& outFrames,
                                          std::string& error) {
    points.clear();
    outFrames = 0U;
    endFrame = std::min(endFrame, sample.totalFrames);
    bool flat = curve.size() < 2U;
    for (float v : curve) if (std::fabs(v) > 0.001F) { flat = false; break; }
    if (flat) {
        outFrames = endFrame > startFrame ? endFrame - startFrame : 0U;
        return buildWaveformRange(sample, startFrame, endFrame, pointCount, points, error);
    }
    error.clear();
    if (!editable(sample, error)) return false;
    if (pointCount == 0U) { error = "Waveform point count must be greater than zero"; return false; }
    if (startFrame >= endFrame) { error = "Waveform range is empty"; return false; }

    // how long one frame of the sample becomes, at every point of the curve (no pow per frame: the curve has
    // few points and the value between them is taken as a straight line, which is enough for a picture)
    const std::size_t n = curve.size();
    std::vector<double> stretch(n, 1.0);
    for (std::size_t i = 0U; i < n; ++i) {
        const double semitones = std::min(static_cast<double>(kPitchCurveLimitSemitones),
                                          std::max(-static_cast<double>(kPitchCurveLimitSemitones), static_cast<double>(curve[i])));
        stretch[i] = std::pow(2.0, -semitones / 12.0);   // higher note -> read faster -> shorter
    }
    const double total = static_cast<double>(sample.totalFrames);
    auto stretchAt = [&](double frame) -> double {
        const double x = std::min(1.0, std::max(0.0, frame / total)) * static_cast<double>(n - 1U);
        const std::size_t i = static_cast<std::size_t>(x);
        if (i + 1U >= n) return stretch.back();
        const double f = x - static_cast<double>(i);
        return stretch[i] * (1.0 - f) + stretch[i + 1U] * f;
    };

    // length of the shown part after the curve
    double length = 0.0;
    const std::uint64_t span = endFrame - startFrame;
    const std::uint64_t stepCount = std::min<std::uint64_t>(span, 4096U);
    const double chunk = static_cast<double>(span) / static_cast<double>(stepCount);
    std::vector<double> edge(static_cast<std::size_t>(stepCount) + 1U, 0.0);
    for (std::uint64_t i = 0U; i < stepCount; ++i) {
        const double a = static_cast<double>(startFrame) + static_cast<double>(i) * chunk;
        const double b = a + chunk;
        length += (stretchAt(a) + stretchAt(b)) / 2.0 * chunk;
        edge[static_cast<std::size_t>(i) + 1U] = length;
    }
    if (length <= 0.0) { error = "The pitch curve leaves nothing of the sample"; return false; }
    outFrames = static_cast<std::uint64_t>(std::llround(length));

    const std::size_t count = static_cast<std::size_t>(std::min<std::uint64_t>(static_cast<std::uint64_t>(length), static_cast<std::uint64_t>(pointCount)));
    if (count == 0U) { error = "The pitch curve leaves nothing of the sample"; return false; }
    points.assign(count, WaveformPoint{1.0F, -1.0F});

    const std::size_t bps = bytesPerSample(sample.encoding);
    const std::size_t fb = frameBytes(sample);
    std::size_t chunkIndex = 0U;
    for (std::uint64_t frame = startFrame; frame < endFrame; ++frame) {
        const double inChunk = (static_cast<double>(frame - startFrame)) / chunk;
        chunkIndex = std::min(static_cast<std::size_t>(inChunk), static_cast<std::size_t>(stepCount) - 1U);
        const double within = inChunk - static_cast<double>(chunkIndex);
        const double place = edge[chunkIndex] + (edge[chunkIndex + 1U] - edge[chunkIndex]) * within;
        std::size_t column = static_cast<std::size_t>(place / length * static_cast<double>(count));
        if (column >= count) column = count - 1U;
        const std::size_t frameOffset = static_cast<std::size_t>(frame) * fb;
        for (std::uint16_t channel = 0U; channel < sample.channels; ++channel) {
            const float value = readScalar(sample.audioData.data() + frameOffset + static_cast<std::size_t>(channel) * bps, sample.encoding);
            points[column].minimum = std::min(points[column].minimum, value);
            points[column].maximum = std::max(points[column].maximum, value);
        }
    }
    // a column that no frame landed in (the sample is read faster there) takes the value of the one before it
    for (std::size_t i = 0U; i < count; ++i) {
        if (points[i].minimum <= points[i].maximum) continue;
        points[i] = i > 0U ? points[i - 1U] : WaveformPoint{0.0F, 0.0F};
    }
    return true;
}

bool SampleEditor::buildWaveform(const ImportedSample& sample,
                                 std::size_t pointCount,
                                 std::vector<WaveformPoint>& points,
                                 std::string& error) {
    return buildWaveformRange(sample, 0U, sample.totalFrames, pointCount, points, error);
}

bool SampleEditor::buildWaveformRange(const ImportedSample& sample,
                                      std::uint64_t startFrame,
                                      std::uint64_t endFrame,
                                      std::size_t pointCount,
                                      std::vector<WaveformPoint>& points,
                                      std::string& error) {
    error.clear();
    points.clear();
    if (!editable(sample, error)) return false;
    if (pointCount == 0U) {
        error = "Waveform point count must be greater than zero";
        return false;
    }
    endFrame = std::min(endFrame, sample.totalFrames);
    if (startFrame >= endFrame) {
        error = "Waveform range is empty";
        return false;
    }
    const std::uint64_t span = endFrame - startFrame;

    const std::size_t count = static_cast<std::size_t>(std::min<std::uint64_t>(span, static_cast<std::uint64_t>(pointCount)));
    points.resize(count);
    const std::size_t bps = bytesPerSample(sample.encoding);
    const std::size_t fb = frameBytes(sample);
    for (std::size_t point = 0U; point < count; ++point) {
        const std::uint64_t begin = startFrame + static_cast<std::uint64_t>((static_cast<long double>(point) * span) / count);
        std::uint64_t end = startFrame + static_cast<std::uint64_t>((static_cast<long double>(point + 1U) * span) / count);
        if (end <= begin) end = begin + 1U;
        end = std::min(end, endFrame);

        float minimum = 1.0F;
        float maximum = -1.0F;
        for (std::uint64_t frame = begin; frame < end; ++frame) {
            const std::size_t frameOffset = static_cast<std::size_t>(frame) * fb;
            for (std::uint16_t channel = 0U; channel < sample.channels; ++channel) {
                const float value = readScalar(sample.audioData.data() + frameOffset + static_cast<std::size_t>(channel) * bps,
                                               sample.encoding);
                minimum = std::min(minimum, value);
                maximum = std::max(maximum, value);
            }
        }
        points[point] = {minimum, maximum};
    }
    return true;
}

} // namespace silveton::manager
