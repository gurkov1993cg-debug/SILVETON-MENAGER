// SILVETON_KONTAKT_V1 - Kontakt .nki / .nkx / .ncw import.
#include "silveton/manager/KontaktImporter.h"
#include "silveton/manager/AudioFileLoader.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <map>
#include <memory>
#include <string>
#include <sys/stat.h>
#include <utility>
#include <vector>

namespace silveton::manager {
namespace {

// ---------------------------------------------------------------- small helpers

std::uint16_t rd16(const std::uint8_t* p) noexcept { return static_cast<std::uint16_t>(p[0] | (static_cast<std::uint16_t>(p[1]) << 8U)); }
std::uint32_t rd32(const std::uint8_t* p) noexcept {
    return static_cast<std::uint32_t>(p[0]) | (static_cast<std::uint32_t>(p[1]) << 8U) |
           (static_cast<std::uint32_t>(p[2]) << 16U) | (static_cast<std::uint32_t>(p[3]) << 24U);
}
std::uint64_t rd64(const std::uint8_t* p) noexcept { return static_cast<std::uint64_t>(rd32(p)) | (static_cast<std::uint64_t>(rd32(p + 4)) << 32U); }
float rdf32(const std::uint8_t* p) noexcept { float f = 0.0F; const std::uint32_t u = rd32(p); std::memcpy(&f, &u, sizeof f); return f; }

bool readFile(const std::string& path, std::vector<std::uint8_t>& out, std::string& error) {
    std::ifstream f(path, std::ios::binary | std::ios::ate);
    if (!f) { error = "Cannot open file: " + path; return false; }
    const std::streamsize size = f.tellg();
    if (size <= 0) { error = "File is empty: " + path; return false; }
    f.seekg(0, std::ios::beg);
    out.resize(static_cast<std::size_t>(size));
    if (!f.read(reinterpret_cast<char*>(out.data()), size)) { error = "Failed to read file: " + path; return false; }
    return true;
}

bool fileExists(const std::string& path) noexcept {
    struct stat st {};
    return ::stat(path.c_str(), &st) == 0 && S_ISREG(st.st_mode);
}

std::string directoryOf(const std::string& path) {
    const std::size_t slash = path.find_last_of('/');
    if (slash == std::string::npos) return ".";
    if (slash == 0U) return "/";
    return path.substr(0U, slash);
}

std::string fileNameOf(const std::string& path) {
    const std::size_t slash = path.find_last_of('/');
    return slash == std::string::npos ? path : path.substr(slash + 1U);
}

std::string stemOf(const std::string& name) {
    const std::size_t dot = name.find_last_of('.');
    return dot == std::string::npos || dot == 0U ? name : name.substr(0U, dot);
}

std::string lowerExt(const std::string& name) {
    const std::size_t dot = name.find_last_of('.');
    if (dot == std::string::npos) return {};
    std::string e = name.substr(dot);
    for (char& c : e) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return e;
}

std::string joinPath(const std::string& a, const std::string& b) {
    if (a.empty()) return b;
    if (b.empty()) return a;
    if (a.back() == '/') return a + b;
    return a + "/" + b;
}

std::string utf16ToUtf8(const std::uint8_t* p, std::size_t chars) {
    std::string out;
    for (std::size_t i = 0U; i < chars; ++i) {
        std::uint32_t c = rd16(p + i * 2U);
        if (c >= 0xD800U && c <= 0xDBFFU && i + 1U < chars) {
            const std::uint32_t lo = rd16(p + (i + 1U) * 2U);
            if (lo >= 0xDC00U && lo <= 0xDFFFU) { c = 0x10000U + ((c - 0xD800U) << 10U) + (lo - 0xDC00U); ++i; }
        }
        if (c < 0x80U) out.push_back(static_cast<char>(c));
        else if (c < 0x800U) { out.push_back(static_cast<char>(0xC0U | (c >> 6U))); out.push_back(static_cast<char>(0x80U | (c & 0x3FU))); }
        else if (c < 0x10000U) {
            out.push_back(static_cast<char>(0xE0U | (c >> 12U))); out.push_back(static_cast<char>(0x80U | ((c >> 6U) & 0x3FU)));
            out.push_back(static_cast<char>(0x80U | (c & 0x3FU)));
        } else {
            out.push_back(static_cast<char>(0xF0U | (c >> 18U))); out.push_back(static_cast<char>(0x80U | ((c >> 12U) & 0x3FU)));
            out.push_back(static_cast<char>(0x80U | ((c >> 6U) & 0x3FU))); out.push_back(static_cast<char>(0x80U | (c & 0x3FU)));
        }
    }
    return out;
}

std::string prettyName(std::string s) {
    for (char& c : s) if (c == '_') c = ' ';
    while (!s.empty() && s.back() == ' ') s.pop_back();
    while (!s.empty() && s.front() == ' ') s.erase(s.begin());
    return s;
}

float gainToDb(float gain) noexcept {
    return gain > 1.0e-6F ? 20.0F * std::log10(gain) : -120.0F;
}

// ---------------------------------------------------------------- byte cursor

struct Cursor {
    const std::uint8_t* p{nullptr};
    std::size_t n{0U};
    std::size_t pos{0U};
    [[nodiscard]] bool has(std::size_t k) const noexcept { return pos + k <= n; }
    bool u8(std::uint8_t& v) noexcept { if (!has(1U)) return false; v = p[pos]; ++pos; return true; }
    bool u16(std::uint16_t& v) noexcept { if (!has(2U)) return false; v = rd16(p + pos); pos += 2U; return true; }
    bool u32(std::uint32_t& v) noexcept { if (!has(4U)) return false; v = rd32(p + pos); pos += 4U; return true; }
    bool i32(std::int32_t& v) noexcept { std::uint32_t u = 0U; if (!u32(u)) return false; v = static_cast<std::int32_t>(u); return true; }
    bool i16(std::int16_t& v) noexcept { std::uint16_t u = 0U; if (!u16(u)) return false; v = static_cast<std::int16_t>(u); return true; }
    bool f32(float& v) noexcept { if (!has(4U)) return false; v = rdf32(p + pos); pos += 4U; return true; }
    bool skip(std::size_t k) noexcept { if (!has(k)) return false; pos += k; return true; }
    // u32 character count + UTF-16LE text
    bool wstr(std::string& s) {
        std::uint32_t chars = 0U;
        if (!u32(chars) || chars > 4096U || !has(static_cast<std::size_t>(chars) * 2U)) return false;
        s = utf16ToUtf8(p + pos, chars);
        pos += static_cast<std::size_t>(chars) * 2U;
        return true;
    }
};

// Kontakt chunk: u16 id, u32 length, data
struct Chunk {
    std::uint16_t id{0U};
    const std::uint8_t* data{nullptr};
    std::size_t size{0U};
};

std::vector<Chunk> chunkList(const std::uint8_t* p, std::size_t n) {
    std::vector<Chunk> out;
    std::size_t pos = 0U;
    while (pos + 6U <= n) {
        Chunk c{};
        c.id = rd16(p + pos);
        const std::uint32_t len = rd32(p + pos + 2U);
        if (static_cast<std::size_t>(len) > n - pos - 6U) break;
        c.data = p + pos + 6U;
        c.size = len;
        out.push_back(c);
        pos += 6U + len;
    }
    return out;
}

// Kontakt "structured object": u8 1, u16 version, u32 publicLen, public, u32 privateLen, private, u32 childLen, children
struct Structured {
    std::uint16_t version{0U};
    const std::uint8_t* pub{nullptr}; std::size_t pubSize{0U};
    const std::uint8_t* priv{nullptr}; std::size_t privSize{0U};
    const std::uint8_t* kids{nullptr}; std::size_t kidsSize{0U};
    std::size_t total{0U};
};

bool parseStructured(const std::uint8_t* p, std::size_t n, Structured& s) {
    if (n < 7U || p[0] != 1U) return false;
    s.version = rd16(p + 1);
    std::size_t pos = 3U;
    const std::uint32_t pubLen = rd32(p + pos); pos += 4U;
    if (static_cast<std::size_t>(pubLen) > n - pos) return false;
    s.pub = p + pos; s.pubSize = pubLen; pos += pubLen;
    if (pos + 4U > n) return false;
    const std::uint32_t privLen = rd32(p + pos); pos += 4U;
    if (static_cast<std::size_t>(privLen) > n - pos) return false;
    s.priv = p + pos; s.privSize = privLen; pos += privLen;
    if (pos + 4U > n) return false;
    const std::uint32_t kidsLen = rd32(p + pos); pos += 4U;
    if (static_cast<std::size_t>(kidsLen) > n - pos) return false;
    s.kids = p + pos; s.kidsSize = kidsLen; pos += kidsLen;
    s.total = pos;
    return true;
}

std::size_t findBytes(const std::uint8_t* p, std::size_t n, const char* needle, std::size_t from = 0U) {
    const std::size_t m = std::strlen(needle);
    if (m == 0U || n < m) return std::string::npos;
    for (std::size_t i = from; i + m <= n; ++i) {
        if (std::memcmp(p + i, needle, m) == 0) return i;
    }
    return std::string::npos;
}

// ---------------------------------------------------------------- NI container -> preset chunk data

// Finds the Kontakt preset chunk list inside a (decompressed) NI container item.
bool findPresetChunks(const std::vector<std::uint8_t>& item, const std::uint8_t*& chunks, std::size_t& size) {
    // DSIN frame with id 0x6d (preset chunk item), then its base item (id 1), then 16 bytes of header
    std::size_t pos = 0U;
    while ((pos = findBytes(item.data(), item.size(), "DSIN", pos)) != std::string::npos) {
        if (pos + 8U <= item.size() && rd32(item.data() + pos + 4U) == 0x6DU) {
            std::size_t base = findBytes(item.data(), item.size(), "DSIN", pos + 4U);
            while (base != std::string::npos && base + 8U <= item.size() && rd32(item.data() + base + 4U) != 1U)
                base = findBytes(item.data(), item.size(), "DSIN", base + 4U);
            if (base == std::string::npos || base + 36U > item.size()) return false;
            const std::size_t hdr = base + 20U;
            const std::uint64_t len = rd64(item.data() + hdr + 8U);
            const std::size_t start = hdr + 16U;
            if (start >= item.size()) return false;
            chunks = item.data() + start;
            size = std::min(static_cast<std::size_t>(len), item.size() - start);
            return true;
        }
        pos += 4U;
    }
    return false;
}

// Locates the compressed subtree payload (DSIN id 0x73) and decompresses it.
bool decompressNki(const std::vector<std::uint8_t>& file, std::vector<std::uint8_t>& item, std::string& error) {
    std::size_t pos = 0U;
    while ((pos = findBytes(file.data(), file.size(), "DSIN", pos)) != std::string::npos) {
        if (pos + 8U <= file.size() && rd32(file.data() + pos + 4U) == 0x73U) {
            // after the frame header: base item frame, then u8 compressed, u32 decompressed size, u32 stored size, data
            for (std::size_t k = pos + 8U; k + 10U < file.size() && k < pos + 128U; ++k) {
                if (file[k] != 1U) continue;
                const std::uint32_t expected = rd32(file.data() + k + 1U);
                const std::uint8_t first = file[k + 9U];
                if (expected < 1024U || expected > 1024U * 1024U * 1024U) continue;
                if ((first & 0xE0U) > 0x20U) continue;   // FastLZ level 1 or 2 marker
                std::vector<std::uint8_t> out;
                if (KontaktImporter::fastLzDecompress(file.data() + k + 9U, file.size() - k - 9U, expected, out) && out.size() == expected) {
                    item = std::move(out);
                    return true;
                }
            }
            error = "Kontakt file: cannot decompress the instrument data (is the file encrypted?)";
            return false;
        }
        pos += 4U;
    }
    error = "Kontakt file: no instrument data found (only Kontakt 5 and newer .nki files are supported)";
    return false;
}

// ---------------------------------------------------------------- Kontakt objects

bool parseGroup(const Structured& s, KontaktGroup& g) {
    Cursor c{s.priv, s.privSize, 0U};
    if (!c.wstr(g.name)) return false;
    float vol = 1.0F, pan = 0.0F, tune = 1.0F;
    if (c.f32(vol) && c.f32(pan) && c.f32(tune)) {
        g.volumeGain = std::isfinite(vol) ? std::max(0.0F, vol) : 1.0F;
        g.pan = std::isfinite(pan) ? std::clamp(pan, -1.0F, 1.0F) : 0.0F;
        g.tuneCents = std::isfinite(tune) && tune > 0.0F ? 1200.0F * std::log2(tune) : 0.0F;
    }
    // modulators: envelope "ENV_AHDSR" and velocity -> "volume"
    for (const Chunk& k : chunkList(s.kids, s.kidsSize)) {
        if (k.id == 0x3BU) {
            const std::size_t env = findBytes(k.data, k.size, "ENV_AHDSR_VOLUME");
            if (env == std::string::npos) continue;
            // the envelope numbers live in the nested chunk 0x3f that follows: u16 id 0x3f, u32 len, data
            for (std::size_t i = env; i + 6U < k.size; ++i) {
                if (k.data[i] == 0x3FU && k.data[i + 1U] == 0U && rd32(k.data + i + 2U) >= 28U && rd32(k.data + i + 2U) < 512U) {
                    const std::uint8_t* d = k.data + i + 6U;
                    const std::size_t dn = std::min<std::size_t>(rd32(k.data + i + 2U), k.size - i - 6U);
                    if (dn < 28U) break;
                    g.hasEnvelope = true;
                    // u8, u16 version, f32 curve, then attack / hold / decay / release (ms) and sustain (0..1)
                    g.attackMs = rdf32(d + 7U); g.holdMs = rdf32(d + 11U); g.decayMs = rdf32(d + 15U);
                    g.releaseMs = rdf32(d + 19U); g.sustain = rdf32(d + 23U);
                    for (float* v : {&g.attackMs, &g.holdMs, &g.decayMs, &g.releaseMs}) if (!std::isfinite(*v) || *v < 0.0F) *v = 0.0F;
                    if (!std::isfinite(g.sustain)) g.sustain = 1.0F;
                    g.sustain = std::clamp(g.sustain, 0.0F, 1.0F);
                    break;
                }
            }
        } else if (k.id == 0x3CU) {
            const std::size_t vel = findBytes(k.data, k.size, "VEL_VOLUME");
            if (vel == std::string::npos) continue;
            g.hasVelocityToVolume = true;
            // intensity: f32 right after the target name "volume" (u32 6 + "volume")
            std::size_t t = findBytes(k.data, k.size, "volume");
            while (t != std::string::npos && t < vel) {
                if (t + 10U <= k.size) {
                    const float in = rdf32(k.data + t + 6U);
                    if (std::isfinite(in) && in >= 0.0F && in <= 1.0F) g.velocityIntensity = in;
                }
                t = findBytes(k.data, k.size, "volume", t + 6U);
            }
            // curve table before "<none>": ... u8 count, then count x (f32 x, f32 y, f32 z)
            const std::size_t none = findBytes(k.data, k.size, "<none>");
            if (none != std::string::npos && none + 10U < vel) {
                const std::size_t tab = none + 6U;
                const std::uint8_t count = k.data[tab + 3U];
                if (count >= 2U && count <= 64U && tab + 4U + static_cast<std::size_t>(count) * 12U <= vel) {
                    std::vector<std::pair<float, float>> pts;
                    for (std::size_t i = 0U; i < count; ++i) {
                        const float x = rdf32(k.data + tab + 4U + i * 12U), y = rdf32(k.data + tab + 8U + i * 12U);
                        if (!std::isfinite(x) || !std::isfinite(y)) { pts.clear(); break; }
                        pts.emplace_back(std::clamp(x, 0.0F, 1.0F), std::clamp(y, 0.0F, 1.0F));
                    }
                    std::sort(pts.begin(), pts.end());
                    g.velocityCurve = std::move(pts);
                }
            }
        }
    }
    return true;
}

bool parseZone(const Structured& s, std::uint32_t groupIndex, KontaktZone& z) {
    if (s.privSize < 63U) return false;
    Cursor c{s.priv, s.privSize, 0U};
    std::int32_t sampleStart = 0, sampleEnd = 0, modRange = 0;
    std::int16_t loVel = 1, hiVel = 127, loKey = 0, hiKey = 127, fLoV = 0, fHiV = 0, fLoK = 0, fHiK = 0, root = 60;
    float vol = 1.0F, pan = 0.0F, tune = 1.0F;
    std::int32_t fileId = 0, dataType = 0, rate = 0, frames = 0;
    std::uint8_t channels = 0U;
    if (!(c.i32(sampleStart) && c.i32(sampleEnd) && c.i32(modRange) && c.i16(loVel) && c.i16(hiVel) && c.i16(loKey) && c.i16(hiKey) &&
          c.i16(fLoV) && c.i16(fHiV) && c.i16(fLoK) && c.i16(fHiK) && c.i16(root) && c.f32(vol) && c.f32(pan) && c.f32(tune) &&
          c.i32(fileId) && c.i32(dataType) && c.i32(rate) && c.u8(channels) && c.i32(frames))) return false;
    (void)sampleStart; (void)sampleEnd; (void)modRange; (void)fLoV; (void)fHiV; (void)fLoK; (void)fHiK; (void)dataType;
    if (loKey < 0 || hiKey > 127 || loKey > hiKey || root < 0 || root > 127 || fileId < 0) return false;
    z.groupIndex = groupIndex;
    z.keyLow = static_cast<std::uint8_t>(loKey);
    z.keyHigh = static_cast<std::uint8_t>(hiKey);
    z.velocityLow = static_cast<std::uint8_t>(std::clamp<int>(loVel, 1, 127));
    z.velocityHigh = static_cast<std::uint8_t>(std::clamp<int>(hiVel, z.velocityLow, 127));
    z.rootKey = static_cast<std::uint8_t>(root);
    z.volumeGain = std::isfinite(vol) ? std::max(0.0F, vol) : 1.0F;
    z.pan = std::isfinite(pan) ? std::clamp(pan, -1.0F, 1.0F) : 0.0F;
    z.tuneCents = std::isfinite(tune) && tune > 0.0F ? 1200.0F * std::log2(tune) : 0.0F;
    z.fileIndex = static_cast<std::uint32_t>(fileId);
    z.numFrames = frames > 0 ? static_cast<std::uint32_t>(frames) : 0U;
    z.channels = channels;
    z.sampleRateTag = rate > 0 ? static_cast<std::uint32_t>(rate) : 0U;
    // loops: child chunk 0x39: u8 0, u16, u16, u32 count, count x { i32 start, i32 length, i32 count, f32 tune, i32 xfade }
    for (const Chunk& k : chunkList(s.kids, s.kidsSize)) {
        if (k.id != 0x39U || k.size < 29U) continue;
        const std::uint32_t count = rd32(k.data + 5U);
        if (count == 0U || 9U + 20U > k.size) continue;
        const std::int32_t start = static_cast<std::int32_t>(rd32(k.data + 9U));
        const std::int32_t length = static_cast<std::int32_t>(rd32(k.data + 13U));
        const std::int32_t loops = static_cast<std::int32_t>(rd32(k.data + 17U));
        const std::int32_t xfade = static_cast<std::int32_t>(rd32(k.data + 25U));
        if (start < 0 || length <= 0) continue;
        z.hasLoop = true;
        z.loop.start = static_cast<std::uint32_t>(start);
        z.loop.length = static_cast<std::uint32_t>(length);
        z.loop.count = loops > 0 ? static_cast<std::uint32_t>(loops) : 0U;
        z.loop.crossfade = xfade > 0 ? static_cast<std::uint32_t>(xfade) : 0U;
    }
    return true;
}

bool parseFileTable(const Chunk& fn, std::vector<KontaktFile>& files, std::string& error) {
    Cursor c{fn.data, fn.size, 0U};
    std::uint16_t version = 0U;
    if (!c.u16(version)) { error = "Kontakt file name table is damaged"; return false; }
    auto readList = [&](std::vector<KontaktFile>* out) -> bool {
        std::uint32_t count = 0U;
        if (!c.u32(count) || count > 2000000U) return false;
        for (std::uint32_t i = 0U; i < count; ++i) {
            std::uint32_t segs = 0U;
            if (!c.u32(segs) || segs > 64U) return false;
            KontaktFile f{};
            std::string path;
            for (std::uint32_t s = 0U; s < segs; ++s) {
                std::uint8_t type = 0U;
                if (!c.u8(type)) return false;
                if (type == 3U) continue;   // relative to the .nki folder
                std::string text;
                if (!c.wstr(text)) return false;
                if (type == 1U || type == 0U) { path = "/"; continue; }   // absolute root / drive
                if (type == 8U) { f.monolith = joinPath(path, text); path = joinPath(path, text); continue; }
                if (type == 4U) { f.name = text; path = joinPath(path, text); continue; }
                path = joinPath(path, text);   // 2 = folder, anything else: keep walking
            }
            f.relativePath = path;
            if (f.name.empty()) f.name = fileNameOf(path);
            if (out != nullptr) out->push_back(std::move(f));
        }
        return true;
    };
    if (version != 2U) { error = "Kontakt file name table version " + std::to_string(version) + " is not supported"; return false; }
    if (!readList(nullptr) || !readList(&files)) { error = "Kontakt file name table is damaged"; return false; }
    return true;
}

// ---------------------------------------------------------------- NKX monolith

struct Monolith {
    std::string path;
    std::ifstream in;
    std::map<std::string, std::pair<std::uint64_t, std::uint64_t>> index;   // name -> (offset, size)
    bool ok{false};
    std::string error;
};

constexpr std::uint32_t kNkxMagic = 0x5E70AC54U;
constexpr std::uint32_t kNkxFileMagic = 0x16CCF80AU;

bool openMonolith(const std::string& path, Monolith& m) {
    m.path = path;
    m.in.open(path, std::ios::binary);
    if (!m.in) { m.error = "Cannot open Kontakt monolith: " + path; return false; }
    std::vector<std::uint8_t> head(22U);
    if (!m.in.read(reinterpret_cast<char*>(head.data()), 22)) { m.error = "Kontakt monolith is too short: " + path; return false; }
    if (rd32(head.data()) != kNkxMagic) { m.error = "Not a Kontakt monolith (.nkx): " + path; return false; }
    // directory entries: u16 length, u32, u16 type, UTF-16LE name, u16 0
    std::vector<std::string> names;
    std::uint64_t pos = 22U;
    for (;;) {
        std::uint8_t e[8];
        m.in.seekg(static_cast<std::streamoff>(pos));
        if (!m.in.read(reinterpret_cast<char*>(e), 8)) { m.error = "Kontakt monolith directory is damaged: " + path; return false; }
        if (rd32(e) == kNkxFileMagic) break;
        const std::uint16_t len = rd16(e);
        if (len < 10U || len > 1024U) { m.error = "Kontakt monolith directory is damaged: " + path; return false; }
        std::vector<std::uint8_t> entry(len);
        m.in.seekg(static_cast<std::streamoff>(pos));
        if (!m.in.read(reinterpret_cast<char*>(entry.data()), len)) { m.error = "Kontakt monolith directory is damaged: " + path; return false; }
        names.push_back(utf16ToUtf8(entry.data() + 8U, static_cast<std::size_t>(len - 10U) / 2U));
        pos += len;
    }
    // file chain: 31-byte header (magic, ..., u64 size at +19) + data, in directory order
    for (const std::string& name : names) {
        std::uint8_t h[31];
        m.in.clear();
        m.in.seekg(static_cast<std::streamoff>(pos));
        if (!m.in.read(reinterpret_cast<char*>(h), 31)) break;   // shorter file: the rest is missing
        if (rd32(h) != kNkxFileMagic) {
            m.error = "Kontakt monolith file chain is damaged: " + path;
            return false;
        }
        const std::uint64_t size = rd64(h + 19U);
        m.index[name] = {pos + 31U, size};
        pos += 31U + size;
    }
    m.in.clear();
    m.ok = true;
    return true;
}

bool readMonolithFile(Monolith& m, const std::string& name, std::vector<std::uint8_t>& out, std::string& error) {
    const auto it = m.index.find(name);
    if (it == m.index.end()) { error = "Sample " + name + " is not inside " + fileNameOf(m.path); return false; }
    if (it->second.second > 512ULL * 1024ULL * 1024ULL) { error = "Sample " + name + " is too large"; return false; }
    out.resize(static_cast<std::size_t>(it->second.second));
    m.in.clear();
    m.in.seekg(static_cast<std::streamoff>(it->second.first));
    if (!m.in.read(reinterpret_cast<char*>(out.data()), static_cast<std::streamsize>(out.size()))) {
        error = "Cannot read sample " + name + " from " + fileNameOf(m.path);
        return false;
    }
    return true;
}

// ---------------------------------------------------------------- sample loading

struct LoadedSample {
    std::uint32_t sampleRate{0U};
    std::uint16_t channels{0U};
    std::uint8_t bits{16U};
    std::uint32_t frames{0U};
    std::vector<std::uint8_t> pcm;
};

struct SampleSource {
    const KontaktLibrary* library{nullptr};
    std::map<std::string, std::unique_ptr<Monolith>> monoliths;

    bool load(std::uint32_t fileIndex, LoadedSample& out, std::string& error) {
        if (fileIndex >= library->files.size()) { error = "Zone points to a missing sample entry"; return false; }
        const KontaktFile& f = library->files[fileIndex];
        std::vector<std::uint8_t> bytes;
        if (!f.monolith.empty()) {
            const std::string path = joinPath(library->directory, f.monolith);
            auto it = monoliths.find(path);
            if (it == monoliths.end()) {
                auto m = std::make_unique<Monolith>();
                if (!openMonolith(path, *m)) { error = m->error; monoliths[path] = std::move(m); return false; }
                it = monoliths.emplace(path, std::move(m)).first;
            }
            if (!it->second->ok) { error = it->second->error; return false; }
            if (!readMonolithFile(*it->second, f.name, bytes, error)) return false;
        } else {
            const std::string path = joinPath(library->directory, f.relativePath);
            const std::string ext = lowerExt(f.name);
            if (ext != ".ncw") {
                auto r = AudioFileLoader::load(path);
                if (!r.ok()) { error = f.name + ": " + r.error; return false; }
                out.sampleRate = r.sample.sampleRate; out.channels = r.sample.channels; out.bits = r.sample.bitsPerSample;
                out.frames = static_cast<std::uint32_t>(r.sample.totalFrames); out.pcm = std::move(r.sample.audioData);
                if (r.sample.encoding == AudioEncoding::Float32LE) { error = f.name + ": float samples are not supported here"; return false; }
                return true;
            }
            if (!readFile(path, bytes, error)) return false;
        }
        return KontaktImporter::decodeNcw(bytes.data(), bytes.size(), out.sampleRate, out.channels, out.bits, out.frames, out.pcm, error);
    }
};

// ---------------------------------------------------------------- velocity helpers

float curveValue(const std::vector<std::pair<float, float>>& curve, float x) noexcept {
    if (curve.size() < 2U) return x;
    if (x <= curve.front().first) return curve.front().second;
    for (std::size_t i = 1U; i < curve.size(); ++i) {
        if (x <= curve[i].first) {
            const float x0 = curve[i - 1U].first, x1 = curve[i].first;
            const float t = x1 > x0 ? (x - x0) / (x1 - x0) : 1.0F;
            return curve[i - 1U].second + t * (curve[i].second - curve[i - 1U].second);
        }
    }
    return curve.back().second;
}

// Kontakt: gain = 1 - intensity * (1 - curve(v/127)). The sampler plays v/127; the zone gain carries the difference.
float velocityCompensationDb(const KontaktGroup& g, int velocityCenter) noexcept {
    if (!g.hasVelocityToVolume) return 0.0F;
    const float x = static_cast<float>(std::clamp(velocityCenter, 1, 127)) / 127.0F;
    const float kontakt = 1.0F - std::clamp(g.velocityIntensity, 0.0F, 1.0F) * (1.0F - curveValue(g.velocityCurve, x));
    const float sampler = x;
    if (kontakt <= 1.0e-4F) return -12.0F;
    return std::clamp(gainToDb(kontakt / sampler), -12.0F, 12.0F);
}

// pitch of a PCM16 mono mix in frames per period (0 = unclear)
double periodFrames(const LoadedSample& s, double expectedPeriod) {
    if (s.frames < 4096U || s.channels == 0U) return 0.0;
    const std::size_t bytesPer = s.bits == 24U ? 3U : 2U;
    const std::size_t start = std::min<std::size_t>(s.frames / 8U, 20000U);
    const std::size_t len = std::min<std::size_t>(s.frames - start, 32768U);
    std::vector<float> x(len);
    for (std::size_t i = 0U; i < len; ++i) {
        float acc = 0.0F;
        for (std::size_t ch = 0U; ch < s.channels; ++ch) {
            const std::uint8_t* p = s.pcm.data() + ((start + i) * s.channels + ch) * bytesPer;
            std::int32_t v = 0;
            if (bytesPer == 2U) v = static_cast<std::int16_t>(rd16(p));
            else { v = static_cast<std::int32_t>(p[0] | (static_cast<std::uint32_t>(p[1]) << 8U) | (static_cast<std::uint32_t>(p[2]) << 16U)); if (v & 0x800000) v -= 0x1000000; }
            acc += static_cast<float>(v);
        }
        x[i] = acc;
    }
    const std::size_t minLag = static_cast<std::size_t>(std::max(8.0, expectedPeriod * 0.5));
    const std::size_t maxLag = static_cast<std::size_t>(std::min(static_cast<double>(len / 3U), expectedPeriod * 2.2));
    if (minLag >= maxLag) return 0.0;
    double e0 = 0.0;
    for (std::size_t i = 0U; i < len - maxLag; ++i) e0 += static_cast<double>(x[i]) * x[i];
    if (e0 <= 1.0) return 0.0;
    double best = -1.0; std::size_t bestLag = 0U;
    for (std::size_t lag = minLag; lag <= maxLag; ++lag) {
        double c = 0.0, e1 = 0.0;
        for (std::size_t i = 0U; i < len - maxLag; ++i) { c += static_cast<double>(x[i]) * x[i + lag]; e1 += static_cast<double>(x[i + lag]) * x[i + lag]; }
        const double r = c / std::sqrt(e0 * std::max(1.0, e1));
        if (r > best) { best = r; bestLag = lag; }
    }
    if (best < 0.5 || bestLag == 0U) return 0.0;
    return static_cast<double>(bestLag);
}

} // namespace

// ---------------------------------------------------------------- FastLZ

bool KontaktImporter::fastLzDecompress(const std::uint8_t* src, std::size_t size, std::size_t expected, std::vector<std::uint8_t>& out) {
    out.clear();
    if (src == nullptr || size == 0U) return false;
    out.reserve(expected);
    std::size_t ip = 0U;
    const int level = (src[0] >> 5U) + 1;
    std::uint32_t ctrl = src[ip++] & 31U;
    bool loop = true;
    while (loop) {
        std::size_t ref = out.size();
        std::size_t len = ctrl >> 5U;
        std::size_t ofs = static_cast<std::size_t>(ctrl & 31U) << 8U;
        if (ctrl >= 32U) {
            --len;
            ref -= ofs;
            if (len == 6U) {
                if (level == 2) {
                    std::uint8_t code = 0U;
                    do { if (ip >= size) return false; code = src[ip++]; len += code; } while (code == 255U);
                } else {
                    if (ip >= size) return false;
                    len += src[ip++];
                }
            }
            if (ip >= size) return false;
            const std::uint8_t code = src[ip++];
            ref -= code;
            if (level == 2 && code == 255U && ofs == (31U << 8U)) {
                if (ip + 1U >= size) return false;
                ofs = static_cast<std::size_t>(src[ip]) << 8U; ++ip;
                ofs += src[ip++];
                ref = out.size() - ofs - 8191U;
            }
            if (ip < size) ctrl = src[ip++]; else loop = false;
            if (ref == out.size()) {
                if (out.empty()) return false;
                const std::uint8_t b = out.back();
                for (std::size_t k = 0U; k < len + 3U; ++k) out.push_back(b);
            } else {
                if (ref == 0U || ref > out.size()) return false;
                --ref;
                for (std::size_t k = 0U; k < len + 3U; ++k) out.push_back(out[ref + k]);
            }
        } else {
            ++ctrl;
            if (ip + ctrl > size) return false;
            out.insert(out.end(), src + ip, src + ip + ctrl);
            ip += ctrl;
            if (ip < size) ctrl = src[ip++]; else loop = false;
        }
        if (out.size() >= expected) break;
    }
    return out.size() == expected;
}

// ---------------------------------------------------------------- NCW

bool KontaktImporter::decodeNcw(const std::uint8_t* data, std::size_t size, std::uint32_t& sampleRate, std::uint16_t& channels,
                                std::uint8_t& bitsPerSample, std::uint32_t& frames, std::vector<std::uint8_t>& pcm, std::string& error) {
    constexpr std::uint32_t kMagic = 0xD69EA801U;
    constexpr std::uint32_t kBlockMagic = 0x3E9A0C16U;
    constexpr std::size_t kBlockSamples = 512U;
    if (data == nullptr || size < 120U || rd32(data) != kMagic) { error = "Not an NCW sample"; return false; }
    channels = rd16(data + 8U);
    const std::uint16_t bits = rd16(data + 10U);
    sampleRate = rd32(data + 12U);
    frames = rd32(data + 16U);
    const std::uint32_t defOffset = rd32(data + 20U), blocksOffset = rd32(data + 24U), blocksSize = rd32(data + 28U);
    if (channels == 0U || channels > 2U || (bits != 16U && bits != 24U) || frames == 0U || defOffset >= blocksOffset ||
        blocksOffset > size || blocksSize > size - blocksOffset) {
        error = "NCW sample header is damaged";
        return false;
    }
    bitsPerSample = static_cast<std::uint8_t>(bits);
    const std::size_t defCount = (blocksOffset - defOffset) / 4U;
    std::vector<std::int32_t> ch[2];
    for (std::uint16_t c = 0U; c < channels; ++c) ch[c].reserve(frames + kBlockSamples);
    std::vector<std::int32_t> blockVals[2];
    for (std::size_t b = 0U; b < defCount; ++b) {
        const std::uint32_t rel = rd32(data + defOffset + b * 4U);
        if (rel >= blocksSize) break;
        std::size_t pos = blocksOffset + rel;
        std::uint16_t flags = 0U;
        for (std::uint16_t c = 0U; c < channels; ++c) {
            if (pos + 16U > size || rd32(data + pos) != kBlockMagic) { error = "NCW block is damaged"; return false; }
            const std::int32_t base = static_cast<std::int32_t>(rd32(data + pos + 4U));
            const std::int16_t nbits = static_cast<std::int16_t>(rd16(data + pos + 8U));
            flags = rd16(data + pos + 10U);
            pos += 16U;
            std::vector<std::int32_t>& v = blockVals[c];
            v.assign(kBlockSamples, base);
            const int width = nbits < 0 ? -nbits : nbits;
            if (width > 0) {
                if (width > 32) { error = "NCW block is damaged"; return false; }
                const std::size_t bytes = kBlockSamples * static_cast<std::size_t>(width) / 8U;
                if (pos + bytes > size) { error = "NCW block is damaged"; return false; }
                std::uint64_t acc = 0U; int nacc = 0; std::size_t ip = pos;
                const std::uint64_t mask = width == 32 ? 0xFFFFFFFFULL : ((1ULL << width) - 1ULL);
                const std::uint64_t sign = 1ULL << (width - 1);
                std::int32_t run = base, prevDelta = 0;
                for (std::size_t i = 0U; i < kBlockSamples; ++i) {
                    while (nacc < width) { acc |= static_cast<std::uint64_t>(data[ip++]) << nacc; nacc += 8; }
                    const std::uint64_t raw = acc & mask; acc >>= width; nacc -= width;
                    const std::int32_t val = static_cast<std::int32_t>((raw & sign) != 0U ? static_cast<std::int64_t>(raw) - static_cast<std::int64_t>(mask) - 1 : static_cast<std::int64_t>(raw));
                    if (nbits > 0) {   // deltas: sample 0 is the base value, sample i = sample i-1 + delta i-1
                        if (i > 0U) run += prevDelta;
                        v[i] = run;
                        prevDelta = val;
                    } else {
                        v[i] = val;
                    }
                }
                pos += bytes;
            }
        }
        if (channels == 2U && (flags & 1U) != 0U) {   // mid/side
            for (std::size_t i = 0U; i < kBlockSamples; ++i) {
                const std::int32_t m = blockVals[0][i], s = blockVals[1][i];
                blockVals[0][i] = m + s; blockVals[1][i] = m - s;
            }
        }
        for (std::uint16_t c = 0U; c < channels; ++c) ch[c].insert(ch[c].end(), blockVals[c].begin(), blockVals[c].end());
    }
    if (ch[0].size() < frames) { error = "NCW sample is shorter than its header says"; return false; }
    const std::size_t bytesPer = bits == 24U ? 3U : 2U;
    pcm.resize(static_cast<std::size_t>(frames) * channels * bytesPer);
    const std::int32_t lo = bits == 24U ? -8388608 : -32768, hi = bits == 24U ? 8388607 : 32767;
    for (std::uint32_t i = 0U; i < frames; ++i) {
        for (std::uint16_t c = 0U; c < channels; ++c) {
            const std::int32_t v = std::clamp(ch[c][i], lo, hi);
            std::uint8_t* p = pcm.data() + (static_cast<std::size_t>(i) * channels + c) * bytesPer;
            p[0] = static_cast<std::uint8_t>(v & 0xFF); p[1] = static_cast<std::uint8_t>((v >> 8) & 0xFF);
            if (bytesPer == 3U) p[2] = static_cast<std::uint8_t>((v >> 16) & 0xFF);
        }
    }
    return true;
}

// ---------------------------------------------------------------- .nki

KontaktLibrary KontaktImporter::open(const std::string& nkiPath) {
    KontaktLibrary lib;
    lib.nkiPath = nkiPath;
    lib.directory = directoryOf(nkiPath);
    std::vector<std::uint8_t> file;
    if (!readFile(nkiPath, file, lib.error)) return lib;
    if (file.size() < 64U || findBytes(file.data(), std::min<std::size_t>(file.size(), 64U), "hsin") == std::string::npos) {
        lib.error = "Not a Kontakt 5+ instrument file (.nki)";
        return lib;
    }
    std::vector<std::uint8_t> item;
    if (!decompressNki(file, item, lib.error)) return lib;
    const std::uint8_t* chunkData = nullptr; std::size_t chunkSize = 0U;
    if (!findPresetChunks(item, chunkData, chunkSize)) { lib.error = "Kontakt file: instrument chunks not found"; return lib; }
    const std::vector<Chunk> top = chunkList(chunkData, chunkSize);
    const Chunk* program = nullptr; const Chunk* fileTable = nullptr;
    for (const Chunk& c : top) {
        if (c.id == 0x28U && program == nullptr) program = &c;
        if (c.id == 0x4BU && fileTable == nullptr) fileTable = &c;
    }
    if (program == nullptr) { lib.error = "Kontakt file has no program (instrument) chunk"; return lib; }
    if (fileTable == nullptr) { lib.error = "Kontakt file has no sample file table"; return lib; }
    Structured prog{};
    if (!parseStructured(program->data, program->size, prog)) { lib.error = "Kontakt program chunk is damaged"; return lib; }
    { Cursor c{prog.priv, prog.privSize, 0U}; std::string name; if (c.wstr(name)) lib.programName = name; }
    if (!parseFileTable(*fileTable, lib.files, lib.error)) return lib;
    for (const Chunk& k : chunkList(prog.kids, prog.kidsSize)) {
        if (k.id == 0x33U) {   // groups
            if (k.size < 4U) continue;
            const std::uint32_t count = rd32(k.data);
            std::size_t pos = 4U;
            for (std::uint32_t i = 0U; i < count && pos < k.size; ++i) {
                Structured s{};
                if (!parseStructured(k.data + pos, k.size - pos, s)) { lib.error = "Kontakt group list is damaged"; return lib; }
                KontaktGroup g{};
                if (!parseGroup(s, g)) g.name = "Group " + std::to_string(i + 1U);
                lib.groups.push_back(std::move(g));
                pos += s.total;
            }
        } else if (k.id == 0x34U) {   // zones
            if (k.size < 4U) continue;
            const std::uint32_t count = rd32(k.data);
            std::size_t pos = 4U;
            for (std::uint32_t i = 0U; i < count && pos + 4U < k.size; ++i) {
                const std::uint32_t groupIndex = rd32(k.data + pos);
                pos += 4U;
                Structured s{};
                if (!parseStructured(k.data + pos, k.size - pos, s)) { lib.error = "Kontakt zone list is damaged"; return lib; }
                KontaktZone z{};
                if (parseZone(s, groupIndex, z)) lib.zones.push_back(z);
                else lib.warnings.push_back("Zone " + std::to_string(i + 1U) + " could not be read and was skipped");
                pos += s.total;
            }
        }
    }
    if (lib.groups.empty()) { lib.error = "Kontakt file has no groups"; return lib; }
    // The sample paths are relative to the library folder, which is the .nki folder for a plain instrument
    // but one or two folders up for a packaged library (Instruments/ next to Samples/). Look for the first file.
    if (!lib.files.empty()) {
        std::vector<std::string> probes;
        for (const KontaktFile& f : lib.files) {
            const std::string relative = f.monolith.empty() ? f.relativePath : f.monolith;
            if (std::find(probes.begin(), probes.end(), relative) == probes.end()) probes.push_back(relative);
            if (probes.size() >= 12U) break;
        }
        bool found = false;
        for (const std::string& relative : probes) {
            std::string dir = lib.directory;
            for (int up = 0; up < 3 && !found; ++up) {
                if (fileExists(joinPath(dir, relative))) { lib.directory = dir; found = true; break; }
                if (dir == "/" || dir == ".") break;
                dir = directoryOf(dir);
            }
            if (found) break;
        }
        const std::string relative = probes.front();
        if (!found) lib.warnings.push_back("The sample folder (" + relative + ") was not found next to the .nki or up to two folders above it.");
    }
    for (std::size_t i = 0U; i < lib.zones.size(); ++i) {
        const KontaktZone& z = lib.zones[i];
        if (z.groupIndex < lib.groups.size()) lib.groups[z.groupIndex].zoneIndices.push_back(static_cast<std::uint32_t>(i));
        else lib.warnings.push_back("A zone points to a missing group and was skipped");
    }
    return lib;
}

// ---------------------------------------------------------------- velocity layers

std::vector<std::size_t> KontaktImporter::chooseVelocityLayers(std::size_t layerCount, int maxLayers) {
    std::vector<std::size_t> out;
    if (layerCount == 0U) return out;
    const std::size_t keep = static_cast<std::size_t>(std::max(1, maxLayers));
    if (layerCount <= keep) { for (std::size_t i = 0U; i < layerCount; ++i) out.push_back(i); return out; }
    for (std::size_t k = 0U; k < keep; ++k) {
        const double t = static_cast<double>(k) * static_cast<double>(layerCount - 1U) / static_cast<double>(keep - 1U);
        const std::size_t idx = static_cast<std::size_t>(std::lround(t));
        if (out.empty() || out.back() != idx) out.push_back(idx);
    }
    if (out.back() != layerCount - 1U) out.push_back(layerCount - 1U);
    return out;
}

// ---------------------------------------------------------------- sample rate probe

std::uint32_t KontaktImporter::probeSampleRate(const KontaktLibrary& library, std::size_t groupIndex, std::uint32_t& tagged, std::string& note) {
    tagged = 0U;
    note.clear();
    if (groupIndex >= library.groups.size()) return 0U;
    const KontaktGroup& g = library.groups[groupIndex];
    SampleSource src{&library, {}};
    static constexpr std::uint32_t kRates[] = {22050U, 44100U, 48000U, 88200U, 96000U};
    std::map<std::uint32_t, int> votes;
    int tested = 0;
    // a few zones spread over the keyboard, middle register first (clearest pitch)
    std::vector<std::uint32_t> candidates;
    for (std::uint32_t zi : g.zoneIndices) {
        const KontaktZone& z = library.zones[zi];
        if (z.rootKey >= 40U && z.rootKey <= 84U && z.velocityHigh >= 80U) candidates.push_back(zi);
    }
    if (candidates.size() < 3U) candidates = g.zoneIndices;
    const std::size_t step = std::max<std::size_t>(1U, candidates.size() / 4U);
    for (std::size_t i = 0U; i < candidates.size() && tested < 4; i += step) {
        const KontaktZone& z = library.zones[candidates[i]];
        LoadedSample s; std::string error;
        if (!src.load(z.fileIndex, s, error)) continue;
        if (tagged == 0U) tagged = s.sampleRate;
        ++tested;
        const double rootHz = 440.0 * std::pow(2.0, (static_cast<double>(z.rootKey) - 69.0) / 12.0);
        for (std::uint32_t rate : kRates) {
            const double expected = static_cast<double>(rate) / rootHz;
            const double period = periodFrames(s, expected);
            if (period <= 0.0) continue;
            const double cents = 1200.0 * std::log2(expected / period);
            if (std::fabs(cents) <= 40.0) ++votes[rate];
        }
    }
    std::uint32_t best = 0U; int bestVotes = 0;
    for (const auto& kv : votes) if (kv.second > bestVotes) { best = kv.first; bestVotes = kv.second; }
    if (tested == 0 || bestVotes == 0) { note = "The pitch of the samples could not be checked."; return 0U; }
    if (votes.count(tagged) != 0U && votes[tagged] == bestVotes) best = tagged;
    if (best != tagged) note = "The files say " + std::to_string(tagged) + " Hz but the pitch fits " + std::to_string(best) + " Hz.";
    else note = "The pitch confirms " + std::to_string(tagged) + " Hz.";
    return best;
}

// ---------------------------------------------------------------- import one group = one SOUND

KontaktImportResult KontaktImporter::importGroup(const KontaktLibrary& library, std::size_t groupIndex,
                                                 const KontaktImportOptions& options, const KontaktProgress& progress) {
    KontaktImportResult r;
    if (!library.ok()) { r.error = library.error; return r; }
    if (groupIndex >= library.groups.size()) { r.error = "No such Kontakt group"; return r; }
    const KontaktGroup& g = library.groups[groupIndex];
    if (g.zoneIndices.empty()) { r.error = g.name + ": this group has no zones (no samples)"; return r; }
    const int maxLayers = std::clamp(options.maxVelocityLayers, 1, 16);

    // zones by key range, each key range sorted by velocity
    std::map<std::pair<std::uint8_t, std::uint8_t>, std::vector<std::uint32_t>> byKey;
    for (std::uint32_t zi : g.zoneIndices) {
        const KontaktZone& z = library.zones[zi];
        byKey[{z.keyLow, z.keyHigh}].push_back(zi);
    }
    struct Placed { std::uint32_t zone; std::uint8_t velLow; std::uint8_t velHigh; std::size_t slot; std::uint8_t keyLow; std::uint8_t keyHigh; };
    std::vector<Placed> placed;
    std::size_t usedSlots = 0U;
    // keyStep 2 / 3: of every 2 / 3 neighbouring key ranges only the middle one is kept and it is
    // stretched over the dropped ones (the sampler plays it a semitone up / down)
    const int keyStep = std::clamp(options.keyStep, 1, 3);
    struct KeyGroup { std::pair<std::uint8_t, std::uint8_t> keep; std::uint8_t keyLow; std::uint8_t keyHigh; };
    std::vector<KeyGroup> keyGroups;
    {
        std::vector<std::pair<std::uint8_t, std::uint8_t>> ranges;
        for (const auto& kv : byKey) ranges.push_back(kv.first);
        for (std::size_t i = 0U; i < ranges.size(); i += static_cast<std::size_t>(keyStep)) {
            const std::size_t last = std::min(ranges.size() - 1U, i + static_cast<std::size_t>(keyStep) - 1U);
            const std::size_t middle = i + (last - i) / 2U;
            keyGroups.push_back({ranges[middle], ranges[i].first, ranges[last].second});
        }
    }
    for (const KeyGroup& kg : keyGroups) {
        std::vector<std::uint32_t>& zs = byKey[kg.keep];
        std::sort(zs.begin(), zs.end(), [&](std::uint32_t a, std::uint32_t b) {
            const KontaktZone& za = library.zones[a]; const KontaktZone& zb = library.zones[b];
            return za.velocityLow != zb.velocityLow ? za.velocityLow < zb.velocityLow : za.velocityHigh < zb.velocityHigh;
        });
        const std::vector<std::size_t> keep = chooseVelocityLayers(zs.size(), maxLayers);
        // velocity ranges: dropped layers are split in the middle between their chosen neighbours;
        // the softest starts at 1, the strongest ends at 127
        std::vector<Placed> here;
        for (std::size_t k = 0U; k < keep.size(); ++k) {
            const KontaktZone& z = library.zones[zs[keep[k]]];
            Placed p{zs[keep[k]], z.velocityLow, z.velocityHigh, 0U, kg.keyLow, kg.keyHigh};
            here.push_back(p);
        }
        for (std::size_t k = 0U; k < here.size(); ++k) {
            int low = 1, high = 127;
            if (k > 0U) {
                const KontaktZone& prev = library.zones[here[k - 1U].zone];
                const KontaktZone& cur = library.zones[here[k].zone];
                const int mid = (static_cast<int>(prev.velocityHigh) + static_cast<int>(cur.velocityLow)) / 2;
                low = std::clamp(mid + 1, 2, 127);
                here[k - 1U].velHigh = static_cast<std::uint8_t>(std::clamp(mid, static_cast<int>(here[k - 1U].velLow), 126));
            }
            here[k].velLow = static_cast<std::uint8_t>(low);
            here[k].velHigh = static_cast<std::uint8_t>(high);
        }
        // slots count from the top: the strongest layer always sits in the highest slot
        const std::size_t n = here.size();
        for (std::size_t k = 0U; k < n; ++k) here[k].slot = static_cast<std::size_t>(maxLayers) - n + k;
        usedSlots = std::max(usedSlots, n);
        placed.insert(placed.end(), here.begin(), here.end());
    }
    const std::size_t firstSlot = static_cast<std::size_t>(maxLayers) - usedSlots;

    // decode samples (each file once)
    SampleSource src{&library, {}};
    std::map<std::uint32_t, std::uint32_t> sampleByFile;
    std::uint32_t sampleRateUsed = 0U;
    const std::size_t total = placed.size();
    std::size_t done = 0U;
    for (const Placed& p : placed) {
        const KontaktZone& z = library.zones[p.zone];
        if (sampleByFile.count(z.fileIndex) != 0U) { ++done; continue; }
        const std::string fileName = z.fileIndex < library.files.size() ? library.files[z.fileIndex].name : std::string("?");
        if (progress && !progress(static_cast<double>(done) / static_cast<double>(std::max<std::size_t>(1U, total)), g.name + "   " + fileName)) {
            r.error = "Import stopped";
            return r;
        }
        LoadedSample s; std::string error;
        if (options.dryRun) {   // layout only: sizes from the .nki, no audio
            s.sampleRate = z.sampleRateTag != 0U ? z.sampleRateTag : 44100U; s.channels = z.channels == 0U ? 1U : z.channels; s.bits = 16U;
            s.frames = std::max(1U, z.numFrames);
        } else if (!src.load(z.fileIndex, s, error)) { r.error = error; return r; }
        ImportedSample sample{};
        sample.name = stemOf(fileName);
        sample.sourcePath = z.fileIndex < library.files.size() ? joinPath(library.directory, library.files[z.fileIndex].relativePath) : std::string();
        sample.sourceIdentity = "kontakt:" + fileNameOf(library.nkiPath) + ":" + (z.fileIndex < library.files.size() ? library.files[z.fileIndex].relativePath : fileName);
        sample.sampleRate = options.sampleRate != 0U ? options.sampleRate : s.sampleRate;
        sample.channels = s.channels;
        sample.encoding = s.bits == 24U ? AudioEncoding::Pcm24LE : AudioEncoding::Pcm16LE;
        sample.bitsPerSample = s.bits;
        sample.rootKey = z.rootKey;
        sample.fineTuneCents = 0.0F;
        sample.totalFrames = s.frames;
        sample.audioData = std::move(s.pcm);
        if (z.hasLoop && z.loop.length > 0U && static_cast<std::uint64_t>(z.loop.start) + z.loop.length <= s.frames) {
            sample.loop.enabled = true;
            sample.loop.startFrame = z.loop.start;
            sample.loop.endFrame = static_cast<std::uint64_t>(z.loop.start) + z.loop.length;
            sample.loop.crossfadeFrames = z.loop.crossfade;
        }
        if (!options.dryRun && !sample.valid()) { r.error = fileName + ": decoded sample is not valid"; return r; }
        sampleRateUsed = sample.sampleRate;
        sampleByFile[z.fileIndex] = static_cast<std::uint32_t>(r.samples.size());
        r.samples.push_back(std::move(sample));
        ++done;
    }
    if (progress) progress(1.0, g.name);

    // multisamples: one per velocity slot, soft -> strong
    const std::string soundName = prettyName(g.name.empty() ? library.programName : g.name);
    std::vector<ImportedMultisample> ms(usedSlots);
    std::vector<std::pair<int, int>> layerVel(usedSlots, {128, 0});
    for (std::size_t i = 0U; i < usedSlots; ++i) {
        ms[i].name = soundName + " V" + std::to_string(i + 1U);
        ms[i].sourceIdentity = "kontakt:" + fileNameOf(library.nkiPath) + ":" + g.name + ":V" + std::to_string(i + 1U);
    }
    for (const Placed& p : placed) {
        const KontaktZone& z = library.zones[p.zone];
        const std::size_t slot = p.slot - firstSlot;
        ImportedZone zone{};
        zone.sampleIndex = sampleByFile[z.fileIndex];
        zone.keyLow = p.keyLow; zone.keyHigh = p.keyHigh;
        zone.velocityLow = p.velLow; zone.velocityHigh = p.velHigh;
        zone.rootKey = z.rootKey;
        zone.tuneCents = z.tuneCents;
        zone.gainDb = gainToDb(z.volumeGain) + velocityCompensationDb(g, (static_cast<int>(p.velLow) + static_cast<int>(p.velHigh)) / 2);
        zone.pan = z.pan;
        zone.sourcePanRaw = static_cast<std::uint8_t>(std::clamp(static_cast<int>(std::lround(64.0F + z.pan * 63.0F)), 0, 127));
        ms[slot].zones.push_back(zone);
        layerVel[slot].first = std::min(layerVel[slot].first, static_cast<int>(p.velLow));
        layerVel[slot].second = std::max(layerVel[slot].second, static_cast<int>(p.velHigh));
    }
    r.sound.name = soundName;
    for (std::size_t i = 0U; i < usedSlots; ++i) {
        if (ms[i].zones.empty()) continue;
        std::sort(ms[i].zones.begin(), ms[i].zones.end(), [](const ImportedZone& a, const ImportedZone& b) { return a.keyLow < b.keyLow; });
        SoundLayer layer{};
        layer.multisampleIndex = static_cast<std::uint32_t>(r.multisamples.size());
        layer.velocityLow = static_cast<std::uint8_t>(std::clamp(layerVel[i].first, 1, 127));
        layer.velocityHigh = static_cast<std::uint8_t>(std::clamp(layerVel[i].second, static_cast<int>(layer.velocityLow), 127));
        layer.levelDb = std::clamp(gainToDb(g.volumeGain), -60.0F, 12.0F);
        layer.pan = g.pan;
        layer.tuneCents = g.tuneCents;
        r.sound.layers.push_back(layer);
        r.multisamples.push_back(std::move(ms[i]));
    }
    if (r.multisamples.empty()) { r.error = g.name + ": no usable zones"; return r; }
    if (g.hasEnvelope) {
        char buf[160];
        std::snprintf(buf, sizeof buf, "%s: Kontakt envelope attack %.0f ms, hold %.0f ms, decay %.0f ms, sustain %.0f %%, release %.0f ms - set it on the TONE page of the sampler.",
                      soundName.c_str(), static_cast<double>(g.attackMs), static_cast<double>(g.holdMs), static_cast<double>(g.decayMs),
                      static_cast<double>(g.sustain) * 100.0, static_cast<double>(g.releaseMs));
        r.warnings.emplace_back(buf);
    }
    if (options.sampleRate != 0U && !r.samples.empty()) {
        r.warnings.push_back(soundName + ": samples imported as " + std::to_string(sampleRateUsed) + " Hz.");
    }
    return r;
}

} // namespace silveton::manager
