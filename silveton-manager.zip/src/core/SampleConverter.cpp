#include "silveton/manager/SampleConverter.h"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <limits>
#include <vector>

namespace silveton::manager {
namespace {

constexpr double kPi = 3.14159265358979323846264338327950288;

std::uint32_t bytesPerSample(AudioEncoding encoding) noexcept {
    switch (encoding) {
        case AudioEncoding::Pcm16LE: return 2U;
        case AudioEncoding::Pcm24LE: return 3U;
        case AudioEncoding::Float32LE: return 4U;
    }
    return 0U;
}

double decodeSample(const std::uint8_t* p, AudioEncoding encoding) noexcept {
    switch (encoding) {
        case AudioEncoding::Pcm16LE: {
            const std::uint16_t u = static_cast<std::uint16_t>(
                static_cast<std::uint32_t>(p[0]) |
                (static_cast<std::uint32_t>(p[1]) << 8U));
            const std::int16_t s = static_cast<std::int16_t>(u);
            return static_cast<double>(s) / 32768.0;
        }
        case AudioEncoding::Pcm24LE: {
            std::int32_t v = static_cast<std::int32_t>(p[0]) |
                             (static_cast<std::int32_t>(p[1]) << 8U) |
                             (static_cast<std::int32_t>(p[2]) << 16U);
            if ((v & 0x00800000) != 0) v |= static_cast<std::int32_t>(0xFF000000U);
            return static_cast<double>(v) / 8388608.0;
        }
        case AudioEncoding::Float32LE: {
            std::uint32_t bits = static_cast<std::uint32_t>(p[0]) |
                                 (static_cast<std::uint32_t>(p[1]) << 8U) |
                                 (static_cast<std::uint32_t>(p[2]) << 16U) |
                                 (static_cast<std::uint32_t>(p[3]) << 24U);
            float value = 0.0F;
            std::memcpy(&value, &bits, sizeof(value));
            return std::isfinite(value) ? static_cast<double>(value) : 0.0;
        }
    }
    return 0.0;
}

std::vector<double> decodeInterleaved(const ImportedSample& sample) {
    const std::uint32_t bps = bytesPerSample(sample.encoding);
    const std::size_t count = static_cast<std::size_t>(sample.totalFrames) * static_cast<std::size_t>(sample.channels);
    std::vector<double> decoded(count, 0.0);
    for (std::size_t i = 0U; i < count; ++i) {
        decoded[i] = decodeSample(sample.audioData.data() + (i * static_cast<std::size_t>(bps)), sample.encoding);
    }
    return decoded;
}

std::vector<double> convertChannels(const std::vector<double>& input,
                                    std::uint64_t frames,
                                    std::uint16_t sourceChannels,
                                    std::uint16_t targetChannels) {
    if (sourceChannels == targetChannels) return input;
    std::vector<double> output(static_cast<std::size_t>(frames) * static_cast<std::size_t>(targetChannels), 0.0);
    if (sourceChannels == 1U && targetChannels == 2U) {
        for (std::uint64_t frame = 0U; frame < frames; ++frame) {
            const double value = input[static_cast<std::size_t>(frame)];
            const std::size_t out = static_cast<std::size_t>(frame) * 2U;
            output[out] = value;
            output[out + 1U] = value;
        }
    } else if (sourceChannels == 2U && targetChannels == 1U) {
        for (std::uint64_t frame = 0U; frame < frames; ++frame) {
            const std::size_t in = static_cast<std::size_t>(frame) * 2U;
            output[static_cast<std::size_t>(frame)] = 0.5 * (input[in] + input[in + 1U]);
        }
    }
    return output;
}

double sinc(double x) noexcept {
    if (std::abs(x) < 1.0e-12) return 1.0;
    const double pix = kPi * x;
    return std::sin(pix) / pix;
}

double besselI0(double x) noexcept {
    double sum = 1.0, term = 1.0;
    const double q = x * x * 0.25;
    for (int k = 1; k < 300; ++k) {
        term *= q / (static_cast<double>(k) * static_cast<double>(k));
        sum += term;
        if (term < sum * 1.0e-17) break;
    }
    return sum;
}

std::uint64_t gcd64(std::uint64_t a, std::uint64_t b) noexcept {
    while (b != 0U) { const std::uint64_t t = a % b; a = b; b = t; }
    return a;
}

// SILVETON_HQ_RESAMPLER_V1: Kaiser-windowed sinc (about 100 dB), exact rational
// polyphase table (44.1 -> 48 kHz uses 160 phases), computed once per conversion.
// 0..20 kHz is kept flat; everything that would fold into 0..20 kHz is removed.
std::vector<double> resample(const std::vector<double>& input,
                             std::uint64_t sourceFrames,
                             std::uint16_t channels,
                             std::uint32_t sourceRate,
                             std::uint32_t targetRate,
                             std::uint64_t targetFrames) {
    if (sourceRate == targetRate) return input;
    std::vector<double> output(static_cast<std::size_t>(targetFrames) * static_cast<std::size_t>(channels), 0.0);

    const double lowRate = static_cast<double>(std::min(sourceRate, targetRate));
    const double passHz = std::min(20000.0, 0.45 * lowRate);
    const double stopHz = std::max(passHz + 0.02 * lowRate, lowRate - passHz);
    const double fc = 0.5 * (passHz + stopHz) / static_cast<double>(sourceRate);      // cycles per input sample
    const double transition = (stopHz - passHz) / static_cast<double>(sourceRate);
    int taps = static_cast<int>(std::ceil((100.0 - 7.95) / (14.36 * transition)));
    taps = std::max(32, std::min(512, taps + (taps & 1)));
    const int half = taps / 2;
    const double beta = 0.1102 * (100.0 - 8.7);
    const double i0Beta = besselI0(beta);

    const std::uint64_t g = gcd64(sourceRate, targetRate);
    const std::uint64_t L = targetRate / g;   // phases
    const std::uint64_t M = sourceRate / g;   // input step per L outputs
    const bool exact = L <= 4096U;
    const std::size_t phases = exact ? static_cast<std::size_t>(L) : 1024U;

    std::vector<double> table((phases + 1U) * static_cast<std::size_t>(taps), 0.0);
    for (std::size_t ph = 0U; ph <= phases; ++ph) {
        const double frac = static_cast<double>(ph) / static_cast<double>(phases);
        double sum = 0.0;
        double* row = table.data() + ph * static_cast<std::size_t>(taps);
        for (int k = 0; k < taps; ++k) {
            const double t = static_cast<double>(k - half + 1) - frac;
            const double x = t / static_cast<double>(half);
            const double win = std::abs(x) >= 1.0 ? 0.0 : besselI0(beta * std::sqrt(1.0 - x * x)) / i0Beta;
            row[k] = 2.0 * fc * sinc(2.0 * fc * t) * win;
            sum += row[k];
        }
        if (std::abs(sum) > 1.0e-15) for (int k = 0; k < taps; ++k) row[k] /= sum;
    }

    const std::size_t ch = channels;
    for (std::uint64_t n = 0U; n < targetFrames; ++n) {
        std::int64_t base = 0;
        const double* w = nullptr;
        std::vector<double> mixed;
        if (exact) {
            const std::uint64_t num = n * M;
            base = static_cast<std::int64_t>(num / L);
            w = table.data() + static_cast<std::size_t>(num % L) * static_cast<std::size_t>(taps);
        } else {
            const long double pos = static_cast<long double>(n) * static_cast<long double>(sourceRate) / static_cast<long double>(targetRate);
            base = static_cast<std::int64_t>(std::floor(pos));
            const double scaled = static_cast<double>(pos - static_cast<long double>(base)) * static_cast<double>(phases);
            const std::size_t p = std::min<std::size_t>(static_cast<std::size_t>(scaled), phases - 1U);
            const double mix = scaled - static_cast<double>(p);
            mixed.resize(static_cast<std::size_t>(taps));
            const double* a = table.data() + p * static_cast<std::size_t>(taps);
            const double* b = a + taps;
            for (int k = 0; k < taps; ++k) mixed[static_cast<std::size_t>(k)] = a[k] + (b[k] - a[k]) * mix;
            w = mixed.data();
        }
        const std::int64_t first = base - half + 1;
        for (std::size_t c = 0U; c < ch; ++c) {
            double acc = 0.0;
            for (int k = 0; k < taps; ++k) {
                const std::int64_t f = first + k;
                if (f < 0 || f >= static_cast<std::int64_t>(sourceFrames)) continue;
                acc += input[static_cast<std::size_t>(f) * ch + c] * w[k];
            }
            output[static_cast<std::size_t>(n) * ch + c] = acc;
        }
    }
    return output;
}

// SILVETON_LOOP_RESAMPLE_V1: a sample with a loop is resampled the way the sampler
// PLAYS it: the loop repeats forever, so the filter sees the loop wrap around
// (no click at the loop point), and the new loop length is a whole number of
// frames that holds exactly the same piece of sound. The tiny rate difference
// this needs (normally far below 1 cent) is returned and put into fine tune.
std::vector<double> resampleLooped(const std::vector<double>& input,
                                   std::uint64_t sourceFrames,
                                   std::uint16_t channels,
                                   std::uint32_t sourceRate,
                                   std::uint32_t targetRate,
                                   std::uint64_t loopStart,
                                   std::uint64_t loopEnd,
                                   std::uint64_t& outFrames,
                                   std::uint64_t& outLoopStart,
                                   std::uint64_t& outLoopEnd,
                                   double& centsCorrection) {
    const double nominal = static_cast<double>(targetRate) / static_cast<double>(sourceRate);
    const std::uint64_t len = loopEnd - loopStart;
    const std::uint64_t newLen = std::max<std::uint64_t>(1U, static_cast<std::uint64_t>(std::llround(static_cast<double>(len) * nominal)));
    const double r = static_cast<double>(newLen) / static_cast<double>(len);     // output frames per input frame
    centsCorrection = 1200.0 * std::log2(r / nominal);
    outLoopStart = static_cast<std::uint64_t>(std::llround(static_cast<double>(loopStart) * r));
    outLoopEnd = outLoopStart + newLen;
    outFrames = std::max<std::uint64_t>(outLoopEnd, static_cast<std::uint64_t>(std::llround(static_cast<double>(sourceFrames) * r)));

    const double lowRate = static_cast<double>(std::min(sourceRate, targetRate));
    const double passHz = std::min(20000.0, 0.45 * lowRate);
    const double stopHz = std::max(passHz + 0.02 * lowRate, lowRate - passHz);
    const double fc = 0.5 * (passHz + stopHz) / static_cast<double>(sourceRate);
    const double transition = (stopHz - passHz) / static_cast<double>(sourceRate);
    int taps = static_cast<int>(std::ceil((100.0 - 7.95) / (14.36 * transition)));
    taps = std::max(32, std::min(512, taps + (taps & 1)));
    const int half = taps / 2;
    const double beta = 0.1102 * (100.0 - 8.7);
    const double i0Beta = besselI0(beta);
    const std::size_t phases = 2048U;
    std::vector<double> table((phases + 1U) * static_cast<std::size_t>(taps), 0.0);
    for (std::size_t ph = 0U; ph <= phases; ++ph) {
        const double frac = static_cast<double>(ph) / static_cast<double>(phases);
        double sum = 0.0;
        double* row = table.data() + ph * static_cast<std::size_t>(taps);
        for (int k = 0; k < taps; ++k) {
            const double t = static_cast<double>(k - half + 1) - frac;
            const double x = t / static_cast<double>(half);
            const double win = std::abs(x) >= 1.0 ? 0.0 : besselI0(beta * std::sqrt(1.0 - x * x)) / i0Beta;
            row[k] = 2.0 * fc * sinc(2.0 * fc * t) * win;
            sum += row[k];
        }
        if (std::abs(sum) > 1.0e-15) for (int k = 0; k < taps; ++k) row[k] /= sum;
    }

    const std::size_t ch = channels;
    const auto S = static_cast<std::int64_t>(loopStart);
    const auto L = static_cast<std::int64_t>(len);
    const auto E = static_cast<std::int64_t>(loopEnd);
    std::vector<double> output(static_cast<std::size_t>(outFrames) * ch, 0.0);
    std::vector<double> w(static_cast<std::size_t>(taps));
    for (std::uint64_t n = 0U; n < outFrames; ++n) {
        const bool looping = n < outLoopEnd;               // what the sampler plays while the key is held
        const bool inLoop = n >= outLoopStart && n < outLoopEnd;
        const long double pos = static_cast<long double>(n) / static_cast<long double>(r);
        const auto base = static_cast<std::int64_t>(std::floor(pos));
        const double scaled = static_cast<double>(pos - static_cast<long double>(base)) * static_cast<double>(phases);
        const std::size_t p = std::min<std::size_t>(static_cast<std::size_t>(scaled), phases - 1U);
        const double mix = scaled - static_cast<double>(p);
        const double* a = table.data() + p * static_cast<std::size_t>(taps);
        const double* b = a + taps;
        for (int k = 0; k < taps; ++k) w[static_cast<std::size_t>(k)] = a[k] + (b[k] - a[k]) * mix;
        const std::int64_t first = base - half + 1;
        for (std::size_t c = 0U; c < ch; ++c) {
            double acc = 0.0;
            for (int k = 0; k < taps; ++k) {
                std::int64_t f = first + k;
                if (inLoop) f = S + (((f - S) % L) + L) % L;     // inside the loop: only loop sound, both ways
                else if (looping && f >= E) f = S + (f - S) % L; // before the loop: the loop follows
                if (f < 0 || f >= static_cast<std::int64_t>(sourceFrames)) continue;
                acc += input[static_cast<std::size_t>(f) * ch + c] * w[static_cast<std::size_t>(k)];
            }
            output[static_cast<std::size_t>(n) * ch + c] = acc;
        }
    }
    return output;
}

struct DitherGenerator {
    std::uint32_t state{0xA5C31E27U};

    std::uint32_t next() noexcept {
        state ^= state << 13U;
        state ^= state >> 17U;
        state ^= state << 5U;
        return state;
    }

    double uniform() noexcept {
        return static_cast<double>(next()) / static_cast<double>(std::numeric_limits<std::uint32_t>::max());
    }

    double tpdf(double lsb) noexcept {
        return (uniform() - uniform()) * lsb;
    }
};

void append16(std::vector<std::uint8_t>& bytes, double value, bool dither, DitherGenerator& rng) {
    if (dither) value += rng.tpdf(1.0 / 32768.0);
    value = std::max(-1.0, std::min(value, 0.999969482421875));
    const long quantized = std::lround(value * 32768.0);
    const auto sample = static_cast<std::int16_t>(std::max<long>(-32768L, std::min<long>(32767L, quantized)));
    const auto u = static_cast<std::uint16_t>(sample);
    bytes.push_back(static_cast<std::uint8_t>(u & 0xFFU));
    bytes.push_back(static_cast<std::uint8_t>((u >> 8U) & 0xFFU));
}

void append24(std::vector<std::uint8_t>& bytes, double value, bool dither, DitherGenerator& rng) {
    if (dither) value += rng.tpdf(1.0 / 8388608.0);
    value = std::max(-1.0, std::min(value, 0.9999998807907104));
    const long long quantized = std::llround(value * 8388608.0);
    const auto sample = static_cast<std::int32_t>(std::max<long long>(-8388608LL, std::min<long long>(8388607LL, quantized)));
    const auto u = static_cast<std::uint32_t>(sample);
    bytes.push_back(static_cast<std::uint8_t>(u & 0xFFU));
    bytes.push_back(static_cast<std::uint8_t>((u >> 8U) & 0xFFU));
    bytes.push_back(static_cast<std::uint8_t>((u >> 16U) & 0xFFU));
}

void appendFloat32(std::vector<std::uint8_t>& bytes, double value) {
    const float sample = static_cast<float>(std::max(-1.0, std::min(value, 1.0)));
    std::uint32_t bits = 0U;
    std::memcpy(&bits, &sample, sizeof(bits));
    bytes.push_back(static_cast<std::uint8_t>(bits & 0xFFU));
    bytes.push_back(static_cast<std::uint8_t>((bits >> 8U) & 0xFFU));
    bytes.push_back(static_cast<std::uint8_t>((bits >> 16U) & 0xFFU));
    bytes.push_back(static_cast<std::uint8_t>((bits >> 24U) & 0xFFU));
}

std::vector<std::uint8_t> encode(const std::vector<double>& values, AudioEncoding encoding, bool dither) {
    const std::uint32_t bps = bytesPerSample(encoding);
    std::vector<std::uint8_t> bytes;
    bytes.reserve(values.size() * static_cast<std::size_t>(bps));
    DitherGenerator rng{};
    for (double value : values) {
        switch (encoding) {
            case AudioEncoding::Pcm16LE: append16(bytes, value, dither, rng); break;
            case AudioEncoding::Pcm24LE: append24(bytes, value, dither, rng); break;
            case AudioEncoding::Float32LE: appendFloat32(bytes, value); break;
        }
    }
    return bytes;
}

std::uint8_t bitDepth(AudioEncoding encoding) noexcept {
    switch (encoding) {
        case AudioEncoding::Pcm16LE: return 16U;
        case AudioEncoding::Pcm24LE: return 24U;
        case AudioEncoding::Float32LE: return 32U;
    }
    return 0U;
}

std::uint64_t scaleFrame(std::uint64_t frame, std::uint32_t sourceRate, std::uint32_t targetRate) noexcept {
    const long double scaled = static_cast<long double>(frame) * static_cast<long double>(targetRate) / static_cast<long double>(sourceRate);
    if (scaled <= 0.0L) return 0U;
    return static_cast<std::uint64_t>(std::llround(scaled));
}

} // namespace

std::vector<double> SampleConverter::decode(const ImportedSample& sample) { return decodeInterleaved(sample); }

std::vector<std::uint8_t> SampleConverter::encodeSamples(const std::vector<double>& values, AudioEncoding encoding, bool dither) {
    return encode(values, encoding, dither && encoding != AudioEncoding::Float32LE);
}

bool SampleConverter::convert(const ImportedSample& source,
                              const SampleConversionOptions& options,
                              ImportedSample& destination,
                              std::string& error) {
    if (!source.valid()) {
        error = "The source sample is invalid.";
        return false;
    }

    const std::uint32_t targetRate = options.sampleRate == 0U ? source.sampleRate : options.sampleRate;
    const std::uint16_t targetChannels = options.channels == 0U ? source.channels : options.channels;
    const AudioEncoding targetEncoding = options.changeEncoding ? options.encoding : source.encoding;

    if (targetRate < 8000U || targetRate > 384000U) {
        error = "Target sample rate must be between 8000 and 384000 Hz.";
        return false;
    }
    if (targetChannels != 1U && targetChannels != 2U) {
        error = "Target channel count must be mono or stereo.";
        return false;
    }
    if (bytesPerSample(targetEncoding) == 0U) {
        error = "Unsupported target sample encoding.";
        return false;
    }

    // A true no-op must stay bit perfect. In particular, enabling dither must
    // never alter audio when sample rate, channel count and encoding are kept.
    if (targetRate == source.sampleRate &&
        targetChannels == source.channels &&
        targetEncoding == source.encoding) {
        destination = source;
        error.clear();
        return true;
    }

    const long double exactFrames = static_cast<long double>(source.totalFrames) *
                                    static_cast<long double>(targetRate) /
                                    static_cast<long double>(source.sampleRate);
    const std::uint64_t targetFrames = std::max<std::uint64_t>(1U, static_cast<std::uint64_t>(std::llround(exactFrames)));

    std::vector<double> decoded = decodeInterleaved(source);
    std::vector<double> channelConverted = convertChannels(decoded, source.totalFrames, source.channels, targetChannels);
    const bool loopOk = source.loop.enabled && source.loop.startFrame < source.loop.endFrame &&
                        source.loop.endFrame <= source.totalFrames && targetRate != source.sampleRate;
    std::uint64_t outFrames = targetFrames, outLoopStart = 0U, outLoopEnd = 0U;
    double centsCorrection = 0.0;
    std::vector<double> resampled = loopOk
        ? resampleLooped(channelConverted, source.totalFrames, targetChannels, source.sampleRate, targetRate,
                         source.loop.startFrame, source.loop.endFrame, outFrames, outLoopStart, outLoopEnd, centsCorrection)
        : resample(channelConverted, source.totalFrames, targetChannels, source.sampleRate, targetRate, targetFrames);

    ImportedSample converted = source;
    converted.sampleRate = targetRate;
    converted.channels = targetChannels;
    converted.encoding = targetEncoding;
    converted.bitsPerSample = bitDepth(targetEncoding);
    converted.totalFrames = outFrames;
    converted.audioData = encode(resampled, targetEncoding, options.dither && targetEncoding != AudioEncoding::Float32LE);

    if (loopOk) {
        converted.loop.startFrame = outLoopStart;
        converted.loop.endFrame = outLoopEnd;
        converted.loop.crossfadeFrames = static_cast<std::uint32_t>(std::min<std::uint64_t>(
            scaleFrame(source.loop.crossfadeFrames, source.sampleRate, targetRate), outLoopEnd - outLoopStart));
        converted.fineTuneCents = static_cast<float>(static_cast<double>(source.fineTuneCents) + centsCorrection);
    } else if (source.loop.enabled) {
        converted.loop.startFrame = std::min(scaleFrame(source.loop.startFrame, source.sampleRate, targetRate), targetFrames - 1U);
        converted.loop.endFrame = std::min(scaleFrame(source.loop.endFrame, source.sampleRate, targetRate), targetFrames);
        converted.loop.crossfadeFrames = static_cast<std::uint32_t>(std::min<std::uint64_t>(
            scaleFrame(source.loop.crossfadeFrames, source.sampleRate, targetRate),
            static_cast<std::uint64_t>(std::numeric_limits<std::uint32_t>::max())));
        if (converted.loop.startFrame >= converted.loop.endFrame) {
            converted.loop = LoopRegion{};
        }
    }

    if (!converted.valid()) {
        error = "Converted sample failed internal validation.";
        return false;
    }

    destination = std::move(converted);
    error.clear();
    return true;
}

} // namespace silveton::manager
