// SILVETON_AUTOMAP_V1 - see include/silveton/manager/AutoMapper.h
#include "silveton/manager/AutoMapper.h"
#include "silveton/manager/ObjectManager.h"
#include "silveton/manager/PitchDetector.h"

#include <algorithm>
#include <cmath>
#include <cctype>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <limits>
#include <map>
#include <string>
#include <vector>

namespace silveton::manager {
namespace {

std::size_t bytesPerSample(AudioEncoding encoding) noexcept {
    switch (encoding) {
        case AudioEncoding::Pcm16LE: return 2U;
        case AudioEncoding::Pcm24LE: return 3U;
        case AudioEncoding::Float32LE: return 4U;
    }
    return 0U;
}

float readScalar(const std::uint8_t* p, AudioEncoding encoding) noexcept {
    switch (encoding) {
        case AudioEncoding::Pcm16LE: {
            const std::uint16_t raw = static_cast<std::uint16_t>(p[0]) |
                                      static_cast<std::uint16_t>(static_cast<std::uint16_t>(p[1]) << 8U);
            return static_cast<float>(static_cast<std::int16_t>(raw)) / 32768.0F;
        }
        case AudioEncoding::Pcm24LE: {
            std::int32_t value = static_cast<std::int32_t>(p[0]) |
                                 (static_cast<std::int32_t>(p[1]) << 8) |
                                 (static_cast<std::int32_t>(p[2]) << 16);
            if ((value & 0x00800000) != 0) value |= static_cast<std::int32_t>(0xFF000000U);
            return static_cast<float>(value) / 8388608.0F;
        }
        case AudioEncoding::Float32LE: {
            const std::uint32_t raw = static_cast<std::uint32_t>(p[0]) |
                                      (static_cast<std::uint32_t>(p[1]) << 8U) |
                                      (static_cast<std::uint32_t>(p[2]) << 16U) |
                                      (static_cast<std::uint32_t>(p[3]) << 24U);
            float value = 0.0F;
            std::memcpy(&value, &raw, sizeof(value));
            return std::isfinite(value) ? value : 0.0F;
        }
    }
    return 0.0F;
}

float peakOf(const ImportedSample& sample) noexcept {
    const std::size_t bps = bytesPerSample(sample.encoding);
    if (bps == 0U || !sample.valid()) return 0.0F;
    const std::size_t fb = static_cast<std::size_t>(sample.channels) * bps;
    float top = 0.0F;
    for (std::uint64_t i = 0U; i < sample.totalFrames; ++i) {
        for (std::uint16_t c = 0U; c < sample.channels; ++c) {
            const float v = std::fabs(readScalar(sample.audioData.data() + static_cast<std::size_t>(i) * fb + static_cast<std::size_t>(c) * bps, sample.encoding));
            top = std::max(top, v);
        }
    }
    return top;
}

} // namespace

bool AutoMapper::isSingleBlend(const ImportedMultisample& multisample) noexcept {
    return multisample.zones.size() == 1U && multisample.sourceIdentity.rfind("single:", 0U) == 0U;
}

std::size_t AutoMapper::dropSingleBlendsFor(BankProject& project, const std::vector<std::size_t>& sampleIndexes) {
    std::vector<std::size_t> doomed;
    for (std::size_t m = 0U; m < project.multisamples.size(); ++m) {
        const ImportedMultisample& ms = project.multisamples[m];
        if (!isSingleBlend(ms)) continue;
        const std::size_t sample = static_cast<std::size_t>(ms.zones.front().sampleIndex);
        if (std::find(sampleIndexes.begin(), sampleIndexes.end(), sample) == sampleIndexes.end()) continue;
        doomed.push_back(m);
    }
    // from the back, so the numbers of the ones still waiting do not move under us
    std::size_t removed = 0U;
    for (auto it = doomed.rbegin(); it != doomed.rend(); ++it) {
        DeleteImpact impact{};
        std::string error;
        if (ObjectManager::deleteMultisampleCascade(project, *it, impact, error)) ++removed;
    }
    return removed;
}

std::size_t AutoMapper::dropSamples(BankProject& project, const std::vector<std::size_t>& sampleIndexes) {
    std::vector<std::size_t> order(sampleIndexes);
    std::sort(order.begin(), order.end(), std::greater<std::size_t>());       // from the back: the numbers of the rest stay
    order.erase(std::unique(order.begin(), order.end()), order.end());
    std::size_t removed = 0U;
    for (std::size_t index : order) {
        if (index >= project.samples.size()) continue;
        DeleteImpact impact{};
        std::string error;
        if (ObjectManager::deleteSampleCascade(project, index, impact, error)) ++removed;
    }
    return removed;
}

int AutoMapper::noteFromText(const std::string& text) noexcept {
    std::string clean;
    for (char c : text) if (c != ' ' && c != '\t') clean.push_back(c);
    if (clean.empty()) return -1;

    // a plain number is the MIDI note itself
    bool digits = true;
    for (char c : clean) if (c < '0' || c > '9') { digits = false; break; }
    if (digits) {
        const long value = std::strtol(clean.c_str(), nullptr, 10);
        return value >= 0 && value <= 127 ? static_cast<int>(value) : -1;
    }

    static const int steps[7] = {9, 11, 0, 2, 4, 5, 7};      // A B C D E F G
    const char letter = static_cast<char>(std::toupper(static_cast<unsigned char>(clean[0])));
    if (letter < 'A' || letter > 'G') return -1;
    int semitone = steps[letter - 'A'];
    std::size_t at = 1U;
    if (at < clean.size() && (clean[at] == '#' || clean[at] == 's')) { ++semitone; ++at; }
    else if (at < clean.size() && (clean[at] == 'b' || clean[at] == 'B')) { --semitone; ++at; }
    if (at >= clean.size()) return -1;
    const long octave = std::strtol(clean.c_str() + at, nullptr, 10);
    if (octave < -1 || octave > 9) return -1;
    const int midi = static_cast<int>((octave + 1) * 12) + semitone;
    return midi >= 0 && midi <= 127 ? midi : -1;
}

AutoMapPlan AutoMapper::listen(const BankProject& project, const std::vector<std::size_t>& sampleIndexes) {
    AutoMapPlan plan;
    for (std::size_t index : sampleIndexes) {
        if (index >= project.samples.size()) continue;
        const ImportedSample& sample = project.samples[index];
        AutoMapEntry entry;
        entry.sampleIndex = index;
        entry.name = sample.name;
        entry.peak = peakOf(sample);
        const PitchResult heard = PitchDetector::detect(sample);
        if (heard.found) {
            entry.rootKey = std::max(0, std::min(127, heard.midi));
            entry.confidence = heard.confidence;
            entry.cents = heard.cents;
            entry.heard = true;
        } else {
            entry.rootKey = static_cast<int>(sample.rootKey);   // nothing clear came out: keep what it has
            entry.confidence = 0.0F;
            entry.cents = 0.0F;
            entry.heard = false;
        }
        plan.entries.push_back(entry);
    }
    arrange(plan);
    return plan;
}

void AutoMapper::arrange(AutoMapPlan& plan) {
    if (plan.entries.empty()) { plan.layers = 1; return; }

    // samples on the same note become velocity layers, the quietest one first
    std::map<int, std::vector<std::size_t>> byKey;
    for (std::size_t i = 0U; i < plan.entries.size(); ++i) {
        plan.entries[i].rootKey = std::max(0, std::min(127, plan.entries[i].rootKey));
        byKey[plan.entries[i].rootKey].push_back(i);
    }
    std::size_t mostPerKey = 1U;
    for (auto& pair : byKey) {
        std::sort(pair.second.begin(), pair.second.end(), [&](std::size_t a, std::size_t b) {
            if (plan.entries[a].peak != plan.entries[b].peak) return plan.entries[a].peak < plan.entries[b].peak;
            return plan.entries[a].name < plan.entries[b].name;
        });
        mostPerKey = std::max(mostPerKey, pair.second.size());
    }
    plan.layers = static_cast<int>(mostPerKey);

    // the keys: every note holds the keys up to halfway towards the note beside it
    std::vector<int> keys;
    keys.reserve(byKey.size());
    for (const auto& pair : byKey) keys.push_back(pair.first);

    for (std::size_t k = 0U; k < keys.size(); ++k) {
        const int here = keys[k];
        int low = 0, high = 127;
        if (k > 0U) low = (keys[k - 1U] + here) / 2 + 1;
        if (k + 1U < keys.size()) high = (here + keys[k + 1U]) / 2;
        const std::vector<std::size_t>& group = byKey[here];
        const std::size_t count = group.size();
        for (std::size_t g = 0U; g < count; ++g) {
            AutoMapEntry& entry = plan.entries[group[g]];
            entry.keyLow = low;
            entry.keyHigh = high;
            // the whole 1...127 of velocity is shared out between the samples of this note
            const int from = static_cast<int>(1 + (127 - 1) * static_cast<double>(g) / static_cast<double>(count));
            const int to = static_cast<int>(1 + (127 - 1) * static_cast<double>(g + 1U) / static_cast<double>(count));
            entry.velocityLow = std::max(1, from);
            entry.velocityHigh = g + 1U == count ? 127 : std::max(entry.velocityLow, to);
            entry.layer = static_cast<int>(g);
        }
    }
}

bool AutoMapper::build(BankProject& project, const AutoMapPlan& plan, const std::string& name,
                       std::size_t& createdSoundIndex, std::string& error) {
    error.clear();
    if (plan.entries.empty()) { error = "No samples were given to map."; return false; }
    const std::string base = name.empty() ? std::string("NEW BLEND") : name;

    const int layers = std::max(1, plan.layers);
    std::vector<std::size_t> madeMultisamples;
    std::uint32_t nextId = 1U;
    for (const auto& ms : project.multisamples) nextId = std::max(nextId, ms.multisampleId + 1U);

    for (int layer = 0; layer < layers; ++layer) {
        ImportedMultisample ms;
        ms.multisampleId = nextId++;
        ms.name = layers == 1 ? base : base + " V" + std::to_string(layer + 1);
        ms.sourceIdentity = "automap";
        int velocityLow = 1, velocityHigh = 127;
        for (const AutoMapEntry& entry : plan.entries) {
            if (entry.layer != layer) continue;
            if (entry.sampleIndex >= project.samples.size()) continue;
            ImportedZone zone;
            zone.sampleIndex = static_cast<std::uint32_t>(entry.sampleIndex);
            zone.keyLow = static_cast<std::uint8_t>(std::max(0, std::min(127, entry.keyLow)));
            zone.keyHigh = static_cast<std::uint8_t>(std::max<int>(zone.keyLow, std::min(127, entry.keyHigh)));
            zone.rootKey = static_cast<std::uint8_t>(std::max(0, std::min(127, entry.rootKey)));
            zone.velocityLow = 1U;
            zone.velocityHigh = 127U;                       // the layer carries the velocity, not the zone
            ms.zones.push_back(zone);
            velocityLow = entry.velocityLow;
            velocityHigh = entry.velocityHigh;
        }
        if (ms.zones.empty()) continue;
        madeMultisamples.push_back(project.multisamples.size());
        project.multisamples.push_back(std::move(ms));
        // remember the velocity band of this layer on the side
        project.multisamples.back().sourceIdentity = "automap " + std::to_string(velocityLow) + "-" + std::to_string(velocityHigh);
    }
    if (madeMultisamples.empty()) { error = "None of the samples could be mapped."; return false; }

    std::size_t created = 0U;
    if (!ObjectManager::createSoundFromMultisample(project, madeMultisamples.front(), base, created, error)) return false;
    createdSoundIndex = created;
    SoundDefinition& sound = project.sounds[created];
    sound.layers.clear();
    for (std::size_t k = 0U; k < madeMultisamples.size(); ++k) {
        SoundLayer soundLayer;
        soundLayer.multisampleIndex = static_cast<std::uint32_t>(madeMultisamples[k]);
        soundLayer.enabled = true;
        soundLayer.keyLow = 0U;
        soundLayer.keyHigh = 127U;
        const int from = static_cast<int>(1 + 126.0 * static_cast<double>(k) / static_cast<double>(madeMultisamples.size()));
        const int to = k + 1U == madeMultisamples.size() ? 127
                      : static_cast<int>(1 + 126.0 * static_cast<double>(k + 1U) / static_cast<double>(madeMultisamples.size()));
        soundLayer.velocityLow = static_cast<std::uint8_t>(std::max(1, from));
        soundLayer.velocityHigh = static_cast<std::uint8_t>(std::max<int>(soundLayer.velocityLow, std::min(127, to)));
        sound.layers.push_back(soundLayer);
    }
    return true;
}

} // namespace silveton::manager
