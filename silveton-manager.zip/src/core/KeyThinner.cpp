// SILVETON_THIN_V1 - see include/silveton/manager/KeyThinner.h
#include "silveton/manager/KeyThinner.h"
#include "silveton/manager/SpectrumAnalyzer.h"

#include <algorithm>
#include <cmath>
#include <limits>
#include <map>
#include <set>
#include <string>
#include <utility>
#include <vector>

namespace silveton::manager {
namespace {

// How much two neighbours may differ and still be called "the same sound". Estimates, to be tuned on real banks.
constexpr double kLevelDb = 3.0;          // loudness of the loudest moment
constexpr double kTuningCents = 15.0;     // detune between the two (the pitch finder is good to a few cents)
constexpr double kDecayRatio = 1.6;       // time to fall 12 dB, after the shift
constexpr double kBrightnessRatio = 1.35; // spectral centre in multiples of the note itself
constexpr double kDecayFallDb = 12.0;
constexpr float kClearConfidence = 0.5F;

using Features = ThinFeatures;

double hzOf(int midi, double cents) {
    return 440.0 * std::pow(2.0, (static_cast<double>(midi) + cents / 100.0 - 69.0) / 12.0);
}

Features measure(const ImportedSample& sample, double f0) {
    Features out;
    if (!sample.valid() || sample.sampleRate == 0U || f0 <= 0.0) return out;
    const std::vector<float> mono = SpectrumAnalyzer::monoMix(sample);
    if (mono.size() < SpectrumAnalyzer::kFftSize / 2U) return out;
    const double rate = static_cast<double>(sample.sampleRate);

    // loudness in blocks of about two periods of the note (25 ms ... 100 ms)
    const double blockSec = std::min(0.1, std::max(0.025, 2.0 / f0));
    const std::size_t block = std::max<std::size_t>(32U, static_cast<std::size_t>(blockSec * rate));
    const std::size_t blocks = mono.size() / block;
    if (blocks < 4U) return out;
    std::vector<double> rms(blocks, 0.0);
    for (std::size_t b = 0U; b < blocks; ++b) {
        double sum = 0.0;
        for (std::size_t i = b * block; i < (b + 1U) * block; ++i) sum += static_cast<double>(mono[i]) * static_cast<double>(mono[i]);
        rms[b] = std::sqrt(sum / static_cast<double>(block));
    }
    std::size_t top = 0U;
    for (std::size_t b = 1U; b < blocks; ++b) if (rms[b] > rms[top]) top = b;
    if (rms[top] < 1e-5) return out;                                 // silence
    out.levelDb = 20.0 * std::log10(rms[top]);

    // how long until it has fallen by 12 dB (two blocks in a row, so a wobble does not count)
    const double threshold = rms[top] * std::pow(10.0, -kDecayFallDb / 20.0);
    out.sustained = true;
    out.decaySec = static_cast<double>(blocks - top) * blockSec;
    for (std::size_t b = top + 1U; b < blocks; ++b) {
        if (rms[b] < threshold && (b + 1U == blocks || rms[b + 1U] < threshold)) {
            out.sustained = false;
            out.decaySec = static_cast<double>(b - top) * blockSec;
            break;
        }
    }

    // brightness: where the spectrum is centred, in multiples of the note, a little after the loudest moment
    const std::size_t start = top * block + static_cast<std::size_t>(0.1 * rate);
    const std::size_t frameEnd = std::min(mono.size(), start + SpectrumAnalyzer::kFftSize);
    const std::vector<float> power = SpectrumAnalyzer::powerAt(mono, frameEnd);
    const double binHz = rate / static_cast<double>(SpectrumAnalyzer::kFftSize);
    const double lo = 0.5 * f0;
    const double hi = std::min(0.45 * rate, 12000.0);
    float maxPower = 0.0F;
    for (std::size_t k = 1U; k < power.size(); ++k) {
        const double hz = static_cast<double>(k) * binHz;
        if (hz >= lo && hz <= hi) maxPower = std::max(maxPower, power[k]);
    }
    if (!(maxPower > 0.0F)) return out;
    const double floorPower = static_cast<double>(maxPower) * 1e-6;     // 60 dB under the strongest part
    double sumA = 0.0, sumFA = 0.0;
    for (std::size_t k = 1U; k < power.size(); ++k) {
        const double hz = static_cast<double>(k) * binHz;
        if (hz < lo || hz > hi || static_cast<double>(power[k]) < floorPower) continue;
        const double a = std::sqrt(static_cast<double>(power[k]));
        sumA += a;
        sumFA += a * hz;
    }
    if (!(sumA > 0.0)) return out;
    out.brightness = (sumFA / sumA) / f0;
    out.valid = out.brightness > 0.0;
    return out;
}

// Would `cover`, shifted to the key of `target`, sound like `target`?
ThinDifference compareFeatures(const Features& cover, int coverKey, double coverCents,
                               const Features& target, int targetKey, double targetCents) {
    if (!cover.valid || !target.valid) return ThinDifference::Unknown;
    if (std::fabs(cover.levelDb - target.levelDb) > kLevelDb) return ThinDifference::Level;
    if (std::fabs(coverCents - targetCents) > kTuningCents) return ThinDifference::Tuning;

    const double a = cover.decaySec * std::pow(2.0, -static_cast<double>(targetKey - coverKey) / 12.0);
    const double b = target.decaySec;
    bool decayOk = true;
    if (cover.sustained && target.sustained) decayOk = true;
    else if (cover.sustained) decayOk = b * kDecayRatio >= a;
    else if (target.sustained) decayOk = a * kDecayRatio >= b;
    else decayOk = std::max(a, b) / std::min(a, b) <= kDecayRatio;
    if (!decayOk) return ThinDifference::Decay;

    if (std::max(cover.brightness, target.brightness) / std::min(cover.brightness, target.brightness) > kBrightnessRatio) {
        return ThinDifference::Brightness;
    }
    return ThinDifference::None;
}

struct Note {
    int key{0};
    std::vector<std::size_t> members;   // entries of the plan on this note, quietest first (the velocity layers)
    bool clear{true};                   // every member was heard with a sure pitch
};

} // namespace

std::vector<ThinDecision> KeyThinner::decide(const BankProject& project, const AutoMapPlan& plan, ThinMode mode,
                                             ThinMemory* memory) {
    const std::size_t entryCount = plan.entries.size();
    std::vector<ThinDecision> out(entryCount);       // every entry starts as "KeepAll"
    if (entryCount == 0U || mode == ThinMode::EveryKey) return out;

    std::map<int, std::vector<std::size_t>> byKey;
    for (std::size_t i = 0U; i < entryCount; ++i) byKey[std::max(0, std::min(127, plan.entries[i].rootKey))].push_back(i);
    std::vector<Note> notes;
    notes.reserve(byKey.size());
    for (auto& pair : byKey) {
        Note note;
        note.key = pair.first;
        note.members = pair.second;
        std::sort(note.members.begin(), note.members.end(), [&](std::size_t a, std::size_t b) {
            if (plan.entries[a].peak != plan.entries[b].peak) return plan.entries[a].peak < plan.entries[b].peak;
            return plan.entries[a].name < plan.entries[b].name;
        });
        for (std::size_t m : note.members) {
            if (!plan.entries[m].heard || plan.entries[m].confidence < kClearConfidence) note.clear = false;
        }
        notes.push_back(std::move(note));
    }
    const std::size_t count = notes.size();
    const int step = mode == ThinMode::EveryTwo ? 2 : 3;
    const bool listening = mode == ThinMode::Decide;

    // ---- what the notes sound like: measured only when it is needed, once per sample
    std::vector<std::vector<Features>> features(count);
    std::vector<bool> measured(count, false);
    auto featuresOf = [&](std::size_t n) -> const std::vector<Features>& {
        if (!measured[n]) {
            measured[n] = true;
            for (std::size_t m : notes[n].members) {
                const AutoMapEntry& entry = plan.entries[m];
                if (entry.sampleIndex >= project.samples.size()) { features[n].push_back(Features{}); continue; }
                const std::pair<std::size_t, int> where(entry.sampleIndex, notes[n].key);
                if (memory != nullptr) {
                    const auto known = memory->features.find(where);
                    if (known != memory->features.end()) { features[n].push_back(known->second); continue; }
                }
                const Features got = measure(project.samples[entry.sampleIndex], hzOf(notes[n].key, static_cast<double>(entry.cents)));
                if (memory != nullptr) memory->features[where] = got;
                features[n].push_back(got);
            }
        }
        return features[n];
    };
    std::map<std::pair<std::size_t, std::size_t>, ThinDifference> memo;
    // would the sample of note `cover` do for note `target`? (all velocity layers, one against one)
    auto difference = [&](std::size_t cover, std::size_t target) -> ThinDifference {
        const auto key = std::make_pair(cover, target);
        const auto found = memo.find(key);
        if (found != memo.end()) return found->second;
        ThinDifference result = ThinDifference::None;
        const std::vector<Features>& a = featuresOf(cover);
        const std::vector<Features>& b = featuresOf(target);
        for (std::size_t l = 0U; l < notes[cover].members.size() && l < notes[target].members.size(); ++l) {
            if (l >= a.size() || l >= b.size()) { result = ThinDifference::Unknown; break; }
            const ThinDifference d = compareFeatures(a[l], notes[cover].key, static_cast<double>(plan.entries[notes[cover].members[l]].cents),
                                                     b[l], notes[target].key, static_cast<double>(plan.entries[notes[target].members[l]].cents));
            if (d != ThinDifference::None) { result = d; break; }
        }
        memo[key] = result;
        return result;
    };

    // ---- the verdict per note
    std::vector<bool> dropNote(count, false);
    std::vector<std::size_t> coveredBy(count, 0U);
    std::vector<ThinReason> reason(count, ThinReason::KeepSpread);
    std::vector<ThinDifference> why(count, ThinDifference::None);

    std::size_t t = 0U;
    while (t < count) {
        if (!notes[t].clear) { reason[t] = ThinReason::KeepUnclear; ++t; continue; }
        // a run of clear notes with the same number of layers: nothing is moved across its ends
        std::size_t u = t;
        while (u + 1U < count && notes[u + 1U].clear && notes[u + 1U].members.size() == notes[t].members.size()) ++u;
        const std::size_t first = t, length = u - t + 1U;

        // fewest samples that still cover every key within `step`, then the most even spread
        constexpr long long kNone = std::numeric_limits<long long>::max();
        std::vector<long long> used(length, kNone), squares(length, kNone);
        std::vector<std::size_t> from(length, 0U);
        used[0] = 1;
        squares[0] = 0;
        for (std::size_t j = 1U; j < length; ++j) {
            for (std::size_t back = 1U; back <= j; ++back) {
                const std::size_t i = j - back;
                const int gap = notes[first + j].key - notes[first + i].key;
                if (back > 1U && gap > step) break;                   // keys only grow further apart from here
                if (used[i] == kNone) continue;
                if (back > 1U && listening) {                         // the notes in between must sound like their cover
                    bool ok = true;
                    for (std::size_t k = i + 1U; k < j && ok; ++k) {
                        const bool lowCovers = notes[first + k].key - notes[first + i].key <= notes[first + j].key - notes[first + k].key;
                        ok = difference(first + (lowCovers ? i : j), first + k) == ThinDifference::None;
                    }
                    if (!ok) continue;
                }
                const long long total = used[i] + 1, spread = squares[i] + static_cast<long long>(gap) * gap;
                if (total < used[j] || (total == used[j] && spread < squares[j])) {
                    used[j] = total;
                    squares[j] = spread;
                    from[j] = i;
                }
            }
        }
        // walk back from the last note of the run: those are the notes that stay
        std::vector<bool> stays(length, false);
        for (std::size_t j = length - 1U;; j = from[j]) {
            stays[j] = true;
            if (j == 0U) break;
        }
        for (std::size_t j = 0U; j < length; ++j) {
            if (stays[j]) continue;
            std::size_t low = j, high = j;
            while (low > 0U && !stays[low]) --low;
            while (high + 1U < length && !stays[high]) ++high;
            const bool lowCovers = notes[first + j].key - notes[first + low].key <= notes[first + high].key - notes[first + j].key;
            dropNote[first + j] = true;
            coveredBy[first + j] = first + (lowCovers ? low : high);
            reason[first + j] = listening ? ThinReason::DropSimilar : ThinReason::DropCovered;
        }
        // why the others stay
        std::vector<bool> covers(count, false);
        for (std::size_t j = 0U; j < length; ++j) if (dropNote[first + j]) covers[coveredBy[first + j]] = true;
        for (std::size_t j = 0U; j < length; ++j) {
            const std::size_t n = first + j;
            if (!stays[j]) continue;
            if (covers[n]) { reason[n] = ThinReason::KeepCovers; continue; }
            if (n == 0U || n + 1U == count) { reason[n] = ThinReason::KeepEdge; continue; }
            if (j == 0U || j + 1U == length) { reason[n] = ThinReason::KeepNextToOdd; continue; }
            reason[n] = ThinReason::KeepSpread;
            if (listening && notes[n + 1U].key - notes[n - 1U].key <= step) {
                // it could have gone by the keys alone: the neighbours sound different
                ThinDifference d = difference(n - 1U, n);
                if (d == ThinDifference::None) d = difference(n + 1U, n);
                if (d != ThinDifference::None) { reason[n] = ThinReason::KeepDifferent; why[n] = d; }
            }
        }
        t = u + 1U;
    }

    for (std::size_t n = 0U; n < count; ++n) {
        for (std::size_t m : notes[n].members) {
            ThinDecision& decision = out[m];
            decision.drop = dropNote[n];
            decision.reason = reason[n];
            decision.difference = why[n];
            decision.coveredBy = dropNote[n] ? notes[coveredBy[n]].key : -1;
        }
    }
    return out;
}

ThinSummary KeyThinner::summarize(const BankProject& project, const AutoMapPlan& plan, const std::vector<ThinDecision>& decisions) {
    ThinSummary sum;
    std::set<int> seen;
    for (std::size_t i = 0U; i < plan.entries.size() && i < decisions.size(); ++i) {
        const AutoMapEntry& entry = plan.entries[i];
        const ThinDecision& decision = decisions[i];
        std::uint64_t bytes = 0U;
        if (entry.sampleIndex < project.samples.size()) bytes = project.samples[entry.sampleIndex].audioData.size();
        ++sum.samples;
        sum.bytesAll += bytes;
        if (decision.drop) { ++sum.samplesDropped; sum.bytesDropped += bytes; }
        const int key = std::max(0, std::min(127, entry.rootKey));
        if (!seen.insert(key).second) continue;                         // count a note once, not once per layer
        ++sum.notes;
        if (decision.drop) ++sum.notesDropped;
        if (decision.reason == ThinReason::KeepSpread) ++sum.notesSpread;
        if (decision.reason == ThinReason::KeepUnclear) ++sum.notesUnclear;
    }
    return sum;
}

} // namespace silveton::manager
