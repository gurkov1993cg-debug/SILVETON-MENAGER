#include "silveton/manager/ObjectManager.h"

#include <set>
#include <algorithm>
#include <cstdlib>
#include <limits>
#include <sstream>
#include <unordered_set>
#include <vector>

namespace silveton::manager {
namespace {

bool addressUsed(const BankProject& project, std::uint16_t bank, std::uint16_t page, std::uint16_t slot) noexcept {
    for (const auto& sound : project.sounds) {
        if (sound.bank == bank && sound.page == page && sound.slot == slot) return true;
    }
    return false;
}

bool positionUsed(const BankProject& project, std::uint16_t position) noexcept {
    for (const auto& sound : project.sounds) if (sound.position == position) return true;
    return false;
}

std::uint32_t nextSampleId(const BankProject& project) noexcept {
    std::uint32_t maxId = 0U;
    for (const auto& sample : project.samples) maxId = std::max(maxId, sample.sampleId);
    return maxId == std::numeric_limits<std::uint32_t>::max() ? 0U : maxId + 1U;
}

std::uint32_t nextMultisampleId(const BankProject& project) noexcept {
    std::uint32_t maxId = 0U;
    for (const auto& ms : project.multisamples) maxId = std::max(maxId, ms.multisampleId);
    return maxId == std::numeric_limits<std::uint32_t>::max() ? 0U : maxId + 1U;
}

bool nextAddress(std::uint16_t& bank, std::uint16_t& page, std::uint16_t& slot) noexcept {
    if (slot < 127U) { ++slot; return true; }
    slot = 0U;
    if (page < 127U) { ++page; return true; }
    page = 0U;
    if (bank < 127U) { ++bank; return true; }
    return false;
}

template <typename Container>
bool nameExists(const Container& container, const std::string& name) {
    return std::any_of(container.begin(), container.end(), [&](const auto& item) { return item.name == name; });
}

} // namespace

bool ObjectManager::validName(const std::string& name) noexcept {
    return std::any_of(name.begin(), name.end(), [](unsigned char c) { return c > 32U; });
}

std::string ObjectManager::uniqueName(const std::string& base, const BankProject& project, int kind) {
    const std::string stem = validName(base) ? base : std::string("Copy");
    auto exists = [&](const std::string& candidate) {
        if (kind == 0) return nameExists(project.samples, candidate);
        if (kind == 1) return nameExists(project.multisamples, candidate);
        return nameExists(project.sounds, candidate);
    };
    std::string candidate = stem + " Copy";
    if (!exists(candidate)) return candidate;
    for (std::size_t i = 2U; i < 100000U; ++i) {
        candidate = stem + " Copy " + std::to_string(i);
        if (!exists(candidate)) return candidate;
    }
    return stem + " Copy Unique";
}

// SILVETON_UNIQUE_SOUND_NAME_V1
std::string ObjectManager::uniqueSoundName(const BankProject& project, const std::string& wanted, std::size_t ignoreIndex) {
    auto taken = [&](const std::string& candidate) {
        for (std::size_t i = 0U; i < project.sounds.size(); ++i) {
            if (i != ignoreIndex && project.sounds[i].name == candidate) return true;
        }
        return false;
    };
    if (!taken(wanted)) return wanted;
    // "Piano" -> "Piano 2", "Piano 3" ...; a name that already ends with " <number>" counts on from it.
    std::string stem = wanted;
    std::size_t next = 2U;
    const std::size_t space = wanted.find_last_of(' ');
    if (space != std::string::npos && space > 0U && space + 1U < wanted.size() && wanted.size() - space - 1U <= 6U) {
        bool digits = true;
        for (std::size_t i = space + 1U; i < wanted.size(); ++i) {
            if (wanted[i] < '0' || wanted[i] > '9') { digits = false; break; }
        }
        const std::string head = wanted.substr(0U, space);
        if (digits && validName(head)) {
            stem = head;
            next = static_cast<std::size_t>(std::strtoul(wanted.c_str() + space + 1U, nullptr, 10)) + 1U;
        }
    }
    for (std::size_t n = next; n < next + 100000U; ++n) {
        const std::string candidate = stem + " " + std::to_string(n);
        if (!taken(candidate)) return candidate;
    }
    return wanted + " Unique";
}

namespace {

bool sameLoop(const LoopRegion& a, const LoopRegion& b) noexcept {
    return a.enabled == b.enabled && a.startFrame == b.startFrame && a.endFrame == b.endFrame &&
           a.crossfadeFrames == b.crossfadeFrames;
}

bool sameSampleAudio(const BankProject& project, std::uint32_t ia, std::uint32_t ib) {
    if (ia >= project.samples.size() || ib >= project.samples.size()) return false;
    if (ia == ib) return true;
    const ImportedSample& a = project.samples[ia];
    const ImportedSample& b = project.samples[ib];
    return a.sampleRate == b.sampleRate && a.channels == b.channels && a.encoding == b.encoding &&
           a.bitsPerSample == b.bitsPerSample && a.totalFrames == b.totalFrames && a.rootKey == b.rootKey &&
           a.fineTuneCents == b.fineTuneCents && sameLoop(a.loop, b.loop) && a.audioData == b.audioData;
}

bool sameZone(const BankProject& project, const ImportedZone& a, const ImportedZone& b) {
    return a.keyLow == b.keyLow && a.keyHigh == b.keyHigh && a.velocityLow == b.velocityLow &&
           a.velocityHigh == b.velocityHigh && a.rootKey == b.rootKey &&
           a.transposeSemitones == b.transposeSemitones && a.tuneCents == b.tuneCents &&
           a.gainDb == b.gainDb && a.pan == b.pan && a.oneShot == b.oneShot && a.reverse == b.reverse &&
           a.nonTranspose == b.nonTranspose && sameSampleAudio(project, a.sampleIndex, b.sampleIndex);
}

} // namespace

// SILVETON_SAME_BLENDS_V1
bool ObjectManager::soundsSameContent(const BankProject& project, std::size_t a, std::size_t b) {
    if (a >= project.sounds.size() || b >= project.sounds.size()) return false;
    if (a == b) return true;
    const SoundDefinition& sa = project.sounds[a];
    const SoundDefinition& sb = project.sounds[b];
    if (sa.layers.empty() || sa.layers.size() != sb.layers.size()) return false;
    for (std::size_t k = 0U; k < sa.layers.size(); ++k) {
        const SoundLayer& la = sa.layers[k];
        const SoundLayer& lb = sb.layers[k];
        if (la.enabled != lb.enabled || la.keyLow != lb.keyLow || la.keyHigh != lb.keyHigh ||
            la.velocityLow != lb.velocityLow || la.velocityHigh != lb.velocityHigh ||
            la.transposeSemitones != lb.transposeSemitones || la.tuneCents != lb.tuneCents ||
            la.levelDb != lb.levelDb || la.pan != lb.pan) return false;
        if (la.multisampleIndex >= project.multisamples.size() || lb.multisampleIndex >= project.multisamples.size()) return false;
        if (la.multisampleIndex == lb.multisampleIndex) continue;
        const ImportedMultisample& ma = project.multisamples[la.multisampleIndex];
        const ImportedMultisample& mb = project.multisamples[lb.multisampleIndex];
        if (ma.zones.empty() || ma.zones.size() != mb.zones.size()) return false;
        for (std::size_t z = 0U; z < ma.zones.size(); ++z) {
            if (!sameZone(project, ma.zones[z], mb.zones[z])) return false;
        }
    }
    return true;
}

// SILVETON_SAME_BLENDS_V1
std::vector<std::vector<std::size_t>> ObjectManager::findSameSounds(const BankProject& project) {
    std::vector<std::vector<std::size_t>> groups;
    std::vector<std::size_t> firstOf;                 // first member of every group, to compare against
    for (std::size_t i = 0U; i < project.sounds.size(); ++i) {
        bool placed = false;
        for (std::size_t g = 0U; g < groups.size(); ++g) {
            if (soundsSameContent(project, firstOf[g], i)) { groups[g].push_back(i); placed = true; break; }
        }
        if (!placed) { groups.push_back({i}); firstOf.push_back(i); }
    }
    groups.erase(std::remove_if(groups.begin(), groups.end(),
                                [](const std::vector<std::size_t>& g) { return g.size() < 2U; }),
                 groups.end());
    return groups;
}

ObjectManager::NewSoundsReport ObjectManager::settleNewSounds(BankProject& project, std::size_t firstNewSound) {
    NewSoundsReport report;
    for (std::size_t i = firstNewSound; i < project.sounds.size(); ++i) {
        const std::string name = project.sounds[i].name;
        bool taken = false;                           // only a blend in front of it counts, so the first one keeps the name
        for (std::size_t j = 0U; j < i && !taken; ++j) taken = project.sounds[j].name == name;
        if (!taken) continue;
        const std::string fresh = uniqueSoundName(project, name, i);
        project.sounds[i].name = fresh;
        report.renamed.push_back(name + " -> " + fresh);
    }
    return report;
}

bool ObjectManager::assignNextFreeSoundAddress(BankProject& project, SoundDefinition& sound, std::string& error) {
    std::uint16_t bank = sound.bank;
    std::uint16_t page = sound.page;
    std::uint16_t slot = sound.slot;
    do {
        if (!addressUsed(project, bank, page, slot)) {
            sound.bank = bank;
            sound.page = page;
            sound.slot = slot;
            error.clear();
            return true;
        }
    } while (nextAddress(bank, page, slot));
    error = "No free Bank/Page/Slot address is available.";
    return false;
}


bool ObjectManager::assignNextFreeSoundPosition(BankProject& project, SoundDefinition& sound, std::string& error) {
    for (std::uint16_t position = kMinSoundPosition; position <= kMaxSoundPosition; ++position) {
        if (!positionUsed(project, position)) {
            sound.position = position;
            error.clear();
            return true;
        }
    }
    error = "No free SILVETON SOUND position is available (1...500).";
    return false;
}

bool ObjectManager::renameSample(BankProject& project, std::size_t sampleIndex, const std::string& name, std::string& error) {
    if (sampleIndex >= project.samples.size()) { error = "Invalid sample index."; return false; }
    if (!validName(name)) { error = "Sample name cannot be empty."; return false; }
    project.samples[sampleIndex].name = name;
    error.clear();
    return true;
}

bool ObjectManager::duplicateSample(BankProject& project, std::size_t sampleIndex, std::size_t& createdIndex, std::string& error) {
    if (sampleIndex >= project.samples.size()) { error = "Invalid sample index."; return false; }
    ImportedSample copy = project.samples[sampleIndex];
    copy.sampleId = nextSampleId(project);
    if (copy.sampleId == 0U) { error = "No free SampleID is available."; return false; }
    copy.name = uniqueName(copy.name, project, 0);
    copy.sourceIdentity += ":copy:" + std::to_string(project.samples.size());
    createdIndex = project.samples.size();
    project.samples.push_back(std::move(copy));
    error.clear();
    return true;
}

bool ObjectManager::deleteSampleCascade(BankProject& project, std::size_t sampleIndex, DeleteImpact& impact, std::string& error) {
    impact = DeleteImpact{};
    if (sampleIndex >= project.samples.size()) { error = "Invalid sample index."; return false; }

    project.samples.erase(project.samples.begin() + static_cast<std::ptrdiff_t>(sampleIndex));
    impact.samplesRemoved = 1U;

    std::vector<bool> removeMultisample(project.multisamples.size(), false);
    for (std::size_t m = 0U; m < project.multisamples.size(); ++m) {
        auto& zones = project.multisamples[m].zones;
        const std::size_t before = zones.size();
        zones.erase(std::remove_if(zones.begin(), zones.end(), [sampleIndex](const ImportedZone& zone) {
            return zone.sampleIndex == sampleIndex;
        }), zones.end());
        impact.zonesRemoved += before - zones.size();
        for (auto& zone : zones) {
            if (zone.sampleIndex > sampleIndex) --zone.sampleIndex;
        }
        if (zones.empty()) removeMultisample[m] = true;
    }

    std::vector<std::uint32_t> map(project.multisamples.size(), std::numeric_limits<std::uint32_t>::max());
    std::vector<ImportedMultisample> kept;
    kept.reserve(project.multisamples.size());
    for (std::size_t old = 0U; old < project.multisamples.size(); ++old) {
        if (removeMultisample[old]) { ++impact.multisamplesRemoved; continue; }
        map[old] = static_cast<std::uint32_t>(kept.size());
        kept.push_back(std::move(project.multisamples[old]));
    }
    project.multisamples = std::move(kept);

    std::vector<SoundDefinition> keptSounds;
    keptSounds.reserve(project.sounds.size());
    for (auto& sound : project.sounds) {
        const std::size_t before = sound.layers.size();
        sound.layers.erase(std::remove_if(sound.layers.begin(), sound.layers.end(), [&](SoundLayer& layer) {
            if (layer.multisampleIndex >= map.size()) return true;
            const std::uint32_t mapped = map[layer.multisampleIndex];
            if (mapped == std::numeric_limits<std::uint32_t>::max()) return true;
            layer.multisampleIndex = mapped;
            return false;
        }), sound.layers.end());
        impact.layersRemoved += before - sound.layers.size();
        if (sound.layers.empty()) { ++impact.soundsRemoved; continue; }
        keptSounds.push_back(std::move(sound));
    }
    project.sounds = std::move(keptSounds);
    error.clear();
    return true;
}

bool ObjectManager::renameMultisample(BankProject& project, std::size_t multisampleIndex, const std::string& name, std::string& error) {
    if (multisampleIndex >= project.multisamples.size()) { error = "Invalid multisample index."; return false; }
    if (!validName(name)) { error = "Multisample name cannot be empty."; return false; }
    project.multisamples[multisampleIndex].name = name;
    error.clear();
    return true;
}

bool ObjectManager::duplicateMultisample(BankProject& project, std::size_t multisampleIndex, std::size_t& createdIndex, std::string& error) {
    if (multisampleIndex >= project.multisamples.size()) { error = "Invalid multisample index."; return false; }
    ImportedMultisample copy = project.multisamples[multisampleIndex];
    copy.multisampleId = nextMultisampleId(project);
    if (copy.multisampleId == 0U) { error = "No free MultisampleID is available."; return false; }
    copy.name = uniqueName(copy.name, project, 1);
    copy.sourceIdentity += ":copy:" + std::to_string(project.multisamples.size());
    createdIndex = project.multisamples.size();
    project.multisamples.push_back(std::move(copy));
    error.clear();
    return true;
}

bool ObjectManager::deleteMultisampleCascade(BankProject& project, std::size_t multisampleIndex, DeleteImpact& impact, std::string& error) {
    impact = DeleteImpact{};
    if (multisampleIndex >= project.multisamples.size()) { error = "Invalid multisample index."; return false; }
    project.multisamples.erase(project.multisamples.begin() + static_cast<std::ptrdiff_t>(multisampleIndex));
    impact.multisamplesRemoved = 1U;

    std::vector<SoundDefinition> keptSounds;
    keptSounds.reserve(project.sounds.size());
    for (auto& sound : project.sounds) {
        const std::size_t before = sound.layers.size();
        sound.layers.erase(std::remove_if(sound.layers.begin(), sound.layers.end(), [multisampleIndex](const SoundLayer& layer) {
            return layer.multisampleIndex == multisampleIndex;
        }), sound.layers.end());
        impact.layersRemoved += before - sound.layers.size();
        for (auto& layer : sound.layers) {
            if (layer.multisampleIndex > multisampleIndex) --layer.multisampleIndex;
        }
        if (sound.layers.empty()) { ++impact.soundsRemoved; continue; }
        keptSounds.push_back(std::move(sound));
    }
    project.sounds = std::move(keptSounds);
    error.clear();
    return true;
}

bool ObjectManager::renameSound(BankProject& project, std::size_t soundIndex, const std::string& name, std::string& error) {
    if (soundIndex >= project.sounds.size()) { error = "Invalid SOUND index."; return false; }
    if (!validName(name)) { error = "SOUND name cannot be empty."; return false; }
    project.sounds[soundIndex].name = uniqueSoundName(project, name, soundIndex);   // SILVETON_UNIQUE_SOUND_NAME_V1
    error.clear();
    return true;
}

bool ObjectManager::createSoundFromMultisample(BankProject& project, std::size_t multisampleIndex, const std::string& name, std::size_t& createdIndex, std::string& error) {
    if (multisampleIndex >= project.multisamples.size()) { error = "Invalid multisample index."; return false; }
    SoundDefinition sound{};
    sound.name = uniqueSoundName(project, validName(name) ? name : project.multisamples[multisampleIndex].name);   // SILVETON_UNIQUE_SOUND_NAME_V1
    SoundLayer layer{};
    layer.multisampleIndex = static_cast<std::uint32_t>(multisampleIndex);
    sound.layers.push_back(layer);
    if (!assignNextFreeSoundPosition(project, sound, error)) return false;
    if (!assignNextFreeSoundAddress(project, sound, error)) return false;
    createdIndex = project.sounds.size();
    project.sounds.push_back(std::move(sound));
    error.clear();
    return true;
}

bool ObjectManager::duplicateSound(BankProject& project, std::size_t soundIndex, std::size_t& createdIndex, std::string& error) {
    if (soundIndex >= project.sounds.size()) { error = "Invalid SOUND index."; return false; }
    SoundDefinition copy = project.sounds[soundIndex];
    copy.name = uniqueName(copy.name, project, 2);
    copy.position = 0U;
    if (!assignNextFreeSoundPosition(project, copy, error)) return false;
    if (!nextAddress(copy.bank, copy.page, copy.slot)) {
        copy.bank = 0U; copy.page = 0U; copy.slot = 0U;
    }
    if (!assignNextFreeSoundAddress(project, copy, error)) return false;
    createdIndex = project.sounds.size();
    project.sounds.push_back(std::move(copy));
    error.clear();
    return true;
}

bool ObjectManager::deleteSound(BankProject& project, std::size_t soundIndex, DeleteImpact& impact, std::string& error) {
    impact = DeleteImpact{};
    if (soundIndex >= project.sounds.size()) { error = "Invalid SOUND index."; return false; }
    project.sounds.erase(project.sounds.begin() + static_cast<std::ptrdiff_t>(soundIndex));
    impact.soundsRemoved = 1U;
    error.clear();
    return true;
}

bool ObjectManager::planSoundContent(const BankProject& project, std::size_t soundIndex,
                                     std::vector<std::size_t>& multisamples, std::vector<std::size_t>& samples,
                                     DeleteImpact& impact, std::string& error) {
    impact = DeleteImpact{};
    multisamples.clear();
    samples.clear();
    if (soundIndex >= project.sounds.size()) { error = "Invalid SOUND index."; return false; }
    const SoundDefinition& sound = project.sounds[soundIndex];

    // multisamples of this SOUND that no other SOUND uses
    std::set<std::size_t> mine;
    for (const auto& layer : sound.layers) {
        if (layer.multisampleIndex < project.multisamples.size()) mine.insert(layer.multisampleIndex);
    }
    std::set<std::size_t> sharedMs;
    for (std::size_t si = 0U; si < project.sounds.size(); ++si) {
        if (si == soundIndex) continue;
        for (const auto& layer : project.sounds[si].layers) sharedMs.insert(layer.multisampleIndex);
    }
    std::set<std::size_t> goMs;
    for (std::size_t m : mine) if (sharedMs.count(m) == 0U) goMs.insert(m);

    // samples inside those multisamples that no staying multisample uses
    std::set<std::size_t> candidates;
    for (std::size_t m : goMs) {
        for (const auto& zone : project.multisamples[m].zones) {
            if (zone.sampleIndex < project.samples.size()) candidates.insert(zone.sampleIndex);
        }
        impact.zonesRemoved += project.multisamples[m].zones.size();
    }
    std::set<std::size_t> staying;
    for (std::size_t m = 0U; m < project.multisamples.size(); ++m) {
        if (goMs.count(m) != 0U) continue;
        for (const auto& zone : project.multisamples[m].zones) staying.insert(zone.sampleIndex);
    }
    for (std::size_t s : candidates) if (staying.count(s) == 0U) samples.push_back(s);
    multisamples.assign(goMs.begin(), goMs.end());

    impact.samplesRemoved = samples.size();
    impact.multisamplesRemoved = multisamples.size();
    impact.layersRemoved = sound.layers.size();
    impact.soundsRemoved = 1U;
    error.clear();
    return true;
}

bool ObjectManager::soundContent(const BankProject& project, std::size_t soundIndex, DeleteImpact& impact, std::string& error) {
    std::vector<std::size_t> ms, smp;
    return planSoundContent(project, soundIndex, ms, smp, impact, error);
}

bool ObjectManager::deleteSoundWithContent(BankProject& project, std::size_t soundIndex, DeleteImpact& impact, std::string& error) {
    std::vector<std::size_t> removeMs, removeSmp;
    if (!planSoundContent(project, soundIndex, removeMs, removeSmp, impact, error)) return false;

    project.sounds.erase(project.sounds.begin() + static_cast<std::ptrdiff_t>(soundIndex));

    // multisamples: drop and remap the layers of the SOUNDs that stay
    const std::set<std::size_t> dropMs(removeMs.begin(), removeMs.end());
    std::vector<std::uint32_t> msMap(project.multisamples.size(), 0U);
    std::vector<ImportedMultisample> keptMs;
    keptMs.reserve(project.multisamples.size());
    for (std::size_t m = 0U; m < project.multisamples.size(); ++m) {
        if (dropMs.count(m) != 0U) continue;
        msMap[m] = static_cast<std::uint32_t>(keptMs.size());
        keptMs.push_back(std::move(project.multisamples[m]));
    }
    project.multisamples = std::move(keptMs);
    for (auto& s : project.sounds) {
        for (auto& layer : s.layers) {
            if (layer.multisampleIndex < msMap.size()) layer.multisampleIndex = msMap[layer.multisampleIndex];
        }
    }

    // samples: drop and remap the zones that stay
    const std::set<std::size_t> dropSmp(removeSmp.begin(), removeSmp.end());
    std::vector<std::uint32_t> smpMap(project.samples.size(), 0U);
    std::vector<ImportedSample> keptSmp;
    keptSmp.reserve(project.samples.size());
    for (std::size_t i = 0U; i < project.samples.size(); ++i) {
        if (dropSmp.count(i) != 0U) continue;
        smpMap[i] = static_cast<std::uint32_t>(keptSmp.size());
        keptSmp.push_back(std::move(project.samples[i]));
    }
    project.samples = std::move(keptSmp);
    for (auto& ms : project.multisamples) {
        for (auto& zone : ms.zones) {
            if (zone.sampleIndex < smpMap.size()) zone.sampleIndex = smpMap[zone.sampleIndex];
        }
    }
    error.clear();
    return true;
}

} // namespace silveton::manager
