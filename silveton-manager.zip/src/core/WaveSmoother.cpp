// SILVETON_CLEANWAVE_V1 - see include/silveton/manager/WaveSmoother.h
#include "silveton/manager/WaveSmoother.h"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <limits>
#include <string>
#include <vector>

namespace silveton::manager {
namespace {

constexpr double kPi = 3.14159265358979323846;

std::size_t bytesPerSample(AudioEncoding encoding) noexcept {
    switch (encoding) {
        case AudioEncoding::Pcm16LE: return 2U;
        case AudioEncoding::Pcm24LE: return 3U;
        case AudioEncoding::Float32LE: return 4U;
    }
    return 0U;
}

std::size_t frameBytes(const ImportedSample& sample) noexcept {
    return static_cast<std::size_t>(sample.channels) * bytesPerSample(sample.encoding);
}

// the same reading and writing the sample editor uses, so a cleaned sample stays bit-for-bit comparable
float readScalar(const std::uint8_t* p, AudioEncoding encoding) noexcept {
    switch (encoding) {
        case AudioEncoding::Pcm16LE: {
            const std::uint16_t raw = static_cast<std::uint16_t>(p[0]) |
                                      static_cast<std::uint16_t>(static_cast<std::uint16_t>(p[1]) << 8U);
            const std::int16_t value = static_cast<std::int16_t>(raw);
            return value < 0 ? static_cast<float>(value) / 32768.0F : static_cast<float>(value) / 32767.0F;
        }
        case AudioEncoding::Pcm24LE: {
            std::int32_t value = static_cast<std::int32_t>(p[0]) |
                                 (static_cast<std::int32_t>(p[1]) << 8) |
                                 (static_cast<std::int32_t>(p[2]) << 16);
            if ((value & 0x00800000) != 0) value |= static_cast<std::int32_t>(0xFF000000U);
            return value < 0 ? static_cast<float>(value) / 8388608.0F : static_cast<float>(value) / 8388607.0F;
        }
        case AudioEncoding::Float32LE: {
            const std::uint32_t raw = static_cast<std::uint32_t>(p[0]) |
                                      (static_cast<std::uint32_t>(p[1]) << 8U) |
                                      (static_cast<std::uint32_t>(p[2]) << 16U) |
                                      (static_cast<std::uint32_t>(p[3]) << 24U);
            float value = 0.0F;
            std::memcpy(&value, &raw, sizeof(value));
            return std::isfinite(value) ? value : 0.0F;
        }
    }
    return 0.0F;
}

void writeScalar(std::uint8_t* p, AudioEncoding encoding, float input) noexcept {
    const float value = std::max(-1.0F, std::min(1.0F, input));
    switch (encoding) {
        case AudioEncoding::Pcm16LE: {
            std::int32_t quantized = 0;
            if (value <= -1.0F) quantized = -32768;
            else if (value >= 1.0F) quantized = 32767;
            else if (value < 0.0F) quantized = static_cast<std::int32_t>(std::lround(static_cast<double>(value) * 32768.0));
            else quantized = static_cast<std::int32_t>(std::lround(static_cast<double>(value) * 32767.0));
            const std::uint16_t raw = static_cast<std::uint16_t>(static_cast<std::int16_t>(quantized));
            p[0] = static_cast<std::uint8_t>(raw & 0xFFU);
            p[1] = static_cast<std::uint8_t>((raw >> 8U) & 0xFFU);
            break;
        }
        case AudioEncoding::Pcm24LE: {
            std::int32_t quantized = 0;
            if (value <= -1.0F) quantized = -8388608;
            else if (value >= 1.0F) quantized = 8388607;
            else if (value < 0.0F) quantized = static_cast<std::int32_t>(std::lround(static_cast<double>(value) * 8388608.0));
            else quantized = static_cast<std::int32_t>(std::lround(static_cast<double>(value) * 8388607.0));
            const std::uint32_t raw = static_cast<std::uint32_t>(quantized);
            p[0] = static_cast<std::uint8_t>(raw & 0xFFU);
            p[1] = static_cast<std::uint8_t>((raw >> 8U) & 0xFFU);
            p[2] = static_cast<std::uint8_t>((raw >> 16U) & 0xFFU);
            break;
        }
        case AudioEncoding::Float32LE: {
            std::uint32_t raw = 0U;
            std::memcpy(&raw, &value, sizeof(raw));
            p[0] = static_cast<std::uint8_t>(raw & 0xFFU);
            p[1] = static_cast<std::uint8_t>((raw >> 8U) & 0xFFU);
            p[2] = static_cast<std::uint8_t>((raw >> 16U) & 0xFFU);
            p[3] = static_cast<std::uint8_t>((raw >> 24U) & 0xFFU);
            break;
        }
    }
}

// ---------------------------------------------------------------- small helpers

// three box passes = a soft, even curve (close to a bell), and it costs one walk per pass
std::vector<double> blur(const std::vector<double>& src, std::size_t radius) {
    if (radius < 1U || src.size() < 3U) return src;
    std::vector<double> cur = src, next(src.size(), 0.0);
    const std::ptrdiff_t r = static_cast<std::ptrdiff_t>(radius);
    const std::ptrdiff_t n = static_cast<std::ptrdiff_t>(src.size());
    for (int pass = 0; pass < 3; ++pass) {
        double sum = 0.0;
        for (std::ptrdiff_t i = 0; i < std::min(r, n); ++i) sum += cur[static_cast<std::size_t>(i)];
        for (std::ptrdiff_t i = 0; i < n; ++i) {
            const std::ptrdiff_t add = i + r, drop = i - r - 1;
            if (add < n) sum += cur[static_cast<std::size_t>(add)];
            if (drop >= 0) sum -= cur[static_cast<std::size_t>(drop)];
            const std::ptrdiff_t lo = std::max<std::ptrdiff_t>(0, i - r), hi = std::min(n - 1, i + r);
            next[static_cast<std::size_t>(i)] = sum / static_cast<double>(hi - lo + 1);
        }
        cur.swap(next);
    }
    return cur;
}

// radix-2 FFT in place
void fft(std::vector<double>& re, std::vector<double>& im, bool inverse) {
    const std::size_t n = re.size();
    for (std::size_t i = 0U, j = 0U; i + 1U < n; ++i) {
        if (i < j) { std::swap(re[i], re[j]); std::swap(im[i], im[j]); }
        std::size_t k = n >> 1U;
        while (k <= j) { j -= k; k >>= 1U; }
        j += k;
    }
    for (std::size_t len = 2U; len <= n; len <<= 1U) {
        const double ang = (inverse ? 2.0 : -2.0) * kPi / static_cast<double>(len);
        const double wr = std::cos(ang), wi = std::sin(ang);
        for (std::size_t i = 0U; i < n; i += len) {
            double cr = 1.0, ci = 0.0;
            for (std::size_t k = 0U; k < len / 2U; ++k) {
                const double ar = re[i + k], ai = im[i + k];
                const double br = re[i + k + len / 2U] * cr - im[i + k + len / 2U] * ci;
                const double bi = re[i + k + len / 2U] * ci + im[i + k + len / 2U] * cr;
                re[i + k] = ar + br; im[i + k] = ai + bi;
                re[i + k + len / 2U] = ar - br; im[i + k + len / 2U] = ai - bi;
                const double ncr = cr * wr - ci * wi;
                ci = cr * wi + ci * wr;
                cr = ncr;
            }
        }
    }
    if (inverse) {
        for (std::size_t i = 0U; i < n; ++i) { re[i] /= static_cast<double>(n); im[i] /= static_cast<double>(n); }
    }
}

// the note at every sample, read from the turning of the loudest low tone
std::vector<float> instantNote(const std::vector<float>& x, double rate) {
    const std::size_t n = x.size();
    std::size_t size = 1U;
    while (size < n) size <<= 1U;
    std::vector<double> re(size, 0.0), im(size, 0.0);
    for (std::size_t i = 0U; i < n; ++i) re[i] = static_cast<double>(x[i]);
    fft(re, im, false);

    const std::size_t lo = std::max<std::size_t>(1U, static_cast<std::size_t>(30.0 / rate * static_cast<double>(size)));
    const std::size_t hi = std::min(size / 2U - 1U, static_cast<std::size_t>(900.0 / rate * static_cast<double>(size)) + 1U);
    std::size_t bestBin = lo;
    double bestMag = 0.0;
    for (std::size_t i = lo; i <= hi; ++i) {
        const double mag = re[i] * re[i] + im[i] * im[i];
        if (mag > bestMag) { bestMag = mag; bestBin = i; }
    }
    if (bestMag <= 0.0) return {};
    const double rough = static_cast<double>(bestBin) / static_cast<double>(size) * rate;

    // the note may travel a long way (a kick), so keep the whole stretch of bins that still carry it
    const double floorMag = bestMag * 0.02;
    std::size_t from = bestBin, to = bestBin;
    while (from > lo && (re[from - 1U] * re[from - 1U] + im[from - 1U] * im[from - 1U]) > floorMag) --from;
    while (to < hi && (re[to + 1U] * re[to + 1U] + im[to + 1U] * im[to + 1U]) > floorMag) ++to;
    from = std::max<std::size_t>(1U, static_cast<std::size_t>(static_cast<double>(from) * 0.8));
    to = std::min(size / 2U - 1U, static_cast<std::size_t>(static_cast<double>(to) * 1.25) + 1U);
    for (std::size_t i = 0U; i < size; ++i) {
        if (i >= from && i <= to) { re[i] *= 2.0; im[i] *= 2.0; }
        else { re[i] = 0.0; im[i] = 0.0; }
    }
    fft(re, im, true);

    std::vector<double> amp(n, 0.0);
    double top = 0.0;
    for (std::size_t i = 0U; i < n; ++i) {
        amp[i] = std::sqrt(re[i] * re[i] + im[i] * im[i]);
        top = std::max(top, amp[i]);
    }
    std::vector<float> hz(n, static_cast<float>(rough));
    double last = 0.0, held = rough;
    for (std::size_t i = 0U; i < n; ++i) {
        const double ph = std::atan2(im[i], re[i]);
        double d = ph - last;
        last = ph;
        while (d > kPi) d -= 2.0 * kPi;
        while (d < -kPi) d += 2.0 * kPi;
        const double f = std::fabs(d) * rate / (2.0 * kPi);
        if (amp[i] > top * 0.02 && f > 20.0 && f < 1200.0) held = f;
        hz[i] = static_cast<float>(held);
    }
    return hz;
}

// spin the sample back by the note we think it has, smooth away everything else, and read the leftover turn
std::vector<float> refineNote(const std::vector<float>& x, const std::vector<float>& hz, double rate) {
    const std::size_t n = x.size();
    if (hz.size() != n) return hz;
    double mean = 0.0;
    for (float v : hz) mean += static_cast<double>(v);
    mean /= static_cast<double>(std::max<std::size_t>(1U, n));
    std::vector<double> zr(n, 0.0), zi(n, 0.0);
    double ph = 0.0;
    for (std::size_t i = 0U; i < n; ++i) {
        ph += 2.0 * kPi * static_cast<double>(hz[i]) / rate;
        zr[i] = static_cast<double>(x[i]) * std::cos(-ph);
        zi[i] = static_cast<double>(x[i]) * std::sin(-ph);
    }
    const std::size_t r = static_cast<std::size_t>(std::max(4.0, rate / std::max(20.0, mean) * 0.75));
    const std::vector<double> lr = blur(zr, r), li = blur(zi, r);
    std::vector<double> amp(n, 0.0);
    double top = 0.0;
    for (std::size_t i = 0U; i < n; ++i) { amp[i] = std::sqrt(lr[i] * lr[i] + li[i] * li[i]); top = std::max(top, amp[i]); }
    std::vector<float> out(n, 0.0F);
    double last = std::atan2(li.empty() ? 0.0 : li[0], lr.empty() ? 1.0 : lr[0]), held = 0.0;
    for (std::size_t i = 0U; i < n; ++i) {
        const double a = std::atan2(li[i], lr[i]);
        double d = a - last;
        last = a;
        while (d > kPi) d -= 2.0 * kPi;
        while (d < -kPi) d += 2.0 * kPi;
        const double corr = d * rate / (2.0 * kPi);
        if (amp[i] > top * 0.02 && std::fabs(corr) < static_cast<double>(hz[i]) * 0.6) held = corr;
        out[i] = static_cast<float>(std::max(20.0, std::min(1200.0, static_cast<double>(hz[i]) + held)));
    }
    return out;
}

std::vector<float> smoothTrack(const std::vector<float>& hz, std::size_t radius) {
    std::vector<double> d(hz.begin(), hz.end());
    const std::vector<double> s = blur(d, radius);
    std::vector<float> out(hz.size(), 0.0F);
    for (std::size_t i = 0U; i < hz.size(); ++i) out[i] = static_cast<float>(s[i]);
    return out;
}

// the note at every sample: read it on a four times slower copy (the note is low, nothing is lost)
std::vector<float> noteOf(const std::vector<float>& mono, double rate) {
    const std::size_t D = 4U;
    const std::size_t m = mono.size() / D;
    if (m < 64U) return {};
    std::vector<float> small(m, 0.0F);
    for (std::size_t i = 0U; i < m; ++i) {
        double sum = 0.0;
        for (std::size_t k = 0U; k < D; ++k) sum += static_cast<double>(mono[i * D + k]);
        small[i] = static_cast<float>(sum / static_cast<double>(D));
    }
    const double srate = rate / static_cast<double>(D);
    std::vector<float> hz = instantNote(small, srate);
    if (hz.empty()) return {};
    hz = smoothTrack(hz, static_cast<std::size_t>(srate * 0.005));
    hz = smoothTrack(refineNote(small, hz, srate), static_cast<std::size_t>(srate * 0.007));
    hz = smoothTrack(refineNote(small, hz, srate), static_cast<std::size_t>(srate * 0.007));
    std::vector<float> full(mono.size(), 0.0F);
    for (std::size_t i = 0U; i < mono.size(); ++i) {
        const double at = static_cast<double>(i) / static_cast<double>(D);
        const std::size_t a = static_cast<std::size_t>(at);
        const double f = at - static_cast<double>(a);
        full[i] = a + 1U < m ? static_cast<float>(hz[a] * (1.0 - f) + hz[a + 1U] * f) : hz[m - 1U];
    }
    return full;
}

// the clean curve a measured line is made of: c + a * e^(-t/T), by least squares over a ladder of T
std::vector<double> idealise(const std::vector<double>& src) {
    const std::size_t n = src.size();
    if (n < 3U) return src;
    std::vector<double> best = src;
    double bestErr = std::numeric_limits<double>::max();
    for (int step = 0; step <= 40; ++step) {
        const double tau = 0.01 * std::pow(200.0, static_cast<double>(step) / 40.0);
        double sE = 0.0, sEE = 0.0, sY = 0.0, sEY = 0.0;
        for (std::size_t i = 0U; i < n; ++i) {
            const double e = std::exp(-(static_cast<double>(i) / static_cast<double>(n - 1U)) / tau);
            sE += e; sEE += e * e; sY += src[i]; sEY += e * src[i];
        }
        const double count = static_cast<double>(n);
        const double det = sEE * count - sE * sE;
        if (std::fabs(det) < 1e-12) continue;
        const double a = (sEY * count - sE * sY) / det;
        const double c = (sEE * sY - sE * sEY) / det;
        std::vector<double> fit(n, 0.0);
        double err = 0.0;
        for (std::size_t i = 0U; i < n; ++i) {
            fit[i] = c + a * std::exp(-(static_cast<double>(i) / static_cast<double>(n - 1U)) / tau);
            const double d = fit[i] - src[i];
            err += d * d;
        }
        if (err < bestErr) { bestErr = err; best.swap(fit); }
    }
    return best;
}

// pull a measured line towards its clean curve
std::vector<float> straighten(const std::vector<float>& line, float amount, std::size_t points) {
    if (amount <= 0.0F || line.size() < 8U) return line;
    const std::size_t n = line.size();
    std::vector<double> small(points, 0.0);
    for (std::size_t k = 0U; k < points; ++k) {
        const std::size_t at = std::min(n - 1U, static_cast<std::size_t>((static_cast<double>(k) + 0.5) / static_cast<double>(points) * static_cast<double>(n)));
        small[k] = static_cast<double>(line[at]);
    }
    const std::vector<double> fit = idealise(small);
    for (std::size_t k = 0U; k < points; ++k) small[k] = small[k] * (1.0 - amount) + fit[k] * amount;
    std::vector<float> out(n, 0.0F);
    for (std::size_t i = 0U; i < n; ++i) {
        const double x = static_cast<double>(i) / static_cast<double>(n) * static_cast<double>(points - 1U);
        const std::size_t a = static_cast<std::size_t>(x);
        const double f = x - static_cast<double>(a);
        out[i] = a + 1U < points ? static_cast<float>(small[a] * (1.0 - f) + small[a + 1U] * f) : static_cast<float>(small[points - 1U]);
    }
    return out;
}

double peakOf(const std::vector<float>& x) {
    double p = 0.0;
    for (float v : x) p = std::max(p, static_cast<double>(std::fabs(v)));
    return p;
}

// average every cycle with the ones beside it: what repeats stays, what does not repeat cancels
std::vector<float> averageCycles(const std::vector<float>& x, const std::vector<float>& hz, double rate, int cycles) {
    const std::size_t n = x.size();
    if (cycles < 1 || hz.size() != n) return x;
    std::vector<double> pos(n, 0.0);
    double ph = 0.0;
    for (std::size_t i = 0U; i < n; ++i) { ph += static_cast<double>(hz[i]) / rate; pos[i] = ph; }
    const double total = pos[n - 1U];
    if (total < 3.0) return x;

    std::vector<double> abs(n, 0.0);
    for (std::size_t i = 0U; i < n; ++i) abs[i] = std::fabs(static_cast<double>(x[i]));
    std::vector<double> env = blur(abs, std::max<std::size_t>(8U, static_cast<std::size_t>(rate * 0.006)));
    for (double& v : env) v = std::max(v, 1e-6);

    const std::size_t stepsPerCycle = 512U;
    const std::size_t tableSize = static_cast<std::size_t>(total * static_cast<double>(stepsPerCycle)) + 2U;
    if (tableSize > 40000000U) return x;
    std::vector<double> table(tableSize, 0.0);
    std::size_t p = 0U;
    for (std::size_t t = 0U; t < tableSize; ++t) {
        const double want = static_cast<double>(t) / static_cast<double>(stepsPerCycle);
        while (p + 1U < n && pos[p + 1U] < want) ++p;
        const double span = pos[std::min(n - 1U, p + 1U)] - pos[p];
        table[t] = span > 1e-12 ? static_cast<double>(p) + (want - pos[p]) / span : static_cast<double>(p);
    }

    std::vector<double> weights;
    std::vector<int> taps;
    for (int k = -cycles; k <= cycles; ++k) {
        taps.push_back(k);
        weights.push_back(0.5 + 0.5 * std::cos(kPi * static_cast<double>(k) / static_cast<double>(cycles + 1)));
    }
    std::vector<float> out(n, 0.0F);
    for (std::size_t i = 0U; i < n; ++i) {
        double sum = 0.0, wsum = 0.0;
        const double here = env[i];
        for (std::size_t k = 0U; k < taps.size(); ++k) {
            const double want = pos[i] + static_cast<double>(taps[k]);
            if (want < 0.0 || want >= total) continue;
            const double u = want * static_cast<double>(stepsPerCycle);
            const std::size_t e0 = static_cast<std::size_t>(u);
            if (e0 + 1U >= tableSize) continue;
            const double f0 = u - static_cast<double>(e0);
            const double idx = table[e0] * (1.0 - f0) + table[e0 + 1U] * f0;
            const std::size_t j0 = static_cast<std::size_t>(idx);
            if (j0 + 1U >= n) continue;
            const double f1 = idx - static_cast<double>(j0);
            const double v = static_cast<double>(x[j0]) * (1.0 - f1) + static_cast<double>(x[j0 + 1U]) * f1;
            const double ev = env[j0] * (1.0 - f1) + env[j0 + 1U] * f1;
            sum += v * (here / ev) * weights[k];
            wsum += weights[k];
        }
        out[i] = wsum > 0.0 ? static_cast<float>(sum / wsum) : x[i];
    }
    return out;
}

// write the wave out again from its own overtones, with the note and the loudness straightened by `edges`
std::vector<float> rewrite(const std::vector<float>& x, const std::vector<float>& hzIn, double rate, int overtones, float edges) {
    const std::size_t n = x.size();
    const int H = std::max(1, std::min(WaveSmoother::kMaxOvertones, overtones));
    const std::vector<float> hz = straighten(hzIn, edges, 200U);

    std::vector<float> cosph(n, 0.0F), sinph(n, 0.0F);
    double ph = 0.0;
    for (std::size_t i = 0U; i < n; ++i) {
        ph += 2.0 * kPi * std::max(20.0, static_cast<double>(hz[i])) / rate;
        cosph[i] = static_cast<float>(std::cos(ph));
        sinph[i] = static_cast<float>(std::sin(ph));
    }

    const std::size_t hop = 256U, W = 768U;
    const std::size_t frames = std::max<std::size_t>(2U, (n + hop - 1U) / hop);
    std::vector<double> cs(frames * static_cast<std::size_t>(H), 0.0), ss(frames * static_cast<std::size_t>(H), 0.0);
    std::vector<double> win(W, 0.0);
    double wsum = 0.0;
    for (std::size_t i = 0U; i < W; ++i) {
        win[i] = 0.5 - 0.5 * std::cos(2.0 * kPi * static_cast<double>(i) / static_cast<double>(W - 1U));
        wsum += win[i];
    }
    for (std::size_t fr = 0U; fr < frames; ++fr) {
        const std::ptrdiff_t from = static_cast<std::ptrdiff_t>(fr * hop) - static_cast<std::ptrdiff_t>(W / 2U);
        for (std::size_t i = 0U; i < W; ++i) {
            const std::ptrdiff_t at = from + static_cast<std::ptrdiff_t>(i);
            if (at < 0 || static_cast<std::size_t>(at) >= n) continue;
            const std::size_t a = static_cast<std::size_t>(at);
            const double v = static_cast<double>(x[a]) * win[i];
            const double c1 = static_cast<double>(cosph[a]), s1 = static_cast<double>(sinph[a]);
            double cC = c1, sC = s1;
            for (int h = 0; h < H; ++h) {
                cs[fr * static_cast<std::size_t>(H) + static_cast<std::size_t>(h)] += v * cC;
                ss[fr * static_cast<std::size_t>(H) + static_cast<std::size_t>(h)] += v * sC;
                const double cN = cC * c1 - sC * s1, sN = sC * c1 + cC * s1;
                cC = cN; sC = sN;
            }
        }
        for (int h = 0; h < H; ++h) {
            cs[fr * static_cast<std::size_t>(H) + static_cast<std::size_t>(h)] *= 2.0 / wsum;
            ss[fr * static_cast<std::size_t>(H) + static_cast<std::size_t>(h)] *= 2.0 / wsum;
        }
    }

    std::vector<float> out(n, 0.0F);
    for (std::size_t i = 0U; i < n; ++i) {
        const double at = static_cast<double>(i) / static_cast<double>(hop);
        const std::size_t f0 = std::min(frames - 1U, static_cast<std::size_t>(at));
        const std::size_t f1 = std::min(frames - 1U, f0 + 1U);
        const double t = at - static_cast<double>(f0);
        const double c1 = static_cast<double>(cosph[i]), s1 = static_cast<double>(sinph[i]);
        double cC = c1, sC = s1, acc = 0.0;
        for (int h = 0; h < H; ++h) {
            const std::size_t k = static_cast<std::size_t>(h);
            acc += (cs[f0 * static_cast<std::size_t>(H) + k] * (1.0 - t) + cs[f1 * static_cast<std::size_t>(H) + k] * t) * cC;
            acc += (ss[f0 * static_cast<std::size_t>(H) + k] * (1.0 - t) + ss[f1 * static_cast<std::size_t>(H) + k] * t) * sC;
            const double cN = cC * c1 - sC * s1, sN = sC * c1 + cC * s1;
            cC = cN; sC = sN;
        }
        out[i] = static_cast<float>(acc);
    }

    // the outline: as measured, pulled towards one clean falling curve by `edges`
    double mean = 0.0;
    for (float v : hz) mean += static_cast<double>(v);
    mean /= static_cast<double>(std::max<std::size_t>(1U, n));
    const std::size_t period = static_cast<std::size_t>(std::max(16.0, rate / std::max(20.0, mean)));
    std::vector<double> absIn(n, 0.0), absOut(n, 0.0);
    for (std::size_t i = 0U; i < n; ++i) { absIn[i] = std::fabs(static_cast<double>(x[i])); absOut[i] = std::fabs(static_cast<double>(out[i])); }
    std::vector<double> want = blur(absIn, period);
    const std::vector<double> have = blur(absOut, period);
    if (edges > 0.0F) {
        std::vector<float> line(n, 0.0F);
        for (std::size_t i = 0U; i < n; ++i) line[i] = static_cast<float>(want[i]);
        const std::vector<float> straightened = straighten(line, edges, 200U);
        for (std::size_t i = 0U; i < n; ++i) want[i] = std::max(0.0, static_cast<double>(straightened[i]));
    }
    std::vector<double> gain(n, 0.0);
    for (std::size_t i = 0U; i < n; ++i) gain[i] = have[i] > 1e-7 ? std::min(12.0, want[i] / have[i]) : 0.0;
    const std::vector<double> smoothGain = blur(gain, period);
    for (std::size_t i = 0U; i < n; ++i) out[i] = static_cast<float>(static_cast<double>(out[i]) * smoothGain[i]);

    const double p = peakOf(out), q = peakOf(x);
    if (p > 1e-7 && q > 1e-7) {
        const double g = q / p;
        for (std::size_t i = 0U; i < n; ++i) out[i] = static_cast<float>(static_cast<double>(out[i]) * g);
    }
    return out;
}

bool usable(const ImportedSample& sample, std::string& error) {
    if (!sample.valid() || bytesPerSample(sample.encoding) == 0U) { error = "Sample data is invalid"; return false; }
    if (sample.totalFrames < 2048U) { error = "The sample is too short to be cleaned"; return false; }
    return true;
}

float amountAt(const std::vector<float>& amount, double pos01) {
    if (amount.empty()) return 1.0F;
    if (amount.size() == 1U) return std::max(0.0F, std::min(1.0F, amount.front()));
    const double x = std::min(1.0, std::max(0.0, pos01)) * static_cast<double>(amount.size() - 1U);
    const std::size_t i = static_cast<std::size_t>(x);
    if (i + 1U >= amount.size()) return std::max(0.0F, std::min(1.0F, amount.back()));
    const double f = x - static_cast<double>(i);
    return std::max(0.0F, std::min(1.0F, static_cast<float>(amount[i] * (1.0 - f) + amount[i + 1U] * f)));
}

// read the sample into one float track per channel, plus the mix used for finding the note
void readChannels(const ImportedSample& sample, std::vector<std::vector<float>>& channels, std::vector<float>& mono) {
    const std::size_t n = static_cast<std::size_t>(sample.totalFrames);
    const std::size_t bps = bytesPerSample(sample.encoding);
    const std::size_t fb = frameBytes(sample);
    channels.assign(sample.channels, std::vector<float>(n, 0.0F));
    mono.assign(n, 0.0F);
    for (std::size_t i = 0U; i < n; ++i) {
        double sum = 0.0;
        for (std::uint16_t c = 0U; c < sample.channels; ++c) {
            const float v = readScalar(sample.audioData.data() + i * fb + static_cast<std::size_t>(c) * bps, sample.encoding);
            channels[c][i] = v;
            sum += static_cast<double>(v);
        }
        mono[i] = static_cast<float>(sum / static_cast<double>(std::max<std::uint16_t>(1U, sample.channels)));
    }
}

} // namespace

std::vector<float> WaveSmoother::noteTrack(const ImportedSample& sample, std::size_t points) {
    std::string error;
    if (!usable(sample, error) || points == 0U) return {};
    std::vector<std::vector<float>> channels;
    std::vector<float> mono;
    readChannels(sample, channels, mono);
    const std::vector<float> hz = noteOf(mono, static_cast<double>(sample.sampleRate));
    if (hz.empty()) return {};
    std::vector<float> out(points, 0.0F);
    for (std::size_t k = 0U; k < points; ++k) {
        const std::size_t at = std::min(hz.size() - 1U, static_cast<std::size_t>((static_cast<double>(k) + 0.5) / static_cast<double>(points) * static_cast<double>(hz.size())));
        out[k] = hz[at];
    }
    return out;
}

bool WaveSmoother::preview(const ImportedSample& sample, const WaveCleanOptions& options,
                           std::vector<float>& out, std::string& error) {
    out.clear();
    error.clear();
    if (!usable(sample, error)) return false;

    std::vector<std::vector<float>> channels;
    std::vector<float> mono;
    readChannels(sample, channels, mono);
    const double rate = static_cast<double>(sample.sampleRate);
    const std::vector<float> hz = noteOf(mono, rate);
    if (hz.empty()) { error = "No clear note was found in this sample"; return false; }

    const std::vector<float> steady = averageCycles(mono, hz, rate, 1);
    const std::vector<float> clean = rewrite(steady, hz, rate, options.overtones, std::max(0.0F, std::min(1.0F, options.edges)));
    const std::size_t n = mono.size();
    out.assign(n, 0.0F);
    for (std::size_t i = 0U; i < n; ++i) {
        const float a = amountAt(options.amount, static_cast<double>(i) / static_cast<double>(n));
        out[i] = mono[i] * (1.0F - a) + clean[i] * a;
    }
    return true;
}

bool WaveSmoother::clean(ImportedSample& sample, const WaveCleanOptions& options, std::string& error) {
    error.clear();
    if (!usable(sample, error)) return false;

    std::vector<std::vector<float>> channels;
    std::vector<float> mono;
    readChannels(sample, channels, mono);
    const double rate = static_cast<double>(sample.sampleRate);
    const std::vector<float> hz = noteOf(mono, rate);
    if (hz.empty()) { error = "No clear note was found in this sample"; return false; }

    const std::size_t n = mono.size();
    const std::size_t bps = bytesPerSample(sample.encoding);
    const std::size_t fb = frameBytes(sample);
    const float edges = std::max(0.0F, std::min(1.0F, options.edges));
    for (std::uint16_t c = 0U; c < sample.channels; ++c) {
        const std::vector<float> steady = averageCycles(channels[c], hz, rate, 1);
        const std::vector<float> clean = rewrite(steady, hz, rate, options.overtones, edges);
        for (std::size_t i = 0U; i < n; ++i) {
            const float a = amountAt(options.amount, static_cast<double>(i) / static_cast<double>(n));
            const float mixed = channels[c][i] * (1.0F - a) + clean[i] * a;
            writeScalar(sample.audioData.data() + i * fb + static_cast<std::size_t>(c) * bps, sample.encoding, mixed);
        }
    }
    return true;
}

} // namespace silveton::manager
