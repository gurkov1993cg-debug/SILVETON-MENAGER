// SILVETON_SEND_V1 - see SvBankMerge.h.
#include "silveton/manager/SvBankMerge.h"

#include "silveton/manager/ManagerTypes.h"
#include "silveton/manager/SvBankFormat.h"

#include <algorithm>
#include <array>
#include <cerrno>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <limits>
#include <map>
#include <tuple>
#include <memory>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace silveton::manager {
namespace {

std::uint64_t alignUp(std::uint64_t value, std::uint64_t alignment) noexcept {
    const std::uint64_t mask = alignment - 1U;
    return (value + mask) & ~mask;
}

// Streaming SHA-256 (the same result as sha256() in SvBankFormat).
class Sha256Stream {
public:
    void update(const std::uint8_t* data, std::size_t size) noexcept {
        total_ += size;
        while (size > 0U) {
            const std::size_t take = std::min(size, static_cast<std::size_t>(64U) - fill_);
            std::memcpy(block_.data() + fill_, data, take);
            fill_ += take; data += take; size -= take;
            if (fill_ == 64U) { compress(); fill_ = 0U; }
        }
    }
    std::array<std::uint8_t, 32> finish() noexcept {
        const std::uint64_t bits = total_ * 8U;
        const std::uint8_t one = 0x80U;
        update(&one, 1U);
        const std::uint8_t zero = 0U;
        while (fill_ != 56U) update(&zero, 1U);
        std::uint8_t len[8];
        for (unsigned i = 0U; i < 8U; ++i) len[7U - i] = static_cast<std::uint8_t>((bits >> (i * 8U)) & 0xFFU);
        update(len, 8U);
        std::array<std::uint8_t, 32> out{};
        for (std::size_t i = 0U; i < 8U; ++i) {
            out[i * 4U] = static_cast<std::uint8_t>((h_[i] >> 24U) & 0xFFU);
            out[i * 4U + 1U] = static_cast<std::uint8_t>((h_[i] >> 16U) & 0xFFU);
            out[i * 4U + 2U] = static_cast<std::uint8_t>((h_[i] >> 8U) & 0xFFU);
            out[i * 4U + 3U] = static_cast<std::uint8_t>(h_[i] & 0xFFU);
        }
        return out;
    }

private:
    static std::uint32_t rotr(std::uint32_t x, std::uint32_t n) noexcept { return (x >> n) | (x << (32U - n)); }
    void compress() noexcept {
        static constexpr std::array<std::uint32_t, 64> k{{
            0x428a2f98U,0x71374491U,0xb5c0fbcfU,0xe9b5dba5U,0x3956c25bU,0x59f111f1U,0x923f82a4U,0xab1c5ed5U,
            0xd807aa98U,0x12835b01U,0x243185beU,0x550c7dc3U,0x72be5d74U,0x80deb1feU,0x9bdc06a7U,0xc19bf174U,
            0xe49b69c1U,0xefbe4786U,0x0fc19dc6U,0x240ca1ccU,0x2de92c6fU,0x4a7484aaU,0x5cb0a9dcU,0x76f988daU,
            0x983e5152U,0xa831c66dU,0xb00327c8U,0xbf597fc7U,0xc6e00bf3U,0xd5a79147U,0x06ca6351U,0x14292967U,
            0x27b70a85U,0x2e1b2138U,0x4d2c6dfcU,0x53380d13U,0x650a7354U,0x766a0abbU,0x81c2c92eU,0x92722c85U,
            0xa2bfe8a1U,0xa81a664bU,0xc24b8b70U,0xc76c51a3U,0xd192e819U,0xd6990624U,0xf40e3585U,0x106aa070U,
            0x19a4c116U,0x1e376c08U,0x2748774cU,0x34b0bcb5U,0x391c0cb3U,0x4ed8aa4aU,0x5b9cca4fU,0x682e6ff3U,
            0x748f82eeU,0x78a5636fU,0x84c87814U,0x8cc70208U,0x90befffaU,0xa4506cebU,0xbef9a3f7U,0xc67178f2U}};
        std::array<std::uint32_t, 64> w{};
        for (std::size_t i = 0U; i < 16U; ++i) {
            const std::size_t j = i * 4U;
            w[i] = (static_cast<std::uint32_t>(block_[j]) << 24U) | (static_cast<std::uint32_t>(block_[j + 1U]) << 16U) |
                   (static_cast<std::uint32_t>(block_[j + 2U]) << 8U) | static_cast<std::uint32_t>(block_[j + 3U]);
        }
        for (std::size_t i = 16U; i < 64U; ++i) {
            const std::uint32_t s0 = rotr(w[i - 15U], 7U) ^ rotr(w[i - 15U], 18U) ^ (w[i - 15U] >> 3U);
            const std::uint32_t s1 = rotr(w[i - 2U], 17U) ^ rotr(w[i - 2U], 19U) ^ (w[i - 2U] >> 10U);
            w[i] = w[i - 16U] + s0 + w[i - 7U] + s1;
        }
        std::uint32_t a = h_[0], b = h_[1], c = h_[2], d = h_[3], e = h_[4], f = h_[5], g = h_[6], hh = h_[7];
        for (std::size_t i = 0U; i < 64U; ++i) {
            const std::uint32_t s1 = rotr(e, 6U) ^ rotr(e, 11U) ^ rotr(e, 25U);
            const std::uint32_t ch = (e & f) ^ ((~e) & g);
            const std::uint32_t temp1 = hh + s1 + ch + k[i] + w[i];
            const std::uint32_t s0 = rotr(a, 2U) ^ rotr(a, 13U) ^ rotr(a, 22U);
            const std::uint32_t maj = (a & b) ^ (a & c) ^ (b & c);
            const std::uint32_t temp2 = s0 + maj;
            hh = g; g = f; f = e; e = d + temp1; d = c; c = b; b = a; a = temp1 + temp2;
        }
        h_[0] += a; h_[1] += b; h_[2] += c; h_[3] += d; h_[4] += e; h_[5] += f; h_[6] += g; h_[7] += hh;
    }
    std::array<std::uint32_t, 8> h_{{0x6a09e667U,0xbb67ae85U,0x3c6ef372U,0xa54ff53aU,0x510e527fU,0x9b05688cU,0x1f83d9abU,0x5be0cd19U}};
    std::array<std::uint8_t, 64> block_{};
    std::size_t fill_{0U};
    std::uint64_t total_{0U};
};

class StringTable {
public:
    StringTable() { bytes_.push_back(0U); offsets_.emplace(std::string{}, 0U); }
    std::uint32_t add(const std::string& text) {
        const auto found = offsets_.find(text);
        if (found != offsets_.end()) return found->second;
        const auto offset = static_cast<std::uint32_t>(bytes_.size());
        bytes_.insert(bytes_.end(), text.begin(), text.end());
        bytes_.push_back(0U);
        offsets_.emplace(text, offset);
        return offset;
    }
    const std::vector<std::uint8_t>& bytes() const noexcept { return bytes_; }

private:
    std::vector<std::uint8_t> bytes_;
    std::unordered_map<std::string, std::uint32_t> offsets_;
};

// One bank file: its small records in memory, the audio stays on the disk.
struct Source {
    std::string path;
    std::uint64_t size{0U};
    SvBankHeader header{};
    std::vector<SvSoundRecord> sounds;
    std::vector<SvSoundLayerRecord> layers;
    std::vector<SvMultisampleRecord> multisamples;
    std::vector<SvSampleRecord> samples;
    std::vector<SvZoneRecord> zones;
    std::vector<std::uint8_t> strings;
    std::unordered_map<std::uint32_t, std::size_t> multisampleById;
    std::unordered_map<std::uint32_t, std::size_t> sampleById;

    bool stringAt(std::uint32_t offset, std::string& out) const {
        if (offset >= strings.size()) return false;
        const auto* begin = strings.data() + offset;
        const auto* end = static_cast<const std::uint8_t*>(std::memchr(begin, 0, strings.size() - offset));
        if (end == nullptr) return false;
        out.assign(reinterpret_cast<const char*>(begin), static_cast<std::size_t>(end - begin));
        return true;
    }
};

bool readBytes(std::ifstream& in, std::uint64_t offset, std::uint64_t size, std::vector<std::uint8_t>& out) {
    if (size > static_cast<std::uint64_t>(std::numeric_limits<std::size_t>::max())) return false;
    out.assign(static_cast<std::size_t>(size), 0U);
    if (size == 0U) return true;
    in.clear();
    in.seekg(static_cast<std::streamoff>(offset));
    in.read(reinterpret_cast<char*>(out.data()), static_cast<std::streamsize>(size));
    return static_cast<std::uint64_t>(in.gcount()) == size;
}

template <typename Record, typename ReadFn>
bool readRecords(std::ifstream& in, const Source& src, SvSection section, std::uint32_t count, std::size_t recordSize,
                 ReadFn read, std::vector<Record>& out, std::string& error) {
    const auto& desc = src.header.sections[static_cast<std::size_t>(section)];
    if (desc.size != static_cast<std::uint64_t>(count) * recordSize) { error = "record section has the wrong size in " + src.path; return false; }
    std::vector<std::uint8_t> bytes;
    if (!readBytes(in, desc.offset, desc.size, bytes)) { error = "cannot read " + src.path; return false; }
    out.resize(count);
    for (std::uint32_t i = 0U; i < count; ++i) {
        if (!read(bytes.data() + static_cast<std::size_t>(i) * recordSize, recordSize, out[i])) { error = "damaged record in " + src.path; return false; }
    }
    return true;
}

bool loadSource(const std::string& path, Source& src, std::string& error) {
    src.path = path;
    std::ifstream in(path, std::ios::binary);
    if (!in) { error = "Cannot open " + path; return false; }
    in.seekg(0, std::ios::end);
    const std::streamoff end = in.tellg();
    if (end < static_cast<std::streamoff>(kSvBankHeaderSize)) { error = "Not a SILVETON bank: " + path; return false; }
    src.size = static_cast<std::uint64_t>(end);
    std::vector<std::uint8_t> head;
    if (!readBytes(in, 0U, kSvBankHeaderSize, head)) { error = "Cannot read " + path; return false; }
    std::string headerError;
    if (!deserializeHeader(head.data(), head.size(), src.header, headerError)) { error = headerError + " (" + path + ")"; return false; }
    if (src.header.fileSize != src.size) { error = "The bank has the wrong size (cut short?): " + path; return false; }
    for (const auto& s : src.header.sections) {
        if (s.offset > src.size || s.size > src.size - s.offset) { error = "A part of the bank lies outside the file: " + path; return false; }
    }
    const SvBankHeader& h = src.header;
    if (!readRecords(in, src, SvSection::Sounds, h.soundCount, kSvSoundRecordSize, readSoundRecord, src.sounds, error) ||
        !readRecords(in, src, SvSection::SoundLayers, h.soundLayerCount, kSvSoundLayerRecordSize, readSoundLayerRecord, src.layers, error) ||
        !readRecords(in, src, SvSection::Multisamples, h.multisampleCount, kSvMultisampleRecordSize, readMultisampleRecord, src.multisamples, error) ||
        !readRecords(in, src, SvSection::Samples, h.sampleCount, kSvSampleRecordSize, readSampleRecord, src.samples, error) ||
        !readRecords(in, src, SvSection::Zones, h.zoneCount, kSvZoneRecordSize, readZoneRecord, src.zones, error)) {
        return false;
    }
    const auto& strings = h.sections[static_cast<std::size_t>(SvSection::Strings)];
    if (!readBytes(in, strings.offset, strings.size, src.strings)) { error = "Cannot read the names of " + path; return false; }
    for (std::size_t i = 0U; i < src.multisamples.size(); ++i) src.multisampleById[src.multisamples[i].multisampleId] = i;
    for (std::size_t i = 0U; i < src.samples.size(); ++i) src.sampleById[src.samples[i].sampleId] = i;
    const std::uint64_t audioSize = h.sections[static_cast<std::size_t>(SvSection::Audio)].size;
    for (const auto& s : src.sounds) {
        if (static_cast<std::uint64_t>(s.firstLayer) + s.layerCount > src.layers.size()) { error = "A SOUND points outside its layers: " + path; return false; }
    }
    for (const auto& m : src.multisamples) {
        if (static_cast<std::uint64_t>(m.firstZone) + m.zoneCount > src.zones.size()) { error = "A multisample points outside its zones: " + path; return false; }
    }
    for (const auto& s : src.samples) {
        if (s.audioOffset > audioSize || s.audioSize > audioSize - s.audioOffset) { error = "A sample points outside the audio: " + path; return false; }
    }
    return true;
}

bool present(const std::string& path) {
    std::ifstream in(path, std::ios::binary);
    return static_cast<bool>(in);
}

} // namespace

bool SvBankMerge::soundList(const std::string& path, std::vector<std::pair<int, std::string>>& sounds, std::string& error) {
    sounds.clear();
    Source src;
    if (!loadSource(path, src, error)) return false;
    for (const auto& s : src.sounds) {
        std::string name;
        if (!src.stringAt(s.nameOffset, name)) { error = "A SOUND name cannot be read: " + path; return false; }
        sounds.emplace_back(static_cast<int>(s.soundSlotId), name);
    }
    return true;
}

bool SvBankMerge::merge(const std::string& basePath, const std::vector<std::string>& addPaths, const std::set<int>& leaveOut,
                        const std::string& outPath, const std::string& bankName, SvMergeStats& stats, std::string& error,
                        const SvMergeProgress& progress) {
    auto report = [&](double fraction, const std::string& text) -> bool { return !progress || progress(fraction, text); };
    stats = SvMergeStats{};
    // ---- the sources
    std::vector<std::unique_ptr<Source>> sources;
    if (!basePath.empty() && present(basePath)) {
        auto s = std::make_unique<Source>();
        if (!loadSource(basePath, *s, error)) return false;
        sources.push_back(std::move(s));
    }
    for (const auto& p : addPaths) {
        auto s = std::make_unique<Source>();
        if (!loadSource(p, *s, error)) return false;
        sources.push_back(std::move(s));
    }
    // ---- which SOUND wins each place: the last file that has one
    std::map<std::uint16_t, std::pair<std::size_t, std::size_t>> winner;   // place -> (source, sound)
    for (std::size_t si = 0U; si < sources.size(); ++si) {
        const Source& s = *sources[si];
        for (std::size_t k = 0U; k < s.sounds.size(); ++k) {
            const std::uint16_t place = s.sounds[k].soundSlotId;
            if (place < kMinSoundPosition || place > kMaxSoundPosition) { error = "A SOUND has a place outside 1...500: " + s.path; return false; }
            winner[place] = {si, k};
        }
    }
    for (const int place : leaveOut) {
        if (place >= 0 && place <= 65535) winner.erase(static_cast<std::uint16_t>(place));
    }
    if (winner.empty()) { error = "There is no SOUND to write."; return false; }

    // ---- the records of the new bank
    StringTable strings;
    SvBankHeader header{};
    std::string name = bankName;
    for (const auto& s : sources) {
        if (!name.empty()) break;
        (void)s->stringAt(s->header.bankNameOffset, name);
    }
    if (name.empty()) name = "SILVETON BANK";
    header.bankNameOffset = strings.add(name);

    std::vector<std::uint8_t> soundBytes, layerBytes, multisampleBytes, sampleBytes, zoneBytes;
    std::map<std::pair<std::size_t, std::uint32_t>, std::uint32_t> newMultisampleId;   // (source, old id) -> new id
    std::vector<std::pair<std::size_t, std::size_t>> multisampleOrder;                   // (source, index) in file order
    std::map<std::pair<std::size_t, std::uint32_t>, std::uint32_t> newSampleId;
    std::vector<std::pair<std::size_t, std::size_t>> sampleOrder;

    std::uint32_t layerCursor = 0U;
    for (const auto& item : winner) {
        const Source& s = *sources[item.second.first];
        const SvSoundRecord& old = s.sounds[item.second.second];
        std::string soundName;
        if (!s.stringAt(old.nameOffset, soundName)) { error = "A SOUND name cannot be read: " + s.path; return false; }
        SvSoundRecord rec = old;
        rec.nameOffset = strings.add(soundName);
        rec.firstLayer = layerCursor;
        appendSoundRecord(soundBytes, rec);
        for (std::uint32_t l = 0U; l < old.layerCount; ++l) {
            SvSoundLayerRecord lr = s.layers[static_cast<std::size_t>(old.firstLayer) + l];
            const auto found = s.multisampleById.find(lr.multisampleId);
            if (found == s.multisampleById.end()) { error = "A SOUND layer points to a missing multisample: " + s.path; return false; }
            const auto key = std::make_pair(item.second.first, lr.multisampleId);
            auto it = newMultisampleId.find(key);
            if (it == newMultisampleId.end()) {
                it = newMultisampleId.emplace(key, static_cast<std::uint32_t>(multisampleOrder.size() + 1U)).first;
                multisampleOrder.emplace_back(item.second.first, found->second);
            }
            lr.multisampleId = it->second;
            appendSoundLayerRecord(layerBytes, lr);
            ++layerCursor;
        }
    }
    header.soundCount = static_cast<std::uint32_t>(winner.size());
    header.soundLayerCount = layerCursor;

    std::uint32_t zoneCursor = 0U;
    for (const auto& ms : multisampleOrder) {
        const Source& s = *sources[ms.first];
        const SvMultisampleRecord& old = s.multisamples[ms.second];
        std::string msName, msIdentity;
        if (!s.stringAt(old.nameOffset, msName) || !s.stringAt(old.sourceIdentityOffset, msIdentity)) { error = "A multisample name cannot be read: " + s.path; return false; }
        SvMultisampleRecord rec = old;
        rec.multisampleId = newMultisampleId[std::make_pair(ms.first, old.multisampleId)];
        rec.nameOffset = strings.add(msName);
        rec.sourceIdentityOffset = strings.add(msIdentity);
        rec.firstZone = zoneCursor;
        appendMultisampleRecord(multisampleBytes, rec);
        for (std::uint32_t z = 0U; z < old.zoneCount; ++z) {
            SvZoneRecord zr = s.zones[static_cast<std::size_t>(old.firstZone) + z];
            const auto found = s.sampleById.find(zr.sampleId);
            if (found == s.sampleById.end()) { error = "A zone points to a missing sample: " + s.path; return false; }
            const auto key = std::make_pair(ms.first, zr.sampleId);
            auto it = newSampleId.find(key);
            if (it == newSampleId.end()) {
                it = newSampleId.emplace(key, static_cast<std::uint32_t>(sampleOrder.size() + 1U)).first;
                sampleOrder.emplace_back(ms.first, found->second);
            }
            zr.sampleId = it->second;
            appendZoneRecord(zoneBytes, zr);
            ++zoneCursor;
        }
    }
    header.multisampleCount = static_cast<std::uint32_t>(multisampleOrder.size());
    header.zoneCount = zoneCursor;

    // audio: every stored recording once (samples that shared bytes in their file share them here too)
    struct Piece { std::size_t source; std::uint64_t from; std::uint64_t size; std::uint64_t to; };
    std::vector<Piece> pieces;
    std::map<std::tuple<std::size_t, std::uint64_t, std::uint64_t>, std::uint64_t> placed;
    std::uint64_t audioSize = 0U;
    for (const auto& sm : sampleOrder) {
        const Source& s = *sources[sm.first];
        const SvSampleRecord& old = s.samples[sm.second];
        std::string sampleName, sampleIdentity;
        if (!s.stringAt(old.nameOffset, sampleName) || !s.stringAt(old.sourceIdentityOffset, sampleIdentity)) { error = "A sample name cannot be read: " + s.path; return false; }
        const auto key = std::make_tuple(sm.first, old.audioOffset, old.audioSize);
        auto it = placed.find(key);
        if (it == placed.end()) {
            it = placed.emplace(key, audioSize).first;
            const std::uint64_t from = s.header.sections[static_cast<std::size_t>(SvSection::Audio)].offset + old.audioOffset;
            pieces.push_back(Piece{sm.first, from, old.audioSize, audioSize});
            audioSize += old.audioSize;
        }
        SvSampleRecord rec = old;
        rec.sampleId = newSampleId[std::make_pair(sm.first, old.sampleId)];
        rec.nameOffset = strings.add(sampleName);
        rec.sourceIdentityOffset = strings.add(sampleIdentity);
        rec.audioOffset = it->second;
        appendSampleRecord(sampleBytes, rec);
    }
    header.sampleCount = static_cast<std::uint32_t>(sampleOrder.size());

    // ---- layout (the same as SvBankBuilder: small sections at 16 bytes, the audio at 4096)
    std::vector<std::uint8_t> head(kSvBankHeaderSize, 0U);
    auto appendSection = [&head](SvSectionDesc& section, const std::vector<std::uint8_t>& data) {
        const std::uint64_t aligned = alignUp(static_cast<std::uint64_t>(head.size()), 16U);
        head.resize(static_cast<std::size_t>(aligned), 0U);
        section.offset = static_cast<std::uint64_t>(head.size());
        section.size = static_cast<std::uint64_t>(data.size());
        head.insert(head.end(), data.begin(), data.end());
    };
    appendSection(header.sections[static_cast<std::size_t>(SvSection::Sounds)], soundBytes);
    appendSection(header.sections[static_cast<std::size_t>(SvSection::SoundLayers)], layerBytes);
    appendSection(header.sections[static_cast<std::size_t>(SvSection::Multisamples)], multisampleBytes);
    appendSection(header.sections[static_cast<std::size_t>(SvSection::Samples)], sampleBytes);
    appendSection(header.sections[static_cast<std::size_t>(SvSection::Zones)], zoneBytes);
    appendSection(header.sections[static_cast<std::size_t>(SvSection::Strings)], strings.bytes());
    head.resize(static_cast<std::size_t>(alignUp(static_cast<std::uint64_t>(head.size()), 4096U)), 0U);
    auto& audioSection = header.sections[static_cast<std::size_t>(SvSection::Audio)];
    audioSection.offset = static_cast<std::uint64_t>(head.size());
    audioSection.size = audioSize;
    header.fileSize = audioSection.offset + audioSize;

    // ---- write: a temporary file, the audio piece by piece, the header last
    const std::string temp = outPath + ".tmp";
    {
        std::ofstream out(temp, std::ios::binary | std::ios::trunc);
        if (!out) { error = "Cannot create " + temp; return false; }
        Sha256Stream sha;
        out.write(reinterpret_cast<const char*>(head.data()), static_cast<std::streamsize>(head.size()));
        sha.update(head.data() + kSvBankHeaderSize, head.size() - kSvBankHeaderSize);
        std::vector<std::ifstream> files;
        files.reserve(sources.size());
        for (const auto& s : sources) files.emplace_back(s->path, std::ios::binary);
        std::vector<std::uint8_t> chunk(4U << 20U);
        std::uint64_t done = 0U;
        for (const Piece& p : pieces) {
            std::ifstream& in = files[p.source];
            in.clear();
            in.seekg(static_cast<std::streamoff>(p.from));
            std::uint64_t left = p.size;
            while (left > 0U) {
                const std::size_t take = static_cast<std::size_t>(std::min<std::uint64_t>(left, chunk.size()));
                in.read(reinterpret_cast<char*>(chunk.data()), static_cast<std::streamsize>(take));
                if (static_cast<std::size_t>(in.gcount()) != take) { error = "Cannot read the audio of " + sources[p.source]->path; (void)std::remove(temp.c_str()); return false; }
                out.write(reinterpret_cast<const char*>(chunk.data()), static_cast<std::streamsize>(take));
                if (!out) { error = "Cannot write " + temp + " (disk full?)"; (void)std::remove(temp.c_str()); return false; }
                sha.update(chunk.data(), take);
                left -= take;
                done += take;
                const double f = audioSize > 0U ? static_cast<double>(done) / static_cast<double>(audioSize) : 1.0;
                if (!report(0.02 + 0.96 * f, "Writing the audio")) { (void)std::remove(temp.c_str()); error = "Stopped"; return false; }
            }
        }
        header.payloadSha256 = sha.finish();
        const auto headerBytes = serializeHeader(header);
        out.seekp(0);
        out.write(reinterpret_cast<const char*>(headerBytes.data()), static_cast<std::streamsize>(headerBytes.size()));
        out.flush();
        if (!out) { error = "Cannot write " + temp + " (disk full?)"; (void)std::remove(temp.c_str()); return false; }
    }
    {
        std::ifstream check(temp, std::ios::binary | std::ios::ate);
        if (!check || static_cast<std::uint64_t>(check.tellg()) != header.fileSize) {
            error = "The written bank has the wrong size (disk full?)";
            (void)std::remove(temp.c_str());
            return false;
        }
    }
    if (std::rename(temp.c_str(), outPath.c_str()) != 0) {
        if (!(std::remove(outPath.c_str()) == 0 && std::rename(temp.c_str(), outPath.c_str()) == 0)) {
            error = "Cannot replace " + outPath + ": " + std::string(std::strerror(errno));
            (void)std::remove(temp.c_str());
            return false;
        }
    }
    stats.soundCount = header.soundCount;
    stats.sampleCount = header.sampleCount;
    stats.audioBytes = audioSize;
    (void)report(1.0, "Done");
    return true;
}

} // namespace silveton::manager
