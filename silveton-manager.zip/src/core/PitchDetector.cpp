// SILVETON_PITCH_V1 - YIN style pitch detection with an octave check, tuned on piano recordings.
#include "silveton/manager/PitchDetector.h"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>

namespace silveton::manager {
namespace {

constexpr double kLowestHz = 25.0;     // below A0
constexpr double kHighestHz = 4500.0;  // above C8
constexpr double kThreshold = 0.15;

float sampleAt(const ImportedSample& s, std::size_t frame, std::size_t channel) noexcept {
    const std::size_t idx = frame * s.channels + channel;
    const std::uint8_t* d = s.audioData.data();
    switch (s.encoding) {
        case AudioEncoding::Pcm16LE: {
            const std::int16_t v = static_cast<std::int16_t>(d[idx * 2U] | (static_cast<std::uint16_t>(d[idx * 2U + 1U]) << 8U));
            return static_cast<float>(v) / 32768.0F;
        }
        case AudioEncoding::Pcm24LE: {
            std::int32_t v = static_cast<std::int32_t>(d[idx * 3U] | (static_cast<std::uint32_t>(d[idx * 3U + 1U]) << 8U) |
                                                       (static_cast<std::uint32_t>(d[idx * 3U + 2U]) << 16U));
            if (v & 0x800000) v -= 0x1000000;
            return static_cast<float>(v) / 8388608.0F;
        }
        case AudioEncoding::Float32LE: {
            float f = 0.0F;
            std::memcpy(&f, d + idx * 4U, sizeof f);
            return std::isfinite(f) ? f : 0.0F;
        }
    }
    return 0.0F;
}

} // namespace

std::string PitchDetector::noteName(int midi) {
    static const char* const names[12] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
    const int n = ((midi % 12) + 12) % 12;
    const int octave = midi / 12 - 1 - (midi < 0 && midi % 12 != 0 ? 1 : 0);
    return std::string(names[n]) + std::to_string(octave);
}

std::string PitchResult::noteName() const { return PitchDetector::noteName(midi); }

PitchResult PitchDetector::detect(const ImportedSample& sample) {
    PitchResult none{};
    if (!sample.valid() || sample.sampleRate == 0U) return none;
    const std::size_t frames = static_cast<std::size_t>(sample.totalFrames);
    // a window after the attack: skip the first 60 ms when there is enough material
    const double fs = static_cast<double>(sample.sampleRate);
    const std::size_t skip = frames > static_cast<std::size_t>(0.4 * fs) ? static_cast<std::size_t>(0.06 * fs) : 0U;
    const std::size_t want = static_cast<std::size_t>(0.3 * fs);
    const std::size_t len = std::min(frames - skip, want);
    if (len < 256U) return none;
    std::vector<float> mono(len);
    for (std::size_t i = 0U; i < len; ++i) {
        float acc = 0.0F;
        for (std::size_t c = 0U; c < sample.channels; ++c) acc += sampleAt(sample, skip + i, c);
        mono[i] = acc / static_cast<float>(sample.channels);
    }
    return detect(mono.data(), mono.size(), fs);
}

PitchResult PitchDetector::detect(const float* mono, std::size_t frames, double sampleRate) {
    PitchResult out{};
    if (mono == nullptr || sampleRate <= 0.0 || frames < 256U) return out;
    // work at most around 24 kHz: halve the rate for high-rate recordings (cheaper, same answer)
    std::vector<float> x;
    double fs = sampleRate;
    if (fs > 60000.0) {
        x.resize(frames / 2U);
        for (std::size_t i = 0U; i < x.size(); ++i) x[i] = 0.5F * (mono[2U * i] + mono[2U * i + 1U]);
        fs /= 2.0;
    } else {
        x.assign(mono, mono + frames);
    }
    // remove DC
    double mean = 0.0;
    for (float v : x) mean += v;
    mean /= static_cast<double>(x.size());
    for (float& v : x) v = static_cast<float>(v - mean);
    double energy = 0.0;
    for (float v : x) energy += static_cast<double>(v) * v;
    if (energy < 1e-7) return out;

    const std::size_t tauMin = std::max<std::size_t>(2U, static_cast<std::size_t>(fs / kHighestHz));
    std::size_t tauMax = static_cast<std::size_t>(fs / kLowestHz);
    if (tauMax + 64U >= x.size()) tauMax = x.size() > 64U ? x.size() - 64U : 0U;
    if (tauMax <= tauMin + 2U) return out;
    const std::size_t n = x.size() - tauMax;   // the same integration window for every lag

    // YIN difference function and its cumulative mean normalised form
    std::vector<double> d(tauMax + 1U, 0.0), dn(tauMax + 1U, 1.0);
    double running = 0.0;
    for (std::size_t tau = 1U; tau <= tauMax; ++tau) {
        double acc = 0.0;
        const float* a = x.data();
        const float* b = x.data() + tau;
        for (std::size_t i = 0U; i < n; ++i) { const double diff = static_cast<double>(a[i]) - b[i]; acc += diff * diff; }
        d[tau] = acc;
        running += acc;
        dn[tau] = running > 0.0 ? acc * static_cast<double>(tau) / running : 1.0;
    }
    // first dip below the threshold (a local minimum), otherwise the deepest dip
    std::size_t best = 0U;
    for (std::size_t tau = tauMin + 1U; tau < tauMax; ++tau) {
        if (dn[tau] < kThreshold && dn[tau] <= dn[tau - 1U] && dn[tau] <= dn[tau + 1U]) {
            // walk down to the bottom of this dip
            std::size_t t = tau;
            while (t + 1U < tauMax && dn[t + 1U] < dn[t]) ++t;
            best = t;
            break;
        }
    }
    if (best == 0U) {
        double low = 1e9;
        for (std::size_t tau = tauMin + 1U; tau < tauMax; ++tau) if (dn[tau] < low) { low = dn[tau]; best = tau; }
        if (best == 0U) return out;
    }
    // octave check: a piano bass note can dip first at half its period (weak fundamental, strong 2nd partial);
    // the true period then dips clearly deeper. A clean tone dips equally at both, and keeps the shorter one.
    for (int tries = 0; tries < 2; ++tries) {
        const std::size_t twice = best * 2U;
        if (twice + 2U >= tauMax) break;
        std::size_t t = twice;
        for (std::size_t k = twice - 2U; k <= twice + 2U; ++k) if (dn[k] < dn[t]) t = k;
        // compare the bottoms of the dips (interpolated), not the nearest whole lags: at high notes the
        // period is only a dozen samples and the whole lag can sit on the slope of the dip
        auto bottom = [&](std::size_t k) {
            if (k == 0U || k + 1U > tauMax) return dn[k];
            const double s0 = dn[k - 1U], s1 = dn[k], s2 = dn[k + 1U];
            const double denom = s0 - 2.0 * s1 + s2;
            if (std::fabs(denom) < 1e-12) return s1;
            const double off = 0.5 * (s0 - s2) / denom;
            return std::max(0.0, s1 - 0.25 * (s0 - s2) * off);
        };
        if (bottom(t) + 0.04 < bottom(best)) best = t; else break;
    }
    // parabolic interpolation around the dip
    double tauF = static_cast<double>(best);
    if (best > 0U && best + 1U <= tauMax) {
        const double s0 = dn[best - 1U], s1 = dn[best], s2 = dn[best + 1U];
        const double denom = s0 - 2.0 * s1 + s2;
        if (std::fabs(denom) > 1e-12) tauF += 0.5 * (s0 - s2) / denom;
    }
    if (tauF <= 0.0) return out;
    out.hz = fs / tauF;
    if (!(out.hz >= kLowestHz * 0.9 && out.hz <= kHighestHz * 1.1)) return out;
    const double midiF = 69.0 + 12.0 * std::log2(out.hz / 440.0);
    out.midi = static_cast<int>(std::lround(midiF));
    out.cents = static_cast<float>((midiF - static_cast<double>(out.midi)) * 100.0);
    out.confidence = static_cast<float>(std::clamp(1.0 - dn[best], 0.0, 1.0));
    out.found = true;
    return out;
}

} // namespace silveton::manager
