// SILVETON_SEND_V1 - see SoundTransfer.h.
#include "silveton/manager/SoundTransfer.h"

#include <set>
#include <unordered_map>

namespace silveton::manager {

bool planTransfer(const std::vector<std::string>& managerNames, const std::vector<std::pair<int, std::string>>& samplerSounds,
                  const std::vector<SentSound>& sentBefore, std::vector<SentSound>& plan, std::string& error) {
    plan.clear();
    std::set<int> taken;
    std::set<std::string> names;
    for (const auto& s : samplerSounds) {
        if (s.first >= kMinSoundPosition && s.first <= kMaxSoundPosition) { taken.insert(s.first); names.insert(s.second); }
    }
    for (const auto& s : sentBefore) { taken.insert(s.place); names.insert(s.samplerName); }
    std::set<std::string> planned;
    for (const auto& managerName : managerNames) {
        if (!planned.insert(managerName).second) continue;   // (the same name twice: once is enough)
        const SentSound* before = nullptr;
        for (const auto& s : sentBefore) if (s.managerName == managerName) { before = &s; break; }
        if (before != nullptr) { plan.push_back(*before); continue; }
        int place = 0;
        for (int p = kMinSoundPosition; p <= kMaxSoundPosition; ++p) if (taken.count(p) == 0U) { place = p; break; }
        if (place == 0) { error = "The sampler has no free place left (1...500)."; return false; }
        std::string samplerName = managerName;
        for (int k = 2; names.count(samplerName) != 0U; ++k) samplerName = managerName + " " + std::to_string(k);
        taken.insert(place);
        names.insert(samplerName);
        plan.push_back(SentSound{managerName, samplerName, place});
    }
    return true;
}

bool transferProject(const BankProject& from, const std::vector<SentSound>& plan, BankProject& out, std::string& error) {
    out = BankProject{};
    out.name = from.name;
    std::unordered_map<std::size_t, std::uint32_t> msMap;       // old multisample index -> new
    std::unordered_map<std::uint32_t, std::uint32_t> smpMap;    // old sample index -> new
    for (const auto& item : plan) {
        std::size_t index = from.sounds.size();
        for (std::size_t i = 0U; i < from.sounds.size(); ++i) if (from.sounds[i].name == item.managerName) { index = i; break; }
        if (index == from.sounds.size()) { error = "The SOUND \"" + item.managerName + "\" is not in the project any more."; return false; }
        if (item.place < kMinSoundPosition || item.place > kMaxSoundPosition) { error = "A place outside 1...500."; return false; }
        SoundDefinition sound = from.sounds[index];
        sound.name = item.samplerName;
        sound.position = static_cast<std::uint16_t>(item.place);
        for (auto& layer : sound.layers) {
            const std::size_t oldMs = layer.multisampleIndex;
            if (oldMs >= from.multisamples.size()) { error = "A layer of \"" + item.managerName + "\" has no multisample."; return false; }
            auto found = msMap.find(oldMs);
            if (found == msMap.end()) {
                ImportedMultisample ms = from.multisamples[oldMs];
                ms.multisampleId = static_cast<std::uint32_t>(out.multisamples.size() + 1U);
                for (auto& zone : ms.zones) {
                    const std::uint32_t oldSmp = zone.sampleIndex;
                    if (oldSmp >= from.samples.size()) { error = "A zone of \"" + item.managerName + "\" has no sample."; return false; }
                    auto s = smpMap.find(oldSmp);
                    if (s == smpMap.end()) {
                        ImportedSample sample = from.samples[oldSmp];
                        sample.sampleId = static_cast<std::uint32_t>(out.samples.size() + 1U);
                        s = smpMap.emplace(oldSmp, static_cast<std::uint32_t>(out.samples.size())).first;
                        out.samples.push_back(std::move(sample));
                    }
                    zone.sampleIndex = s->second;
                }
                found = msMap.emplace(oldMs, static_cast<std::uint32_t>(out.multisamples.size())).first;
                out.multisamples.push_back(std::move(ms));
            }
            layer.multisampleIndex = found->second;
        }
        const std::size_t at = out.sounds.size();
        sound.slot = static_cast<std::uint16_t>(at % 128U);
        sound.page = static_cast<std::uint16_t>((at / 128U) % 128U);
        sound.bank = static_cast<std::uint16_t>(at / (128U * 128U));
        out.sounds.push_back(std::move(sound));
    }
    if (out.sounds.empty()) { error = "Nothing to send."; return false; }
    return true;
}

} // namespace silveton::manager
