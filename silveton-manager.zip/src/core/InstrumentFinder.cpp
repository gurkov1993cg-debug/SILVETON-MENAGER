#include "silveton/manager/InstrumentFinder.h"

#include <algorithm>
#include <cctype>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <utility>

namespace silveton::manager {
namespace {

std::string lowerCase(std::string text) {
    for (char& c : text) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return text;
}

// 1 = Kontakt .nki, 2 = Korg .kmp, 0 = anything else
int instrumentKind(const std::string& name) {
    const std::size_t dot = name.find_last_of('.');
    if (dot == std::string::npos) return 0;
    const std::string ext = lowerCase(name.substr(dot));
    if (ext == ".nki") return 1;
    if (ext == ".kmp") return 2;
    return 0;
}

struct Pending {
    std::string path;
    std::string relative;
    int depth;
};

} // namespace

InstrumentSearchResult InstrumentFinder::search(const std::string& root,
                                                const InstrumentSearchOptions& options,
                                                const std::atomic<bool>* cancel,
                                                const Progress& progress) {
    InstrumentSearchResult result;
    struct stat rootInfo;
    if (root.empty() || ::stat(root.c_str(), &rootInfo) != 0 || !S_ISDIR(rootInfo.st_mode)) {
        result.error = "The folder cannot be opened: " + root;
        return result;
    }

    std::vector<Pending> stack;
    stack.push_back(Pending{root, std::string(), 0});
    std::size_t sinceReport = 0U;
    while (!stack.empty()) {
        if (cancel != nullptr && cancel->load()) { result.cancelled = true; break; }
        if (result.directories >= options.maxDirectories) { result.cutOff = true; break; }
        Pending here = std::move(stack.back());
        stack.pop_back();
        DIR* dir = ::opendir(here.path.c_str());
        if (dir == nullptr) continue;                       // no right to look inside: skipped
        ++result.directories;
        const std::string prefix = here.path.back() == '/' ? here.path : here.path + "/";
        while (const dirent* entry = ::readdir(dir)) {
            const std::string name = entry->d_name;
            if (name.empty() || name[0] == '.') continue;   // hidden entries, ".", "..", macOS "._" copies
            const std::string full = prefix + name;
            struct stat info;
            if (::lstat(full.c_str(), &info) != 0) continue;
            if (S_ISDIR(info.st_mode)) {
                if (here.depth < options.maxDepth) {
                    stack.push_back(Pending{full, here.relative.empty() ? name : here.relative + "/" + name, here.depth + 1});
                } else {
                    result.cutOff = true;
                }
                continue;
            }
            if (!S_ISREG(info.st_mode)) continue;           // links and other special entries are not followed
            const int kind = instrumentKind(name);
            if (kind == 0) continue;
            if (result.files.size() >= options.maxResults) {
                result.cutOff = true;
                stack.clear();
                break;
            }
            FoundInstrumentFile file;
            file.path = full;
            file.folder = here.relative;
            file.name = name;
            file.kontakt = (kind == 1);
            file.bytes = static_cast<std::uint64_t>(info.st_size);
            result.files.push_back(std::move(file));
        }
        ::closedir(dir);
        if (progress && ++sinceReport >= 25U) {
            sinceReport = 0U;
            progress(result.directories, result.files.size());
        }
    }

    std::sort(result.files.begin(), result.files.end(), [](const FoundInstrumentFile& left, const FoundInstrumentFile& right) {
        const std::string leftFolder = lowerCase(left.folder);
        const std::string rightFolder = lowerCase(right.folder);
        if (leftFolder != rightFolder) return leftFolder < rightFolder;
        return lowerCase(left.name) < lowerCase(right.name);
    });
    if (progress) progress(result.directories, result.files.size());
    return result;
}

} // namespace silveton::manager
