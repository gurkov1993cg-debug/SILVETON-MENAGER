// SILVETON_ANALYZER_V2
#include "silveton/manager/SpectrumAnalyzer.h"
#include "silveton/manager/SampleConverter.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <complex>
#include <thread>

namespace silveton::manager {
namespace {

constexpr double kPi = 3.14159265358979323846;

void fft(std::vector<std::complex<double>>& a) {
    const std::size_t n = a.size();
    for (std::size_t i = 1U, j = 0U; i < n; ++i) {
        std::size_t bit = n >> 1U;
        for (; (j & bit) != 0U; bit >>= 1U) j ^= bit;
        j ^= bit;
        if (i < j) std::swap(a[i], a[j]);
    }
    for (std::size_t len = 2U; len <= n; len <<= 1U) {
        const double ang = -2.0 * kPi / static_cast<double>(len);
        const std::complex<double> wl(std::cos(ang), std::sin(ang));
        for (std::size_t i = 0U; i < n; i += len) {
            std::complex<double> w(1.0, 0.0);
            for (std::size_t k = 0U; k < len / 2U; ++k) {
                const std::complex<double> u = a[i + k];
                const std::complex<double> v = a[i + k + len / 2U] * w;
                a[i + k] = u + v;
                a[i + k + len / 2U] = u - v;
                w *= wl;
            }
        }
    }
}

const std::vector<double>& hann() {
    static const std::vector<double> w = [] {
        std::vector<double> v(SpectrumAnalyzer::kFftSize);
        for (std::size_t i = 0U; i < v.size(); ++i) {
            v[i] = 0.5 - 0.5 * std::cos(2.0 * kPi * static_cast<double>(i) / static_cast<double>(v.size()));
        }
        return v;
    }();
    return w;
}

// Power per FFT bin, scaled so that a full scale sine gives 0 dB.
void powerOf(const std::vector<float>& mono, std::int64_t start, std::vector<float>& power) {
    const std::size_t n = SpectrumAnalyzer::kFftSize;
    const std::vector<double>& w = hann();
    std::vector<std::complex<double>> buf(n);
    for (std::size_t i = 0U; i < n; ++i) {
        const std::int64_t at = start + static_cast<std::int64_t>(i);
        const double x = (at >= 0 && at < static_cast<std::int64_t>(mono.size())) ? static_cast<double>(mono[static_cast<std::size_t>(at)]) : 0.0;
        buf[i] = std::complex<double>(x * w[i], 0.0);
    }
    fft(buf);
    const double norm = 2.0 / (static_cast<double>(n) * 0.5);  // window sum = n/2
    power.resize(n / 2U + 1U);
    for (std::size_t k = 0U; k <= n / 2U; ++k) {
        const double mag = std::abs(buf[k]) * norm;
        power[k] = static_cast<float>(mag * mag);
    }
}

} // namespace

double SpectrumAnalyzer::pointHz(std::size_t point) noexcept {
    const double t = static_cast<double>(point) / static_cast<double>(kPoints - 1U);
    return 20.0 * std::pow(1000.0, t);  // 20 Hz ... 20 kHz
}

std::vector<float> SpectrumAnalyzer::monoMix(const ImportedSample& sample) {
    std::vector<float> mono;
    if (!sample.valid()) return mono;
    const std::vector<double> v = SampleConverter::decode(sample);
    const std::size_t ch = sample.channels;
    const std::size_t frames = v.size() / ch;
    mono.resize(frames);
    for (std::size_t f = 0U; f < frames; ++f) {
        double m = 0.0;
        for (std::size_t c = 0U; c < ch; ++c) m += v[f * ch + c];
        mono[f] = static_cast<float>(m / static_cast<double>(ch));
    }
    return mono;
}

std::vector<float> SpectrumAnalyzer::powerAt(const std::vector<float>& mono, std::uint64_t frame) {
    std::vector<float> power;
    powerOf(mono, static_cast<std::int64_t>(frame) - static_cast<std::int64_t>(kFftSize), power);
    return power;
}

SpectrumPower SpectrumAnalyzer::analyse(const ImportedSample& sample) {
    SpectrumPower out;
    if (!sample.valid()) return out;
    const std::vector<float> mono = monoMix(sample);
    if (mono.empty()) return out;
    out.sampleRate = sample.sampleRate;
    double sq = 0.0;
    float peak = 0.0F;
    for (float x : mono) { sq += static_cast<double>(x) * x; peak = std::max(peak, std::fabs(x)); }
    out.peak = peak;
    out.rms = static_cast<float>(std::sqrt(sq / static_cast<double>(mono.size())));
    const std::size_t hop = kFftSize / 4U;  // 75 % overlap
    const std::size_t blocks = mono.size() > kFftSize ? (mono.size() - kFftSize) / hop + 1U : 1U;
    const std::size_t step = blocks > 600U ? (blocks + 599U) / 600U : 1U;  // long samples: at most ~600 blocks
    std::vector<double> sum(kFftSize / 2U + 1U, 0.0);
    out.maximum.assign(sum.size(), 0.0F);
    std::vector<float> power;
    std::size_t used = 0U;
    for (std::size_t b = 0U; b < blocks; b += step) {
        powerOf(mono, static_cast<std::int64_t>(b * hop), power);
        for (std::size_t k = 0U; k < sum.size(); ++k) {
            sum[k] += power[k];
            out.maximum[k] = std::max(out.maximum[k], power[k]);
        }
        ++used;
    }
    out.average.resize(sum.size());
    for (std::size_t k = 0U; k < sum.size(); ++k) out.average[k] = static_cast<float>(sum[k] / static_cast<double>(std::max<std::size_t>(1U, used)));
    return out;
}

std::vector<float> SpectrumAnalyzer::toCurve(const std::vector<float>& binPower, std::uint32_t sampleRate, double smoothOctaves) {
    std::vector<float> out(kPoints, kFloorDb);
    if (binPower.size() < 2U || sampleRate == 0U) return out;
    const double binHz = static_cast<double>(sampleRate) / static_cast<double>(kFftSize);
    const double nyquist = static_cast<double>(sampleRate) / 2.0;
    const double oct = std::max(1.0 / 48.0, smoothOctaves);
    const std::size_t last = binPower.size() - 1U;
    for (std::size_t p = 0U; p < kPoints; ++p) {
        const double hz = pointHz(p);
        if (hz >= nyquist * 0.995) break;
        // gaussian in frequency: full width at half height = `oct` octaves, never narrower than ~1.4 bins
        const double fwhm = hz * (std::pow(2.0, oct / 2.0) - std::pow(2.0, -oct / 2.0));
        const double sigma = std::max(fwhm / 2.3548, 0.6 * binHz);
        const double lo = std::max(0.0, hz - 3.0 * sigma);
        const double hi = hz + 3.0 * sigma;
        const std::size_t k0 = std::min(last, static_cast<std::size_t>(std::floor(lo / binHz)));
        const std::size_t k1 = std::min(last, static_cast<std::size_t>(std::ceil(hi / binHz)));
        double sum = 0.0, wsum = 0.0;
        for (std::size_t k = k0; k <= k1; ++k) {
            const double d = (static_cast<double>(k) * binHz - hz) / sigma;
            const double g = std::exp(-0.5 * d * d);
            sum += g * binPower[k];
            wsum += g;
        }
        // energy in the band (a Hann window spreads one sine over 1.5 bins): a sine reads its true level
        // at any smoothing. The display adds (slope - 3) dB/oct so slope 4.5 looks exactly like SPAN.
        (void)wsum;
        const double v = sum / 1.5;
        out[p] = v > 1e-16 ? static_cast<float>(10.0 * std::log10(v)) : kFloorDb;
    }
    return out;
}

std::vector<SpectrumPower> SpectrumAnalyzer::analyseMany(const BankProject& project,
                                                         const std::vector<std::size_t>& indexes,
                                                         const std::function<void(double)>& progress,
                                                         const std::atomic<bool>* cancel) {
    const std::size_t n = indexes.size();
    std::vector<SpectrumPower> out(n);
    std::atomic<std::size_t> next{0U};
    std::atomic<std::size_t> done{0U};
    auto worker = [&]() {
        for (;;) {
            if (cancel != nullptr && cancel->load()) return;
            const std::size_t i = next.fetch_add(1U);
            if (i >= n) return;
            if (indexes[i] < project.samples.size()) out[i] = analyse(project.samples[indexes[i]]);
            done.fetch_add(1U);
        }
    };
    const unsigned threads = std::max(1U, std::min(std::thread::hardware_concurrency(), static_cast<unsigned>(std::max<std::size_t>(1U, n))));
    std::vector<std::thread> pool;
    for (unsigned t = 0U; t < threads; ++t) pool.emplace_back(worker);
    while (done.load() < n) {
        if (cancel != nullptr && cancel->load()) break;
        if (progress) progress(static_cast<double>(done.load()) / static_cast<double>(std::max<std::size_t>(1U, n)));
        std::this_thread::sleep_for(std::chrono::milliseconds(40));
    }
    for (auto& t : pool) t.join();
    if (progress) progress(1.0);
    return out;
}

} // namespace silveton::manager
