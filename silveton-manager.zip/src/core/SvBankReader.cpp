#include "silveton/manager/SvBankReader.h"

#include "silveton/manager/SampleHash.h"

#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <limits>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace silveton::manager {
namespace {

bool sectionValid(const SvBankHeader& header, SvSection section) noexcept {
    const auto& s = header.sections[static_cast<std::size_t>(section)];
    return s.offset >= kSvBankHeaderSize && s.offset <= header.fileSize && s.size <= header.fileSize - s.offset;
}

bool sectionsNonOverlapping(const SvBankHeader& header) noexcept {
    std::array<SvSectionDesc, kSvSectionCount> sections = header.sections;
    std::sort(sections.begin(), sections.end(), [](const SvSectionDesc& a, const SvSectionDesc& b) {
        return a.offset < b.offset;
    });
    std::uint64_t previousEnd = kSvBankHeaderSize;
    for (const auto& section : sections) {
        if (section.offset < previousEnd || section.size > header.fileSize - section.offset) return false;
        previousEnd = section.offset + section.size;
    }
    return true;
}

bool recordSectionSize(const SvBankHeader& header, SvSection section, std::uint64_t count, std::size_t recordSize) noexcept {
    const auto& s = header.sections[static_cast<std::size_t>(section)];
    if (count > std::numeric_limits<std::uint64_t>::max() / recordSize) return false;
    return s.size == count * static_cast<std::uint64_t>(recordSize);
}

bool readString(const std::vector<std::uint8_t>& bytes, const SvBankHeader& header,
                std::uint32_t offset, std::string& out) {
    const auto& strings = header.sections[static_cast<std::size_t>(SvSection::Strings)];
    if (offset >= strings.size) return false;
    const std::uint64_t begin64 = strings.offset + static_cast<std::uint64_t>(offset);
    const std::uint64_t end64 = strings.offset + strings.size;
    if (begin64 > bytes.size() || end64 > bytes.size()) return false;
    const std::size_t begin = static_cast<std::size_t>(begin64);
    const std::size_t end = static_cast<std::size_t>(end64);
    std::size_t pos = begin;
    while (pos < end && bytes[pos] != 0U) ++pos;
    if (pos >= end) return false;
    out.assign(reinterpret_cast<const char*>(bytes.data() + begin), pos - begin);
    return true;
}

bool validLoop(const SvSampleRecord& record) noexcept {
    if (record.loopEnabled == 0U) return true;
    if (record.loopStart >= record.loopEnd || record.loopEnd > record.totalFrames) return false;
    const std::uint64_t loopLength = record.loopEnd - record.loopStart;
    return static_cast<std::uint64_t>(record.loopCrossfadeFrames) <= loopLength;
}

} // namespace

SvReadResult SvBankReader::read(const std::vector<std::uint8_t>& bytes, bool verifyIntegrity) {
    SvReadResult out{};
    if (!deserializeHeader(bytes.data(), bytes.size(), out.header, out.error)) return out;
    if (out.header.fileSize != bytes.size()) { out.error = "SV2 bank file-size mismatch"; return out; }
    for (std::size_t i = 0U; i < kSvSectionCount; ++i) {
        if (!sectionValid(out.header, static_cast<SvSection>(i))) {
            out.error = "SV2 bank section is outside file bounds";
            return out;
        }
    }
    if (!sectionsNonOverlapping(out.header)) { out.error = "SV2 bank sections overlap or are invalid"; return out; }
    if (!recordSectionSize(out.header, SvSection::Sounds, out.header.soundCount, kSvSoundRecordSize) ||
        !recordSectionSize(out.header, SvSection::SoundLayers, out.header.soundLayerCount, kSvSoundLayerRecordSize) ||
        !recordSectionSize(out.header, SvSection::Multisamples, out.header.multisampleCount, kSvMultisampleRecordSize) ||
        !recordSectionSize(out.header, SvSection::Samples, out.header.sampleCount, kSvSampleRecordSize) ||
        !recordSectionSize(out.header, SvSection::Zones, out.header.zoneCount, kSvZoneRecordSize)) {
        out.error = "SV2 bank record-section size mismatch";
        return out;
    }
    if (out.header.soundCount > static_cast<std::uint32_t>(kMaxSoundPosition)) {
        out.error = "SV2 bank contains more than 500 SOUND slots";
        return out;
    }
    if (verifyIntegrity) {
        const auto digest = sha256(bytes.data() + kSvBankHeaderSize, bytes.size() - kSvBankHeaderSize);
        if (digest != out.header.payloadSha256) { out.error = "SV2 bank SHA-256 integrity mismatch"; return out; }
    }

    if (!readString(bytes, out.header, out.header.bankNameOffset, out.project.name)) {
        out.error = "SV2 bank name string offset is invalid";
        return out;
    }

    const auto& sampleSec = out.header.sections[static_cast<std::size_t>(SvSection::Samples)];
    const auto& audioSec = out.header.sections[static_cast<std::size_t>(SvSection::Audio)];
    out.project.samples.reserve(out.header.sampleCount);
    std::unordered_map<std::uint32_t, std::uint32_t> sampleIdToIndex;
    sampleIdToIndex.reserve(out.header.sampleCount);
    for (std::uint32_t i = 0U; i < out.header.sampleCount; ++i) {
        SvSampleRecord sr{};
        const std::uint64_t recordOffset64 = sampleSec.offset + static_cast<std::uint64_t>(i) * kSvSampleRecordSize;
        if (recordOffset64 > bytes.size()) { out.error = "SV2 sample record offset is invalid"; return out; }
        const std::size_t recordOffset = static_cast<std::size_t>(recordOffset64);
        if (!readSampleRecord(bytes.data() + recordOffset, bytes.size() - recordOffset, sr)) { out.error = "Cannot decode SV2 sample record"; return out; }
        if (sr.sampleId == 0U || sampleIdToIndex.find(sr.sampleId) != sampleIdToIndex.end()) {
            out.error = "SV2 bank contains duplicate/zero SampleID";
            return out;
        }
        if (sr.audioOffset > audioSec.size || sr.audioSize > audioSec.size - sr.audioOffset) {
            out.error = "SV2 sample audio range is invalid";
            return out;
        }
        if (!validLoop(sr)) { out.error = "SV2 sample loop range is invalid"; return out; }

        ImportedSample sample{};
        if (!readString(bytes, out.header, sr.nameOffset, sample.name) ||
            !readString(bytes, out.header, sr.sourceIdentityOffset, sample.sourceIdentity)) {
            out.error = "SV2 sample string offset is invalid";
            return out;
        }
        sample.sampleId = sr.sampleId;
        sample.sampleRate = sr.sampleRate;
        sample.channels = sr.channels;
        sample.encoding = static_cast<AudioEncoding>(sr.encoding);
        sample.bitsPerSample = sr.bitsPerSample;
        sample.rootKey = sr.rootKey;
        sample.fineTuneCents = sr.fineTuneCents;
        sample.totalFrames = sr.totalFrames;
        sample.loop.enabled = sr.loopEnabled != 0U;
        sample.loop.startFrame = sr.loopStart;
        sample.loop.endFrame = sr.loopEnd;
        sample.loop.crossfadeFrames = sr.loopCrossfadeFrames;

        const std::uint64_t audioStart64 = audioSec.offset + sr.audioOffset;
        const std::uint64_t audioEnd64 = audioStart64 + sr.audioSize;
        if (audioStart64 > bytes.size() || audioEnd64 > bytes.size()) { out.error = "SV2 sample audio offset is outside file"; return out; }
        const std::size_t audioStart = static_cast<std::size_t>(audioStart64);
        const std::size_t audioEnd = static_cast<std::size_t>(audioEnd64);
        sample.audioData.assign(bytes.begin() + static_cast<std::ptrdiff_t>(audioStart),
                                bytes.begin() + static_cast<std::ptrdiff_t>(audioEnd));
        if (!sample.valid()) { out.error = "SV2 sample record failed semantic validation"; return out; }
        if (hashSampleAudio(sample) != sr.audioHash) { out.error = "SV2 sample audio hash mismatch"; return out; }

        sampleIdToIndex.emplace(sr.sampleId, i);
        out.project.samples.push_back(std::move(sample));
    }

    const auto& zoneSec = out.header.sections[static_cast<std::size_t>(SvSection::Zones)];
    std::vector<ImportedZone> allZones;
    allZones.reserve(out.header.zoneCount);
    for (std::uint32_t i = 0U; i < out.header.zoneCount; ++i) {
        SvZoneRecord zr{};
        const std::uint64_t recordOffset64 = zoneSec.offset + static_cast<std::uint64_t>(i) * kSvZoneRecordSize;
        if (recordOffset64 > bytes.size()) { out.error = "SV2 zone record offset is invalid"; return out; }
        const std::size_t recordOffset = static_cast<std::size_t>(recordOffset64);
        if (!readZoneRecord(bytes.data() + recordOffset, bytes.size() - recordOffset, zr)) { out.error = "Cannot decode SV2 zone record"; return out; }
        if (zr.sampleId == 0U) { out.error = "SV2 Zone contains zero SampleID"; return out; }
        const auto sampleIt = sampleIdToIndex.find(zr.sampleId);
        if (sampleIt == sampleIdToIndex.end()) { out.error = "SV2 Zone references missing SampleID"; return out; }

        ImportedZone z{};
        z.sampleIndex = sampleIt->second;
        z.keyLow = zr.keyLow; z.keyHigh = zr.keyHigh;
        z.velocityLow = zr.velocityLow; z.velocityHigh = zr.velocityHigh;
        z.rootKey = zr.rootKey; z.transposeSemitones = zr.transposeSemitones;
        z.oneShot = (zr.flags & 1U) != 0U; z.reverse = (zr.flags & 2U) != 0U; z.nonTranspose = (zr.flags & 4U) != 0U;
        z.sourcePanRaw = zr.sourcePanRaw; z.sourceLevelRaw = zr.sourceLevelRaw; z.sourceFilterRaw = zr.sourceFilterRaw;
        z.tuneCents = zr.tuneCents; z.gainDb = zr.gainDb; z.pan = zr.pan;
        if (z.keyLow > z.keyHigh || z.velocityLow == 0U || z.velocityLow > z.velocityHigh) {
            out.error = "SV2 zone failed semantic validation";
            return out;
        }
        allZones.push_back(z);
    }

    const auto& msSec = out.header.sections[static_cast<std::size_t>(SvSection::Multisamples)];
    out.project.multisamples.reserve(out.header.multisampleCount);
    std::unordered_map<std::uint32_t, std::uint32_t> multisampleIdToIndex;
    multisampleIdToIndex.reserve(out.header.multisampleCount);
    for (std::uint32_t i = 0U; i < out.header.multisampleCount; ++i) {
        SvMultisampleRecord mr{};
        const std::uint64_t recordOffset64 = msSec.offset + static_cast<std::uint64_t>(i) * kSvMultisampleRecordSize;
        if (recordOffset64 > bytes.size()) { out.error = "SV2 multisample record offset is invalid"; return out; }
        const std::size_t recordOffset = static_cast<std::size_t>(recordOffset64);
        if (!readMultisampleRecord(bytes.data() + recordOffset, bytes.size() - recordOffset, mr)) { out.error = "Cannot decode SV2 multisample record"; return out; }
        if (mr.multisampleId == 0U || multisampleIdToIndex.find(mr.multisampleId) != multisampleIdToIndex.end()) {
            out.error = "SV2 bank contains duplicate/zero MultisampleID";
            return out;
        }
        if (mr.firstZone > allZones.size() || mr.zoneCount > allZones.size() - mr.firstZone) {
            out.error = "SV2 multisample zone range is invalid";
            return out;
        }

        ImportedMultisample ms{};
        ms.multisampleId = mr.multisampleId;
        if (!readString(bytes, out.header, mr.nameOffset, ms.name) ||
            !readString(bytes, out.header, mr.sourceIdentityOffset, ms.sourceIdentity)) {
            out.error = "SV2 multisample string offset is invalid";
            return out;
        }
        ms.zones.assign(allZones.begin() + static_cast<std::ptrdiff_t>(mr.firstZone),
                        allZones.begin() + static_cast<std::ptrdiff_t>(mr.firstZone + mr.zoneCount));
        if (ms.zones.empty()) { out.error = "SV2 multisample has no zones"; return out; }
        multisampleIdToIndex.emplace(mr.multisampleId, i);
        out.project.multisamples.push_back(std::move(ms));
    }

    const auto& layerSec = out.header.sections[static_cast<std::size_t>(SvSection::SoundLayers)];
    std::vector<SoundLayer> allLayers;
    allLayers.reserve(out.header.soundLayerCount);
    for (std::uint32_t i = 0U; i < out.header.soundLayerCount; ++i) {
        SvSoundLayerRecord lr{};
        const std::uint64_t recordOffset64 = layerSec.offset + static_cast<std::uint64_t>(i) * kSvSoundLayerRecordSize;
        if (recordOffset64 > bytes.size()) { out.error = "SV2 SOUND layer record offset is invalid"; return out; }
        const std::size_t recordOffset = static_cast<std::size_t>(recordOffset64);
        if (!readSoundLayerRecord(bytes.data() + recordOffset, bytes.size() - recordOffset, lr)) { out.error = "Cannot decode SV2 SOUND layer record"; return out; }
        if (lr.multisampleId == 0U) { out.error = "SV2 SOUND layer contains zero MultisampleID"; return out; }
        const auto multisampleIt = multisampleIdToIndex.find(lr.multisampleId);
        if (multisampleIt == multisampleIdToIndex.end()) { out.error = "SV2 SOUND layer references missing MultisampleID"; return out; }
        if (lr.keyLow > lr.keyHigh || lr.velocityLow == 0U || lr.velocityLow > lr.velocityHigh) {
            out.error = "SV2 SOUND layer failed semantic validation";
            return out;
        }

        SoundLayer layer{};
        layer.multisampleIndex = multisampleIt->second;
        layer.enabled = lr.enabled != 0U;
        layer.keyLow = lr.keyLow; layer.keyHigh = lr.keyHigh;
        layer.velocityLow = lr.velocityLow; layer.velocityHigh = lr.velocityHigh;
        layer.transposeSemitones = lr.transposeSemitones;
        layer.tuneCents = lr.tuneCents; layer.levelDb = lr.levelDb; layer.pan = lr.pan;
        allLayers.push_back(layer);
    }

    const auto& soundSec = out.header.sections[static_cast<std::size_t>(SvSection::Sounds)];
    out.project.sounds.reserve(out.header.soundCount);
    std::unordered_set<std::uint16_t> soundSlots;
    for (std::uint32_t i = 0U; i < out.header.soundCount; ++i) {
        SvSoundRecord sr{};
        const std::uint64_t recordOffset64 = soundSec.offset + static_cast<std::uint64_t>(i) * kSvSoundRecordSize;
        if (recordOffset64 > bytes.size()) { out.error = "SV2 SOUND record offset is invalid"; return out; }
        const std::size_t recordOffset = static_cast<std::size_t>(recordOffset64);
        if (!readSoundRecord(bytes.data() + recordOffset, bytes.size() - recordOffset, sr)) { out.error = "Cannot decode SV2 SOUND record"; return out; }
        if (sr.soundSlotId < kMinSoundPosition || sr.soundSlotId > kMaxSoundPosition || !soundSlots.insert(sr.soundSlotId).second) {
            out.error = "SV2 bank contains duplicate/invalid SOUND slot";
            return out;
        }
        if (sr.layerCount == 0U || sr.firstLayer > allLayers.size() || sr.layerCount > allLayers.size() - sr.firstLayer) {
            out.error = "SV2 SOUND layer range is invalid";
            return out;
        }

        SoundDefinition sound{};
        if (!readString(bytes, out.header, sr.nameOffset, sound.name)) { out.error = "SV2 SOUND name offset is invalid"; return out; }
        sound.position = sr.soundSlotId;
        sound.category = sr.category;
        sound.layers.assign(allLayers.begin() + static_cast<std::ptrdiff_t>(sr.firstLayer),
                            allLayers.begin() + static_cast<std::ptrdiff_t>(sr.firstLayer + sr.layerCount));
        out.project.sounds.push_back(std::move(sound));
    }

    out.error.clear();
    return out;
}

SvReadResult SvBankReader::readFile(const std::string& path, bool verifyIntegrity) {
    std::ifstream in(path, std::ios::binary | std::ios::ate);
    if (!in) { SvReadResult r{}; r.error = "Cannot open SV2 bank: " + path; return r; }
    const auto size = in.tellg();
    if (size < 0) { SvReadResult r{}; r.error = "Cannot determine SV2 bank size"; return r; }
    in.seekg(0, std::ios::beg);
    std::vector<std::uint8_t> bytes(static_cast<std::size_t>(size));
    if (!bytes.empty() && !in.read(reinterpret_cast<char*>(bytes.data()), size)) { SvReadResult r{}; r.error = "Failed to read SV2 bank"; return r; }
    return read(bytes, verifyIntegrity);
}

} // namespace silveton::manager
