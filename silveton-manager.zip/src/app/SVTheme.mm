// SILVETON_LOOK_V1 - shared look and custom controls.
#import "SVTheme.h"

#include <algorithm>
#include <cmath>

namespace {
NSColor* rgb(int r, int g, int b) { return [NSColor colorWithCalibratedRed:r / 255.0 green:g / 255.0 blue:b / 255.0 alpha:1.0]; }
}

NSColor* SVColBackground(void) { return rgb(13, 16, 19); }
NSColor* SVColBar(void) { return rgb(21, 25, 30); }
NSColor* SVColPanel(void) { return rgb(20, 26, 31); }
NSColor* SVColBorder(void) { return rgb(42, 48, 56); }
NSColor* SVColField(void) { return rgb(11, 14, 17); }
NSColor* SVColAmber(void) { return rgb(240, 168, 48); }
NSColor* SVColAmberLight(void) { return rgb(247, 193, 90); }
NSColor* SVColAmberText(void) { return rgb(26, 20, 8); }
NSColor* SVColText(void) { return rgb(230, 233, 236); }
NSColor* SVColDim(void) { return rgb(154, 163, 173); }
NSColor* SVColSelection(void) { return rgb(43, 37, 22); }
NSColor* SVColSelectionText(void) { return rgb(255, 210, 122); }
NSColor* SVColGreen(void) { return rgb(127, 211, 138); }
NSColor* SVColRed(void) { return rgb(255, 154, 154); }
NSColor* SVColRedFill(void) { return rgb(58, 28, 28); }
NSColor* SVColKeyOff(void) { return rgb(28, 33, 39); }

NSFont* SVFont(CGFloat size, BOOL bold) {
    return [NSFont systemFontOfSize:size weight:bold ? NSFontWeightSemibold : NSFontWeightRegular];
}

NSTextField* SVLabel(NSRect frame, NSString* text, CGFloat size, BOOL bold, NSColor* color) {
    NSTextField* label = [[NSTextField alloc] initWithFrame:frame];
    label.stringValue = text ?: @"";
    label.editable = NO;
    label.selectable = NO;
    label.bezeled = NO;
    label.drawsBackground = NO;
    label.font = SVFont(size, bold);
    label.textColor = color ?: SVColText();
    label.lineBreakMode = NSLineBreakByTruncatingTail;
    return label;
}

NSTextField* SVTitle(NSRect frame, NSString* text) {
    NSTextField* label = SVLabel(frame, text, 12.0, YES, SVColAmber());
    NSMutableAttributedString* spaced = [[NSMutableAttributedString alloc] initWithString:text ?: @""];
    [spaced addAttributes:@{NSKernAttributeName: @1.5, NSFontAttributeName: SVFont(12.0, YES), NSForegroundColorAttributeName: SVColAmber()}
                    range:NSMakeRange(0, spaced.length)];
    label.attributedStringValue = spaced;
    return label;
}

NSTextField* SVField(NSRect frame, NSString* text) {
    NSTextField* field = [[NSTextField alloc] initWithFrame:frame];
    field.stringValue = text ?: @"";
    field.editable = YES;
    field.selectable = YES;
    field.bezeled = YES;
    field.bezelStyle = NSTextFieldSquareBezel;
    field.drawsBackground = YES;
    field.backgroundColor = SVColField();
    field.textColor = SVColText();
    field.font = SVFont(12.0, NO);
    return field;
}

NSPopUpButton* SVPopup(NSRect frame) {
    NSPopUpButton* popup = [[NSPopUpButton alloc] initWithFrame:frame pullsDown:NO];
    popup.font = SVFont(12.0, NO);
    return popup;
}

NSScrollView* SVScroll(NSRect frame, NSView* document) {
    NSScrollView* scroll = [[NSScrollView alloc] initWithFrame:frame];
    scroll.hasVerticalScroller = YES;
    scroll.hasHorizontalScroller = NO;
    scroll.borderType = NSBezelBorder;
    scroll.backgroundColor = SVColField();
    scroll.drawsBackground = YES;
    scroll.documentView = document;
    return scroll;
}

void SVStyleTable(NSTableView* table) {
    table.backgroundColor = SVColField();
    table.usesAlternatingRowBackgroundColors = NO;
    table.rowHeight = 24.0;
    table.gridStyleMask = NSTableViewGridNone;
    table.font = SVFont(13.0, NO);
}

NSTableColumn* SVTextColumn(NSString* identifier, NSString* title, CGFloat width) {
    NSTableColumn* column = [[NSTableColumn alloc] initWithIdentifier:identifier];
    column.title = title ?: @"";
    column.width = width;
    column.minWidth = 20.0;
    NSTextFieldCell* cell = [[NSTextFieldCell alloc] init];
    cell.font = SVFont(13.0, NO);
    cell.textColor = SVColText();
    cell.lineBreakMode = NSLineBreakByTruncatingTail;
    column.dataCell = cell;
    column.editable = NO;
    return column;
}

NSTableColumn* SVCheckColumn(NSString* identifier, CGFloat width) {
    NSTableColumn* column = [[NSTableColumn alloc] initWithIdentifier:identifier];
    column.title = @"";
    column.width = width;
    column.minWidth = 20.0;
    NSButtonCell* cell = [[NSButtonCell alloc] init];
    [cell setButtonType:NSButtonTypeSwitch];
    cell.title = @"";
    cell.controlSize = NSControlSizeSmall;
    column.dataCell = cell;
    column.editable = YES;
    return column;
}

void SVAlert(NSWindow* window, NSString* title, NSString* text, BOOL critical) {
    NSAlert* alert = [[NSAlert alloc] init];
    alert.messageText = title ?: @"SILVETON Manager";
    alert.informativeText = text ?: @"";
    alert.alertStyle = critical ? NSAlertStyleCritical : NSAlertStyleWarning;
    (void)window;
    [alert runModal];
}

BOOL SVConfirm(NSWindow* window, NSString* title, NSString* text, NSString* okTitle) {
    (void)window;
    NSAlert* alert = [[NSAlert alloc] init];
    alert.messageText = title ?: @"";
    alert.informativeText = text ?: @"";
    [alert addButtonWithTitle:okTitle ?: @"Да"];
    [alert addButtonWithTitle:@"Отказ"];
    return [alert runModal] == NSAlertFirstButtonReturn ? YES : NO;
}

NSString* SVAskText(NSWindow* window, NSString* title, NSString* text, NSString* initial) {
    (void)window;
    NSAlert* alert = [[NSAlert alloc] init];
    alert.messageText = title ?: @"";
    alert.informativeText = text ?: @"";
    [alert addButtonWithTitle:@"Добре"];
    [alert addButtonWithTitle:@"Отказ"];
    NSTextField* field = [[NSTextField alloc] initWithFrame:NSMakeRect(0.0, 0.0, 320.0, 24.0)];
    field.stringValue = initial ?: @"";
    field.editable = YES;
    field.selectable = YES;
    alert.accessoryView = field;
    if ([alert runModal] != NSAlertFirstButtonReturn) return nil;
    return [field.stringValue stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

NSString* SVNoteName(NSInteger midi) {
    static NSString* const names[12] = {@"C", @"C#", @"D", @"D#", @"E", @"F", @"F#", @"G", @"G#", @"A", @"A#", @"B"};
    if (midi < 0 || midi > 127) return @"-";
    return [NSString stringWithFormat:@"%@%ld", names[midi % 12], static_cast<long>(midi / 12 - 1)];
}

NSString* SVMegabytes(double bytes) {
    const double mb = bytes / (1024.0 * 1024.0);
    if (mb >= 1024.0) return [NSString stringWithFormat:@"%.2f GB", mb / 1024.0];
    if (mb >= 10.0) return [NSString stringWithFormat:@"%.0f MB", mb];
    return [NSString stringWithFormat:@"%.1f MB", mb];
}

NSString* SVSeconds(double seconds) {
    if (seconds < 1.0) return [NSString stringWithFormat:@"%.0f ms", seconds * 1000.0];
    return [NSString stringWithFormat:@"%.2f s", seconds];
}

// ---------------------------------------------------------------- flipped view / panel

@implementation SVFlippedView
- (BOOL)isFlipped { return YES; }
@end

@implementation SVPanel
- (instancetype)initWithFrame:(NSRect)frame title:(NSString*)title {
    self = [super initWithFrame:frame];
    if (self) {
        _title = [title copy];
    }
    return self;
}
- (void)setTitle:(NSString*)title { _title = [title copy]; [self setNeedsDisplay:YES]; }
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    NSRect box = NSInsetRect(self.bounds, 0.5, 0.5);
    NSBezierPath* path = [NSBezierPath bezierPathWithRoundedRect:box xRadius:8.0 yRadius:8.0];
    [SVColPanel() setFill];
    [path fill];
    [SVColBorder() setStroke];
    path.lineWidth = 1.0;
    [path stroke];
    if (_title.length > 0U) {
        NSDictionary* attrs = @{NSFontAttributeName: SVFont(12.0, YES), NSForegroundColorAttributeName: SVColAmber(), NSKernAttributeName: @1.5};
        [_title drawAtPoint:NSMakePoint(12.0, 10.0) withAttributes:attrs];
    }
}
@end

// ---------------------------------------------------------------- nav button

@implementation SVNavButton
- (instancetype)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) { self.bordered = NO; [self setButtonType:NSButtonTypeMomentaryChange]; _on = NO; _number = 0; }
    return self;
}
- (void)setOn:(BOOL)on { _on = on; [self setNeedsDisplay:YES]; }
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    NSRect box = NSInsetRect(self.bounds, 0.5, 0.5);
    NSBezierPath* path = [NSBezierPath bezierPathWithRoundedRect:box xRadius:8.0 yRadius:8.0];
    if (_on) {
        [SVColAmber() setFill]; [path fill];
        [SVColAmberLight() setStroke]; [path stroke];
    } else {
        [SVColKeyOff() setFill]; [path fill];
        [SVColBorder() setStroke]; [path stroke];
    }
    const CGFloat r = 13.0;
    NSRect circle = NSMakeRect(14.0, NSMidY(self.bounds) - r, 2.0 * r, 2.0 * r);
    NSBezierPath* c = [NSBezierPath bezierPathWithOvalInRect:circle];
    [(_on ? SVColAmberText() : [NSColor colorWithCalibratedRed:0.165 green:0.192 blue:0.224 alpha:1.0]) setFill];
    [c fill];
    NSString* number = [NSString stringWithFormat:@"%ld", static_cast<long>(_number)];
    NSDictionary* numberAttrs = @{NSFontAttributeName: SVFont(13.0, YES), NSForegroundColorAttributeName: _on ? SVColAmber() : SVColText()};
    NSSize ns = [number sizeWithAttributes:numberAttrs];
    [number drawAtPoint:NSMakePoint(NSMidX(circle) - ns.width / 2.0, NSMidY(circle) - ns.height / 2.0) withAttributes:numberAttrs];
    NSDictionary* titleAttrs = @{NSFontAttributeName: SVFont(15.0, YES), NSForegroundColorAttributeName: _on ? SVColAmberText() : SVColText(), NSKernAttributeName: @1.0};
    NSSize ts = [self.title sizeWithAttributes:titleAttrs];
    [self.title drawAtPoint:NSMakePoint(NSMaxX(circle) + 12.0, NSMidY(self.bounds) - ts.height / 2.0) withAttributes:titleAttrs];
}
@end

// ---------------------------------------------------------------- key button

@implementation SVKeyButton
+ (instancetype)keyWithFrame:(NSRect)frame title:(NSString*)title kind:(NSInteger)kind target:(id)target action:(SEL)action {
    SVKeyButton* key = [[SVKeyButton alloc] initWithFrame:frame];
    key.title = title ?: @"";
    key.kind = kind;
    key.target = target;
    key.action = action;
    return key;
}
- (instancetype)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) { self.bordered = NO; [self setButtonType:NSButtonTypeMomentaryChange]; _kind = 0; _textSize = 13.0; }
    return self;
}
- (void)setKind:(NSInteger)kind { _kind = kind; [self setNeedsDisplay:YES]; }
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    NSRect box = NSInsetRect(self.bounds, 0.5, 0.5);
    NSBezierPath* path = [NSBezierPath bezierPathWithRoundedRect:box xRadius:6.0 yRadius:6.0];
    NSColor* fill = _kind == 1 ? SVColAmber() : _kind == 2 ? SVColRedFill() : SVColKeyOff();
    NSColor* border = _kind == 1 ? SVColAmberLight() : _kind == 2 ? [NSColor colorWithCalibratedRed:0.35 green:0.16 blue:0.16 alpha:1.0] : SVColBorder();
    NSColor* text = _kind == 1 ? SVColAmberText() : _kind == 2 ? SVColRed() : SVColText();
    if (!self.enabled) { fill = [fill colorWithAlphaComponent:0.45]; text = [text colorWithAlphaComponent:0.45]; }
    if ([self.cell isHighlighted] && self.enabled) fill = [fill highlightWithLevel:0.15] ?: fill;
    [fill setFill]; [path fill];
    [border setStroke]; [path stroke];
    NSDictionary* attrs = @{NSFontAttributeName: SVFont(_textSize, YES), NSForegroundColorAttributeName: text, NSKernAttributeName: @0.5};
    NSSize size = [self.title sizeWithAttributes:attrs];
    [self.title drawAtPoint:NSMakePoint(NSMidX(self.bounds) - size.width / 2.0, NSMidY(self.bounds) - size.height / 2.0) withAttributes:attrs];
}
@end

// ---------------------------------------------------------------- toggle

@implementation SVToggle
- (instancetype)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) { self.bordered = NO; [self setButtonType:NSButtonTypeMomentaryChange]; self.title = @""; _on = NO; }
    return self;
}
- (void)setOn:(BOOL)on { _on = on; [self setNeedsDisplay:YES]; }
- (void)mouseDown:(NSEvent*)event {
    (void)event;
    if (!self.enabled) return;
    self.on = !_on;
    if (self.target != nil && self.action != nullptr) [NSApp sendAction:self.action to:self.target from:self];
}
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    const CGFloat h = std::min(self.bounds.size.height, 22.0);
    NSRect pill = NSMakeRect(0.0, NSMidY(self.bounds) - h / 2.0, std::min(self.bounds.size.width, 44.0), h);
    NSBezierPath* path = [NSBezierPath bezierPathWithRoundedRect:pill xRadius:h / 2.0 yRadius:h / 2.0];
    [(_on ? SVColAmber() : [NSColor colorWithCalibratedRed:0.165 green:0.192 blue:0.224 alpha:1.0]) setFill];
    [path fill];
    const CGFloat k = h - 4.0;
    NSRect knob = NSMakeRect(_on ? NSMaxX(pill) - k - 2.0 : pill.origin.x + 2.0, pill.origin.y + 2.0, k, k);
    [(_on ? SVColAmberText() : SVColDim()) setFill];
    [[NSBezierPath bezierPathWithOvalInRect:knob] fill];
}
@end

// ---------------------------------------------------------------- knob

@implementation SVKnob {
    NSPoint _dragStart;
    double _dragValue;
}
- (instancetype)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) { _value = 0.0; _minimum = 0.0; _maximum = 1.0; _step = 0.0; _label = @""; _enabled = YES; _action = nullptr; }
    return self;
}
- (void)setEnabled:(BOOL)enabled { _enabled = enabled; [self setNeedsDisplay:YES]; }
- (void)fire { if (_target != nil && _action != nullptr) [NSApp sendAction:_action to:_target from:self]; }
- (void)setValue:(double)value {
    double v = std::isfinite(value) ? std::min(std::max(value, _minimum), _maximum) : _minimum;
    if (_step > 0.0) v = _minimum + std::round((v - _minimum) / _step) * _step;
    _value = std::min(std::max(v, _minimum), _maximum);
    [self setNeedsDisplay:YES];
}
- (void)mouseDown:(NSEvent*)event {
    if (!_enabled) return;
    _dragStart = [self convertPoint:event.locationInWindow fromView:nil];
    _dragValue = _value;
}
- (void)mouseDragged:(NSEvent*)event {
    if (!_enabled) return;
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    const double dy = _dragStart.y - p.y;   // flipped view: dragging up makes the value bigger
    const double fine = (event.modifierFlags & NSEventModifierFlagShift) != 0U ? 0.2 : 1.0;
    self.value = _dragValue + dy / 150.0 * (_maximum - _minimum) * fine;
    [self fire];
}
- (void)scrollWheel:(NSEvent*)event {
    if (!_enabled) return;
    self.value = _value + event.scrollingDeltaY / 300.0 * (_maximum - _minimum);
    [self fire];
}
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    const CGFloat d = std::min(self.bounds.size.width, 46.0);
    NSRect circle = NSMakeRect(NSMidX(self.bounds) - d / 2.0, 0.0, d, d);
    NSBezierPath* c = [NSBezierPath bezierPathWithOvalInRect:NSInsetRect(circle, 1.0, 1.0)];
    [[NSColor colorWithCalibratedRed:0.13 green:0.15 blue:0.18 alpha:1.0] setFill];
    [c fill];
    [[NSColor colorWithCalibratedRed:0.23 green:0.26 blue:0.30 alpha:1.0] setStroke];
    c.lineWidth = 2.0;
    [c stroke];
    const double t = _maximum > _minimum ? (_value - _minimum) / (_maximum - _minimum) : 0.0;
    const double angle = (135.0 - 270.0 * t) * M_PI / 180.0;   // 7 o'clock .. 5 o'clock
    const CGFloat r = d / 2.0 - 4.0;
    NSPoint center = NSMakePoint(NSMidX(circle), NSMidY(circle));
    NSBezierPath* line = [NSBezierPath bezierPath];
    [line moveToPoint:NSMakePoint(center.x + std::cos(angle) * r * 0.45, center.y - std::sin(angle) * r * 0.45)];
    [line lineToPoint:NSMakePoint(center.x + std::cos(angle) * r, center.y - std::sin(angle) * r)];
    line.lineWidth = 2.5;
    [(_enabled ? SVColAmber() : SVColDim()) setStroke];
    [line stroke];
    NSString* value = _format != nil ? _format(_value) : [NSString stringWithFormat:@"%.2f", _value];
    NSDictionary* va = @{NSFontAttributeName: SVFont(12.0, NO), NSForegroundColorAttributeName: SVColText()};
    NSSize vs = [value sizeWithAttributes:va];
    [value drawAtPoint:NSMakePoint(NSMidX(self.bounds) - vs.width / 2.0, d + 4.0) withAttributes:va];
    NSDictionary* la = @{NSFontAttributeName: SVFont(10.0, NO), NSForegroundColorAttributeName: SVColDim(), NSKernAttributeName: @0.5};
    NSSize ls = [_label sizeWithAttributes:la];
    [_label drawAtPoint:NSMakePoint(NSMidX(self.bounds) - ls.width / 2.0, d + 20.0) withAttributes:la];
}
- (BOOL)isFlipped { return YES; }
@end

// ---------------------------------------------------------------- bar

@implementation SVBar
- (void)setFraction:(double)fraction { _fraction = std::isfinite(fraction) ? std::min(std::max(fraction, 0.0), 1.0) : 0.0; [self setNeedsDisplay:YES]; }
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    NSRect box = NSInsetRect(self.bounds, 0.5, 0.5);
    const CGFloat r = box.size.height / 2.0;
    NSBezierPath* path = [NSBezierPath bezierPathWithRoundedRect:box xRadius:r yRadius:r];
    [SVColKeyOff() setFill]; [path fill];
    [SVColBorder() setStroke]; [path stroke];
    if (_fraction > 0.0) {
        NSRect fill = box;
        fill.size.width = std::max(box.size.height, box.size.width * _fraction);
        [SVColAmber() setFill];
        [[NSBezierPath bezierPathWithRoundedRect:fill xRadius:r yRadius:r] fill];
    }
}
@end
