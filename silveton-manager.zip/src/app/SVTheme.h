// SILVETON_LOOK_V1 - the look of the Manager: dark board, matte dark = off.
// SILVETON_MERGE_V1: the colours of the sampler - green = on / chosen, white text, yellow = look here, blue = marked.
// (The functions keep their old names "Amber": they are the colour of "on", which is green now.)
// Shared colours, fonts and the few custom controls every page is built from.
#pragma once
#import <AppKit/AppKit.h>

#ifdef __cplusplus
extern "C" {
#endif

NSColor* SVColBackground(void);   // window
NSColor* SVColBar(void);          // top / bottom bars
NSColor* SVColPanel(void);        // panel fill
NSColor* SVColBorder(void);       // panel border
NSColor* SVColField(void);        // list / lcd background
NSColor* SVColAmber(void);
NSColor* SVColAmberLight(void);
NSColor* SVColAmberText(void);    // dark text on amber
NSColor* SVColText(void);
NSColor* SVColDim(void);
NSColor* SVColSelection(void);    // selected row fill
NSColor* SVColSelectionText(void);
NSColor* SVColGreen(void);
NSColor* SVColRed(void);
NSColor* SVColRedFill(void);
NSColor* SVColKeyOff(void);       // matte dark key
NSColor* SVColWarn(void);         // yellow: look here (a guess, not done yet, overlapping)
NSColor* SVColMark(void);         // blue: marked / a folder
NSColor* SVColWave(void);         // a waveform or a range (no state)

NSFont* SVFont(CGFloat size, BOOL bold);

// labels
NSTextField* SVLabel(NSRect frame, NSString* text, CGFloat size, BOOL bold, NSColor* color);
NSTextField* SVTitle(NSRect frame, NSString* text);                 // amber, letter spaced panel title
NSTextField* SVField(NSRect frame, NSString* text);                 // editable value field
NSPopUpButton* SVPopup(NSRect frame);
NSScrollView* SVScroll(NSRect frame, NSView* document);
void SVStyleTable(NSTableView* table);
NSTableColumn* SVTextColumn(NSString* identifier, NSString* title, CGFloat width);
NSTableColumn* SVCheckColumn(NSString* identifier, CGFloat width);
void SVAlert(NSWindow* window, NSString* title, NSString* text, BOOL critical);
BOOL SVConfirm(NSWindow* window, NSString* title, NSString* text, NSString* okTitle);
NSString* SVAskText(NSWindow* window, NSString* title, NSString* text, NSString* initial);   // nil = cancelled
NSString* SVNoteName(NSInteger midi);
NSString* SVMegabytes(double bytes);
NSString* SVSeconds(double seconds);

#ifdef __cplusplus
}
#endif

// A flipped container: y grows downwards, like the drawings.
@interface SVFlippedView : NSView
@end

// Rounded panel with an optional amber title in the top left corner. Flipped.
@interface SVPanel : SVFlippedView
@property(nonatomic, copy) NSString* title;
- (instancetype)initWithFrame:(NSRect)frame title:(NSString*)title;
@end

// Big page button on the left: number in a circle + name. Amber when it is the current page.
@interface SVNavButton : NSButton
@property(nonatomic) BOOL on;
@property(nonatomic) NSInteger number;
@end

// Normal key. kind 0 = dark, 1 = amber action, 2 = red (delete / stop).
@interface SVKeyButton : NSButton
@property(nonatomic) NSInteger kind;
@property(nonatomic) CGFloat textSize;
+ (instancetype)keyWithFrame:(NSRect)frame title:(NSString*)title kind:(NSInteger)kind target:(id)target action:(SEL)action;
@end

// ON / OFF switch. Amber when on. `on` is the state; target/action fires on click.
@interface SVToggle : NSButton
@property(nonatomic) BOOL on;
@end

// Round knob: drag up / down (or scroll) to change. Shows the value under it and a small label.
@interface SVKnob : NSView
@property(nonatomic, weak) id target;
@property(nonatomic) SEL action;
@property(nonatomic) BOOL enabled;
@property(nonatomic) double value;
@property(nonatomic) double minimum;
@property(nonatomic) double maximum;
@property(nonatomic) double step;
@property(nonatomic, copy) NSString* label;
@property(nonatomic, copy) NSString* (^format)(double value);
@end

// Horizontal bar 0..1 (progress / level).
@interface SVBar : NSView
@property(nonatomic) double fraction;
@end
