// SILVETON_UNUSED_SOUNDS_V1 - which sounds of a bank the blends of the sampler use (plain C++, also used by the test on Linux).
// Used = a blend of the LIST next to the sampler's bank (SILVETON_BLENDS.SVSET) or of a saved set (SILVETON_SETS) has it as its basic
// sound, as a layer or as a TRANSWAVE frame, or the COMBI that is open now has it. A blend remembers place + name of each sound and
// finds it by name - the same rule (resolveSoundByName) the sampler uses when it loads the blends.
#pragma once

#include "silveton/sampler/SamplerTypes.h"
#include "silveton/sampler/SetPackage.h"
#include "silveton/ui/SamplerAppController.h"

#include <sys/stat.h>

#include <cstdint>
#include <set>
#include <string>
#include <utility>
#include <vector>

// sounds: (position 1..500, name) of every sound of the bank. false = something could not be read or there is no blend at all
// (then nothing may be deleted); `why` says what.
inline bool SVUsedSoundPositions(silveton::ui::SamplerAppController& controller, const std::vector<std::pair<int, std::string>>& sounds,
                                 std::set<int>& used, std::string& why) {
    namespace sp = silveton::sampler;
    used.clear();
    std::vector<sp::SoundCandidate> candidates;
    for (const auto& s : sounds) {
        if (s.first <= 0 || s.first > 65535) continue;
        sp::SoundCandidate c;
        c.slot = static_cast<std::uint16_t>(s.first);
        c.name = s.second;
        candidates.push_back(c);
    }
    auto mark = [&](std::uint16_t slot, const std::string& name) {
        if (slot == sp::kNoSoundSlot) return;
        const auto found = sp::resolveSoundByName(slot, name, candidates);
        if (found.found) used.insert(static_cast<int>(found.slot));
    };
    auto markWaves = [&](const sp::ToneExtra& x) {   // TRANSWAVE MULTI: other sounds are its frames
        for (const auto slot : x.waveSlot) if (slot != 0U) used.insert(static_cast<int>(slot));
    };
    auto markName = [&](const std::string& name) {   // the open COMBI: every sound with that name
        if (name.empty()) return;
        for (const auto& c : candidates) if (c.name == name) used.insert(static_cast<int>(c.slot));
    };
    auto present = [](const std::string& path) {
        struct stat st {};
        return ::stat(path.c_str(), &st) == 0;
    };

    const std::string setsDir = controller.setsFolders();
    const std::size_t cut = setsDir.find_last_of('/');
    const std::string folder = cut == std::string::npos ? std::string(".") : setsDir.substr(0U, cut);
    std::vector<std::string> files;
    const std::string blends = folder + "/SILVETON_BLENDS.SVSET";
    if (present(blends)) files.push_back(blends);
    for (const auto& name : controller.savedSets()) files.push_back(setsDir + "/" + name + ".SVSET");

    std::size_t blendCount = 0U;
    for (const auto& file : files) {
        const auto loaded = sp::SetPackage::load(file);
        if (!loaded.ok()) { why = "Не се чете „" + file + "“: " + loaded.error; return false; }
        for (const auto& slot : loaded.data.combis) {
            ++blendCount;
            for (const auto& u : slot.combi.uppers) {
                mark(u.soundSlotId, u.name);
                markWaves(u.toneExtra);
                for (const auto& l : u.layers) {
                    mark(l.soundSlotId, l.name);
                    markWaves(l.tone.x);
                }
            }
        }
    }
    for (int u = 0; u < sp::kUpperCount; ++u) {
        const auto state = controller.upperState(u);
        if (state) markName(state->soundName);
        for (int l = 0; l < sp::kUpperLayers; ++l) markName(controller.layerName(u, l));
        for (int s = 0; s <= sp::kUpperLayers; ++s) {   // TRANSWAVE frames of the open COMBI (ids 10..17 = sound slots)
            const std::vector<float> wave = controller.soundWaveParams(u, s);
            for (std::size_t i = 10U; i < wave.size() && i < 18U; ++i) if (wave[i] >= 1.0F) used.insert(static_cast<int>(wave[i] + 0.5F));
        }
    }
    if (blendCount == 0U) { why = "Още няма записани бленди в ЛИСТА - не се знае кое се ползва, затова нищо не се трие."; return false; }
    why.clear();
    return true;
}
