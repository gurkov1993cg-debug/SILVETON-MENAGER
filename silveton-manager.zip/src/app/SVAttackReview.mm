// SILVETON_ATTACK_V1 - look before you cut: every sample that starts late, drawn with the cut line on it.
#import "SVAttackReview.h"
#import "SVTheme.h"

#include <algorithm>
#include <cmath>

// ---------------------------------------------------------------- the little picture in a row

@interface SVMiniWaveCell : NSCell
@end

@implementation SVMiniWaveCell

- (void)drawInteriorWithFrame:(NSRect)frame inView:(NSView*)view {
    (void)view;
    NSDictionary* row = [self objectValue];
    if (![row isKindOfClass:[NSDictionary class]]) return;
    NSArray<NSNumber*>* points = row[@"points"];
    const NSRect box = NSInsetRect(frame, 2.0, 3.0);
    [SVColField() setFill];
    NSRectFill(box);

    const CGFloat mid = NSMidY(box);
    const CGFloat half = (box.size.height - 4.0) / 2.0;
    [[SVColBorder() colorWithAlphaComponent:0.7] setFill];
    NSRectFill(NSMakeRect(box.origin.x, mid, box.size.width, 1.0));

    const NSUInteger n = points.count / 2U;
    const double cut = [row[@"cut"] doubleValue];
    const CGFloat cutX = box.origin.x + box.size.width * static_cast<CGFloat>(std::min(1.0, std::max(0.0, cut)));
    if (n > 0U) {
        // what goes away is drawn dim, what stays is drawn in amber
        for (NSUInteger i = 0U; i < n; ++i) {
            const CGFloat x = box.origin.x + box.size.width * static_cast<CGFloat>(i) / static_cast<CGFloat>(std::max<NSUInteger>(1U, n - 1U));
            const double lo = points[i * 2U].doubleValue, hi = points[i * 2U + 1U].doubleValue;
            [(x < cutX ? SVColDim() : SVColAmber()) setFill];
            const CGFloat top = mid - half * static_cast<CGFloat>(hi);
            const CGFloat bottom = mid - half * static_cast<CGFloat>(lo);
            NSRectFill(NSMakeRect(x, std::min(top, bottom), 1.0, std::max<CGFloat>(1.0, std::fabs(bottom - top))));
        }
    }
    // the cut itself
    [SVColGreen() setFill];
    NSRectFill(NSMakeRect(cutX - 1.0, box.origin.y, 2.0, box.size.height));

    NSDictionary* attrs = @{NSFontAttributeName: SVFont(9.0, NO), NSForegroundColorAttributeName: SVColDim()};
    NSString* span = [NSString stringWithFormat:@"%.0f ms", [row[@"window"] doubleValue] * 1000.0];
    [span drawAtPoint:NSMakePoint(NSMaxX(box) - 46.0, NSMaxY(box) - 13.0) withAttributes:attrs];
    [SVColBorder() setStroke];
    [[NSBezierPath bezierPathWithRect:NSInsetRect(box, 0.5, 0.5)] stroke];
}

@end

// ---------------------------------------------------------------- the window

@interface SVAttackReviewPanel : NSObject <NSTableViewDataSource, NSTableViewDelegate>
@end

@implementation SVAttackReviewPanel {
    NSPanel* _panel;
    NSTableView* _table;
    NSTextField* _count;
    NSArray<NSDictionary<NSString*, id>*>* _rows;
    NSMutableArray<NSNumber*>* _ticked;      // one YES/NO per row
    BOOL _accepted;
}

- (instancetype)initWithRows:(NSArray<NSDictionary<NSString*, id>*>*)rows {
    self = [super init];
    if (self) {
        _rows = [rows copy];
        _accepted = NO;
        _ticked = [NSMutableArray arrayWithCapacity:_rows.count];
        for (NSUInteger i = 0U; i < _rows.count; ++i) [_ticked addObject:@(YES)];

        _panel = [[NSPanel alloc] initWithContentRect:NSMakeRect(0.0, 0.0, 900.0, 620.0)
                                            styleMask:(NSWindowStyleMaskTitled | NSWindowStyleMaskResizable)
                                              backing:NSBackingStoreBuffered
                                                defer:NO];
        _panel.title = @"Начало на семплите";
        _panel.backgroundColor = SVColBackground();
        NSView* c = _panel.contentView;

        NSTextField* title = SVLabel(NSMakeRect(20.0, 584.0, 860.0, 22.0), @"КЪДЕ ЩЕ СЕ РЕЖЕ", 16.0, YES, SVColAmber());
        title.autoresizingMask = NSViewMinYMargin | NSViewWidthSizable;
        [c addSubview:title];
        NSTextField* hint = SVLabel(NSMakeRect(20.0, 560.0, 860.0, 18.0),
                                    @"Зелената черта е мястото на рязане. Сивото пред нея се маха, жълтото остава. Показано е само началото, до първия удар.",
                                    11.0, NO, SVColDim());
        hint.autoresizingMask = NSViewMinYMargin | NSViewWidthSizable;
        [c addSubview:hint];

        _table = [[NSTableView alloc] initWithFrame:NSZeroRect];
        SVStyleTable(_table);
        _table.rowHeight = 52.0;
        _table.dataSource = self;
        _table.delegate = self;
        [_table addTableColumn:SVCheckColumn(@"on", 26.0)];
        [_table addTableColumn:SVTextColumn(@"name", @"СЕМПЪЛ", 260.0)];
        NSTableColumn* lead = SVTextColumn(@"lead", @"ТИШИНА", 90.0);
        [(NSTextFieldCell*)lead.dataCell setAlignment:NSTextAlignmentRight];
        [_table addTableColumn:lead];
        NSTableColumn* wave = [[NSTableColumn alloc] initWithIdentifier:@"wave"];
        wave.title = @"НАЧАЛОТО НА ЗВУКА";
        wave.width = 470.0;
        wave.dataCell = [[SVMiniWaveCell alloc] init];
        [_table addTableColumn:wave];
        NSScrollView* scroll = SVScroll(NSMakeRect(20.0, 70.0, 860.0, 478.0), _table);
        scroll.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
        [c addSubview:scroll];

        SVKeyButton* all = [SVKeyButton keyWithFrame:NSMakeRect(20.0, 20.0, 110.0, 34.0) title:@"ВСИЧКИ" kind:0 target:self action:@selector(tickAll:)];
        all.textSize = 11.0; all.autoresizingMask = NSViewMaxYMargin; [c addSubview:all];
        SVKeyButton* none = [SVKeyButton keyWithFrame:NSMakeRect(138.0, 20.0, 110.0, 34.0) title:@"НИЩО" kind:0 target:self action:@selector(tickNone:)];
        none.textSize = 11.0; none.autoresizingMask = NSViewMaxYMargin; [c addSubview:none];
        _count = SVLabel(NSMakeRect(258.0, 28.0, 300.0, 18.0), @"", 11.0, NO, SVColDim());
        _count.autoresizingMask = NSViewMaxYMargin; [c addSubview:_count];

        SVKeyButton* cancel = [SVKeyButton keyWithFrame:NSMakeRect(630.0, 20.0, 110.0, 34.0) title:@"ОТКАЗ" kind:0 target:self action:@selector(cancelPressed:)];
        cancel.autoresizingMask = NSViewMaxYMargin | NSViewMinXMargin;
        cancel.keyEquivalent = @"\x1b";
        [c addSubview:cancel];
        SVKeyButton* ok = [SVKeyButton keyWithFrame:NSMakeRect(750.0, 20.0, 130.0, 34.0) title:@"ОТРЕЖИ" kind:1 target:self action:@selector(okPressed:)];
        ok.autoresizingMask = NSViewMaxYMargin | NSViewMinXMargin;
        ok.keyEquivalent = @"\r";
        [c addSubview:ok];
        [self updateCount];
    }
    return self;
}

- (void)updateCount {
    NSUInteger on = 0U;
    for (NSNumber* n in _ticked) if (n.boolValue) ++on;
    _count.stringValue = [NSString stringWithFormat:@"Отметнати %lu от %lu.", static_cast<unsigned long>(on), static_cast<unsigned long>(_rows.count)];
}

- (NSArray<NSNumber*>*)run {
    [_panel center];
    [NSApp runModalForWindow:_panel];
    [_panel orderOut:nil];
    if (!_accepted) return nil;
    NSMutableArray<NSNumber*>* chosen = [NSMutableArray array];
    for (NSUInteger i = 0U; i < _rows.count; ++i) {
        if (_ticked[i].boolValue) [chosen addObject:_rows[i][@"index"]];
    }
    return chosen;
}

- (void)tickAll:(id)sender {
    (void)sender;
    for (NSUInteger i = 0U; i < _ticked.count; ++i) _ticked[i] = @(YES);
    [_table reloadData];
    [self updateCount];
}
- (void)tickNone:(id)sender {
    (void)sender;
    for (NSUInteger i = 0U; i < _ticked.count; ++i) _ticked[i] = @(NO);
    [_table reloadData];
    [self updateCount];
}
- (void)okPressed:(id)sender { (void)sender; _accepted = YES; [NSApp stopModal]; }
- (void)cancelPressed:(id)sender { (void)sender; _accepted = NO; [NSApp stopModal]; }

- (NSInteger)numberOfRowsInTableView:(NSTableView*)tableView { (void)tableView; return static_cast<NSInteger>(_rows.count); }

- (id)tableView:(NSTableView*)tableView objectValueForTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView;
    if (row < 0 || static_cast<NSUInteger>(row) >= _rows.count) return nil;
    NSDictionary* item = _rows[static_cast<NSUInteger>(row)];
    NSString* identifier = tableColumn.identifier;
    if ([identifier isEqualToString:@"on"]) return _ticked[static_cast<NSUInteger>(row)];
    if ([identifier isEqualToString:@"name"]) return item[@"name"];
    if ([identifier isEqualToString:@"lead"]) return [NSString stringWithFormat:@"%.0f ms", [item[@"leadIn"] doubleValue] * 1000.0];
    return item;
}

- (void)tableView:(NSTableView*)tableView setObjectValue:(id)object forTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView;
    if (row < 0 || static_cast<NSUInteger>(row) >= _ticked.count) return;
    if (![tableColumn.identifier isEqualToString:@"on"]) return;
    _ticked[static_cast<NSUInteger>(row)] = @([object boolValue]);
    [self updateCount];
}

@end

NSArray<NSNumber*>* SVReviewLateStarts(NSWindow* parent, NSArray<NSDictionary<NSString*, id>*>* rows) {
    (void)parent;
    if (rows.count == 0U) return nil;
    SVAttackReviewPanel* panel = [[SVAttackReviewPanel alloc] initWithRows:rows];
    return [panel run];
}
