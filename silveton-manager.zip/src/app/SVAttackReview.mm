// SILVETON_ATTACK_V1 - look before you cut: every sample that starts late, drawn with the cut line on it.
#import "SVAttackReview.h"
#import "SVTheme.h"

#include <algorithm>
#include <cmath>

// ---------------------------------------------------------------- the little picture in a row

@interface SVMiniWaveCell : NSCell
@end

@implementation SVMiniWaveCell

- (void)drawInteriorWithFrame:(NSRect)frame inView:(NSView*)view {
    (void)view;
    NSDictionary* row = [self objectValue];
    if (![row isKindOfClass:[NSDictionary class]]) return;
    NSArray<NSNumber*>* points = row[@"points"];
    const NSRect box = NSInsetRect(frame, 2.0, 3.0);
    [SVColField() setFill];
    NSRectFill(box);

    const CGFloat mid = NSMidY(box);
    const CGFloat half = (box.size.height - 4.0) / 2.0;
    [[SVColBorder() colorWithAlphaComponent:0.7] setFill];
    NSRectFill(NSMakeRect(box.origin.x, mid, box.size.width, 1.0));

    const NSUInteger n = points.count / 2U;
    const double cut = [row[@"cut"] doubleValue];
    const CGFloat cutX = box.origin.x + box.size.width * static_cast<CGFloat>(std::min(1.0, std::max(0.0, cut)));
    if (n > 0U) {
        // what goes away is drawn dim, what stays is drawn in amber
        for (NSUInteger i = 0U; i < n; ++i) {
            const CGFloat x = box.origin.x + box.size.width * static_cast<CGFloat>(i) / static_cast<CGFloat>(std::max<NSUInteger>(1U, n - 1U));
            const double lo = points[i * 2U].doubleValue, hi = points[i * 2U + 1U].doubleValue;
            [(x < cutX ? SVColDim() : SVColWave()) setFill];
            const CGFloat top = mid - half * static_cast<CGFloat>(hi);
            const CGFloat bottom = mid - half * static_cast<CGFloat>(lo);
            NSRectFill(NSMakeRect(x, std::min(top, bottom), 1.0, std::max<CGFloat>(1.0, std::fabs(bottom - top))));
        }
    }
    // the cut itself
    [SVColGreen() setFill];
    NSRectFill(NSMakeRect(cutX - 1.0, box.origin.y, 2.0, box.size.height));

    NSDictionary* attrs = @{NSFontAttributeName: SVFont(9.0, NO), NSForegroundColorAttributeName: SVColDim()};
    NSString* span = [NSString stringWithFormat:@"%.0f ms", [row[@"window"] doubleValue] * 1000.0];
    [span drawAtPoint:NSMakePoint(NSMaxX(box) - 46.0, NSMaxY(box) - 13.0) withAttributes:attrs];
    [SVColBorder() setStroke];
    [[NSBezierPath bezierPathWithRect:NSInsetRect(box, 0.5, 0.5)] stroke];
}

@end

// ---------------------------------------------------------------- a table whose line can be dragged

@interface SVReviewTable : NSTableView
@property(nonatomic, copy) void (^onMoveLine)(NSInteger row, double fraction);
@property(nonatomic, copy) void (^onEndMove)(void);      // SILVETON_ATTACK_V3: the mouse button went up after moving a line
@end

@implementation SVReviewTable {
    BOOL _movingLine;
}
- (void)moveLineFor:(NSEvent*)event {
    if (_onMoveLine == nil) return;
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    const NSInteger row = [self rowAtPoint:p];
    const NSInteger column = [self columnAtPoint:p];
    if (row < 0 || column < 0) return;
    NSTableColumn* which = (NSTableColumn*)self.tableColumns[static_cast<NSUInteger>(column)];
    if (![which.identifier isEqualToString:@"wave"]) return;
    const NSRect box = NSInsetRect([self frameOfCellAtColumn:column row:row], 2.0, 3.0);
    if (box.size.width <= 1.0) return;
    _onMoveLine(row, static_cast<double>((p.x - box.origin.x) / box.size.width));
}
- (void)mouseDown:(NSEvent*)event {
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    const NSInteger column = [self columnAtPoint:p];
    NSTableColumn* which = column >= 0 ? (NSTableColumn*)self.tableColumns[static_cast<NSUInteger>(column)] : nil;
    if (which != nil && [which.identifier isEqualToString:@"wave"]) {
        _movingLine = YES;
        [self moveLineFor:event];
        return;                      // the picture is for moving the line, not for picking rows
    }
    [super mouseDown:event];
}
- (void)mouseDragged:(NSEvent*)event { [self moveLineFor:event]; }
- (void)mouseUp:(NSEvent*)event {
    if (_movingLine) {
        _movingLine = NO;
        if (_onEndMove != nil) _onEndMove();
        return;
    }
    [super mouseUp:event];
}
@end

// ---------------------------------------------------------------- the window

@interface SVAttackReviewPanel : NSObject <NSTableViewDataSource, NSTableViewDelegate>
@end

@implementation SVAttackReviewPanel {
    NSPanel* _panel;
    SVReviewTable* _table;
    NSTextField* _count;
    NSArray<NSDictionary<NSString*, id>*>* _rows;
    NSMutableArray<NSNumber*>* _ticked;      // one YES/NO per row
    NSMutableArray<NSNumber*>* _cuts;        // where the line stands now, 0...1 inside the picture
    BOOL _accepted;
    SVReviewPlayBlock _play;                 // SILVETON_ATTACK_V3
    SVToggle* _playOn;                       // ON = the part in front of the line sounds while the line is moved
    NSInteger _movedRow;                     // the row whose line was moved last
    CFAbsoluteTime _busyUntil;               // the last little piece is still sounding until then
}

- (instancetype)initWithBlendName:(NSString*)blendName rows:(NSArray<NSDictionary<NSString*, id>*>*)rows play:(SVReviewPlayBlock)play {
    self = [super init];
    if (self) {
        _rows = [rows copy];
        _play = [play copy];
        _movedRow = -1;
        _busyUntil = 0.0;
        _accepted = NO;
        _ticked = [NSMutableArray arrayWithCapacity:_rows.count];
        _cuts = [NSMutableArray arrayWithCapacity:_rows.count];
        for (NSUInteger i = 0U; i < _rows.count; ++i) {
            [_ticked addObject:@(YES)];
            [_cuts addObject:_rows[i][@"cut"] ?: @(0.0)];
        }

        _panel = [[NSPanel alloc] initWithContentRect:NSMakeRect(0.0, 0.0, 900.0, 620.0)
                                            styleMask:(NSWindowStyleMaskTitled | NSWindowStyleMaskResizable)
                                              backing:NSBackingStoreBuffered
                                                defer:NO];
        _panel.title = @"Начало на семплите";
        _panel.backgroundColor = SVColBackground();
        NSView* c = _panel.contentView;

        NSTextField* title = SVLabel(NSMakeRect(20.0, 584.0, 860.0, 22.0), blendName.length > 0U ? [NSString stringWithFormat:@"КЪДЕ ЩЕ СЕ РЕЖЕ  ·  %@", blendName] : @"КЪДЕ ЩЕ СЕ РЕЖЕ", 16.0, YES, SVColText());
        title.autoresizingMask = NSViewMinYMargin | NSViewWidthSizable;
        [c addSubview:title];
        NSTextField* hint = SVLabel(NSMakeRect(20.0, 560.0, 860.0, 18.0),
                                    @"Зелената черта е мястото на рязане: сивото пред нея се маха, жълтото остава. Хвани я с мишката и я мести, където искаш. Показано е само началото, до първия удар.",
                                    11.0, NO, SVColDim());
        hint.autoresizingMask = NSViewMinYMargin | NSViewWidthSizable;
        [c addSubview:hint];

        _table = [[SVReviewTable alloc] initWithFrame:NSZeroRect];
        SVStyleTable(_table);
        _table.rowHeight = 52.0;
        _table.dataSource = self;
        _table.delegate = self;
        [_table addTableColumn:SVCheckColumn(@"on", 26.0)];
        [_table addTableColumn:SVTextColumn(@"name", @"СЕМПЪЛ", 260.0)];
        NSTableColumn* lead = SVTextColumn(@"lead", @"ТИШИНА", 90.0);
        [(NSTextFieldCell*)lead.dataCell setAlignment:NSTextAlignmentRight];
        [_table addTableColumn:lead];
        NSTableColumn* wave = [[NSTableColumn alloc] initWithIdentifier:@"wave"];
        wave.title = @"НАЧАЛОТО НА ЗВУКА";
        wave.width = 470.0;
        wave.dataCell = [[SVMiniWaveCell alloc] init];
        [_table addTableColumn:wave];
        __weak SVAttackReviewPanel* weakSelf = self;
        _table.onMoveLine = ^(NSInteger row, double fraction) { [weakSelf moveLineAtRow:row to:fraction]; };
        _table.onEndMove = ^{ [weakSelf lineLetGo]; };
        NSScrollView* scroll = SVScroll(NSMakeRect(20.0, 70.0, 860.0, 478.0), _table);
        scroll.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
        [c addSubview:scroll];

        SVKeyButton* all = [SVKeyButton keyWithFrame:NSMakeRect(20.0, 20.0, 110.0, 34.0) title:@"ВСИЧКИ" kind:0 target:self action:@selector(tickAll:)];
        all.textSize = 11.0; all.autoresizingMask = NSViewMaxYMargin; [c addSubview:all];
        SVKeyButton* none = [SVKeyButton keyWithFrame:NSMakeRect(138.0, 20.0, 110.0, 34.0) title:@"НИЩО" kind:0 target:self action:@selector(tickNone:)];
        none.textSize = 11.0; none.autoresizingMask = NSViewMaxYMargin; [c addSubview:none];
        _count = SVLabel(NSMakeRect(258.0, 28.0, 150.0, 18.0), @"", 11.0, NO, SVColDim());
        _count.autoresizingMask = NSViewMaxYMargin; [c addSubview:_count];
        // SILVETON_ATTACK_V3: hear what is in front of the green line while it is moved
        _playOn = [[SVToggle alloc] initWithFrame:NSMakeRect(416.0, 26.0, 44.0, 22.0)];
        _playOn.target = self; _playOn.action = @selector(playToggled:);
        _playOn.autoresizingMask = NSViewMaxYMargin;
        _playOn.toolTip = @"Включено: докато местиш зелената черта, звучи частта пред нея - тази, която ще се отреже. Ако чуеш началото на удара, чертата е твърде надясно.";
        [c addSubview:_playOn];
        NSTextField* playLabel = SVLabel(NSMakeRect(468.0, 28.0, 158.0, 18.0), @"СВИРИ ПРИ МЕСТЕНЕ", 11.0, NO, SVColText());
        playLabel.autoresizingMask = NSViewMaxYMargin; [c addSubview:playLabel];

        SVKeyButton* cancel = [SVKeyButton keyWithFrame:NSMakeRect(630.0, 20.0, 110.0, 34.0) title:@"ОТКАЗ" kind:0 target:self action:@selector(cancelPressed:)];
        cancel.autoresizingMask = NSViewMaxYMargin | NSViewMinXMargin;
        cancel.keyEquivalent = @"\x1b";
        [c addSubview:cancel];
        SVKeyButton* ok = [SVKeyButton keyWithFrame:NSMakeRect(750.0, 20.0, 130.0, 34.0) title:@"ОТРЕЖИ" kind:1 target:self action:@selector(okPressed:)];
        ok.autoresizingMask = NSViewMaxYMargin | NSViewMinXMargin;
        ok.keyEquivalent = @"\r";
        [c addSubview:ok];
        [self updateCount];
    }
    return self;
}

// the hand wins over the automatic point
- (void)moveLineAtRow:(NSInteger)row to:(double)fraction {
    if (row < 0 || static_cast<NSUInteger>(row) >= _cuts.count) return;
    _cuts[static_cast<NSUInteger>(row)] = @(std::min(0.98, std::max(0.0, fraction)));
    [_table reloadDataForRowIndexes:[NSIndexSet indexSetWithIndex:static_cast<NSUInteger>(row)]
                      columnIndexes:[NSIndexSet indexSetWithIndexesInRange:NSMakeRange(0U, _table.tableColumns.count)]];
    _movedRow = row;
    [self playPieceAtRow:row force:NO];
}

// SILVETON_ATTACK_V3: the part in front of the line - the part that goes away - sounds. While the line is dragged a new
// piece starts as soon as the last one is over (or after 0.35 s at most); when the mouse is let go the final piece sounds.
- (void)playPieceAtRow:(NSInteger)row force:(BOOL)force {
    if (_play == nil || !_playOn.on) return;
    if (row < 0 || static_cast<NSUInteger>(row) >= _rows.count) return;
    const CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    if (!force && now < _busyUntil) return;
    NSDictionary* item = _rows[static_cast<NSUInteger>(row)];
    const double cut = _cuts[static_cast<NSUInteger>(row)].doubleValue;
    const double windowFrames = [item[@"windowFrames"] doubleValue];
    const unsigned long long frames = static_cast<unsigned long long>(std::llround(cut * windowFrames));
    _busyUntil = now + std::min(0.35, cut * [item[@"window"] doubleValue]);
    _play([item[@"index"] unsignedIntegerValue], frames);
}
- (void)lineLetGo { [self playPieceAtRow:_movedRow force:YES]; }
- (void)playToggled:(id)sender {
    (void)sender;
    if (!_playOn.on && _play != nil) { _busyUntil = 0.0; _play(0U, 0ULL); }
}

- (void)updateCount {
    NSUInteger on = 0U;
    for (NSNumber* n in _ticked) if (n.boolValue) ++on;
    _count.stringValue = [NSString stringWithFormat:@"Отметнати %lu от %lu.", static_cast<unsigned long>(on), static_cast<unsigned long>(_rows.count)];
}

- (NSArray<NSDictionary<NSString*, id>*>*)run {
    [_panel center];
    [NSApp runModalForWindow:_panel];
    [_panel orderOut:nil];
    if (_play != nil) _play(0U, 0ULL);             // nothing keeps sounding after the window is gone
    if (!_accepted) return nil;
    NSMutableArray<NSDictionary<NSString*, id>*>* chosen = [NSMutableArray array];
    for (NSUInteger i = 0U; i < _rows.count; ++i) {
        if (!_ticked[i].boolValue) continue;
        const double cut = _cuts[i].doubleValue;
        const unsigned long long window = [_rows[i][@"windowFrames"] unsignedLongLongValue];
        const unsigned long long frame = static_cast<unsigned long long>(std::llround(cut * static_cast<double>(window)));
        if (frame == 0U) continue;                    // the line was pulled to the very start: nothing to cut
        [chosen addObject:@{@"index": _rows[i][@"index"], @"startFrame": @(frame)}];
    }
    return chosen;
}

- (void)tickAll:(id)sender {
    (void)sender;
    for (NSUInteger i = 0U; i < _ticked.count; ++i) _ticked[i] = @(YES);
    [_table reloadData];
    [self updateCount];
}
- (void)tickNone:(id)sender {
    (void)sender;
    for (NSUInteger i = 0U; i < _ticked.count; ++i) _ticked[i] = @(NO);
    [_table reloadData];
    [self updateCount];
}
- (void)okPressed:(id)sender { (void)sender; _accepted = YES; [NSApp stopModal]; }
- (void)cancelPressed:(id)sender { (void)sender; _accepted = NO; [NSApp stopModal]; }

- (NSInteger)numberOfRowsInTableView:(NSTableView*)tableView { (void)tableView; return static_cast<NSInteger>(_rows.count); }

- (id)tableView:(NSTableView*)tableView objectValueForTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView;
    if (row < 0 || static_cast<NSUInteger>(row) >= _rows.count) return nil;
    NSDictionary* item = _rows[static_cast<NSUInteger>(row)];
    NSString* identifier = tableColumn.identifier;
    if ([identifier isEqualToString:@"on"]) return _ticked[static_cast<NSUInteger>(row)];
    if ([identifier isEqualToString:@"name"]) return item[@"name"];
    const double cut = _cuts[static_cast<NSUInteger>(row)].doubleValue;
    if ([identifier isEqualToString:@"lead"]) return [NSString stringWithFormat:@"%.0f ms", cut * [item[@"window"] doubleValue] * 1000.0];
    NSMutableDictionary* live = [item mutableCopy];
    live[@"cut"] = @(cut);
    return live;
}

- (void)tableView:(NSTableView*)tableView setObjectValue:(id)object forTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView;
    if (row < 0 || static_cast<NSUInteger>(row) >= _ticked.count) return;
    if (![tableColumn.identifier isEqualToString:@"on"]) return;
    _ticked[static_cast<NSUInteger>(row)] = @([object boolValue]);
    [self updateCount];
}

@end

NSArray<NSDictionary<NSString*, id>*>* SVReviewLateStarts(NSWindow* parent, NSString* blendName, NSArray<NSDictionary<NSString*, id>*>* rows, SVReviewPlayBlock play) {
    (void)parent;
    if (rows.count == 0U) return nil;
    SVAttackReviewPanel* panel = [[SVAttackReviewPanel alloc] initWithBlendName:blendName rows:rows play:play];
    return [panel run];
}
