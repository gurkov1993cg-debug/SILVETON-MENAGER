// SILVETON_KONTAKT_V1 - KONTAKT IMPORT window: pick the instruments inside a .nki, choose the sample
// rate, press IMPORT. Every instrument becomes one SOUND with up to 5 velocity layers.
#import <AppKit/AppKit.h>
#import <objc/runtime.h>

#import "SVProgress.h"

#include "silveton/manager/KontaktImporter.h"
#include "silveton/manager/ManagerTypes.h"

#include <utility>
#include <algorithm>
#include <cstdint>
#include <limits>
#include <string>
#include <vector>

using silveton::manager::BankProject;
using silveton::manager::ImportedMultisample;
using silveton::manager::ImportedSample;
using silveton::manager::KontaktImporter;
using silveton::manager::KontaktImportOptions;
using silveton::manager::KontaktImportResult;
using silveton::manager::KontaktLibrary;
using silveton::manager::SoundDefinition;
using silveton::manager::kMaxSoundPosition;
using silveton::manager::kMinSoundPosition;

@interface SVManagerDocument : NSObject
- (void)markCurrentStateChanged;
@end

@interface SVProgressPanel : NSObject
- (instancetype)initWithTitle:(NSString*)title;
- (void)setFraction:(double)fraction text:(NSString*)text;
- (BOOL)stopRequested;
- (void)runWork:(void (^)(SVProgressPanel* progress))work;
@end

namespace {

constexpr int kVelocityLayers = 5;   // the basic sound + L1..L4 of an Upper

NSTextField* KLabel(NSRect frame, NSString* text, CGFloat size, NSFontWeight weight, NSColor* color) {
    NSTextField* label = [[NSTextField alloc] initWithFrame:frame];
    label.stringValue = text ?: @"";
    label.editable = NO;
    label.selectable = NO;
    label.bezeled = NO;
    label.drawsBackground = NO;
    label.font = [NSFont systemFontOfSize:size weight:weight];
    label.textColor = color;
    label.lineBreakMode = NSLineBreakByTruncatingMiddle;
    return label;
}

NSButton* KButton(NSRect frame, NSString* title, id target, SEL action) {
    NSButton* button = [[NSButton alloc] initWithFrame:frame];
    button.title = title;
    button.target = target;
    button.action = action;
    button.bezelStyle = NSBezelStyleRounded;
    button.font = [NSFont systemFontOfSize:12.0 weight:NSFontWeightMedium];
    return button;
}

NSString* ns(const std::string& s) { return [NSString stringWithUTF8String:s.c_str()] ?: @""; }

BankProject* ProjectOf(SVManagerDocument* document) noexcept {
    if (document == nil) return nullptr;
    Ivar ivar = class_getInstanceVariable([SVManagerDocument class], "_project");
    if (ivar == nullptr) return nullptr;
    const ptrdiff_t offset = ivar_getOffset(ivar);
    if (offset <= 0) return nullptr;
    auto* base = reinterpret_cast<unsigned char*>((__bridge void*)document);
    return reinterpret_cast<BankProject*>(base + offset);
}

std::uint32_t nextSampleId(const BankProject& p) noexcept {
    std::uint32_t m = 0U; for (const auto& s : p.samples) m = std::max(m, s.sampleId);
    return m == std::numeric_limits<std::uint32_t>::max() ? 0U : m + 1U;
}
std::uint32_t nextMultisampleId(const BankProject& p) noexcept {
    std::uint32_t m = 0U; for (const auto& s : p.multisamples) m = std::max(m, s.multisampleId);
    return m == std::numeric_limits<std::uint32_t>::max() ? 0U : m + 1U;
}
std::uint16_t nextFreeSoundPosition(const BankProject& p) noexcept {
    for (std::uint16_t position = kMinSoundPosition; position <= kMaxSoundPosition; ++position) {
        bool used = false;
        for (const auto& s : p.sounds) if (s.position == position) { used = true; break; }
        if (!used) return position;
    }
    return 0U;
}

// Appends one imported instrument (samples, 1..5 multisamples, one SOUND) to the project.
bool appendKontakt(BankProject& project, KontaktImportResult result, std::string& error) {
    const std::uint16_t position = nextFreeSoundPosition(project);
    if (position == 0U) { error = "No free SOUND position remains (1...500)."; return false; }
    const std::uint32_t sampleBase = static_cast<std::uint32_t>(project.samples.size());
    const std::uint32_t multisampleBase = static_cast<std::uint32_t>(project.multisamples.size());
    std::uint32_t sampleId = nextSampleId(project);
    std::uint32_t multisampleId = nextMultisampleId(project);
    for (auto& sample : result.samples) { sample.sampleId = sampleId++; project.samples.push_back(std::move(sample)); }
    for (auto& ms : result.multisamples) {
        for (auto& zone : ms.zones) zone.sampleIndex += sampleBase;
        ms.multisampleId = multisampleId++;
        project.multisamples.push_back(std::move(ms));
    }
    SoundDefinition sound = std::move(result.sound);
    sound.position = position;
    const std::size_t index = project.sounds.size();
    sound.slot = static_cast<std::uint16_t>(index % 128U);
    sound.page = static_cast<std::uint16_t>((index / 128U) % 128U);
    sound.bank = static_cast<std::uint16_t>(index / (128U * 128U));
    for (auto& layer : sound.layers) layer.multisampleIndex += multisampleBase;
    project.sounds.push_back(std::move(sound));
    return true;
}

struct Row {
    std::size_t groupIndex;
    BOOL selected;
    double megabytes;
    NSString* name;
    NSString* keys;
    NSString* layers;
    NSString* samples;
    NSString* size;
};

} // namespace

@interface SVKontaktImportPanel : NSObject <NSTableViewDataSource, NSTableViewDelegate>
- (instancetype)initWithLibrary:(const KontaktLibrary*)library;
- (BOOL)run;   // modal; YES = IMPORT pressed
- (std::vector<std::size_t>)selectedGroups;
- (std::uint32_t)sampleRate;
@end

@implementation SVKontaktImportPanel {
    const KontaktLibrary* _library;
    std::vector<Row> _rows;
    NSPanel* _panel;
    NSTableView* _table;
    NSPopUpButton* _ratePopup;
    NSTextField* _rateNote;
    NSTextField* _countLabel;
    std::vector<std::uint32_t> _rateValues;
    BOOL _accepted;
}

- (instancetype)initWithLibrary:(const KontaktLibrary*)library {
    self = [super init];
    if (self) {
        _library = library;
        _accepted = NO;
        [self buildRows];
        [self buildPanel];
    }
    return self;
}

- (void)buildRows {
    _rows.clear();
    KontaktImportOptions dry;
    dry.maxVelocityLayers = kVelocityLayers;
    dry.dryRun = true;
    for (std::size_t gi = 0U; gi < _library->groups.size(); ++gi) {
        const auto& g = _library->groups[gi];
        if (g.zoneIndices.empty()) continue;
        std::uint8_t keyLow = 127U, keyHigh = 0U;
        std::size_t maxLayers = 0U;
        {
            std::vector<std::pair<std::uint8_t, std::uint8_t>> ranges;
            for (std::uint32_t zi : g.zoneIndices) {
                const auto& z = _library->zones[zi];
                keyLow = std::min(keyLow, z.keyLow); keyHigh = std::max(keyHigh, z.keyHigh);
                ranges.emplace_back(z.keyLow, z.keyHigh);
            }
            std::sort(ranges.begin(), ranges.end());
            std::size_t run = 0U;
            for (std::size_t i = 0U; i < ranges.size(); ++i) {
                run = (i > 0U && ranges[i] == ranges[i - 1U]) ? run + 1U : 1U;
                maxLayers = std::max(maxLayers, run);
            }
        }
        KontaktImportResult r = KontaktImporter::importGroup(*_library, gi, dry, nullptr);
        double bytes = 0.0;
        for (const auto& s : r.samples) bytes += static_cast<double>(s.totalFrames) * static_cast<double>(s.channels) * (s.bitsPerSample == 24U ? 3.0 : 2.0);
        Row row{};
        row.groupIndex = gi;
        row.selected = NO;
        row.megabytes = bytes / (1024.0 * 1024.0);
        row.name = ns(r.ok() ? r.sound.name : g.name);
        row.keys = [NSString stringWithFormat:@"%u-%u", static_cast<unsigned>(keyLow), static_cast<unsigned>(keyHigh)];
        row.layers = maxLayers > static_cast<std::size_t>(kVelocityLayers)
                         ? [NSString stringWithFormat:@"%lu -> %d", static_cast<unsigned long>(maxLayers), kVelocityLayers]
                         : [NSString stringWithFormat:@"%lu", static_cast<unsigned long>(maxLayers)];
        row.samples = [NSString stringWithFormat:@"%lu", static_cast<unsigned long>(r.samples.size())];
        row.size = [NSString stringWithFormat:@"%.0f MB", bytes / (1024.0 * 1024.0)];
        _rows.push_back(row);
    }
}

- (void)buildPanel {
    _panel = [[NSPanel alloc] initWithContentRect:NSMakeRect(0.0, 0.0, 860.0, 620.0)
                                        styleMask:(NSWindowStyleMaskTitled | NSWindowStyleMaskResizable)
                                          backing:NSBackingStoreBuffered
                                            defer:NO];
    _panel.title = @"KONTAKT IMPORT";
    _panel.minSize = NSMakeSize(760.0, 520.0);
    _panel.backgroundColor = [NSColor colorWithCalibratedRed:0.055 green:0.067 blue:0.078 alpha:1.0];
    NSView* c = _panel.contentView;
    NSColor* mainText = [NSColor colorWithCalibratedWhite:0.90 alpha:1.0];
    NSColor* dimText = [NSColor colorWithCalibratedWhite:0.62 alpha:1.0];
    NSColor* accent = [NSColor colorWithCalibratedRed:0.45 green:0.72 blue:0.96 alpha:1.0];

    NSTextField* title = KLabel(NSMakeRect(24.0, 574.0, 500.0, 30.0), @"KONTAKT IMPORT", 21.0, NSFontWeightSemibold, accent);
    title.autoresizingMask = NSViewMinYMargin;
    [c addSubview:title];
    NSString* fileLine = [NSString stringWithFormat:@"%@   (%@)", ns(_library->programName), ns(_library->nkiPath).lastPathComponent];
    NSTextField* file = KLabel(NSMakeRect(24.0, 550.0, 812.0, 20.0), fileLine, 12.0, NSFontWeightRegular, mainText);
    file.autoresizingMask = NSViewMinYMargin | NSViewWidthSizable;
    [c addSubview:file];
    NSTextField* help = KLabel(NSMakeRect(24.0, 528.0, 812.0, 20.0),
                               @"Tick the instruments to import. Each becomes one SOUND with up to 5 velocity layers: soft, medium, stronger, strong and the top hit.",
                               11.0, NSFontWeightRegular, dimText);
    help.autoresizingMask = NSViewMinYMargin | NSViewWidthSizable;
    [c addSubview:help];

    NSScrollView* scroll = [[NSScrollView alloc] initWithFrame:NSMakeRect(24.0, 150.0, 812.0, 368.0)];
    scroll.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    scroll.hasVerticalScroller = YES;
    scroll.borderType = NSBezelBorder;
    scroll.backgroundColor = [NSColor colorWithCalibratedRed:0.075 green:0.086 blue:0.098 alpha:1.0];
    scroll.drawsBackground = YES;
    _table = [[NSTableView alloc] initWithFrame:scroll.bounds];
    _table.rowHeight = 22.0;
    _table.allowsMultipleSelection = NO;
    _table.dataSource = self;
    _table.delegate = self;
    _table.backgroundColor = scroll.backgroundColor;
    _table.usesAlternatingRowBackgroundColors = NO;
    struct Col { NSString* ident; NSString* title; CGFloat width; };
    const Col cols[] = {{@"on", @"", 28.0}, {@"name", @"Instrument", 330.0}, {@"keys", @"Keys", 80.0},
                        {@"layers", @"Velocity layers", 120.0}, {@"samples", @"Samples", 80.0}, {@"size", @"Size", 100.0}};
    for (const Col& col : cols) {
        NSTableColumn* column = [[NSTableColumn alloc] initWithIdentifier:col.ident];
        column.title = col.title;
        column.width = col.width;
        column.minWidth = 24.0;
        if ([col.ident isEqualToString:@"on"]) {
            NSButtonCell* check = [[NSButtonCell alloc] init];
            [check setButtonType:NSButtonTypeSwitch];
            check.title = @"";
            check.controlSize = NSControlSizeSmall;
            column.dataCell = check;
        } else {
            NSTextFieldCell* cell = [[NSTextFieldCell alloc] init];
            cell.font = [NSFont systemFontOfSize:12.0];
            cell.textColor = mainText;
            cell.lineBreakMode = NSLineBreakByTruncatingTail;
            column.dataCell = cell;
            column.editable = NO;
        }
        [_table addTableColumn:column];
    }
    scroll.documentView = _table;
    [c addSubview:scroll];

    NSButton* all = KButton(NSMakeRect(24.0, 112.0, 90.0, 28.0), @"All", self, @selector(tickAll:));
    all.autoresizingMask = NSViewMaxYMargin;
    [c addSubview:all];
    NSButton* none = KButton(NSMakeRect(120.0, 112.0, 90.0, 28.0), @"None", self, @selector(tickNone:));
    none.autoresizingMask = NSViewMaxYMargin;
    [c addSubview:none];
    _countLabel = KLabel(NSMakeRect(224.0, 116.0, 400.0, 20.0), @"", 11.0, NSFontWeightRegular, dimText);
    _countLabel.autoresizingMask = NSViewMaxYMargin;
    [c addSubview:_countLabel];

    NSTextField* rateLabel = KLabel(NSMakeRect(24.0, 70.0, 100.0, 20.0), @"Sample rate", 11.0, NSFontWeightRegular, mainText);
    rateLabel.autoresizingMask = NSViewMaxYMargin;
    [c addSubview:rateLabel];
    _ratePopup = [[NSPopUpButton alloc] initWithFrame:NSMakeRect(124.0, 64.0, 220.0, 28.0) pullsDown:NO];
    _ratePopup.autoresizingMask = NSViewMaxYMargin;
    [c addSubview:_ratePopup];
    _rateNote = KLabel(NSMakeRect(356.0, 70.0, 480.0, 20.0), @"", 11.0, NSFontWeightRegular, dimText);
    _rateNote.autoresizingMask = NSViewMaxYMargin | NSViewWidthSizable;
    [c addSubview:_rateNote];
    [self fillRateChoices];

    NSButton* cancel = KButton(NSMakeRect(596.0, 18.0, 110.0, 32.0), @"Cancel", self, @selector(cancelPressed:));
    cancel.autoresizingMask = NSViewMaxYMargin | NSViewMinXMargin;
    cancel.keyEquivalent = @"\x1b";
    [c addSubview:cancel];
    NSButton* importButton = KButton(NSMakeRect(716.0, 18.0, 120.0, 32.0), @"IMPORT", self, @selector(importPressed:));
    importButton.autoresizingMask = NSViewMaxYMargin | NSViewMinXMargin;
    importButton.keyEquivalent = @"\r";
    [c addSubview:importButton];
    [self updateCount];
}

- (void)fillRateChoices {
    // the first instrument tells what the files say and what their pitch says
    std::uint32_t tagged = 0U, detected = 0U;
    std::string note;
    if (!_rows.empty()) detected = KontaktImporter::probeSampleRate(*_library, _rows.front().groupIndex, tagged, note);
    _rateValues.clear();
    [_ratePopup removeAllItems];
    if (tagged != 0U) [_ratePopup addItemWithTitle:[NSString stringWithFormat:@"As in the files (%u Hz)", static_cast<unsigned>(tagged)]];
    else [_ratePopup addItemWithTitle:@"As in the files"];
    _rateValues.push_back(0U);
    const std::uint32_t rates[] = {22050U, 44100U, 48000U, 88200U, 96000U};
    for (std::uint32_t r : rates) {
        [_ratePopup addItemWithTitle:[NSString stringWithFormat:@"%u Hz", static_cast<unsigned>(r)]];
        _rateValues.push_back(r);
    }
    NSInteger select = 0;
    if (detected != 0U && detected != tagged) {
        for (std::size_t i = 0U; i < _rateValues.size(); ++i) if (_rateValues[i] == detected) select = static_cast<NSInteger>(i);
    }
    [_ratePopup selectItemAtIndex:select];
    _rateNote.stringValue = ns(note);
}

- (double)selectedMegabytes {
    double mb = 0.0;
    for (const Row& r : _rows) if (r.selected) mb += r.megabytes;
    return mb;
}

- (void)updateCount {
    std::size_t n = 0U;
    for (const Row& r : _rows) if (r.selected) ++n;
    _countLabel.stringValue = [NSString stringWithFormat:@"%lu of %lu instruments selected   ·   %.0f MB", static_cast<unsigned long>(n), static_cast<unsigned long>(_rows.size()), [self selectedMegabytes]];
}

- (void)tickAll:(id)sender { (void)sender; for (Row& r : _rows) r.selected = YES; [_table reloadData]; [self updateCount]; }
- (void)tickNone:(id)sender { (void)sender; for (Row& r : _rows) r.selected = NO; [_table reloadData]; [self updateCount]; }
- (void)cancelPressed:(id)sender { (void)sender; _accepted = NO; [NSApp stopModal]; }
- (void)importPressed:(id)sender {
    (void)sender;
    bool any = false;
    for (const Row& r : _rows) if (r.selected) any = true;
    if (!any) { NSBeep(); _countLabel.stringValue = @"Tick at least one instrument."; return; }
    const double mb = [self selectedMegabytes];
    if (mb > 3000.0) {
        NSAlert* alert = [[NSAlert alloc] init];
        alert.messageText = @"A lot of samples";
        alert.informativeText = [NSString stringWithFormat:@"The ticked instruments take about %.0f MB of memory. The Mac and the tablet may run out of memory. Import one or two pianos at a time.", mb];
        [alert addButtonWithTitle:@"Import anyway"];
        [alert addButtonWithTitle:@"Back"];
        if ([alert runModal] != NSAlertFirstButtonReturn) return;
    }
    _accepted = YES;
    [NSApp stopModal];
}

- (BOOL)run {
    [_panel center];
    [NSApp runModalForWindow:_panel];
    [_panel orderOut:nil];
    return _accepted;
}

- (std::vector<std::size_t>)selectedGroups {
    std::vector<std::size_t> out;
    for (const Row& r : _rows) if (r.selected) out.push_back(r.groupIndex);
    return out;
}

- (std::uint32_t)sampleRate {
    const NSInteger i = _ratePopup.indexOfSelectedItem;
    return i >= 0 && static_cast<std::size_t>(i) < _rateValues.size() ? _rateValues[static_cast<std::size_t>(i)] : 0U;
}

// ---- table
- (NSInteger)numberOfRowsInTableView:(NSTableView*)tableView { (void)tableView; return static_cast<NSInteger>(_rows.size()); }

- (id)tableView:(NSTableView*)tableView objectValueForTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView;
    if (row < 0 || static_cast<std::size_t>(row) >= _rows.size()) return nil;
    const Row& r = _rows[static_cast<std::size_t>(row)];
    NSString* ident = tableColumn.identifier;
    if ([ident isEqualToString:@"on"]) return @(r.selected ? 1 : 0);
    if ([ident isEqualToString:@"name"]) return r.name;
    if ([ident isEqualToString:@"keys"]) return r.keys;
    if ([ident isEqualToString:@"layers"]) return r.layers;
    if ([ident isEqualToString:@"samples"]) return r.samples;
    if ([ident isEqualToString:@"size"]) return r.size;
    return nil;
}

- (void)tableView:(NSTableView*)tableView setObjectValue:(id)object forTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView;
    if (row < 0 || static_cast<std::size_t>(row) >= _rows.size()) return;
    if (![tableColumn.identifier isEqualToString:@"on"]) return;
    _rows[static_cast<std::size_t>(row)].selected = [object integerValue] != 0 ? YES : NO;
    [self updateCount];
}

- (BOOL)tableView:(NSTableView*)tableView shouldSelectRow:(NSInteger)row {
    (void)tableView; (void)row;
    return NO;   // the tick box decides, rows are not highlighted
}
@end

// ---------------------------------------------------------------- entry point

static BOOL SVRunKontaktImport(SVManagerDocument* document, const KontaktLibrary& library, const std::vector<std::size_t>& groups,
                               const KontaktImportOptions& options, NSString** details) {
    BankProject* project = ProjectOf(document);
    if (project == nullptr) { if (details != nullptr) *details = @"The project is not available."; return NO; }
    SVProgressPanel* progress = [[SVProgressPanel alloc] initWithTitle:@"KONTAKT IMPORT"];
    NSMutableArray<NSString*>* messages = [NSMutableArray array];
    for (const auto& w : library.warnings) [messages addObject:ns(w)];
    __block NSUInteger imported = 0U;
    __block BOOL stopped = NO;
    [progress runWork:^(SVProgressPanel* p) {
        const std::size_t total = groups.size();
        for (std::size_t i = 0U; i < total; ++i) {
            if ([p stopRequested]) { stopped = YES; break; }
            const std::size_t gi = groups[i];
            const std::string name = library.groups[gi].name;
            auto report = [&](double fraction, const std::string& text) -> bool {
                const double overall = (static_cast<double>(i) + fraction) / static_cast<double>(std::max<std::size_t>(1U, total));
                [p setFraction:overall text:[NSString stringWithFormat:@"%lu / %lu   %@", static_cast<unsigned long>(i + 1U), static_cast<unsigned long>(total), ns(text)]];
                return ![p stopRequested];
            };
            KontaktImportResult result = KontaktImporter::importGroup(library, gi, options, report);
            if (!result.ok()) {
                if ([p stopRequested]) { stopped = YES; break; }
                [messages addObject:[NSString stringWithFormat:@"%@: %@", ns(name), ns(result.error)]];
                continue;
            }
            for (const auto& w : result.warnings) [messages addObject:ns(w)];
            std::string error;
            if (!appendKontakt(*project, std::move(result), error)) { [messages addObject:[NSString stringWithFormat:@"%@: %@", ns(name), ns(error)]]; continue; }
            ++imported;
        }
        [p setFraction:1.0 text:@"Done"];
    }];
    if (imported > 0U) [document markCurrentStateChanged];
    if (stopped) [messages addObject:[NSString stringWithFormat:@"Import stopped. %lu of %lu instruments were imported.", static_cast<unsigned long>(imported), static_cast<unsigned long>(groups.size())]];
    if (details != nullptr) *details = messages.count > 0U ? [messages componentsJoinedByString:@"\n"] : nil;
    if (imported == 0U && details != nullptr && *details == nil) *details = @"No Kontakt instrument was imported.";
    return imported > 0U ? YES : NO;
}

BOOL SVImportKontaktGroups(SVManagerDocument* document, NSString* path, NSArray<NSNumber*>* groupIndexes, NSUInteger sampleRate, NSWindow* parent, NSString** details) {
    (void)parent;
    if (document == nil || path.length == 0U || groupIndexes.count == 0U) { if (details != nullptr) *details = @"No Kontakt instrument was selected."; return NO; }
    const KontaktLibrary library = KontaktImporter::open(std::string([path fileSystemRepresentation]));
    if (!library.ok()) { if (details != nullptr) *details = ns(library.error); return NO; }
    std::vector<std::size_t> groups;
    for (NSNumber* n in groupIndexes) if (n.unsignedLongValue < library.groups.size()) groups.push_back(static_cast<std::size_t>(n.unsignedLongValue));
    KontaktImportOptions options;
    options.maxVelocityLayers = kVelocityLayers;
    options.sampleRate = static_cast<std::uint32_t>(sampleRate);
    return SVRunKontaktImport(document, library, groups, options, details);
}

BOOL SVImportKontaktFile(SVManagerDocument* document, NSString* path, NSWindow* parent, NSString** details) {
    (void)parent;
    if (document == nil || path.length == 0U) { if (details != nullptr) *details = @"No Kontakt file was selected."; return NO; }
    const KontaktLibrary library = KontaktImporter::open(std::string([path fileSystemRepresentation]));
    if (!library.ok()) { if (details != nullptr) *details = ns(library.error); return NO; }
    SVKontaktImportPanel* panel = [[SVKontaktImportPanel alloc] initWithLibrary:&library];
    if (![panel run]) { if (details != nullptr) *details = nil; return NO; }
    KontaktImportOptions options;
    options.maxVelocityLayers = kVelocityLayers;
    options.sampleRate = [panel sampleRate];
    return SVRunKontaktImport(document, library, [panel selectedGroups], options, details);
}
