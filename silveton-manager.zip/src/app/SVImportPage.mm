// SILVETON_LOOK_V1 - page 1 ВНАСЯНЕ: files on the disk (left), what will come in (right), what came in (bottom).
#import "SVShell.h"
#import "SVDocument.h"
#import "SVTheme.h"
#import "SVProgress.h"

#include "silveton/manager/KontaktImporter.h"
#include "silveton/manager/MediaPathPolicy.h"

#include <algorithm>
#include <cstdint>
#include <utility>
#include <string>
#include <vector>

using silveton::manager::KontaktImporter;
using silveton::manager::KontaktImportOptions;
using silveton::manager::KontaktImportResult;
using silveton::manager::KontaktLibrary;
using silveton::manager::MediaEntryKind;
using silveton::manager::MediaPathPolicy;

namespace {
NSString* const kPrefFolder = @"SVImportFolder";
constexpr int kVelocityLayers = 5;

struct FileRow {
    NSURL* url;
    NSString* name;
    NSString* info;
    BOOL isFolder;
    BOOL isBack;
    BOOL importable;
    BOOL ticked;
};

struct InstrumentRow {
    std::size_t groupIndex;
    BOOL ticked;
    NSString* name;
    NSString* keys;
    NSString* layers;
    NSString* samples;
    double megabytes;
};

NSString* kindText(NSString* name) {
    NSString* ext = name.pathExtension.lowercaseString;
    if ([ext isEqualToString:@"nki"]) return @"Kontakt инструмент";
    if ([ext isEqualToString:@"kmp"]) return @"Korg KMP";
    if ([ext isEqualToString:@"ksc"]) return @"Korg KSC (набор KMP)";
    if ([ext isEqualToString:@"ksf"]) return @"Korg KSF (семпъл)";
    if ([ext isEqualToString:@"sv"]) return @"SILVETON банка (зарежда се от БАНКА)";
    return @"WAV / AIFF";
}
}

@interface SVImportPage : SVPageView <NSTableViewDataSource, NSTableViewDelegate>
@end

@implementation SVImportPage {
    std::vector<FileRow> _files;
    std::vector<InstrumentRow> _instruments;
    NSURL* _folder;
    NSTableView* _fileTable;
    NSTableView* _previewTable;
    NSTableView* _logTable;
    NSTextField* _pathLabel;
    SVPanel* _previewPanel;
    NSTextField* _previewNote;
    NSTextField* _rateLabel;
    NSPopUpButton* _ratePopup;
    std::vector<unsigned> _rateValues;
    SVKeyButton* _importKey;
    NSString* _kontaktPath;
    NSArray<NSString*>* _log;
    BOOL _kontaktMode;
}

- (instancetype)initWithShell:(SVShellWindowController*)shell frame:(NSRect)frame {
    self = [super initWithShell:shell frame:frame];
    if (self) {
        _kontaktMode = NO;
        _log = @[];
        NSString* saved = [[NSUserDefaults standardUserDefaults] stringForKey:kPrefFolder];
        BOOL isDir = NO;
        if (saved.length > 0U && [[NSFileManager defaultManager] fileExistsAtPath:saved isDirectory:&isDir] && isDir) _folder = [NSURL fileURLWithPath:saved isDirectory:YES];
        else _folder = [NSURL fileURLWithPath:NSHomeDirectory() isDirectory:YES];
        [self build];
        [self loadFolder];
    }
    return self;
}

- (void)build {
    const NSRect b = self.bounds;
    // ---- left: files
    SVPanel* left = [[SVPanel alloc] initWithFrame:NSMakeRect(16.0, 16.0, 420.0, b.size.height - 32.0) title:@"ФАЙЛОВЕ НА ДИСКА"];
    left.autoresizingMask = NSViewHeightSizable;
    _pathLabel = SVLabel(NSMakeRect(12.0, 32.0, 396.0, 18.0), @"", 11.0, NO, SVColDim());
    _pathLabel.lineBreakMode = NSLineBreakByTruncatingHead;
    [left addSubview:_pathLabel];
    _fileTable = [[NSTableView alloc] initWithFrame:NSZeroRect];
    SVStyleTable(_fileTable);
    _fileTable.headerView = nil;
    _fileTable.dataSource = self;
    _fileTable.delegate = self;
    _fileTable.target = self;
    _fileTable.doubleAction = @selector(fileDoubleClicked:);
    [_fileTable addTableColumn:SVCheckColumn(@"on", 24.0)];
    [_fileTable addTableColumn:SVTextColumn(@"name", @"", 220.0)];
    NSTableColumn* info = SVTextColumn(@"info", @"", 130.0);
    [(NSTextFieldCell*)info.dataCell setTextColor:SVColDim()];
    [(NSTextFieldCell*)info.dataCell setAlignment:NSTextAlignmentRight];
    [_fileTable addTableColumn:info];
    NSScrollView* scroll = SVScroll(NSMakeRect(12.0, 54.0, 396.0, left.bounds.size.height - 54.0 - 56.0), _fileTable);
    scroll.autoresizingMask = NSViewHeightSizable;
    [left addSubview:scroll];
    const CGFloat by = left.bounds.size.height - 46.0;
    SVKeyButton* disk = [SVKeyButton keyWithFrame:NSMakeRect(12.0, by, 130.0, 34.0) title:@"ИЗБЕРИ ПАПКА" kind:0 target:self action:@selector(chooseFolder:)];
    disk.autoresizingMask = NSViewMinYMargin;
    [left addSubview:disk];
    SVKeyButton* all = [SVKeyButton keyWithFrame:NSMakeRect(150.0, by, 90.0, 34.0) title:@"ВСИЧКИ" kind:0 target:self action:@selector(tickAll:)];
    all.autoresizingMask = NSViewMinYMargin;
    [left addSubview:all];
    SVKeyButton* none = [SVKeyButton keyWithFrame:NSMakeRect(248.0, by, 90.0, 34.0) title:@"НИЩО" kind:0 target:self action:@selector(tickNone:)];
    none.autoresizingMask = NSViewMinYMargin;
    [left addSubview:none];
    [self addSubview:left];

    // ---- right top: preview
    const CGFloat rx = 452.0;
    const CGFloat previewH = std::max(300.0, b.size.height - 32.0 - 190.0 - 16.0);
    _previewPanel = [[SVPanel alloc] initWithFrame:NSMakeRect(rx, 16.0, b.size.width - rx - 16.0, previewH) title:@"КАКВО ЩЕ ВЛЕЗЕ"];
    _previewPanel.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    _previewTable = [[NSTableView alloc] initWithFrame:NSZeroRect];
    SVStyleTable(_previewTable);
    _previewTable.dataSource = self;
    _previewTable.delegate = self;
    [_previewTable addTableColumn:SVCheckColumn(@"on", 24.0)];
    [_previewTable addTableColumn:SVTextColumn(@"name", @"ИНСТРУМЕНТ / ФАЙЛ", 300.0)];
    [_previewTable addTableColumn:SVTextColumn(@"keys", @"КЛАВИШИ", 80.0)];
    [_previewTable addTableColumn:SVTextColumn(@"layers", @"СЛОЕВЕ", 80.0)];
    [_previewTable addTableColumn:SVTextColumn(@"samples", @"СЕМПЛИ", 70.0)];
    [_previewTable addTableColumn:SVTextColumn(@"mb", @"MB", 60.0)];
    NSScrollView* pscroll = SVScroll(NSMakeRect(12.0, 32.0, _previewPanel.bounds.size.width - 24.0, _previewPanel.bounds.size.height - 32.0 - 80.0), _previewTable);
    pscroll.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    [_previewPanel addSubview:pscroll];
    const CGFloat py = _previewPanel.bounds.size.height - 42.0;
    _rateLabel = SVLabel(NSMakeRect(12.0, py - 22.0, 420.0, 18.0), @"", 11.0, NO, SVColDim());
    _rateLabel.autoresizingMask = NSViewMinYMargin;
    [_previewPanel addSubview:_rateLabel];
    _ratePopup = SVPopup(NSMakeRect(12.0, py + 2.0, 190.0, 26.0));
    _ratePopup.autoresizingMask = NSViewMinYMargin;
    [_previewPanel addSubview:_ratePopup];
    _previewNote = SVLabel(NSMakeRect(212.0, py + 6.0, _previewPanel.bounds.size.width - 212.0 - 240.0, 18.0), @"", 11.0, NO, SVColDim());
    _previewNote.autoresizingMask = NSViewMinYMargin | NSViewWidthSizable;
    [_previewPanel addSubview:_previewNote];
    _importKey = [SVKeyButton keyWithFrame:NSMakeRect(_previewPanel.bounds.size.width - 12.0 - 220.0, py - 8.0, 220.0, 44.0) title:@"ВНЕСИ ИЗБРАНИТЕ" kind:1 target:self action:@selector(importPressed:)];
    _importKey.textSize = 15.0;
    _importKey.autoresizingMask = NSViewMinYMargin | NSViewMinXMargin;
    [_previewPanel addSubview:_importKey];
    [self addSubview:_previewPanel];

    // ---- right bottom: log
    SVPanel* logPanel = [[SVPanel alloc] initWithFrame:NSMakeRect(rx, 16.0 + previewH + 16.0, b.size.width - rx - 16.0, b.size.height - 32.0 - previewH - 16.0) title:@"ВЛЯЗЛО ДОСЕГА"];
    logPanel.autoresizingMask = NSViewWidthSizable | NSViewMinYMargin;
    _logTable = [[NSTableView alloc] initWithFrame:NSZeroRect];
    SVStyleTable(_logTable);
    _logTable.headerView = nil;
    _logTable.dataSource = self;
    _logTable.delegate = self;
    [_logTable addTableColumn:SVTextColumn(@"line", @"", 800.0)];
    NSScrollView* lscroll = SVScroll(NSMakeRect(12.0, 32.0, logPanel.bounds.size.width - 24.0, logPanel.bounds.size.height - 44.0), _logTable);
    lscroll.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    [logPanel addSubview:lscroll];
    [self addSubview:logPanel];
}

// ---------------------------------------------------------------- folder

- (void)loadFolder {
    _files.clear();
    NSFileManager* fm = [NSFileManager defaultManager];
    NSString* home = NSHomeDirectory();
    if (![_folder.path isEqualToString:@"/"]) {
        FileRow back{};
        back.url = _folder.URLByDeletingLastPathComponent;
        back.name = @"⬅  назад";
        back.info = @"";
        back.isBack = YES;
        _files.push_back(back);
    }
    (void)home;
    NSArray<NSURL*>* items = [fm contentsOfDirectoryAtURL:_folder
                                includingPropertiesForKeys:@[NSURLIsDirectoryKey, NSURLFileSizeKey, NSURLIsHiddenKey]
                                                   options:NSDirectoryEnumerationSkipsHiddenFiles
                                                     error:nil];
    std::vector<FileRow> folders, files;
    for (NSURL* url in items) {
        NSNumber* isDir = nil;
        [url getResourceValue:&isDir forKey:NSURLIsDirectoryKey error:nil];
        NSString* name = url.lastPathComponent ?: @"";
        if (isDir.boolValue) {
            FileRow row{};
            row.url = url; row.name = [@"📁  " stringByAppendingString:name]; row.info = @""; row.isFolder = YES;
            folders.push_back(row);
            continue;
        }
        const MediaEntryKind kind = MediaPathPolicy::classify(std::string(url.path.UTF8String ?: ""), false);
        if (kind == MediaEntryKind::Unsupported) continue;
        NSNumber* size = nil;
        [url getResourceValue:&size forKey:NSURLFileSizeKey error:nil];
        FileRow row{};
        row.url = url; row.name = name; row.importable = kind == MediaEntryKind::ImportableSamplerFile;
        row.info = [NSString stringWithFormat:@"%@ · %@", kindText(name), SVMegabytes(size.doubleValue)];
        files.push_back(row);
    }
    auto byName = [](const FileRow& a, const FileRow& b) { return [a.name localizedCaseInsensitiveCompare:b.name] == NSOrderedAscending; };
    std::sort(folders.begin(), folders.end(), byName);
    std::sort(files.begin(), files.end(), byName);
    _files.insert(_files.end(), folders.begin(), folders.end());
    _files.insert(_files.end(), files.begin(), files.end());
    _pathLabel.stringValue = _folder.path ?: @"";
    [[NSUserDefaults standardUserDefaults] setObject:_folder.path forKey:kPrefFolder];
    [_fileTable reloadData];
    [self previewChanged];
}

- (void)chooseFolder:(id)sender {
    (void)sender;
    NSOpenPanel* panel = [NSOpenPanel openPanel];
    panel.canChooseFiles = NO;
    panel.canChooseDirectories = YES;
    panel.allowsMultipleSelection = NO;
    panel.prompt = @"Избери";
    panel.directoryURL = _folder;
    if ([panel runModal] != NSModalResponseOK || panel.URLs.count == 0U) return;
    _folder = (NSURL*)panel.URLs.firstObject;
    [self loadFolder];
}

- (void)fileDoubleClicked:(id)sender {
    (void)sender;
    const NSInteger row = _fileTable.clickedRow;
    if (row < 0 || static_cast<std::size_t>(row) >= _files.size()) return;
    const FileRow& f = _files[static_cast<std::size_t>(row)];
    if (f.isBack || f.isFolder) { _folder = f.url; [self loadFolder]; }
}

- (void)tickAll:(id)sender { (void)sender; for (FileRow& f : _files) if (f.importable) f.ticked = YES; [_fileTable reloadData]; [self previewChanged]; }
- (void)tickNone:(id)sender { (void)sender; for (FileRow& f : _files) f.ticked = NO; [_fileTable reloadData]; [self previewChanged]; }

// ---------------------------------------------------------------- preview

- (void)previewChanged {
    _instruments.clear();
    _kontaktPath = nil;
    _kontaktMode = NO;
    NSMutableArray<NSString*>* others = [NSMutableArray array];
    for (const FileRow& f : _files) {
        if (!f.ticked) continue;
        if ([f.name.pathExtension.lowercaseString isEqualToString:@"nki"] && _kontaktPath == nil) _kontaktPath = f.url.path;
        else [others addObject:f.name];
    }
    [_ratePopup removeAllItems];
    _rateValues.clear();
    _rateLabel.stringValue = @"";
    _previewNote.stringValue = @"";
    _ratePopup.hidden = YES;
    _rateLabel.hidden = YES;
    if (_kontaktPath != nil) {
        [self loadKontaktPreview];
        if (others.count > 0U) _previewNote.stringValue = [NSString stringWithFormat:@"+ още %lu файла (KMP/KSC/WAV) влизат преди Kontakt", static_cast<unsigned long>(others.count)];
    } else {
        _previewPanel.title = others.count == 0U ? @"КАКВО ЩЕ ВЛЕЗЕ" : [NSString stringWithFormat:@"КАКВО ЩЕ ВЛЕЗЕ: %lu ФАЙЛА", static_cast<unsigned long>(others.count)];
        _previewNote.stringValue = others.count == 0U ? @"Тикни файлове отляво." : @"";
    }
    [self updateImportKey];
    [_previewTable reloadData];
}

- (void)loadKontaktPreview {
    _kontaktMode = YES;
    const KontaktLibrary lib = KontaktImporter::open(std::string(_kontaktPath.fileSystemRepresentation));
    if (!lib.ok()) {
        _previewPanel.title = @"КАКВО ЩЕ ВЛЕЗЕ";
        _previewNote.stringValue = SVNs(lib.error);
        _kontaktMode = NO;
        return;
    }
    _previewPanel.title = [NSString stringWithFormat:@"КАКВО ЩЕ ВЛЕЗЕ ОТ: %@", _kontaktPath.lastPathComponent];
    KontaktImportOptions dry;
    dry.maxVelocityLayers = kVelocityLayers;
    dry.dryRun = true;
    for (std::size_t gi = 0U; gi < lib.groups.size(); ++gi) {
        const auto& g = lib.groups[gi];
        if (g.zoneIndices.empty()) continue;
        std::uint8_t keyLow = 127U, keyHigh = 0U;
        std::vector<std::pair<std::uint8_t, std::uint8_t>> ranges;
        for (std::uint32_t zi : g.zoneIndices) {
            const auto& z = lib.zones[zi];
            keyLow = std::min(keyLow, z.keyLow); keyHigh = std::max(keyHigh, z.keyHigh);
            ranges.emplace_back(z.keyLow, z.keyHigh);
        }
        std::sort(ranges.begin(), ranges.end());
        std::size_t maxLayers = 0U, run = 0U;
        for (std::size_t i = 0U; i < ranges.size(); ++i) {
            run = (i > 0U && ranges[i] == ranges[i - 1U]) ? run + 1U : 1U;
            maxLayers = std::max(maxLayers, run);
        }
        KontaktImportResult r = KontaktImporter::importGroup(lib, gi, dry, nullptr);
        double bytes = 0.0;
        for (const auto& s : r.samples) bytes += static_cast<double>(s.totalFrames) * s.channels * (s.bitsPerSample == 24U ? 3.0 : 2.0);
        InstrumentRow row{};
        row.groupIndex = gi;
        row.ticked = NO;
        row.name = SVNs(r.ok() ? r.sound.name : g.name);
        row.keys = [NSString stringWithFormat:@"%u–%u", static_cast<unsigned>(keyLow), static_cast<unsigned>(keyHigh)];
        row.layers = maxLayers > static_cast<std::size_t>(kVelocityLayers)
                         ? [NSString stringWithFormat:@"%lu → %d", static_cast<unsigned long>(maxLayers), kVelocityLayers]
                         : [NSString stringWithFormat:@"%lu", static_cast<unsigned long>(maxLayers)];
        row.samples = [NSString stringWithFormat:@"%lu", static_cast<unsigned long>(r.samples.size())];
        row.megabytes = bytes / (1024.0 * 1024.0);
        _instruments.push_back(row);
    }
    // sample rate: what the files say and what their pitch says
    std::uint32_t tagged = 0U, detected = 0U;
    std::string note;
    if (!_instruments.empty()) detected = KontaktImporter::probeSampleRate(lib, _instruments.front().groupIndex, tagged, note);
    _ratePopup.hidden = NO;
    _rateLabel.hidden = NO;
    [_ratePopup addItemWithTitle:tagged != 0U ? [NSString stringWithFormat:@"както е в файловете (%u Hz)", static_cast<unsigned>(tagged)] : @"както е в файловете"];
    _rateValues.push_back(0U);
    for (unsigned r : {22050U, 44100U, 48000U, 88200U, 96000U}) { [_ratePopup addItemWithTitle:[NSString stringWithFormat:@"%u Hz", r]]; _rateValues.push_back(r); }
    NSInteger select = 0;
    if (detected != 0U && detected != tagged) for (std::size_t i = 0U; i < _rateValues.size(); ++i) if (_rateValues[i] == detected) select = static_cast<NSInteger>(i);
    [_ratePopup selectItemAtIndex:select];
    if (detected != 0U && detected != tagged)
        _rateLabel.stringValue = [NSString stringWithFormat:@"Честота: файловете казват %u Hz, по тона е %u Hz – оставено е %u Hz. Слоеве на клавиш: %d (основен + L1–L4), най-силният удар влиза винаги.",
                                  static_cast<unsigned>(tagged), static_cast<unsigned>(detected), static_cast<unsigned>(detected), kVelocityLayers];
    else
        _rateLabel.stringValue = [NSString stringWithFormat:@"Честота: %@. Слоеве на клавиш: %d (основен + L1–L4), най-силният удар влиза винаги.", SVNs(note), kVelocityLayers];
}

- (void)updateImportKey {
    NSUInteger files = 0U, instruments = 0U;
    double mb = 0.0;
    for (const FileRow& f : _files) if (f.ticked && ![f.name.pathExtension.lowercaseString isEqualToString:@"nki"]) ++files;
    for (const InstrumentRow& r : _instruments) if (r.ticked) { ++instruments; mb += r.megabytes; }
    const NSUInteger total = files + instruments;
    _importKey.title = total == 0U ? @"ВНЕСИ ИЗБРАНИТЕ" : [NSString stringWithFormat:@"ВНЕСИ ИЗБРАНИТЕ (%lu)", static_cast<unsigned long>(total)];
    _importKey.enabled = total > 0U;
    if (_kontaktMode && instruments > 0U) _previewNote.stringValue = [NSString stringWithFormat:@"%lu инструмента · %.0f MB", static_cast<unsigned long>(instruments), mb];
    [_importKey setNeedsDisplay:YES];
}

// ---------------------------------------------------------------- import

- (void)importPressed:(id)sender {
    (void)sender;
    NSMutableArray<NSString*>* paths = [NSMutableArray array];
    for (const FileRow& f : _files) if (f.ticked && ![f.name.pathExtension.lowercaseString isEqualToString:@"nki"]) [paths addObject:f.url.path];
    NSMutableArray<NSNumber*>* groups = [NSMutableArray array];
    double mb = 0.0;
    for (const InstrumentRow& r : _instruments) if (r.ticked) { [groups addObject:@(r.groupIndex)]; mb += r.megabytes; }
    if (paths.count == 0U && groups.count == 0U) { SVAlert(self.window, @"ВНАСЯНЕ", @"Тикни поне един файл или инструмент.", NO); return; }
    if (mb > 3000.0 && !SVConfirm(self.window, @"Много семпли", [NSString stringWithFormat:@"Тикнатите инструменти са около %.0f MB. Паметта на Мака и на таблета може да не стигне. Внасяй по едно–две пиана.", mb], @"Внеси въпреки това")) return;
    SVManagerDocument* document = self.shell.documentModel;
    NSMutableArray<NSString*>* messages = [NSMutableArray array];
    BOOL any = NO;
    if (paths.count > 0U) {
        NSString* details = nil;
        if (SVImportPathsWithProgress(document, paths, self.window, &details)) {
            any = YES;
            for (NSString* p in paths) [self.shell appendImportLog:[NSString stringWithFormat:@"✓  %@", p.lastPathComponent]];
        }
        if (details.length > 0U) [messages addObject:details];
    }
    if (groups.count > 0U && _kontaktPath != nil) {
        NSString* details = nil;
        NSUInteger rate = 0U;
        const NSInteger i = _ratePopup.indexOfSelectedItem;
        if (i >= 0 && static_cast<std::size_t>(i) < _rateValues.size()) rate = _rateValues[static_cast<std::size_t>(i)];
        NSArray<NSString*>* names = [self tickedInstrumentNames];
        if (SVImportKontaktGroups(document, _kontaktPath, groups, rate, self.window, &details)) {
            any = YES;
            for (NSString* n in names) [self.shell appendImportLog:[NSString stringWithFormat:@"✓  %@  (Kontakt, 5 слоя)", n]];
        }
        if (details.length > 0U) [messages addObject:details];
    }
    for (const FileRow& fr : _files) { (void)fr; }
    for (FileRow& f : _files) f.ticked = NO;
    for (InstrumentRow& r : _instruments) r.ticked = NO;
    [_fileTable reloadData];
    [_previewTable reloadData];
    [self updateImportKey];
    [self.shell refreshAll];
    if (messages.count > 0U) {
        for (NSString* m in messages) for (NSString* line in [m componentsSeparatedByString:@"\n"]) if (line.length > 0U) [self.shell appendImportLog:[NSString stringWithFormat:@"!  %@", line]];
        [self refresh];
        SVAlert(self.window, any ? @"Внесено с бележки" : @"Нищо не влезе", [messages componentsJoinedByString:@"\n"], !any);
    }
}

- (NSArray<NSString*>*)tickedInstrumentNames {
    NSMutableArray<NSString*>* names = [NSMutableArray array];
    for (const InstrumentRow& r : _instruments) if (r.ticked) [names addObject:r.name];
    return names;
}

- (void)refresh {
    _log = [[self.shell importLog] copy];
    [_logTable reloadData];
    if (_log.count > 0U) [_logTable scrollRowToVisible:static_cast<NSInteger>(_log.count) - 1];
}

// ---------------------------------------------------------------- tables

- (NSInteger)numberOfRowsInTableView:(NSTableView*)tableView {
    if (tableView == _fileTable) return static_cast<NSInteger>(_files.size());
    if (tableView == _previewTable) {
        if (_kontaktMode) return static_cast<NSInteger>(_instruments.size());
        NSInteger n = 0;
        for (const FileRow& f : _files) if (f.ticked) ++n;
        return n;
    }
    return static_cast<NSInteger>(_log.count);
}

- (const FileRow*)tickedFileAt:(NSInteger)row {
    NSInteger n = 0;
    for (const FileRow& f : _files) { if (!f.ticked) continue; if (n == row) return &f; ++n; }
    return nullptr;
}

- (id)tableView:(NSTableView*)tableView objectValueForTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    NSString* ident = tableColumn.identifier;
    if (tableView == _fileTable) {
        if (row < 0 || static_cast<std::size_t>(row) >= _files.size()) return nil;
        const FileRow& f = _files[static_cast<std::size_t>(row)];
        if ([ident isEqualToString:@"on"]) return f.importable ? @(f.ticked ? 1 : 0) : nil;
        if ([ident isEqualToString:@"name"]) return f.name;
        return f.info;
    }
    if (tableView == _previewTable) {
        if (_kontaktMode) {
            if (row < 0 || static_cast<std::size_t>(row) >= _instruments.size()) return nil;
            const InstrumentRow& r = _instruments[static_cast<std::size_t>(row)];
            if ([ident isEqualToString:@"on"]) return @(r.ticked ? 1 : 0);
            if ([ident isEqualToString:@"name"]) return r.name;
            if ([ident isEqualToString:@"keys"]) return r.keys;
            if ([ident isEqualToString:@"layers"]) return r.layers;
            if ([ident isEqualToString:@"samples"]) return r.samples;
            return [NSString stringWithFormat:@"%.0f", r.megabytes];
        }
        const FileRow* f = [self tickedFileAt:row];
        if (f == nullptr) return nil;
        if ([ident isEqualToString:@"on"]) return @1;
        if ([ident isEqualToString:@"name"]) return f->name;
        if ([ident isEqualToString:@"keys"]) return kindText(f->name);
        return @"";
    }
    if (row < 0 || static_cast<NSUInteger>(row) >= _log.count) return nil;
    return _log[static_cast<NSUInteger>(row)];
}

- (void)tableView:(NSTableView*)tableView setObjectValue:(id)object forTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    if (![tableColumn.identifier isEqualToString:@"on"]) return;
    const BOOL on = [object integerValue] != 0 ? YES : NO;
    if (tableView == _fileTable) {
        if (row < 0 || static_cast<std::size_t>(row) >= _files.size()) return;
        FileRow& f = _files[static_cast<std::size_t>(row)];
        if (!f.importable) return;
        f.ticked = on;
        [self previewChanged];
    } else if (tableView == _previewTable && _kontaktMode) {
        if (row < 0 || static_cast<std::size_t>(row) >= _instruments.size()) return;
        _instruments[static_cast<std::size_t>(row)].ticked = on;
        [self updateImportKey];
    } else if (tableView == _previewTable) {
        const FileRow* f = [self tickedFileAt:row];
        if (f == nullptr) return;
        for (FileRow& g : _files) if (g.url == f->url) g.ticked = NO;
        [_fileTable reloadData];
        [self previewChanged];
    }
}

- (BOOL)tableView:(NSTableView*)tableView shouldSelectRow:(NSInteger)row {
    (void)tableView; (void)row;
    return tableView == _fileTable;
}

// the tick box must work even though the row itself is not selected
- (BOOL)tableView:(NSTableView*)tableView shouldTrackCell:(NSCell*)cell forTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView; (void)cell; (void)tableColumn; (void)row;
    return YES;
}

- (void)tableView:(NSTableView*)tableView willDisplayCell:(id)cell forTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView; (void)tableColumn; (void)row;
    if ([cell isKindOfClass:[NSTextFieldCell class]]) {
        NSTextFieldCell* text = cell;
        BOOL folder = NO;
        if (tableView == _fileTable && row >= 0 && static_cast<std::size_t>(row) < _files.size()) folder = _files[static_cast<std::size_t>(row)].isFolder || _files[static_cast<std::size_t>(row)].isBack;
        if ([tableColumn.identifier isEqualToString:@"name"]) text.textColor = folder ? SVColAmberLight() : SVColText();
    }
}
@end
