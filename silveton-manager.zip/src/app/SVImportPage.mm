// SILVETON_LOOK_V1 / SILVETON_FIND_V1 - ВНАСЯНЕ. It is no page of its own any more: SVSamplesPage (СЕМПЛИ) holds it
// on the right of the project tree and shows it with the key ВНАСЯНЕ ОТ ДИСКА. From top to bottom:
// files on the disk, what will come in, what came in. ТЪРСИ В ПАПКАТА И ПОД-ПАПКИТЕ lists every .nki and .kmp below the folder.
#import "SVShell.h"
#import "SVDocument.h"
#import "SVTheme.h"
#import "SVProgress.h"
#import "SVAutoMapReview.h"

#include "silveton/manager/InstrumentFinder.h"
#include "silveton/manager/KontaktImporter.h"
#include "silveton/manager/MediaPathPolicy.h"

#include <atomic>
#include <cstddef>
#include <algorithm>
#include <cstdint>
#include <memory>
#include <utility>
#include <string>
#include <vector>

using silveton::manager::InstrumentFinder;
using silveton::manager::InstrumentSearchOptions;
using silveton::manager::InstrumentSearchResult;
using silveton::manager::KontaktImporter;
using silveton::manager::KontaktInstrumentSet;
using silveton::manager::KontaktImportOptions;
using silveton::manager::KontaktImportResult;
using silveton::manager::KontaktLibrary;
using silveton::manager::KontaktListenAudio;
using silveton::manager::KontaktListenItem;
using silveton::manager::MediaEntryKind;
using silveton::manager::MediaPathPolicy;

namespace {
NSString* const kPrefFolder = @"SVImportFolder";
constexpr int kVelocityLayers = 5;

struct FileRow {
    NSURL* url;
    NSString* name;
    NSString* info;
    NSString* folder;         // SILVETON_FIND_V1: in the search list, the sub-folder the file lies in
    BOOL isFolder;
    BOOL isBack;
    BOOL importable;
    BOOL ticked;
};

struct InstrumentRow {
    std::size_t setIndex;     // index into KontaktImporter::instrumentSets (a plain group, or all strings of one technique)
    BOOL ticked;
    NSString* name;
    NSString* keys;
    NSString* layers;
    NSString* samples;
    double megabytes;
};

NSString* kindText(NSString* name) {
    NSString* ext = name.pathExtension.lowercaseString;
    if ([ext isEqualToString:@"nki"]) return @"Kontakt инструмент";
    if ([ext isEqualToString:@"kmp"]) return @"Korg KMP";
    if ([ext isEqualToString:@"ksc"]) return @"Korg KSC (набор KMP)";
    if ([ext isEqualToString:@"ksf"]) return @"Korg KSF (семпъл)";
    if ([ext isEqualToString:@"ncw"]) return @"Kontakt NCW (семпъл)";
    if ([ext isEqualToString:@"sv"]) return @"SILVETON банка (зарежда се от БАНКА)";
    return @"WAV / AIFF";
}

// the instrument files themselves are small: SVMegabytes would say "0.0 MB"
NSString* fileSizeText(unsigned long long bytes) {
    if (bytes < 1024ULL * 1024ULL) return [NSString stringWithFormat:@"%.0f KB", static_cast<double>(bytes) / 1024.0];
    return SVMegabytes(static_cast<double>(bytes));
}
}

// ---------------------------------------------------------------- SILVETON_KONTAKT_LISTEN_V1
// Listening only: the samples of ONE Kontakt instrument in a small window. A click on a sample plays it at once.
// Nothing is ticked, changed or imported from here.

@interface SVKontaktListenPanel : NSObject <NSTableViewDataSource, NSTableViewDelegate, NSWindowDelegate>
- (instancetype)initWithPlayer:(SVSampleAuditionPlayer*)player rate:(unsigned (^)(void))rate;
- (void)showInstrument:(NSString*)name library:(std::shared_ptr<KontaktLibrary>)library set:(const KontaktInstrumentSet&)set;
- (void)closeWindow;
@end

@implementation SVKontaktListenPanel {
    SVSampleAuditionPlayer* _player;
    unsigned (^_rate)(void);                       // the rate chosen on the page, 0 = as the files say
    std::shared_ptr<KontaktLibrary> _library;
    std::vector<KontaktListenItem> _items;
    NSPanel* _panel;
    NSTableView* _table;
    NSTextField* _title;
    NSTextField* _status;
    BOOL _placed;
    BOOL _quiet;                                   // YES while the list is rebuilt: nothing may start playing then
}

- (instancetype)initWithPlayer:(SVSampleAuditionPlayer*)player rate:(unsigned (^)(void))rate {
    self = [super init];
    if (self) {
        _player = player;
        _rate = [rate copy];
        _placed = NO;
        _panel = [[NSPanel alloc] initWithContentRect:NSMakeRect(0.0, 0.0, 560.0, 560.0)
                                            styleMask:(NSWindowStyleMaskTitled | NSWindowStyleMaskClosable | NSWindowStyleMaskResizable)
                                              backing:NSBackingStoreBuffered
                                                defer:NO];
        _panel.title = @"ПРЕСЛУШВАНЕ";
        _panel.backgroundColor = SVColBackground();
        _panel.floatingPanel = YES;
        _panel.hidesOnDeactivate = NO;
        _panel.releasedWhenClosed = NO;
        _panel.minSize = NSMakeSize(460.0, 320.0);
        _panel.delegate = self;
        NSView* c = _panel.contentView;

        _title = SVLabel(NSMakeRect(20.0, 520.0, 520.0, 22.0), @"", 16.0, YES, SVColText());
        _title.autoresizingMask = NSViewMinYMargin | NSViewWidthSizable;
        [c addSubview:_title];
        NSTextField* hint = SVLabel(NSMakeRect(20.0, 496.0, 520.0, 18.0), @"Цъкни семпъл и той свири. Само слушане: нищо не се променя и нищо не се внася.", 11.0, NO, SVColDim());
        hint.autoresizingMask = NSViewMinYMargin | NSViewWidthSizable;
        [c addSubview:hint];

        _table = [[NSTableView alloc] initWithFrame:NSZeroRect];
        SVStyleTable(_table);
        _table.dataSource = self;
        _table.delegate = self;
        [_table addTableColumn:SVTextColumn(@"keys", @"КЛАВИШИ", 110.0)];
        [_table addTableColumn:SVTextColumn(@"root", @"ОСНОВЕН ТОН", 90.0)];
        [_table addTableColumn:SVTextColumn(@"vel", @"СИЛА", 70.0)];
        [_table addTableColumn:SVTextColumn(@"len", @"ДЪЛЖИНА", 80.0)];
        [_table addTableColumn:SVTextColumn(@"group", @"ГРУПА", 140.0)];
        NSScrollView* scroll = SVScroll(NSMakeRect(20.0, 62.0, 520.0, 426.0), _table);
        scroll.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
        [c addSubview:scroll];

        SVKeyButton* stop = [SVKeyButton keyWithFrame:NSMakeRect(20.0, 14.0, 110.0, 34.0) title:@"■ СПРИ" kind:0 target:self action:@selector(stopPressed:)];
        stop.autoresizingMask = NSViewMaxYMargin;
        [c addSubview:stop];
        _status = SVLabel(NSMakeRect(142.0, 22.0, 398.0, 18.0), @"", 11.0, NO, SVColDim());
        _status.autoresizingMask = NSViewMaxYMargin | NSViewWidthSizable;
        _status.lineBreakMode = NSLineBreakByTruncatingTail;
        [c addSubview:_status];
    }
    return self;
}

- (void)showInstrument:(NSString*)name library:(std::shared_ptr<KontaktLibrary>)library set:(const KontaktInstrumentSet&)set {
    [_player stop];
    _library = library;
    _items = library != nullptr ? KontaktImporter::listenItems(*library, set) : std::vector<KontaktListenItem>();
    _title.stringValue = [NSString stringWithFormat:@"ПРЕСЛУШВАНЕ: %@", name];
    _status.stringValue = [NSString stringWithFormat:@"%lu семпъла. Цъкни един, за да го чуеш.", static_cast<unsigned long>(_items.size())];
    _quiet = YES;
    [_table deselectAll:nil];
    [_table reloadData];
    _quiet = NO;
    if (!_items.empty()) [_table scrollRowToVisible:0];
    if (!_placed) { [_panel center]; _placed = YES; }
    [_panel makeKeyAndOrderFront:nil];
    [_panel makeFirstResponder:_table];
}

- (void)closeWindow {
    [_player stop];
    [_panel orderOut:nil];
}

- (void)windowWillClose:(NSNotification*)notification {
    (void)notification;
    [_player stop];
}

- (void)stopPressed:(id)sender {
    (void)sender;
    [_player stop];
    _status.stringValue = @"Спряно.";
}

- (NSInteger)numberOfRowsInTableView:(NSTableView*)tableView {
    (void)tableView;
    return static_cast<NSInteger>(_items.size());
}

- (id)tableView:(NSTableView*)tableView objectValueForTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView;
    if (row < 0 || static_cast<std::size_t>(row) >= _items.size()) return nil;
    const KontaktListenItem& item = _items[static_cast<std::size_t>(row)];
    NSString* ident = tableColumn.identifier;
    if ([ident isEqualToString:@"keys"]) {
        if (item.keyLow == item.keyHigh) return SVNoteName(item.keyLow);
        return [NSString stringWithFormat:@"%@–%@", SVNoteName(item.keyLow), SVNoteName(item.keyHigh)];
    }
    if ([ident isEqualToString:@"root"]) return SVNoteName(item.rootKey);
    if ([ident isEqualToString:@"vel"]) return [NSString stringWithFormat:@"%u–%u", static_cast<unsigned>(item.velocityLow), static_cast<unsigned>(item.velocityHigh)];
    if ([ident isEqualToString:@"len"]) {
        unsigned rate = _rate != nil ? _rate() : 0U;
        if (rate == 0U) rate = item.sampleRateTag;
        return rate == 0U ? @"" : [NSString stringWithFormat:@"%.2f s", static_cast<double>(item.frames) / static_cast<double>(rate)];
    }
    return SVNs(item.group);
}

// a click (or an arrow key) on a sample plays it at once
- (void)tableViewSelectionDidChange:(NSNotification*)notification {
    (void)notification;
    if (_quiet) return;
    const NSInteger row = _table.selectedRow;
    if (row >= 0) [self playRow:row];
}

- (void)playRow:(NSInteger)row {
    if (_library == nullptr || row < 0 || static_cast<std::size_t>(row) >= _items.size()) return;
    [_player stop];
    const KontaktListenItem& item = _items[static_cast<std::size_t>(row)];
    KontaktListenAudio audio;
    std::string error;
    if (!KontaktImporter::loadListenAudio(*_library, item.zoneIndex, audio, error)) {
        _status.stringValue = [NSString stringWithFormat:@"Не мога да прочета семпъла: %@", SVNs(error)];
        return;
    }
    unsigned rate = _rate != nil ? _rate() : 0U;
    if (rate == 0U) rate = audio.sampleRate;
    NSData* data = [NSData dataWithBytes:audio.pcm.data() length:static_cast<NSUInteger>(audio.pcm.size())];
    NSDictionary* state = @{@"name": SVNs(item.group), @"audioData": data, @"sampleRate": @(rate), @"channels": @(audio.channels),
                            @"encoding": @(audio.bitsPerSample == 24U ? 2U : 1U), @"bitsPerSample": @(audio.bitsPerSample),
                            @"totalFrames": @(audio.frames), @"loopEnabled": @NO, @"loopStart": @0, @"loopEnd": @0};
    NSString* playError = nil;
    if (![_player playState:state loopOnly:NO error:&playError]) {
        _status.stringValue = [NSString stringWithFormat:@"Не мога да го пусна: %@", playError ?: @"грешка"];
        return;
    }
    _status.stringValue = [NSString stringWithFormat:@"Свири: основен тон %@ · сила %u–%u · %u Hz", SVNoteName(item.rootKey),
                           static_cast<unsigned>(item.velocityLow), static_cast<unsigned>(item.velocityHigh), rate];
}

@end

@interface SVImportPage : SVPageView <NSTableViewDataSource, NSTableViewDelegate>
@end

@implementation SVImportPage {
    std::vector<FileRow> _files;
    std::vector<InstrumentRow> _instruments;
    NSURL* _folder;
    NSTableView* _fileTable;
    NSTableView* _previewTable;
    NSTableView* _logTable;
    NSTextField* _pathLabel;
    SVPanel* _previewPanel;
    NSTextField* _previewNote;
    NSTextField* _rateLabel;
    NSPopUpButton* _ratePopup;
    std::vector<unsigned> _rateValues;
    NSPopUpButton* _stepPopup;   // one sample per 1 / 2 / 3 keys
    SVKeyButton* _importKey;
    NSString* _kontaktPath;
    NSArray<NSString*>* _log;
    BOOL _kontaktMode;
    std::shared_ptr<KontaktLibrary> _lib;          // SILVETON_KONTAKT_LISTEN_V1: the opened instrument file, for listening
    std::vector<KontaktInstrumentSet> _sets;       // the same list as the rows (row.setIndex points into it)
    SVKontaktListenPanel* _listen;
    // SILVETON_FIND_V1: the search through the folder and all its sub-folders
    SVKeyButton* _scanKey;
    NSTableColumn* _folderColumn;
    BOOL _scanMode;                                // YES = the left list shows what the search found, not one folder
    BOOL _scanning;                                // YES = the search runs in the background
    NSUInteger _scanGeneration;                    // a result of an older search is thrown away
    std::shared_ptr<std::atomic<bool>> _cancelFlag;
    NSUInteger _waitingNki;                        // more .nki ticked than the one shown on the right: they wait their turn
}

- (instancetype)initWithShell:(SVShellWindowController*)shell frame:(NSRect)frame {
    self = [super initWithShell:shell frame:frame];
    if (self) {
        _kontaktMode = NO;
        _log = @[];
        NSString* saved = [[NSUserDefaults standardUserDefaults] stringForKey:kPrefFolder];
        BOOL isDir = NO;
        if (saved.length > 0U && [[NSFileManager defaultManager] fileExistsAtPath:saved isDirectory:&isDir] && isDir) _folder = [NSURL fileURLWithPath:saved isDirectory:YES];
        else _folder = [NSURL fileURLWithPath:NSHomeDirectory() isDirectory:YES];
        [self build];
        [self loadFolder];
    }
    return self;
}

- (void)build {
    const NSRect b = self.bounds;
    // SILVETON_FIND_V1: three panels one under the other - files on the disk, what will come in, what came in
    const CGFloat filesH = 270.0;
    const CGFloat logH = 108.0;
    // ---- top: files
    SVPanel* left = [[SVPanel alloc] initWithFrame:NSMakeRect(0.0, 0.0, b.size.width, filesH) title:@"ФАЙЛОВЕ НА ДИСКА"];
    left.autoresizingMask = NSViewWidthSizable | NSViewMaxYMargin;
    _pathLabel = SVLabel(NSMakeRect(12.0, 32.0, left.bounds.size.width - 24.0, 18.0), @"", 11.0, NO, SVColDim());
    _pathLabel.lineBreakMode = NSLineBreakByTruncatingHead;
    _pathLabel.autoresizingMask = NSViewWidthSizable;
    [left addSubview:_pathLabel];
    _fileTable = [[NSTableView alloc] initWithFrame:NSZeroRect];
    SVStyleTable(_fileTable);
    _fileTable.headerView = nil;
    _fileTable.dataSource = self;
    _fileTable.delegate = self;
    _fileTable.target = self;
    _fileTable.doubleAction = @selector(fileDoubleClicked:);
    [_fileTable addTableColumn:SVCheckColumn(@"on", 24.0)];
    [_fileTable addTableColumn:SVTextColumn(@"name", @"", 240.0)];
    _folderColumn = SVTextColumn(@"folder", @"", 250.0);
    [(NSTextFieldCell*)_folderColumn.dataCell setTextColor:SVColDim()];
    [(NSTextFieldCell*)_folderColumn.dataCell setLineBreakMode:NSLineBreakByTruncatingHead];   // the end of a long path stays visible
    _folderColumn.hidden = YES;                                                             // only the search list has it
    [_fileTable addTableColumn:_folderColumn];
    NSTableColumn* info = SVTextColumn(@"info", @"", 150.0);
    [(NSTextFieldCell*)info.dataCell setTextColor:SVColDim()];
    [(NSTextFieldCell*)info.dataCell setAlignment:NSTextAlignmentRight];
    [_fileTable addTableColumn:info];
    NSScrollView* scroll = SVScroll(NSMakeRect(12.0, 54.0, left.bounds.size.width - 24.0, left.bounds.size.height - 54.0 - 56.0), _fileTable);
    scroll.autoresizingMask = NSViewWidthSizable;
    [left addSubview:scroll];
    const CGFloat by = left.bounds.size.height - 46.0;
    SVKeyButton* disk = [SVKeyButton keyWithFrame:NSMakeRect(12.0, by, 124.0, 34.0) title:@"ИЗБЕРИ ПАПКА" kind:0 target:self action:@selector(chooseFolder:)];
    disk.autoresizingMask = NSViewMinYMargin;
    [left addSubview:disk];
    _scanKey = [SVKeyButton keyWithFrame:NSMakeRect(144.0, by, 290.0, 34.0) title:@"ТЪРСИ В ПАПКАТА И ПОД-ПАПКИТЕ" kind:0 target:self action:@selector(scanPressed:)];
    _scanKey.textSize = 11.0;
    _scanKey.autoresizingMask = NSViewMinYMargin;
    _scanKey.toolTip = @"Намира всички .nki (Kontakt) и .kmp (Korg) във избраната папка и във всички папки под нея. Нищо не се внася само - тикваш ти.";
    [left addSubview:_scanKey];
    SVKeyButton* all = [SVKeyButton keyWithFrame:NSMakeRect(442.0, by, 90.0, 34.0) title:@"ВСИЧКИ" kind:0 target:self action:@selector(tickAll:)];
    all.autoresizingMask = NSViewMinYMargin;
    [left addSubview:all];
    SVKeyButton* none = [SVKeyButton keyWithFrame:NSMakeRect(540.0, by, 90.0, 34.0) title:@"НИЩО" kind:0 target:self action:@selector(tickNone:)];
    none.autoresizingMask = NSViewMinYMargin;
    [left addSubview:none];
    [self addSubview:left];

    // ---- middle: preview
    const CGFloat previewY = filesH + 16.0;
    const CGFloat previewH = std::max(200.0, b.size.height - logH - 16.0 - previewY);
    _previewPanel = [[SVPanel alloc] initWithFrame:NSMakeRect(0.0, previewY, b.size.width, previewH) title:@"КАКВО ЩЕ ВЛЕЗЕ"];
    _previewPanel.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    _previewTable = [[NSTableView alloc] initWithFrame:NSZeroRect];
    SVStyleTable(_previewTable);
    _previewTable.dataSource = self;
    _previewTable.delegate = self;
    _previewTable.target = self;
    _previewTable.action = @selector(previewClicked:);   // SILVETON_KONTAKT_LISTEN_V1: a click on an instrument opens the listening window
    [_previewTable addTableColumn:SVCheckColumn(@"on", 24.0)];
    [_previewTable addTableColumn:SVTextColumn(@"name", @"ИНСТРУМЕНТ / ФАЙЛ", 300.0)];
    [_previewTable addTableColumn:SVTextColumn(@"keys", @"КЛАВИШИ", 80.0)];
    [_previewTable addTableColumn:SVTextColumn(@"layers", @"СЛОЕВЕ", 80.0)];
    [_previewTable addTableColumn:SVTextColumn(@"samples", @"СЕМПЛИ", 70.0)];
    [_previewTable addTableColumn:SVTextColumn(@"mb", @"MB", 60.0)];
    NSScrollView* pscroll = SVScroll(NSMakeRect(12.0, 32.0, _previewPanel.bounds.size.width - 24.0, _previewPanel.bounds.size.height - 32.0 - 80.0), _previewTable);
    pscroll.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    [_previewPanel addSubview:pscroll];
    const CGFloat py = _previewPanel.bounds.size.height - 42.0;
    // one row that fits at the smallest window: two choosers on the left, the big key on the right
    _rateLabel = SVLabel(NSMakeRect(12.0, py - 22.0, 290.0, 18.0), @"", 11.0, NO, SVColDim());
    _rateLabel.autoresizingMask = NSViewMinYMargin;
    [_previewPanel addSubview:_rateLabel];
    _ratePopup = SVPopup(NSMakeRect(12.0, py + 2.0, 178.0, 26.0));
    _ratePopup.autoresizingMask = NSViewMinYMargin;
    [_previewPanel addSubview:_ratePopup];
    _stepPopup = SVPopup(NSMakeRect(196.0, py + 2.0, 210.0, 26.0));
    _stepPopup.autoresizingMask = NSViewMinYMargin;
    [_stepPopup addItemsWithTitles:@[@"на всеки клавиш", @"1 семпъл на 2 клавиша", @"1 семпъл на 3 клавиша"]];
    _stepPopup.target = self;
    _stepPopup.action = @selector(stepChanged:);
    [_previewPanel addSubview:_stepPopup];
    _previewNote = SVLabel(NSMakeRect(306.0, py - 22.0, std::max(120.0, _previewPanel.bounds.size.width - 306.0 - 12.0), 18.0), @"", 11.0, NO, SVColDim());
    _previewNote.autoresizingMask = NSViewMinYMargin | NSViewWidthSizable;
    _previewNote.lineBreakMode = NSLineBreakByTruncatingTail;
    [_previewPanel addSubview:_previewNote];
    _importKey = [SVKeyButton keyWithFrame:NSMakeRect(_previewPanel.bounds.size.width - 12.0 - 176.0, py + 2.0, 176.0, 26.0) title:@"ВНЕСИ ИЗБРАНИТЕ" kind:1 target:self action:@selector(importPressed:)];
    _importKey.textSize = 12.0;
    _importKey.autoresizingMask = NSViewMinYMargin | NSViewMinXMargin;
    [_previewPanel addSubview:_importKey];
    [self addSubview:_previewPanel];

    // ---- bottom: log
    SVPanel* logPanel = [[SVPanel alloc] initWithFrame:NSMakeRect(0.0, b.size.height - logH, b.size.width, logH) title:@"ВЛЯЗЛО ДОСЕГА"];
    logPanel.autoresizingMask = NSViewWidthSizable | NSViewMinYMargin;
    _logTable = [[NSTableView alloc] initWithFrame:NSZeroRect];
    SVStyleTable(_logTable);
    _logTable.headerView = nil;
    _logTable.dataSource = self;
    _logTable.delegate = self;
    [_logTable addTableColumn:SVTextColumn(@"line", @"", 800.0)];
    NSScrollView* lscroll = SVScroll(NSMakeRect(12.0, 32.0, logPanel.bounds.size.width - 24.0, logPanel.bounds.size.height - 44.0), _logTable);
    lscroll.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    [logPanel addSubview:lscroll];
    [self addSubview:logPanel];
}

// ---------------------------------------------------------------- folder

- (void)loadFolder {
    [self cancelScan];          // SILVETON_FIND_V1: looking into a folder by hand ends the search list
    _scanMode = NO;
    _folderColumn.hidden = YES;
    _files.clear();
    NSFileManager* fm = [NSFileManager defaultManager];
    NSString* home = NSHomeDirectory();
    if (![_folder.path isEqualToString:@"/"]) {
        FileRow back{};
        back.url = _folder.URLByDeletingLastPathComponent;
        back.name = @"⬅  назад";
        back.info = @"";
        back.isBack = YES;
        _files.push_back(back);
    }
    (void)home;
    NSArray<NSURL*>* items = [fm contentsOfDirectoryAtURL:_folder
                                includingPropertiesForKeys:@[NSURLIsDirectoryKey, NSURLFileSizeKey, NSURLIsHiddenKey]
                                                   options:NSDirectoryEnumerationSkipsHiddenFiles
                                                     error:nil];
    std::vector<FileRow> folders, files;
    for (NSURL* url in items) {
        NSNumber* isDir = nil;
        [url getResourceValue:&isDir forKey:NSURLIsDirectoryKey error:nil];
        NSString* name = url.lastPathComponent ?: @"";
        if (isDir.boolValue) {
            FileRow row{};
            row.url = url; row.name = [@"📁  " stringByAppendingString:name]; row.info = @""; row.isFolder = YES;
            folders.push_back(row);
            continue;
        }
        const MediaEntryKind kind = MediaPathPolicy::classify(std::string(url.path.UTF8String ?: ""), false);
        if (kind == MediaEntryKind::Unsupported) continue;
        NSNumber* size = nil;
        [url getResourceValue:&size forKey:NSURLFileSizeKey error:nil];
        FileRow row{};
        row.url = url; row.name = name; row.importable = kind == MediaEntryKind::ImportableSamplerFile;
        row.info = [NSString stringWithFormat:@"%@ · %@", kindText(name), SVMegabytes(size.doubleValue)];
        files.push_back(row);
    }
    auto byName = [](const FileRow& a, const FileRow& b) { return [a.name localizedCaseInsensitiveCompare:b.name] == NSOrderedAscending; };
    std::sort(folders.begin(), folders.end(), byName);
    std::sort(files.begin(), files.end(), byName);
    _files.insert(_files.end(), folders.begin(), folders.end());
    _files.insert(_files.end(), files.begin(), files.end());
    _pathLabel.stringValue = _folder.path ?: @"";
    [[NSUserDefaults standardUserDefaults] setObject:_folder.path forKey:kPrefFolder];
    [_fileTable reloadData];
    [self previewChanged];
}

- (void)chooseFolder:(id)sender {
    (void)sender;
    NSOpenPanel* panel = [NSOpenPanel openPanel];
    panel.canChooseFiles = NO;
    panel.canChooseDirectories = YES;
    panel.allowsMultipleSelection = NO;
    panel.prompt = @"Избери";
    panel.directoryURL = _folder;
    if ([panel runModal] != NSModalResponseOK || panel.URLs.count == 0U) return;
    _folder = (NSURL*)panel.URLs.firstObject;
    [self loadFolder];
}

- (void)fileDoubleClicked:(id)sender {
    (void)sender;
    const NSInteger row = _fileTable.clickedRow;
    if (row < 0 || static_cast<std::size_t>(row) >= _files.size()) return;
    const FileRow& f = _files[static_cast<std::size_t>(row)];
    if (f.isBack || f.isFolder) { _folder = f.url; [self loadFolder]; }
}

// ---------------------------------------------------------------- SILVETON_FIND_V1: search below the folder

- (void)updateScanKey {
    _scanKey.title = _scanning ? @"■ СПРИ ТЪРСЕНЕТО" : @"ТЪРСИ В ПАПКАТА И ПОД-ПАПКИТЕ";
    _scanKey.kind = _scanning ? 2 : 0;
    [_scanKey setNeedsDisplay:YES];
}

// another folder / the end of the search list: a running search is thrown away
- (void)cancelScan {
    if (_cancelFlag != nullptr) _cancelFlag->store(true);
    _cancelFlag.reset();
    _scanning = NO;
    ++_scanGeneration;
    [self updateScanKey];
}

- (void)scanPressed:(id)sender {
    (void)sender;
    if (_scanning) {      // pressed again while it runs: stop and keep what was found until now
        if (_cancelFlag != nullptr) _cancelFlag->store(true);
        _scanKey.title = @"СПИРАМ…";
        [_scanKey setNeedsDisplay:YES];
        return;
    }
    NSString* root = _folder.path;
    if (root.length == 0U) return;
    ++_scanGeneration;
    const NSUInteger generation = _scanGeneration;
    _scanning = YES;
    _cancelFlag = std::make_shared<std::atomic<bool>>(false);
    const std::shared_ptr<std::atomic<bool>> cancel = _cancelFlag;
    [self updateScanKey];
    _pathLabel.stringValue = [NSString stringWithFormat:@"Търся в %@ и във всички папки под нея…", root];
    __weak SVImportPage* weakSelf = self;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        const std::string rootPath(root.fileSystemRepresentation);
        const InstrumentSearchOptions options{};
        void (^report)(std::size_t, std::size_t) = ^(std::size_t directories, std::size_t found) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [weakSelf scanProgressDirectories:static_cast<NSUInteger>(directories) found:static_cast<NSUInteger>(found) generation:generation];
            });
        };
        auto result = std::make_shared<InstrumentSearchResult>(InstrumentFinder::search(rootPath, options, cancel.get(),
            [report](std::size_t directories, std::size_t found) { report(directories, found); }));
        dispatch_async(dispatch_get_main_queue(), ^{ [weakSelf scanFinished:result generation:generation]; });
    });
}

- (void)scanProgressDirectories:(NSUInteger)directories found:(NSUInteger)found generation:(NSUInteger)generation {
    if (generation != _scanGeneration || !_scanning) return;
    _pathLabel.stringValue = [NSString stringWithFormat:@"Търся… преглед на %lu папки, намерени %lu", static_cast<unsigned long>(directories), static_cast<unsigned long>(found)];
}

- (void)scanFinished:(std::shared_ptr<InstrumentSearchResult>)result generation:(NSUInteger)generation {
    if (generation != _scanGeneration) return;       // an older search, the folder was changed meanwhile
    _scanning = NO;
    _cancelFlag.reset();
    [self updateScanKey];
    _pathLabel.stringValue = _folder.path ?: @"";
    if (result == nullptr) return;
    if (!result->error.empty()) { SVFlash(@"ТЪРСЕНЕ", SVNs(result->error), YES); return; }
    if (result->files.empty()) {
        SVFlash(@"ТЪРСЕНЕ", result->cancelled ? @"Спряно, нищо не е намерено дотук." : @"Не намерих .nki или .kmp в тази папка и във папките под нея.", YES);
        return;
    }
    _files.clear();
    FileRow back{};
    back.url = _folder;                               // a double click on this row looks into the folder again
    back.name = @"⬅  обратно към папките";
    back.info = @"";
    back.isBack = YES;
    _files.push_back(back);
    NSUInteger kontakt = 0U, korg = 0U;
    for (const auto& item : result->files) {
        FileRow row{};
        row.url = [NSURL fileURLWithPath:SVNs(item.path)];
        row.name = SVNs(item.name);
        row.folder = item.folder.empty() ? @"(тази папка)" : SVNs(item.folder);
        row.importable = YES;
        row.info = [NSString stringWithFormat:@"%@ · %@", item.kontakt ? @"Kontakt" : @"Korg KMP", fileSizeText(item.bytes)];
        if (item.kontakt) ++kontakt; else ++korg;
        _files.push_back(row);
    }
    _scanMode = YES;
    _folderColumn.hidden = NO;
    NSMutableString* text = [NSMutableString stringWithFormat:@"Намерени %lu: %lu Kontakt .nki · %lu Korg .kmp   (в %@ и под нея)",
                             static_cast<unsigned long>(kontakt + korg), static_cast<unsigned long>(kontakt), static_cast<unsigned long>(korg), _folder.path ?: @""];
    if (result->cancelled) [text appendString:@"   · спряно, това е намереното дотук"];
    if (result->cutOff) [text appendString:@"   · спрях на лимита, има още - избери по-тясна папка"];
    _pathLabel.stringValue = text;
    [_fileTable reloadData];
    [_fileTable scrollRowToVisible:0];
    [self previewChanged];
}

- (void)tickAll:(id)sender { (void)sender; for (FileRow& f : _files) if (f.importable) f.ticked = YES; [_fileTable reloadData]; [self previewChanged]; }
- (void)tickNone:(id)sender { (void)sender; for (FileRow& f : _files) f.ticked = NO; [_fileTable reloadData]; [self previewChanged]; }

// ---------------------------------------------------------------- preview

- (void)previewChanged {
    [_listen closeWindow];
    _lib.reset();
    _sets.clear();
    _instruments.clear();
    _kontaktPath = nil;
    _kontaktMode = NO;
    NSMutableArray<NSString*>* others = [NSMutableArray array];
    _waitingNki = 0U;
    for (const FileRow& f : _files) {
        if (!f.ticked) continue;
        if ([f.name.pathExtension.lowercaseString isEqualToString:@"nki"]) {
            // SILVETON_FIND_V1: one .nki is open on the right at a time; the other ticked ones wait and come next, after ВНЕСИ
            if (_kontaktPath == nil) _kontaktPath = f.url.path;
            else ++_waitingNki;
        } else {
            [others addObject:f.name];
        }
    }
    [_ratePopup removeAllItems];
    _rateValues.clear();
    _rateLabel.stringValue = @"";
    _previewNote.stringValue = @"";
    _ratePopup.hidden = YES;
    _rateLabel.hidden = YES;
    _stepPopup.hidden = YES;
    if (_kontaktPath != nil) {
        [self loadKontaktPreview];
        NSMutableArray<NSString*>* parts = [NSMutableArray array];
        if (others.count > 0U) [parts addObject:[NSString stringWithFormat:@"+ още %lu файла (KMP/KSC/WAV/NCW) влизат преди Kontakt", static_cast<unsigned long>(others.count)]];
        if (_waitingNki > 0U) [parts addObject:[NSString stringWithFormat:@"още %lu .nki чакат реда си", static_cast<unsigned long>(_waitingNki)]];
        if (_kontaktMode && parts.count > 0U) _previewNote.stringValue = [parts componentsJoinedByString:@" · "];   // a file that could not be opened keeps its error text
    } else {
        _previewPanel.title = others.count == 0U ? @"КАКВО ЩЕ ВЛЕЗЕ" : [NSString stringWithFormat:@"КАКВО ЩЕ ВЛЕЗЕ: %lu ФАЙЛА", static_cast<unsigned long>(others.count)];
        _previewNote.stringValue = others.count == 0U ? @"Тикни файлове отляво." : @"";
    }
    [self updateImportKey];
    [_previewTable reloadData];
}

- (void)loadKontaktPreview {
    _kontaktMode = YES;
    _instruments.clear();   // a reload (step change) must not list the instruments twice
    const KontaktLibrary lib = KontaktImporter::open(std::string(_kontaktPath.fileSystemRepresentation));
    if (!lib.ok()) {
        _previewPanel.title = @"КАКВО ЩЕ ВЛЕЗЕ";
        _previewNote.stringValue = SVNs(lib.error);
        _kontaktMode = NO;
        return;
    }
    _previewPanel.title = [NSString stringWithFormat:@"КАКВО ЩЕ ВЛЕЗЕ ОТ: %@", _kontaktPath.lastPathComponent];
    KontaktImportOptions dry;
    dry.maxVelocityLayers = kVelocityLayers;
    dry.dryRun = true;
    dry.keyStep = [self keyStep];
    // one row per instrument; a bass split per string (B_ E_ A_ D_ G_ ...) shows one row per playing technique
    const std::vector<KontaktInstrumentSet> sets = KontaktImporter::instrumentSets(lib);
    _sets = sets;
    _lib = std::make_shared<KontaktLibrary>(lib);
    for (std::size_t si = 0U; si < sets.size(); ++si) {
        const KontaktInstrumentSet& set = sets[si];
        KontaktImportResult r = KontaktImporter::importSet(lib, set, dry, nullptr);
        double bytes = 0.0;
        for (const auto& smp : r.samples) bytes += static_cast<double>(smp.totalFrames) * smp.channels * (smp.bitsPerSample == 24U ? 3.0 : 2.0);
        InstrumentRow row{};
        row.setIndex = si;
        row.ticked = NO;
        if (set.merged()) {
            row.name = [NSString stringWithFormat:@"%@   ·  струни %@", SVNs(set.name), SVNs(set.strings)];
        } else {
            row.name = SVNs(r.ok() ? r.sound.name : set.name);
        }
        row.keys = [NSString stringWithFormat:@"%u–%u", static_cast<unsigned>(set.keyLow), static_cast<unsigned>(set.keyHigh)];
        row.layers = r.sourceLayers == 0U ? @"—"
                     : (r.sourceLayers > static_cast<std::size_t>(kVelocityLayers)
                            ? [NSString stringWithFormat:@"%lu → %d", static_cast<unsigned long>(r.sourceLayers), kVelocityLayers]
                            : [NSString stringWithFormat:@"%lu", static_cast<unsigned long>(r.sourceLayers)]);
        row.samples = [NSString stringWithFormat:@"%lu", static_cast<unsigned long>(r.samples.size())];
        row.megabytes = bytes / (1024.0 * 1024.0);
        _instruments.push_back(row);
    }
    // sample rate: what the files say and what their pitch says
    std::uint32_t tagged = 0U, detected = 0U;
    std::string note;
    if (!sets.empty()) detected = KontaktImporter::probeSampleRate(lib, sets.front().groups[sets.front().groups.size() / 2U], tagged, note);
    _ratePopup.hidden = NO;
    _rateLabel.hidden = NO;
    _stepPopup.hidden = NO;
    [_ratePopup addItemWithTitle:tagged != 0U ? [NSString stringWithFormat:@"както е в файловете (%u Hz)", static_cast<unsigned>(tagged)] : @"както е в файловете"];
    _rateValues.push_back(0U);
    for (unsigned r : {22050U, 44100U, 48000U, 88200U, 96000U}) { [_ratePopup addItemWithTitle:[NSString stringWithFormat:@"%u Hz", r]]; _rateValues.push_back(r); }
    NSInteger select = 0;
    if (detected != 0U && detected != tagged) for (std::size_t i = 0U; i < _rateValues.size(); ++i) if (_rateValues[i] == detected) select = static_cast<NSInteger>(i);
    [_ratePopup selectItemAtIndex:select];
    if (detected != 0U && detected != tagged)
        _rateLabel.stringValue = [NSString stringWithFormat:@"Честота: файловете казват %u Hz, по тона е %u Hz – оставено е %u Hz. Слоеве на клавиш: %d (основен + L1–L4), най-силният удар влиза винаги.",
                                  static_cast<unsigned>(tagged), static_cast<unsigned>(detected), static_cast<unsigned>(detected), kVelocityLayers];
    else
        _rateLabel.stringValue = [NSString stringWithFormat:@"Честота: %@. Слоеве на клавиш: %d (основен + L1–L4), най-силният удар влиза винаги.", SVNs(note), kVelocityLayers];
}

- (NSInteger)keyStep {
    const NSInteger i = _stepPopup != nil ? _stepPopup.indexOfSelectedItem : 0;
    return i < 0 ? 1 : i + 1;
}

- (void)stepChanged:(id)sender {
    (void)sender;
    if (!_kontaktMode || _kontaktPath == nil) return;
    std::vector<std::size_t> ticked;
    for (const InstrumentRow& r : _instruments) if (r.ticked) ticked.push_back(r.setIndex);
    const NSInteger rateIndex = _ratePopup.indexOfSelectedItem;
    [self loadKontaktPreview];
    for (InstrumentRow& r : _instruments) r.ticked = std::find(ticked.begin(), ticked.end(), r.setIndex) != ticked.end() ? YES : NO;
    if (rateIndex >= 0 && rateIndex < _ratePopup.numberOfItems) [_ratePopup selectItemAtIndex:rateIndex];
    [_previewTable reloadData];
    [self updateImportKey];
}

- (void)updateImportKey {
    NSUInteger files = 0U, instruments = 0U;
    double mb = 0.0;
    for (const FileRow& f : _files) if (f.ticked && ![f.name.pathExtension.lowercaseString isEqualToString:@"nki"]) ++files;
    for (const InstrumentRow& r : _instruments) if (r.ticked) { ++instruments; mb += r.megabytes; }
    const NSUInteger total = files + instruments;
    _importKey.title = total == 0U ? @"ВНЕСИ ИЗБРАНИТЕ" : [NSString stringWithFormat:@"ВНЕСИ ИЗБРАНИТЕ (%lu)", static_cast<unsigned long>(total)];
    _importKey.enabled = total > 0U;
    if (_kontaktMode && instruments > 0U) {
        _previewNote.stringValue = [NSString stringWithFormat:@"%lu инструмента · %.0f MB%@", static_cast<unsigned long>(instruments), mb,
                                    _waitingNki > 0U ? [NSString stringWithFormat:@" · още %lu .nki чакат", static_cast<unsigned long>(_waitingNki)] : @""];
    }
    [_importKey setNeedsDisplay:YES];
}

// ---------------------------------------------------------------- import

- (void)importPressed:(id)sender {
    (void)sender;
    NSMutableArray<NSString*>* paths = [NSMutableArray array];
    for (const FileRow& f : _files) if (f.ticked && ![f.name.pathExtension.lowercaseString isEqualToString:@"nki"]) [paths addObject:f.url.path];
    NSMutableArray<NSNumber*>* groups = [NSMutableArray array];
    double mb = 0.0;
    for (const InstrumentRow& r : _instruments) if (r.ticked && ![groups containsObject:@(r.setIndex)]) { [groups addObject:@(r.setIndex)]; mb += r.megabytes; }
    if (paths.count == 0U && groups.count == 0U) { SVFlash(@"ВНАСЯНЕ", @"Тикни поне един файл или инструмент.", YES); return; }
    if (mb > 3000.0 && !SVConfirm(self.window, @"Много семпли", [NSString stringWithFormat:@"Тикнатите инструменти са около %.0f MB. Паметта на Мака и на таблета може да не стигне. Внасяй по едно–две пиана.", mb], @"Внеси въпреки това")) return;
    SVManagerDocument* document = self.shell.documentModel;
    NSMutableArray<NSString*>* messages = [NSMutableArray array];
    BOOL any = NO;
    BOOL filesCame = NO;
    // SILVETON_PLACE_V1: the samples that were free before this import are not the new ones
    NSSet<NSNumber*>* looseBefore = [NSSet setWithArray:[document looseSampleIndexes]];
    if (paths.count > 0U) {
        NSString* details = nil;
        if (SVImportPathsWithProgress(document, paths, self.window, &details)) {
            any = YES;
            filesCame = YES;
            for (NSString* p in paths) [self.shell appendImportLog:[NSString stringWithFormat:@"✓  %@", p.lastPathComponent]];
        }
        if (details.length > 0U) [messages addObject:details];
    }
    if (groups.count > 0U && _kontaktPath != nil) {
        NSString* details = nil;
        NSUInteger rate = 0U;
        const NSInteger i = _ratePopup.indexOfSelectedItem;
        if (i >= 0 && static_cast<std::size_t>(i) < _rateValues.size()) rate = _rateValues[static_cast<std::size_t>(i)];
        NSArray<NSString*>* names = [self tickedInstrumentNames];
        if (SVImportKontaktSets(document, _kontaktPath, groups, rate, [self keyStep], self.window, &details)) {
            any = YES;
            for (NSString* n in names) [self.shell appendImportLog:[NSString stringWithFormat:@"✓  %@  (Kontakt, 5 слоя, %@)", n, [self keyStep] == 1 ? @"всеки клавиш" : [NSString stringWithFormat:@"1 семпъл на %ld клавиша", static_cast<long>([self keyStep])]]];
        }
        if (details.length > 0U) [messages addObject:details];
    }
    // SILVETON_FIND_V1: what was imported is unticked. Of the .nki only the one that was open is unticked (and only when
    // instruments of it were asked for); the other ticked .nki stay ticked, the next one opens on the right.
    NSString* openedNki = _kontaktPath;
    for (FileRow& f : _files) {
        if (!f.ticked) continue;
        if ([f.name.pathExtension.lowercaseString isEqualToString:@"nki"]) {
            if (groups.count > 0U && openedNki != nil && [f.url.path isEqualToString:openedNki]) f.ticked = NO;
        } else {
            f.ticked = NO;
        }
    }
    [_fileTable reloadData];
    [self previewChanged];
    [self.shell refreshAll];
    if (filesCame) [self placeNewLooseSamplesNotIn:looseBefore];
    if (messages.count > 0U) {
        for (NSString* m in messages) for (NSString* line in [m componentsSeparatedByString:@"\n"]) if (line.length > 0U) [self.shell appendImportLog:[NSString stringWithFormat:@"!  %@", line]];
        [self refresh];
        SVAlert(self.window, any ? @"Внесено с бележки" : @"Нищо не влезе", [messages componentsJoinedByString:@"\n"], !any);
    }
}

// SILVETON_PLACE_V1: a sample that comes in on its own (WAV, AIFF, NCW, KSF) carries nothing that says which key it belongs to.
// So after every import the NEW ones are listened to and laid over the keyboard by the note they are - always, not only when the key
// НАПРАВИ БЛЕНДА ОТ СЕМПЛИТЕ on СЕМПЛИ is pressed. The same review window opens: a wrong note is typed over by hand, single rows can be
// unticked. ОТКАЗ leaves the samples as they came in (a blend of one file each); the key on СЕМПЛИ can still do it later.
// Files that bring their own mapping (.kmp, .nki) are never touched: their samples already sit in real blends.
- (void)placeNewLooseSamplesNotIn:(NSSet<NSNumber*>*)before {
    SVManagerDocument* document = self.shell.documentModel;
    NSMutableArray<NSNumber*>* fresh = [NSMutableArray array];
    for (NSNumber* index in [document looseSampleIndexes]) if (![before containsObject:index]) [fresh addObject:index];
    if (fresh.count == 0U) return;
    NSArray<NSDictionary<NSString*, id>*>* rows = [document autoMapPlanForSampleIndexes:fresh];
    if (rows.count == 0U) {
        [self.shell appendImportLog:@"!  Не можах да прочета новите семпли, за да чуя тона им - остават по един."];
        return;
    }
    NSString* name = nil;
    BOOL dropOld = YES;
    NSArray<NSNumber*>* giveAway = @[];
    NSArray<NSDictionary<NSString*, id>*>* chosen = SVReviewAutoMap(self.window, document, rows, &name, &dropOld, &giveAway);
    if (chosen == nil || chosen.count == 0U) {
        [self.shell appendImportLog:@"!  Подреждането по клавиши е отказано - семплите остават по един. СЕМПЛИ → НАПРАВИ ЗВУК ОТ СЕМПЛИТЕ ги подрежда и по-късно."];
        return;
    }
    NSString* error = nil;
    NSUInteger created = 0U;
    NSUInteger removed = 0U;
    NSUInteger gone = 0U;
    double freed = 0.0;
    if (![document buildAutoMapWithRows:chosen name:name removeOldSingles:dropOld removeSamples:giveAway createdIndex:&created removedOldCount:&removed removedSampleCount:&gone freedBytes:&freed error:&error]) {
        SVAlert(self.window, @"Звук от семплите", error, YES);
        return;
    }
    NSString* blendName = name.length > 0U ? name : @"НОВ ЗВУК";
    [self.shell appendImportLog:[NSString stringWithFormat:@"✓  Звук „%@“ от %lu семпъла, подредени по тоновете им", blendName, static_cast<unsigned long>(chosen.count)]];
    // SILVETON_THIN_V1: only when it was chosen in the window
    NSString* extra = @"";
    if (gone > 0U) {
        extra = [NSString stringWithFormat:@" Излязоха от банката %lu семпъла, които съседният тон свири вместо тях (около %@ памет).", static_cast<unsigned long>(gone), SVMegabytes(freed)];
        [self.shell appendImportLog:[NSString stringWithFormat:@"✓  Махнати от банката: %lu семпъла (около %@), защото съседният тон ги свири", static_cast<unsigned long>(gone), SVMegabytes(freed)]];
    }
    [self.shell refreshAll];
    SVFlash(@"Звук от семплите", [NSString stringWithFormat:@"Готово: звук „%@“ от %lu семпъла.%@", blendName, static_cast<unsigned long>(chosen.count), extra], NO);
}

// SILVETON_KONTAKT_LISTEN_V1: a click on an instrument (not on its tick box) opens the listening window with its samples
- (void)previewClicked:(id)sender {
    (void)sender;
    if (!_kontaktMode || _lib == nullptr) return;
    const NSInteger row = _previewTable.clickedRow;
    const NSInteger column = _previewTable.clickedColumn;
    if (row < 0 || column < 0 || static_cast<std::size_t>(row) >= _instruments.size()) return;
    NSTableColumn* which = _previewTable.tableColumns[static_cast<NSUInteger>(column)];
    if ([which.identifier isEqualToString:@"on"]) return;       // the tick box only ticks
    const InstrumentRow& r = _instruments[static_cast<std::size_t>(row)];
    if (r.setIndex >= _sets.size()) return;
    if (_listen == nil) {
        __weak SVImportPage* weakSelf = self;
        _listen = [[SVKontaktListenPanel alloc] initWithPlayer:self.shell.audition rate:^unsigned { return [weakSelf selectedRate]; }];
    }
    [_listen showInstrument:r.name library:_lib set:_sets[r.setIndex]];
}

// the sample rate chosen under the list, 0 = as in the files
- (unsigned)selectedRate {
    const NSInteger i = _ratePopup.indexOfSelectedItem;
    return (i >= 0 && static_cast<std::size_t>(i) < _rateValues.size()) ? _rateValues[static_cast<std::size_t>(i)] : 0U;
}

- (void)pageWillHide { [_listen closeWindow]; }

- (NSArray<NSString*>*)tickedInstrumentNames {
    NSMutableArray<NSString*>* names = [NSMutableArray array];
    for (const InstrumentRow& r : _instruments) if (r.ticked) [names addObject:r.name];
    return names;
}

- (void)refresh {
    _log = [[self.shell importLog] copy];
    [_logTable reloadData];
    if (_log.count > 0U) [_logTable scrollRowToVisible:static_cast<NSInteger>(_log.count) - 1];
}

// ---------------------------------------------------------------- tables

- (NSInteger)numberOfRowsInTableView:(NSTableView*)tableView {
    if (tableView == _fileTable) return static_cast<NSInteger>(_files.size());
    if (tableView == _previewTable) {
        if (_kontaktMode) return static_cast<NSInteger>(_instruments.size());
        NSInteger n = 0;
        for (const FileRow& f : _files) if (f.ticked) ++n;
        return n;
    }
    return static_cast<NSInteger>(_log.count);
}

- (const FileRow*)tickedFileAt:(NSInteger)row {
    NSInteger n = 0;
    for (const FileRow& f : _files) { if (!f.ticked) continue; if (n == row) return &f; ++n; }
    return nullptr;
}

- (id)tableView:(NSTableView*)tableView objectValueForTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    NSString* ident = tableColumn.identifier;
    if (tableView == _fileTable) {
        if (row < 0 || static_cast<std::size_t>(row) >= _files.size()) return nil;
        const FileRow& f = _files[static_cast<std::size_t>(row)];
        if ([ident isEqualToString:@"on"]) return f.importable ? @(f.ticked ? 1 : 0) : nil;
        if ([ident isEqualToString:@"name"]) return f.name;
        if ([ident isEqualToString:@"folder"]) return f.folder ?: @"";
        return f.info;
    }
    if (tableView == _previewTable) {
        if (_kontaktMode) {
            if (row < 0 || static_cast<std::size_t>(row) >= _instruments.size()) return nil;
            const InstrumentRow& r = _instruments[static_cast<std::size_t>(row)];
            if ([ident isEqualToString:@"on"]) return @(r.ticked ? 1 : 0);
            if ([ident isEqualToString:@"name"]) return r.name;
            if ([ident isEqualToString:@"keys"]) return r.keys;
            if ([ident isEqualToString:@"layers"]) return r.layers;
            if ([ident isEqualToString:@"samples"]) return r.samples;
            return [NSString stringWithFormat:@"%.0f", r.megabytes];
        }
        const FileRow* f = [self tickedFileAt:row];
        if (f == nullptr) return nil;
        if ([ident isEqualToString:@"on"]) return @1;
        if ([ident isEqualToString:@"name"]) return f->name;
        if ([ident isEqualToString:@"keys"]) return kindText(f->name);
        return @"";
    }
    if (row < 0 || static_cast<NSUInteger>(row) >= _log.count) return nil;
    return _log[static_cast<NSUInteger>(row)];
}

- (void)tableView:(NSTableView*)tableView setObjectValue:(id)object forTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    if (![tableColumn.identifier isEqualToString:@"on"]) return;
    const BOOL on = [object integerValue] != 0 ? YES : NO;
    if (tableView == _fileTable) {
        if (row < 0 || static_cast<std::size_t>(row) >= _files.size()) return;
        FileRow& f = _files[static_cast<std::size_t>(row)];
        if (!f.importable) return;
        f.ticked = on;
        [self previewChanged];
    } else if (tableView == _previewTable && _kontaktMode) {
        if (row < 0 || static_cast<std::size_t>(row) >= _instruments.size()) return;
        _instruments[static_cast<std::size_t>(row)].ticked = on;
        [self updateImportKey];
    } else if (tableView == _previewTable) {
        const FileRow* f = [self tickedFileAt:row];
        if (f == nullptr) return;
        for (FileRow& g : _files) if (g.url == f->url) g.ticked = NO;
        [_fileTable reloadData];
        [self previewChanged];
    }
}

- (BOOL)tableView:(NSTableView*)tableView shouldSelectRow:(NSInteger)row {
    (void)tableView; (void)row;
    return tableView == _fileTable || (tableView == _previewTable && _kontaktMode);
}

// the tick box must work even though the row itself is not selected
- (BOOL)tableView:(NSTableView*)tableView shouldTrackCell:(NSCell*)cell forTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView; (void)cell; (void)tableColumn; (void)row;
    return YES;
}

- (void)tableView:(NSTableView*)tableView willDisplayCell:(id)cell forTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView; (void)tableColumn; (void)row;
    if ([cell isKindOfClass:[NSTextFieldCell class]]) {
        NSTextFieldCell* text = cell;
        BOOL folder = NO;
        if (tableView == _fileTable && row >= 0 && static_cast<std::size_t>(row) < _files.size()) folder = _files[static_cast<std::size_t>(row)].isFolder || _files[static_cast<std::size_t>(row)].isBack;
        if ([tableColumn.identifier isEqualToString:@"name"]) text.textColor = folder ? SVColMark() : SVColText();
    }
}
@end
