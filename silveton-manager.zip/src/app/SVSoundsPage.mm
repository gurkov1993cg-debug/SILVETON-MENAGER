// SILVETON_LOOK_V1 - page 3 БЛЕНДИ: the sounds of the bank, their velocity layers, the keyboard of a layer.
#import "SVShell.h"
#import "SVDocument.h"
#import "SVTheme.h"
#import "SVChooser.h"
#import "SVSamplerPage.h"

#include <algorithm>
#include <cmath>
#include <map>
#include <set>
#include <string>
#include <vector>

using silveton::manager::BankProject;

// ---------------------------------------------------------------- keyboard

@interface SVKeyboardView : NSView
@property(nonatomic, copy) NSArray<NSDictionary*>* zones;      // keyLow, keyHigh, velocityLow, velocityHigh
@property(nonatomic) NSInteger selectedKey;                       // -1 none
@property(nonatomic, copy) void (^onKey)(NSInteger key);
@end

@implementation SVKeyboardView
- (instancetype)initWithFrame:(NSRect)frame { self = [super initWithFrame:frame]; if (self) { _selectedKey = -1; } return self; }
- (BOOL)isFlipped { return YES; }
- (BOOL)isBlack:(NSInteger)midi { const NSInteger n = midi % 12; return n == 1 || n == 3 || n == 6 || n == 8 || n == 10; }
- (NSInteger)whiteIndexOf:(NSInteger)midi {   // number of white keys from A0 up to this key
    NSInteger count = 0;
    for (NSInteger k = 21; k < midi; ++k) if (![self isBlack:k]) ++count;
    return count;
}
- (CGFloat)whiteWidth { return (self.bounds.size.width - 8.0) / 52.0; }
- (NSRect)rectOfKey:(NSInteger)midi {
    const CGFloat w = [self whiteWidth];
    const CGFloat h = self.bounds.size.height - 8.0;
    if (![self isBlack:midi]) return NSMakeRect(4.0 + w * static_cast<CGFloat>([self whiteIndexOf:midi]), 4.0, w - 1.0, h);
    const CGFloat x = 4.0 + w * static_cast<CGFloat>([self whiteIndexOf:midi]) - w * 0.3;
    return NSMakeRect(x, 4.0, w * 0.6, h * 0.6);
}
- (NSColor*)zoneColorForKey:(NSInteger)midi {
    NSInteger hits = 0;
    for (NSDictionary* z in _zones) {
        if (midi >= [z[@"keyLow"] integerValue] && midi <= [z[@"keyHigh"] integerValue]) ++hits;
    }
    if (hits == 0) return nil;
    return hits == 1 ? SVColAmber() : SVColWarn();
}
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    [SVColField() setFill];
    NSRectFill(self.bounds);
    for (NSInteger k = 21; k <= 108; ++k) {
        if ([self isBlack:k]) continue;
        NSColor* zone = [self zoneColorForKey:k];
        [(zone ?: [NSColor colorWithCalibratedWhite:0.91 alpha:1.0]) setFill];
        NSRectFill([self rectOfKey:k]);
        if (k == _selectedKey) { [SVColGreen() setStroke]; [[NSBezierPath bezierPathWithRect:NSInsetRect([self rectOfKey:k], 0.5, 0.5)] stroke]; }
    }
    for (NSInteger k = 21; k <= 108; ++k) {
        if (![self isBlack:k]) continue;
        NSColor* zone = [self zoneColorForKey:k];
        [(zone != nil ? [zone shadowWithLevel:0.35] : [NSColor colorWithCalibratedWhite:0.08 alpha:1.0]) setFill];
        NSRectFill([self rectOfKey:k]);
        if (k == _selectedKey) { [SVColGreen() setStroke]; [[NSBezierPath bezierPathWithRect:NSInsetRect([self rectOfKey:k], 0.5, 0.5)] stroke]; }
    }
    NSDictionary* attrs = @{NSFontAttributeName: SVFont(9.0, NO), NSForegroundColorAttributeName: [NSColor colorWithCalibratedWhite:0.25 alpha:1.0]};
    for (NSInteger k = 24; k <= 108; k += 12) {
        const NSRect r = [self rectOfKey:k];
        [SVNoteName(k) drawAtPoint:NSMakePoint(r.origin.x + 2.0, NSMaxY(r) - 14.0) withAttributes:attrs];
    }
}
- (void)mouseDown:(NSEvent*)event {
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    NSInteger hit = -1;
    for (NSInteger k = 21; k <= 108 && hit < 0; ++k) if ([self isBlack:k] && NSPointInRect(p, [self rectOfKey:k])) hit = k;
    for (NSInteger k = 21; k <= 108 && hit < 0; ++k) if (![self isBlack:k] && NSPointInRect(p, [self rectOfKey:k])) hit = k;
    if (hit < 0) return;
    _selectedKey = hit;
    [self setNeedsDisplay:YES];
    if (_onKey != nil) _onKey(hit);
}
@end

// ---------------------------------------------------------------- page

@interface SVSoundsPage : SVPageView <NSTableViewDataSource, NSTableViewDelegate, NSMenuDelegate>
- (void)selectSoundIndex:(NSUInteger)index;
@end

@implementation SVSoundsPage {
    NSTableView* _soundTable;
    std::vector<NSUInteger> _soundOrder;        // sound indexes sorted by position
    NSTableView* _layerTable;
    NSArray<NSDictionary*>* _layers;
    NSUInteger _sound;                           // NSNotFound = none
    NSInteger _layer;                            // -1 none
    SVPanel* _layerPanel;
    SVPanel* _keysPanel;
    // layer strip
    SVToggle* _layerOn; NSTextField* _velLow; NSTextField* _velHigh; NSTextField* _level; NSTextField* _pan;
    // keyboard
    SVKeyboardView* _keys;
    NSArray<NSDictionary*>* _zones;
    NSPopUpButton* _zonePopup;
    std::vector<NSUInteger> _zonesAtKey;
    NSTextField* _zoneInfo;
    NSTextField* _zKeyLow; NSTextField* _zKeyHigh; NSTextField* _zRoot; NSTextField* _zVelLow; NSTextField* _zVelHigh;
    NSTextField* _zSampleLabel;
    NSUInteger _zoneSample;
}

- (instancetype)initWithShell:(SVShellWindowController*)shell frame:(NSRect)frame {
    self = [super initWithShell:shell frame:frame];
    if (self) { _sound = NSNotFound; _layer = -1; _layers = @[]; _zones = @[]; _zoneSample = NSNotFound; [self build]; }
    return self;
}

- (void)build {
    const NSRect b = self.bounds;
    // ---- sounds list
    SVPanel* left = [[SVPanel alloc] initWithFrame:NSMakeRect(16.0, 16.0, 330.0, b.size.height - 32.0) title:@"ЗВУЦИ В БАНКАТА"];
    left.autoresizingMask = NSViewHeightSizable;
    _soundTable = [[NSTableView alloc] initWithFrame:NSZeroRect];
    SVStyleTable(_soundTable);
    _soundTable.headerView = nil;
    _soundTable.dataSource = self;
    _soundTable.delegate = self;
    _soundTable.allowsMultipleSelection = YES;   // SILVETON_PASTE_V1: several sounds are copied at once
    NSMenu* copyMenu = [[NSMenu alloc] initWithTitle:@""];
    copyMenu.delegate = self;
    copyMenu.autoenablesItems = NO;
    _soundTable.menu = copyMenu;                  // right button: Копирай
    NSTableColumn* pos = SVTextColumn(@"pos", @"", 44.0);
    [(NSTextFieldCell*)pos.dataCell setTextColor:SVColDim()];
    [_soundTable addTableColumn:pos];
    [_soundTable addTableColumn:SVTextColumn(@"name", @"", 180.0)];
    NSTableColumn* layers = SVTextColumn(@"layers", @"", 70.0);
    [(NSTextFieldCell*)layers.dataCell setTextColor:SVColDim()];
    [(NSTextFieldCell*)layers.dataCell setAlignment:NSTextAlignmentRight];
    [_soundTable addTableColumn:layers];
    NSScrollView* scroll = SVScroll(NSMakeRect(12.0, 32.0, 306.0, left.bounds.size.height - 32.0 - 142.0), _soundTable);
    scroll.autoresizingMask = NSViewHeightSizable;
    [left addSubview:scroll];
    CGFloat by = left.bounds.size.height - 132.0;
    SVKeyButton* k1 = [SVKeyButton keyWithFrame:NSMakeRect(12.0, by, 100.0, 34.0) title:@"НОВА" kind:1 target:self action:@selector(newPressed:)];
    k1.autoresizingMask = NSViewMinYMargin; [left addSubview:k1];
    SVKeyButton* k2 = [SVKeyButton keyWithFrame:NSMakeRect(120.0, by, 110.0, 34.0) title:@"КОПИРАЙ" kind:0 target:self action:@selector(copyPressed:)];
    k2.autoresizingMask = NSViewMinYMargin; [left addSubview:k2];
    by += 42.0;
    SVKeyButton* k3 = [SVKeyButton keyWithFrame:NSMakeRect(12.0, by, 150.0, 34.0) title:@"ПРЕИМЕНУВАЙ" kind:0 target:self action:@selector(renamePressed:)];
    k3.autoresizingMask = NSViewMinYMargin; [left addSubview:k3];
    SVKeyButton* k4 = [SVKeyButton keyWithFrame:NSMakeRect(170.0, by, 100.0, 34.0) title:@"ИЗТРИЙ" kind:2 target:self action:@selector(deletePressed:)];
    k4.autoresizingMask = NSViewMinYMargin; [left addSubview:k4];
    by += 42.0;
    // SILVETON_UNUSED_SOUNDS_V1: the sounds no blend of the sampler uses go out in one press (after one question)
    SVKeyButton* k5 = [SVKeyButton keyWithFrame:NSMakeRect(12.0, by, 258.0, 34.0) title:@"ИЗТРИЙ НЕИЗПОЛЗВАНИТЕ ЗВУЦИ" kind:2 target:self action:@selector(deleteUnusedPressed:)];
    k5.autoresizingMask = NSViewMinYMargin;
    k5.toolTip = @"Трие звуците, които не са в нито една бленда на семплера (ЛИСТА, записаните сетове, отвореното КОМБИ). Първо пита.";
    [left addSubview:k5];
    [self addSubview:left];

    // ---- layers
    const CGFloat rx = 362.0;
    _layerPanel = [[SVPanel alloc] initWithFrame:NSMakeRect(rx, 16.0, b.size.width - rx - 16.0, 318.0) title:@"СЛОЕВЕ"];
    _layerPanel.autoresizingMask = NSViewWidthSizable;
    _layerTable = [[NSTableView alloc] initWithFrame:NSZeroRect];
    SVStyleTable(_layerTable);
    _layerTable.dataSource = self;
    _layerTable.delegate = self;
    [_layerTable addTableColumn:SVCheckColumn(@"on", 30.0)];
    [_layerTable addTableColumn:SVTextColumn(@"name", @"СЛОЙ", 260.0)];
    [_layerTable addTableColumn:SVTextColumn(@"vel", @"СИЛА НА УДАРА (1–127)", 150.0)];
    [_layerTable addTableColumn:SVTextColumn(@"level", @"НИВО", 80.0)];
    [_layerTable addTableColumn:SVTextColumn(@"pan", @"ПАН", 80.0)];
    [_layerTable addTableColumn:SVTextColumn(@"zones", @"СЕМПЛИ", 70.0)];
    NSScrollView* lscroll = SVScroll(NSMakeRect(12.0, 32.0, _layerPanel.bounds.size.width - 24.0, 170.0), _layerTable);
    lscroll.autoresizingMask = NSViewWidthSizable;
    [_layerPanel addSubview:lscroll];
    CGFloat y = 214.0;
    _layerOn = [[SVToggle alloc] initWithFrame:NSMakeRect(12.0, y + 2.0, 44.0, 22.0)];
    [_layerPanel addSubview:_layerOn];
    [_layerPanel addSubview:SVLabel(NSMakeRect(62.0, y + 4.0, 30.0, 18.0), @"ВКЛ", 11.0, NO, SVColDim())];
    [_layerPanel addSubview:SVLabel(NSMakeRect(104.0, y + 4.0, 50.0, 18.0), @"сила от", 11.0, NO, SVColDim())];
    _velLow = SVField(NSMakeRect(158.0, y, 52.0, 24.0), @"1"); [_layerPanel addSubview:_velLow];
    [_layerPanel addSubview:SVLabel(NSMakeRect(216.0, y + 4.0, 24.0, 18.0), @"до", 11.0, NO, SVColDim())];
    _velHigh = SVField(NSMakeRect(240.0, y, 52.0, 24.0), @"127"); [_layerPanel addSubview:_velHigh];
    [_layerPanel addSubview:SVLabel(NSMakeRect(306.0, y + 4.0, 52.0, 18.0), @"ниво dB", 11.0, NO, SVColDim())];
    _level = SVField(NSMakeRect(362.0, y, 60.0, 24.0), @"0.0"); [_layerPanel addSubview:_level];
    [_layerPanel addSubview:SVLabel(NSMakeRect(434.0, y + 4.0, 62.0, 18.0), @"пан −1…1", 11.0, NO, SVColDim())];
    _pan = SVField(NSMakeRect(500.0, y, 60.0, 24.0), @"0.0"); [_layerPanel addSubview:_pan];
    [_layerPanel addSubview:[SVKeyButton keyWithFrame:NSMakeRect(572.0, y - 5.0, 130.0, 34.0) title:@"ЗАПИШИ СЛОЯ" kind:1 target:self action:@selector(saveLayer:)]];
    y += 42.0;
    [_layerPanel addSubview:[SVKeyButton keyWithFrame:NSMakeRect(12.0, y, 220.0, 34.0) title:@"ДОБАВИ СЛОЙ ОТ СЕМПЛИ…" kind:0 target:self action:@selector(addLayerPressed:)]];
    [_layerPanel addSubview:[SVKeyButton keyWithFrame:NSMakeRect(240.0, y, 130.0, 34.0) title:@"МАХНИ СЛОЯ" kind:2 target:self action:@selector(removeLayerPressed:)]];
    [_layerPanel addSubview:SVLabel(NSMakeRect(380.0, y + 8.0, _layerPanel.bounds.size.width - 392.0, 18.0), @"Слоят свири при тази сила; зоните вътре може да имат свои по-тесни граници.", 11.0, NO, SVColDim())];
    [self addSubview:_layerPanel];

    // ---- keyboard
    const CGFloat ky = 16.0 + 318.0 + 16.0;
    _keysPanel = [[SVPanel alloc] initWithFrame:NSMakeRect(rx, ky, b.size.width - rx - 16.0, b.size.height - ky - 16.0) title:@"КЛАВИАТУРА"];
    _keysPanel.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    _keys = [[SVKeyboardView alloc] initWithFrame:NSMakeRect(12.0, 32.0, _keysPanel.bounds.size.width - 24.0, 78.0)];
    _keys.autoresizingMask = NSViewWidthSizable;
    __weak SVSoundsPage* weakSelf = self;
    _keys.onKey = ^(NSInteger key) { [weakSelf keyPressed:key]; };
    [_keysPanel addSubview:_keys];
    y = 118.0;
    _zoneInfo = SVLabel(NSMakeRect(12.0, y, _keysPanel.bounds.size.width - 24.0, 18.0), @"Цъкни клавиш – показва коя зона (кой семпъл) свири там.", 12.0, NO, SVColDim());
    _zoneInfo.autoresizingMask = NSViewWidthSizable;
    [_keysPanel addSubview:_zoneInfo];
    y += 28.0;
    _zonePopup = SVPopup(NSMakeRect(12.0, y - 2.0, 200.0, 26.0));
    _zonePopup.target = self; _zonePopup.action = @selector(zoneChosen:);
    [_keysPanel addSubview:_zonePopup];
    auto lab = [&](CGFloat x, NSString* t, CGFloat w) { [_keysPanel addSubview:SVLabel(NSMakeRect(x, y + 4.0, w, 18.0), t, 11.0, NO, SVColDim())]; };
    auto fld = [&](CGFloat x) { NSTextField* f = SVField(NSMakeRect(x, y, 52.0, 24.0), @""); [_keysPanel addSubview:f]; return f; };
    lab(224.0, @"нисък", 44.0); _zKeyLow = fld(268.0);
    lab(330.0, @"висок", 44.0); _zKeyHigh = fld(374.0);
    lab(436.0, @"основен", 56.0); _zRoot = fld(492.0);
    lab(554.0, @"сила от", 52.0); _zVelLow = fld(606.0);
    lab(668.0, @"до", 20.0); _zVelHigh = fld(690.0);
    y += 38.0;
    _zSampleLabel = SVLabel(NSMakeRect(12.0, y + 8.0, 360.0, 18.0), @"семпъл: –", 12.0, NO, SVColText());
    [_keysPanel addSubview:_zSampleLabel];
    [_keysPanel addSubview:[SVKeyButton keyWithFrame:NSMakeRect(380.0, y, 150.0, 34.0) title:@"СМЕНИ СЕМПЪЛА…" kind:0 target:self action:@selector(changeSamplePressed:)]];
    [_keysPanel addSubview:[SVKeyButton keyWithFrame:NSMakeRect(538.0, y, 100.0, 34.0) title:@"▶ ПУСНИ" kind:0 target:self action:@selector(playZonePressed:)]];
    [_keysPanel addSubview:[SVKeyButton keyWithFrame:NSMakeRect(646.0, y, 140.0, 34.0) title:@"ЗАПИШИ ЗОНАТА" kind:1 target:self action:@selector(saveZone:)]];
    y += 42.0;
    [_keysPanel addSubview:[SVKeyButton keyWithFrame:NSMakeRect(12.0, y, 190.0, 34.0) title:@"НОВА ЗОНА ОТ СЕМПЪЛ…" kind:0 target:self action:@selector(addZonePressed:)]];
    [_keysPanel addSubview:[SVKeyButton keyWithFrame:NSMakeRect(210.0, y, 140.0, 34.0) title:@"МАХНИ ЗОНАТА" kind:2 target:self action:@selector(removeZonePressed:)]];
    [self addSubview:_keysPanel];
}

// ---------------------------------------------------------------- data

- (void)refresh {
    SVManagerDocument* doc = self.shell.documentModel;
    BankProject* project = SVProjectOf(doc);
    _soundOrder.clear();
    if (project != nullptr) {
        for (std::size_t i = 0U; i < project->sounds.size(); ++i) _soundOrder.push_back(i);
        std::sort(_soundOrder.begin(), _soundOrder.end(), [&](NSUInteger a, NSUInteger c) { return project->sounds[a].position < project->sounds[c].position; });
    }
    [_soundTable reloadData];
    if (_sound != NSNotFound && _sound < [doc soundCount]) {
        for (std::size_t r = 0U; r < _soundOrder.size(); ++r) if (_soundOrder[r] == _sound) [_soundTable selectRowIndexes:[NSIndexSet indexSetWithIndex:r] byExtendingSelection:NO];
        [self loadSound:_sound keepLayer:YES];
    } else {
        _sound = NSNotFound;
        [self loadSound:NSNotFound keepLayer:NO];
    }
}

- (void)selectSoundIndex:(NSUInteger)index {
    _sound = index;
    _layer = -1;
    [self refresh];
}

- (void)loadSound:(NSUInteger)index keepLayer:(BOOL)keep {
    SVManagerDocument* doc = self.shell.documentModel;
    NSDictionary* st = index == NSNotFound ? nil : [doc soundStateAtIndex:index];
    if (st == nil) {
        _sound = NSNotFound; _layers = @[]; _layer = -1;
        _layerPanel.title = @"СЛОЕВЕ";
        [_layerTable reloadData];
        [self loadLayer:-1];
        return;
    }
    _sound = index;
    _layers = [doc soundLayerStatesAtIndex:index] ?: @[];
    _layerPanel.title = [NSString stringWithFormat:@"СЛОЕВЕ НА: %@   (така ще свири в семплера – по сила на удара)", st[@"name"]];
    [_layerTable reloadData];
    NSInteger layer = keep ? _layer : -1;
    if (layer < 0 || static_cast<NSUInteger>(layer) >= _layers.count) layer = _layers.count > 0U ? 0 : -1;
    if (layer >= 0) [_layerTable selectRowIndexes:[NSIndexSet indexSetWithIndex:static_cast<NSUInteger>(layer)] byExtendingSelection:NO];
    [self loadLayer:layer];
}

- (void)loadLayer:(NSInteger)layer {
    _layer = layer;
    _zones = @[];
    _zonesAtKey.clear();
    [_zonePopup removeAllItems];
    _zoneSample = NSNotFound;
    _keys.selectedKey = -1;
    if (layer < 0 || static_cast<NSUInteger>(layer) >= _layers.count) {
        _keysPanel.title = @"КЛАВИАТУРА";
        _keys.zones = @[];
        [_keys setNeedsDisplay:YES];
        _layerOn.on = NO; _velLow.stringValue = @""; _velHigh.stringValue = @""; _level.stringValue = @""; _pan.stringValue = @"";
        [self showZone:NSNotFound];
        return;
    }
    NSDictionary* l = _layers[static_cast<NSUInteger>(layer)];
    _layerOn.on = [l[@"enabled"] boolValue];
    _velLow.stringValue = [l[@"velocityLow"] stringValue];
    _velHigh.stringValue = [l[@"velocityHigh"] stringValue];
    _level.stringValue = [NSString stringWithFormat:@"%.1f", [l[@"levelDb"] doubleValue]];
    _pan.stringValue = [NSString stringWithFormat:@"%.2f", [l[@"pan"] doubleValue]];
    _keysPanel.title = [NSString stringWithFormat:@"КЛАВИАТУРА НА СЛОЙ V%ld   (цъкни клавиш – показва кой семпъл свири там)", static_cast<long>(layer + 1)];
    _zones = [self.shell.documentModel zoneStatesForMultisampleAtIndex:[l[@"multisampleIndex"] unsignedIntegerValue]] ?: @[];
    _keys.zones = _zones;
    [_keys setNeedsDisplay:YES];
    [self showZone:NSNotFound];
}

- (void)keyPressed:(NSInteger)key {
    _zonesAtKey.clear();
    [_zonePopup removeAllItems];
    for (NSUInteger i = 0U; i < _zones.count; ++i) {
        NSDictionary* z = _zones[i];
        if (key >= [z[@"keyLow"] integerValue] && key <= [z[@"keyHigh"] integerValue]) {
            _zonesAtKey.push_back(i);
            [_zonePopup addItemWithTitle:[NSString stringWithFormat:@"зона %lu · сила %@–%@", static_cast<unsigned long>(i + 1U), z[@"velocityLow"], z[@"velocityHigh"]]];
        }
    }
    if (_zonesAtKey.empty()) {
        _zoneInfo.stringValue = [NSString stringWithFormat:@"Клавиш %@ (%ld): никоя зона на този слой не свири тук.", SVNoteName(key), static_cast<long>(key)];
        [self showZone:NSNotFound];
        return;
    }
    [_zonePopup selectItemAtIndex:0];
    [self showZone:_zonesAtKey.front()];
}

- (void)zoneChosen:(id)sender {
    (void)sender;
    const NSInteger i = _zonePopup.indexOfSelectedItem;
    if (i >= 0 && static_cast<std::size_t>(i) < _zonesAtKey.size()) [self showZone:_zonesAtKey[static_cast<std::size_t>(i)]];
}

- (NSUInteger)currentZone {
    const NSInteger i = _zonePopup.indexOfSelectedItem;
    if (i >= 0 && static_cast<std::size_t>(i) < _zonesAtKey.size()) return _zonesAtKey[static_cast<std::size_t>(i)];
    return NSNotFound;
}

- (void)showZone:(NSUInteger)zoneIndex {
    if (zoneIndex == NSNotFound || zoneIndex >= _zones.count) {
        _zKeyLow.stringValue = @""; _zKeyHigh.stringValue = @""; _zRoot.stringValue = @""; _zVelLow.stringValue = @""; _zVelHigh.stringValue = @"";
        _zSampleLabel.stringValue = @"семпъл: –";
        _zoneSample = NSNotFound;
        if (_keys.selectedKey < 0) _zoneInfo.stringValue = @"Цъкни клавиш – показва коя зона (кой семпъл) свири там.";
        return;
    }
    NSDictionary* z = _zones[zoneIndex];
    _zKeyLow.stringValue = [z[@"keyLow"] stringValue];
    _zKeyHigh.stringValue = [z[@"keyHigh"] stringValue];
    _zRoot.stringValue = [z[@"rootKey"] stringValue];
    _zVelLow.stringValue = [z[@"velocityLow"] stringValue];
    _zVelHigh.stringValue = [z[@"velocityHigh"] stringValue];
    _zoneSample = [z[@"sampleIndex"] unsignedIntegerValue];
    _zSampleLabel.stringValue = [NSString stringWithFormat:@"семпъл: %@", z[@"sampleName"]];
    _zoneInfo.stringValue = [NSString stringWithFormat:@"Клавиш %@ (%ld) → %@ · основен тон %@ · зона %@–%@ · сила %@–%@ · ниво %.1f dB",
                             SVNoteName(_keys.selectedKey), static_cast<long>(_keys.selectedKey), z[@"sampleName"], SVNoteName([z[@"rootKey"] integerValue]),
                             SVNoteName([z[@"keyLow"] integerValue]), SVNoteName([z[@"keyHigh"] integerValue]), z[@"velocityLow"], z[@"velocityHigh"], [z[@"gainDb"] doubleValue]];
}

// ---------------------------------------------------------------- tables

- (NSInteger)numberOfRowsInTableView:(NSTableView*)tableView {
    if (tableView == _soundTable) return static_cast<NSInteger>(_soundOrder.size()) + 1;
    return static_cast<NSInteger>(_layers.count);
}

- (id)tableView:(NSTableView*)tableView objectValueForTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    NSString* ident = tableColumn.identifier;
    if (tableView == _soundTable) {
        if (row < 0) return nil;
        if (static_cast<std::size_t>(row) >= _soundOrder.size()) {
            if ([ident isEqualToString:@"name"]) return @"… до 500 звука";
            return @"";
        }
        NSDictionary* st = [self.shell.documentModel soundStateAtIndex:_soundOrder[static_cast<std::size_t>(row)]];
        if ([ident isEqualToString:@"pos"]) return [NSString stringWithFormat:@"%03d", [st[@"position"] intValue]];
        if ([ident isEqualToString:@"name"]) return st[@"name"];
        return [NSString stringWithFormat:@"%@ слоя", st[@"layerCount"]];
    }
    if (row < 0 || static_cast<NSUInteger>(row) >= _layers.count) return nil;
    NSDictionary* l = _layers[static_cast<NSUInteger>(row)];
    if ([ident isEqualToString:@"on"]) return @([l[@"enabled"] boolValue] ? 1 : 0);
    if ([ident isEqualToString:@"name"]) return [NSString stringWithFormat:@"V%ld  %@", static_cast<long>(row + 1), l[@"multisampleName"]];
    if ([ident isEqualToString:@"vel"]) return [NSString stringWithFormat:@"%@ – %@", l[@"velocityLow"], l[@"velocityHigh"]];
    if ([ident isEqualToString:@"level"]) return [NSString stringWithFormat:@"%.1f dB", [l[@"levelDb"] doubleValue]];
    if ([ident isEqualToString:@"pan"]) { const double p = [l[@"pan"] doubleValue]; return std::fabs(p) < 0.01 ? @"център" : [NSString stringWithFormat:@"%+.2f", p]; }
    return [l[@"zoneCount"] stringValue];
}

- (void)tableView:(NSTableView*)tableView setObjectValue:(id)object forTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    if (tableView != _layerTable || ![tableColumn.identifier isEqualToString:@"on"]) return;
    if (_sound == NSNotFound || row < 0 || static_cast<NSUInteger>(row) >= _layers.count) return;
    NSDictionary* l = _layers[static_cast<NSUInteger>(row)];
    NSString* error = nil;
    if (![self.shell.documentModel updateSoundLayerAtIndex:_sound layerIndex:static_cast<NSUInteger>(row) multisampleIndex:[l[@"multisampleIndex"] unsignedIntegerValue]
                                                   enabled:[object integerValue] != 0 keyLow:[l[@"keyLow"] unsignedIntegerValue] keyHigh:[l[@"keyHigh"] unsignedIntegerValue]
                                               velocityLow:[l[@"velocityLow"] unsignedIntegerValue] velocityHigh:[l[@"velocityHigh"] unsignedIntegerValue]
                                        transposeSemitones:[l[@"transposeSemitones"] integerValue] tuneCents:[l[@"tuneCents"] floatValue] levelDb:[l[@"levelDb"] floatValue]
                                                       pan:[l[@"pan"] floatValue] error:&error]) { SVAlert(self.window, @"Слой", error, YES); return; }
    [self.shell.documentModel markCurrentStateChanged];
    [self.shell refreshAll];
}

- (void)tableViewSelectionDidChange:(NSNotification*)notification {
    NSTableView* table = notification.object;
    if (table == _soundTable) {
        const NSInteger row = _soundTable.selectedRow;
        if (row < 0 || static_cast<std::size_t>(row) >= _soundOrder.size()) { [self loadSound:NSNotFound keepLayer:NO]; return; }
        _layer = -1;
        [self loadSound:_soundOrder[static_cast<std::size_t>(row)] keepLayer:NO];
    } else if (table == _layerTable) {
        [self loadLayer:_layerTable.selectedRow];
    }
}

- (BOOL)tableView:(NSTableView*)tableView shouldSelectRow:(NSInteger)row {
    if (tableView == _soundTable) return static_cast<std::size_t>(row) < _soundOrder.size();
    return YES;
}

// the tick box must work even though the row itself is not selected
- (BOOL)tableView:(NSTableView*)tableView shouldTrackCell:(NSCell*)cell forTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView; (void)cell; (void)tableColumn; (void)row;
    return YES;
}

// ---------------------------------------------------------------- sound keys

- (BOOL)requireSound {
    if (_sound != NSNotFound) return YES;
    SVFlash(@"Звуци", @"Първо избери звук отляво.", NO);
    return NO;
}

- (NSArray<NSString*>*)multisampleNames {
    NSMutableArray<NSString*>* names = [NSMutableArray array];
    SVManagerDocument* doc = self.shell.documentModel;
    for (NSUInteger i = 0U; i < [doc multisampleCount]; ++i) {
        NSDictionary* m = [doc multisampleStateAtIndex:i];
        [names addObject:[NSString stringWithFormat:@"%@   ·   %@ семпла", m[@"name"], m[@"zoneCount"]]];
    }
    return names;
}

- (NSArray<NSString*>*)sampleNames {
    NSMutableArray<NSString*>* names = [NSMutableArray array];
    SVManagerDocument* doc = self.shell.documentModel;
    for (NSUInteger i = 0U; i < [doc sampleCount]; ++i) {
        NSDictionary* s = [doc sampleStateAtIndex:i];
        [names addObject:[NSString stringWithFormat:@"%@   ·   %@", s[@"name"], SVNoteName([s[@"rootKey"] integerValue])]];
    }
    return names;
}

- (void)newPressed:(id)sender {
    (void)sender;
    SVManagerDocument* doc = self.shell.documentModel;
    if ([doc multisampleCount] == 0U) { SVFlash(@"Нов звук", @"Няма семпли. Първо внеси нещо (СЕМПЛИ → ВНАСЯНЕ ОТ ДИСКА).", YES); return; }
    const NSInteger ms = SVChooseFromList(self.window, @"Нов звук – от кой набор семпли?", @"Звукът започва с един слой; после добавяш още.", [self multisampleNames], 0);
    if (ms < 0) return;
    NSDictionary* m = [doc multisampleStateAtIndex:static_cast<NSUInteger>(ms)];
    NSString* name = SVAskText(self.window, @"Име на новия звук", @"", m[@"name"]);
    if (name.length == 0U) return;
    NSString* error = nil; NSUInteger created = 0U;
    if (![doc createSoundFromMultisampleIndex:static_cast<NSUInteger>(ms) name:name createdIndex:&created error:&error]) { SVAlert(self.window, @"Нов звук", error, YES); return; }
    [doc markCurrentStateChanged];
    _sound = created; _layer = -1;
    [self.shell refreshAll];
}

- (void)copyPressed:(id)sender {
    (void)sender;
    if (![self requireSound]) return;
    NSString* error = nil; NSUInteger created = 0U;
    if (![self.shell.documentModel duplicateObjectKind:2 index:_sound createdIndex:&created error:&error]) { SVAlert(self.window, @"Копиране", error, YES); return; }
    [self.shell.documentModel markCurrentStateChanged];
    _sound = created; _layer = -1;
    [self.shell refreshAll];
}

- (void)renamePressed:(id)sender {
    (void)sender;
    if (![self requireSound]) return;
    NSDictionary* st = [self.shell.documentModel soundStateAtIndex:_sound];
    NSString* name = SVAskText(self.window, @"Ново име на звука", @"", st[@"name"]);
    if (name.length == 0U) return;
    NSString* error = nil;
    if (![self.shell.documentModel renameObjectKind:2 index:_sound name:name error:&error]) { SVAlert(self.window, @"Преименуване", error, YES); return; }
    [self.shell.documentModel markCurrentStateChanged];
    [self.shell refreshAll];
}

- (void)deletePressed:(id)sender {
    (void)sender;
    if (![self requireSound]) return;
    NSDictionary* st = [self.shell.documentModel soundStateAtIndex:_sound];
    if (!SVConfirm(self.window, @"Изтриване на звук", [NSString stringWithFormat:@"„%@“ ще бъде махнат от банката. Семплите остават в проекта. Сигурен ли си?", st[@"name"]], @"Изтрий")) return;
    NSString* error = nil; NSString* summary = nil;
    if (![self.shell.documentModel deleteObjectKind:2 index:_sound summary:&summary error:&error]) { SVAlert(self.window, @"Изтриване", error, YES); return; }
    [self.shell.documentModel markCurrentStateChanged];
    _sound = NSNotFound; _layer = -1;
    [self.shell refreshAll];
}

// SILVETON_UNUSED_SOUNDS_V1: which sounds the blends of the sampler use is asked from the sampler (page СЕМПЛЕР); the rest can go.
- (void)deleteUnusedPressed:(id)sender {
    (void)sender;
    SVManagerDocument* doc = self.shell.documentModel;
    BankProject* project = SVProjectOf(doc);
    if (project == nullptr || project->sounds.empty()) { SVFlash(@"Неизползвани звуци", @"Още няма звуци в проекта.", NO); return; }
    // SILVETON_SEND_V1: the blends live in the sampler, so the question is asked about the sampler's sounds; a sound of the Manager is
    // used when its sent copy is used (or, never sent, when a used sound of the sampler has its name - e.g. a bank written before)
    SVSamplerHost* host = [SVSamplerHost shared];
    const auto samplerSounds = [host samplerSounds];
    std::set<int> usedPlaces;
    std::string why;
    if (![host usedSoundPositions:samplerSounds used:usedPlaces why:why]) { SVAlert(self.window, @"Неизползвани звуци", SVNs(why), NO); return; }
    std::set<std::string> usedNames;
    for (const auto& s : samplerSounds) if (usedPlaces.count(s.first) != 0U) usedNames.insert(s.second);
    std::map<std::string, int> sentPlace;
    for (const auto& s : [host sentSounds]) sentPlace[s.managerName] = s.place;
    std::vector<NSUInteger> unused;
    std::set<std::string> unusedNames;
    NSMutableArray<NSString*>* names = [NSMutableArray array];
    for (std::size_t i = 0U; i < project->sounds.size(); ++i) {
        const auto& name = project->sounds[i].name;
        const auto sent = sentPlace.find(name);
        const bool isUsed = sent != sentPlace.end() ? usedPlaces.count(sent->second) != 0U : usedNames.count(name) != 0U;
        if (isUsed) continue;
        unused.push_back(static_cast<NSUInteger>(i));
        unusedNames.insert(name);
        if (names.count < 25U) [names addObject:SVNs(name)];
    }
    if (unused.empty()) { SVFlash(@"Неизползвани звуци", @"Всички звуци се ползват в бленди - няма какво да се трие.", NO); return; }
    NSString* list = [names componentsJoinedByString:@", "];
    if (unused.size() > names.count) list = [list stringByAppendingString:@" …"];
    NSString* text = [NSString stringWithFormat:@"%lu от %lu звука не са в нито една бленда (ЛИСТА, записаните сетове, отвореното КОМБИ):\n\n%@\n\nТе излизат от проекта заедно със семплите, които ползват само те, а пратените в семплера няма да влязат в банката за таблета. Това не може да се върне. Сигурен ли си?",
                      static_cast<unsigned long>(unused.size()), static_cast<unsigned long>(project->sounds.size()), list];
    if (!SVConfirm(self.window, @"Изтриване на неизползваните звуци", text, @"Изтрий")) return;
    [self.shell.audition stop];
    // from the last to the first, so the numbers of the ones still waiting do not move
    std::sort(unused.begin(), unused.end(), [](NSUInteger a, NSUInteger b) { return a > b; });
    NSUInteger done = 0U;
    for (const NSUInteger index : unused) {
        NSString* error = nil;
        NSString* summary = nil;
        if (![doc deleteObjectKind:3 index:index summary:&summary error:&error]) { SVAlert(self.window, @"Изтриване", error, YES); break; }
        ++done;
    }
    std::set<std::string> gone = unusedNames;   // the ones still in the project were not deleted (an error stopped the loop)
    for (const auto& snd : project->sounds) gone.erase(snd.name);
    [host dropSentManagerNames:gone];
    _sound = NSNotFound;
    _layer = -1;
    [self.shell refreshAll];
    SVFlash(@"Неизползвани звуци", [NSString stringWithFormat:@"Изтрити: %lu звука. Няма да влязат в банката за таблета.", static_cast<unsigned long>(done)], NO);
}

// ---------------------------------------------------------------- SILVETON_PASTE_V1: Копирай (Cmd+C), then Постави (Cmd+V) in the sampler's LIST

// the marked rows; a right click on a row that is not marked copies only that row
- (std::vector<NSUInteger>)soundsToCopy:(NSInteger)clickedRow {
    NSIndexSet* rows = _soundTable.selectedRowIndexes;
    if (clickedRow >= 0 && ![rows containsIndex:static_cast<NSUInteger>(clickedRow)]) rows = [NSIndexSet indexSetWithIndex:static_cast<NSUInteger>(clickedRow)];
    std::vector<NSUInteger> out;
    for (NSUInteger row = rows.firstIndex; row != NSNotFound; row = [rows indexGreaterThanIndex:row]) {
        if (row < _soundOrder.size()) out.push_back(_soundOrder[row]);
    }
    return out;
}

- (void)menuNeedsUpdate:(NSMenu*)menu {
    [menu removeAllItems];
    const std::size_t count = [self soundsToCopy:_soundTable.clickedRow].size();
    if (count == 0U) return;
    NSString* title = count == 1U ? @"Копирай" : [NSString stringWithFormat:@"Копирай (%lu звука)", static_cast<unsigned long>(count)];
    NSMenuItem* item = [[NSMenuItem alloc] initWithTitle:title action:@selector(copyMenuChosen:) keyEquivalent:@""];
    item.target = self;
    item.tag = _soundTable.clickedRow;
    [menu addItem:item];
}

- (void)copyMenuChosen:(NSMenuItem*)item { [self copySounds:[self soundsToCopy:item.tag]]; }

// Cmd+C (menu Редакция > Копирай) while the list of sounds is in front
- (void)copy:(id)sender {
    (void)sender;
    [self copySounds:[self soundsToCopy:-1]];
}

- (BOOL)validateMenuItem:(NSMenuItem*)item {
    if (item.action == @selector(copy:)) return _soundTable.selectedRowIndexes.count > 0U;
    return YES;
}

- (void)copySounds:(const std::vector<NSUInteger>&)indexes {
    BankProject* project = SVProjectOf(self.shell.documentModel);
    NSMutableArray<NSString*>* names = [NSMutableArray array];
    if (project != nullptr) {
        for (const NSUInteger i : indexes) if (i < project->sounds.size()) [names addObject:SVNs(project->sounds[i].name)];
    }
    if (names.count == 0U) { SVFlash(@"Копирай", @"Маркирай звук отляво (за няколко: Cmd или Shift + клик).", YES); return; }
    [SVSamplerHost shared].copiedSounds = names;
    SVFlash(@"Копирай", [NSString stringWithFormat:@"Копирани: %lu звука. Иди на СЕМПЛЕР → ЛИСТ, десен бутон на реда, от който да почнат → ПОСТАВИ.", static_cast<unsigned long>(names.count)], NO);
}

// ---------------------------------------------------------------- layer keys

- (void)saveLayer:(id)sender {
    (void)sender;
    if (![self requireSound]) return;
    if (_layer < 0 || static_cast<NSUInteger>(_layer) >= _layers.count) { SVFlash(@"Слой", @"Избери слой в таблицата.", YES); return; }
    NSDictionary* l = _layers[static_cast<NSUInteger>(_layer)];
    const NSInteger lo = _velLow.integerValue, hi = _velHigh.integerValue;
    if (lo < 1 || hi > 127 || lo > hi) { SVFlash(@"Слой", @"Силата е от 1 до 127, „от“ не може да е над „до“.", YES); return; }
    const double pan = _pan.doubleValue;
    if (pan < -1.0 || pan > 1.0) { SVFlash(@"Слой", @"Панорамата е от −1 (ляво) до +1 (дясно).", YES); return; }
    NSString* error = nil;
    if (![self.shell.documentModel updateSoundLayerAtIndex:_sound layerIndex:static_cast<NSUInteger>(_layer) multisampleIndex:[l[@"multisampleIndex"] unsignedIntegerValue]
                                                   enabled:_layerOn.on keyLow:[l[@"keyLow"] unsignedIntegerValue] keyHigh:[l[@"keyHigh"] unsignedIntegerValue]
                                               velocityLow:static_cast<NSUInteger>(lo) velocityHigh:static_cast<NSUInteger>(hi)
                                        transposeSemitones:[l[@"transposeSemitones"] integerValue] tuneCents:[l[@"tuneCents"] floatValue]
                                                   levelDb:static_cast<float>(_level.doubleValue) pan:static_cast<float>(pan) error:&error]) { SVAlert(self.window, @"Слой", error, YES); return; }
    [self.shell.documentModel markCurrentStateChanged];
    [self.shell refreshAll];
}

- (void)addLayerPressed:(id)sender {
    (void)sender;
    if (![self requireSound]) return;
    SVManagerDocument* doc = self.shell.documentModel;
    if ([doc multisampleCount] == 0U) { SVFlash(@"Слой", @"Няма набори семпли. Първо внеси нещо.", YES); return; }
    const NSInteger ms = SVChooseFromList(self.window, @"Кой набор семпли става слой?", @"Всеки внесен KMP / Kontakt слой е набор семпли (мултисемпъл).", [self multisampleNames], 0);
    if (ms < 0) return;
    NSString* error = nil;
    if (![doc addSoundLayerAtIndex:_sound multisampleIndex:static_cast<NSUInteger>(ms) error:&error]) { SVAlert(self.window, @"Слой", error, YES); return; }
    [doc markCurrentStateChanged];
    _layer = static_cast<NSInteger>(_layers.count);
    [self.shell refreshAll];
}

- (void)removeLayerPressed:(id)sender {
    (void)sender;
    if (![self requireSound]) return;
    if (_layer < 0 || static_cast<NSUInteger>(_layer) >= _layers.count) { SVFlash(@"Слой", @"Избери слой в таблицата.", YES); return; }
    if (!SVConfirm(self.window, @"Махане на слой", @"Слоят се маха от звука. Семплите му остават в проекта.", @"Махни")) return;
    NSString* error = nil;
    if (![self.shell.documentModel removeSoundLayerAtIndex:_sound layerIndex:static_cast<NSUInteger>(_layer) error:&error]) { SVAlert(self.window, @"Слой", error, YES); return; }
    [self.shell.documentModel markCurrentStateChanged];
    _layer = -1;
    [self.shell refreshAll];
}

// ---------------------------------------------------------------- zone keys

- (NSUInteger)currentMultisample {
    if (_layer < 0 || static_cast<NSUInteger>(_layer) >= _layers.count) return NSNotFound;
    return [_layers[static_cast<NSUInteger>(_layer)][@"multisampleIndex"] unsignedIntegerValue];
}

- (void)saveZone:(id)sender {
    (void)sender;
    const NSUInteger zi = [self currentZone];
    const NSUInteger ms = [self currentMultisample];
    if (zi == NSNotFound || ms == NSNotFound) { SVFlash(@"Зона", @"Първо цъкни клавиш, за да избереш зона.", YES); return; }
    NSDictionary* z = _zones[zi];
    const NSInteger kl = _zKeyLow.integerValue, kh = _zKeyHigh.integerValue, root = _zRoot.integerValue, vl = _zVelLow.integerValue, vh = _zVelHigh.integerValue;
    if (kl < 0 || kh > 127 || kl > kh || root < 0 || root > 127) { SVFlash(@"Зона", @"Клавишите са от 0 до 127, нисък ≤ висок.", YES); return; }
    if (vl < 1 || vh > 127 || vl > vh) { SVFlash(@"Зона", @"Силата е от 1 до 127, „от“ ≤ „до“.", YES); return; }
    NSString* error = nil;
    if (![self.shell.documentModel updateZoneAtMultisampleIndex:ms zoneIndex:zi sampleIndex:_zoneSample keyLow:static_cast<NSUInteger>(kl) keyHigh:static_cast<NSUInteger>(kh)
                                                     velocityLow:static_cast<NSUInteger>(vl) velocityHigh:static_cast<NSUInteger>(vh) rootKey:static_cast<NSUInteger>(root)
                                              transposeSemitones:[z[@"transposeSemitones"] integerValue] tuneCents:[z[@"tuneCents"] floatValue] gainDb:[z[@"gainDb"] floatValue]
                                                             pan:[z[@"pan"] floatValue] error:&error]) { SVAlert(self.window, @"Зона", error, YES); return; }
    [self.shell.documentModel markCurrentStateChanged];
    const NSInteger key = _keys.selectedKey;
    [self.shell refreshAll];
    if (key >= 0) { _keys.selectedKey = key; [_keys setNeedsDisplay:YES]; [self keyPressed:key]; }
}

- (void)changeSamplePressed:(id)sender {
    (void)sender;
    if ([self currentZone] == NSNotFound) { SVFlash(@"Зона", @"Първо цъкни клавиш, за да избереш зона.", YES); return; }
    const NSInteger s = SVChooseFromList(self.window, @"Кой семпъл да свири в тази зона?", @"Запиши зоната след това със ЗАПИШИ ЗОНАТА.", [self sampleNames], _zoneSample == NSNotFound ? -1 : static_cast<NSInteger>(_zoneSample));
    if (s < 0) return;
    _zoneSample = static_cast<NSUInteger>(s);
    _zSampleLabel.stringValue = [NSString stringWithFormat:@"семпъл: %@ (незаписано)", [self.shell.documentModel sampleStateAtIndex:_zoneSample][@"name"]];
}

- (void)playZonePressed:(id)sender {
    (void)sender;
    if (_zoneSample == NSNotFound) { SVFlash(@"Пускане", @"Първо цъкни клавиш, за да избереш зона.", YES); return; }
    NSString* error = nil;
    NSDictionary* state = [self.shell.documentModel auditionStateAtIndex:_zoneSample error:&error];
    if (state == nil || ![self.shell.audition playState:state loopOnly:NO error:&error]) SVAlert(self.window, @"Пускане", error, YES);
}

- (void)addZonePressed:(id)sender {
    (void)sender;
    const NSUInteger ms = [self currentMultisample];
    if (ms == NSNotFound) { SVFlash(@"Зона", @"Избери слой в таблицата.", YES); return; }
    const NSInteger s = SVChooseFromList(self.window, @"Кой семпъл влиза в новата зона?", @"Зоната се създава на основния тон на семпъла; после я разширяваш и записваш.", [self sampleNames], 0);
    if (s < 0) return;
    NSString* error = nil;
    if (![self.shell.documentModel addZoneToMultisampleAtIndex:ms sampleIndex:static_cast<NSUInteger>(s) error:&error]) { SVAlert(self.window, @"Зона", error, YES); return; }
    [self.shell.documentModel markCurrentStateChanged];
    [self.shell refreshAll];
}

- (void)removeZonePressed:(id)sender {
    (void)sender;
    const NSUInteger zi = [self currentZone];
    const NSUInteger ms = [self currentMultisample];
    if (zi == NSNotFound || ms == NSNotFound) { SVFlash(@"Зона", @"Първо цъкни клавиш, за да избереш зона.", YES); return; }
    if (!SVConfirm(self.window, @"Махане на зона", @"Зоната се маха от слоя. Семпълът остава в проекта.", @"Махни")) return;
    NSString* error = nil;
    if (![self.shell.documentModel removeZoneFromMultisampleAtIndex:ms zoneIndex:zi error:&error]) { SVAlert(self.window, @"Зона", error, YES); return; }
    [self.shell.documentModel markCurrentStateChanged];
    [self.shell refreshAll];
}

- (void)pageWillHide { [self.shell.audition stop]; }
@end
