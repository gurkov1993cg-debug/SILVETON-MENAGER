// SILVETON_LOOK_V1 - page 5 БАНКА: what is inside, save, load, update a client's bank.
#import "SVShell.h"
#import "SVDocument.h"
#import "SVTheme.h"
#import "SVProgress.h"

#include "silveton/manager/SvBankBuilder.h"
#include "silveton/manager/SvBankReader.h"

#include <algorithm>
#include <limits>
#include <set>
#include <string>
#include <vector>

using silveton::manager::BankProject;
using silveton::manager::SvBankBuilder;
using silveton::manager::SvBankReader;
using silveton::manager::SvBuildStats;
using silveton::manager::kMaxSoundPosition;
using silveton::manager::kMinSoundPosition;

@interface SVProgressPanel : NSObject
- (instancetype)initWithTitle:(NSString*)title;
- (void)setFraction:(double)fraction text:(NSString*)text;
- (BOOL)stopRequested;
- (void)runWork:(void (^)(SVProgressPanel* progress))work;
@end

namespace {
NSString* const kPrefClientBank = @"SVClientBankPath";

// Adds every SOUND of `ours` (with its multisamples and samples) to `client`. SOUNDs whose name already exists are skipped.
bool mergeInto(BankProject& client, const BankProject& ours, std::size_t& added, std::size_t& skipped, std::string& error) {
    added = 0U; skipped = 0U;
    std::uint32_t sampleId = 0U, msId = 0U;
    for (const auto& s : client.samples) sampleId = std::max(sampleId, s.sampleId);
    for (const auto& m : client.multisamples) msId = std::max(msId, m.multisampleId);
    const std::uint32_t sampleBase = static_cast<std::uint32_t>(client.samples.size());
    const std::uint32_t msBase = static_cast<std::uint32_t>(client.multisamples.size());
    std::set<std::string> names;
    std::set<std::uint16_t> positions;
    for (const auto& snd : client.sounds) { names.insert(snd.name); positions.insert(snd.position); }
    std::vector<silveton::manager::SoundDefinition> newSounds;
    for (const auto& snd : ours.sounds) {
        if (names.count(snd.name) != 0U) { ++skipped; continue; }
        std::uint16_t position = 0U;
        for (std::uint16_t p = kMinSoundPosition; p <= kMaxSoundPosition; ++p) if (positions.count(p) == 0U) { position = p; break; }
        if (position == 0U) { error = "No free SOUND position remains in the client's bank (1...500)."; return false; }
        positions.insert(position);
        names.insert(snd.name);
        silveton::manager::SoundDefinition copy = snd;
        copy.position = position;
        for (auto& layer : copy.layers) layer.multisampleIndex += msBase;
        newSounds.push_back(std::move(copy));
        ++added;
    }
    if (added == 0U) return true;
    for (const auto& s : ours.samples) { auto copy = s; copy.sampleId = ++sampleId; client.samples.push_back(std::move(copy)); }
    for (const auto& m : ours.multisamples) {
        auto copy = m;
        copy.multisampleId = ++msId;
        for (auto& z : copy.zones) z.sampleIndex += sampleBase;
        client.multisamples.push_back(std::move(copy));
    }
    for (auto& snd : newSounds) {
        const std::size_t index = client.sounds.size();
        snd.slot = static_cast<std::uint16_t>(index % 128U);
        snd.page = static_cast<std::uint16_t>((index / 128U) % 128U);
        snd.bank = static_cast<std::uint16_t>(index / (128U * 128U));
        client.sounds.push_back(std::move(snd));
    }
    return true;
}
}

@interface SVBankPage : SVPageView <NSTableViewDataSource, NSTableViewDelegate>
@end

@implementation SVBankPage {
    NSTableView* _table;
    NSTextField* _totals;
    NSTextField* _where;
    NSTextField* _clientWhere;
    NSTextField* _last;
    NSString* _clientPath;
}

- (instancetype)initWithShell:(SVShellWindowController*)shell frame:(NSRect)frame {
    self = [super initWithShell:shell frame:frame];
    if (self) { _clientPath = [[NSUserDefaults standardUserDefaults] stringForKey:kPrefClientBank]; [self build]; }
    return self;
}

- (void)build {
    const NSRect b = self.bounds;
    SVPanel* left = [[SVPanel alloc] initWithFrame:NSMakeRect(16.0, 16.0, 560.0, b.size.height - 32.0) title:@"СЪДЪРЖАНИЕ НА БАНКАТА"];
    left.autoresizingMask = NSViewHeightSizable;
    _table = [[NSTableView alloc] initWithFrame:NSZeroRect];
    SVStyleTable(_table);
    _table.dataSource = self;
    _table.delegate = self;
    [_table addTableColumn:SVTextColumn(@"pos", @"№", 44.0)];
    [_table addTableColumn:SVTextColumn(@"name", @"БЛЕНДА", 220.0)];
    [_table addTableColumn:SVTextColumn(@"layers", @"СЛОЕВЕ", 60.0)];
    [_table addTableColumn:SVTextColumn(@"samples", @"СЕМПЛИ", 60.0)];
    [_table addTableColumn:SVTextColumn(@"mb", @"MB", 60.0)];
    [_table addTableColumn:SVTextColumn(@"done", @"ОБРАБОТЕНА", 80.0)];
    NSScrollView* scroll = SVScroll(NSMakeRect(12.0, 32.0, 536.0, left.bounds.size.height - 32.0 - 70.0), _table);
    scroll.autoresizingMask = NSViewHeightSizable;
    [left addSubview:scroll];
    _totals = SVLabel(NSMakeRect(12.0, left.bounds.size.height - 52.0, 536.0, 40.0), @"", 12.0, NO, SVColDim());
    _totals.autoresizingMask = NSViewMinYMargin;
    _totals.lineBreakMode = NSLineBreakByWordWrapping;
    [_totals.cell setWraps:YES];
    [left addSubview:_totals];
    [self addSubview:left];

    const CGFloat rx = 592.0;
    const CGFloat rw = b.size.width - rx - 16.0;
    SVPanel* save = [[SVPanel alloc] initWithFrame:NSMakeRect(rx, 16.0, rw, 200.0) title:@"ЗАПИШИ БАНКАТА"];
    save.autoresizingMask = NSViewWidthSizable;
    _where = SVLabel(NSMakeRect(12.0, 34.0, rw - 24.0, 18.0), @"", 12.0, NO, SVColText());
    _where.autoresizingMask = NSViewWidthSizable;
    _where.lineBreakMode = NSLineBreakByTruncatingHead;
    [save addSubview:_where];
    [save addSubview:[SVKeyButton keyWithFrame:NSMakeRect(12.0, 62.0, 170.0, 34.0) title:@"ИЗБЕРИ МЯСТО…" kind:0 target:self action:@selector(choosePlace:)]];
    SVKeyButton* saveKey = [SVKeyButton keyWithFrame:NSMakeRect(12.0, 106.0, 160.0, 44.0) title:@"ЗАПИШИ" kind:1 target:self action:@selector(savePressed:)];
    saveKey.textSize = 15.0;
    [save addSubview:saveKey];
    [save addSubview:SVLabel(NSMakeRect(12.0, 160.0, rw - 24.0, 18.0), @"Записва се наведнъж, с проверка. След това копираш файла на таблета.", 11.0, NO, SVColDim())];
    [self addSubview:save];

    SVPanel* load = [[SVPanel alloc] initWithFrame:NSMakeRect(rx, 232.0, rw, 150.0) title:@"ЗАРЕДИ БАНКА"];
    load.autoresizingMask = NSViewWidthSizable;
    [load addSubview:SVLabel(NSMakeRect(12.0, 34.0, rw - 24.0, 18.0), @"Отваря съществуваща SILVETON_BANK.sv, за да добавиш звуци към нея.", 11.0, NO, SVColDim())];
    SVKeyButton* loadKey = [SVKeyButton keyWithFrame:NSMakeRect(12.0, 64.0, 160.0, 44.0) title:@"ЗАРЕДИ…" kind:0 target:self action:@selector(loadPressed:)];
    loadKey.textSize = 15.0;
    [load addSubview:loadKey];
    [load addSubview:[SVKeyButton keyWithFrame:NSMakeRect(184.0, 69.0, 200.0, 34.0) title:@"НОВ ПРАЗЕН ПРОЕКТ" kind:0 target:self action:@selector(newProjectPressed:)]];
    [self addSubview:load];

    SVPanel* client = [[SVPanel alloc] initWithFrame:NSMakeRect(rx, 398.0, rw, b.size.height - 398.0 - 16.0) title:@"ОБНОВИ БАНКА НА КЛИЕНТ"];
    client.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    NSTextField* ct = SVLabel(NSMakeRect(12.0, 34.0, rw - 24.0, 36.0), @"Добавя новите бленди от този проект в банката на клиента. Неговите бленди и позиции остават непокътнати; бленда със същото име се пропуска. Старата банка се пази като копие.", 11.0, NO, SVColDim());
    ct.autoresizingMask = NSViewWidthSizable;
    ct.lineBreakMode = NSLineBreakByWordWrapping;
    [ct.cell setWraps:YES];
    [client addSubview:ct];
    _clientWhere = SVLabel(NSMakeRect(12.0, 76.0, rw - 24.0, 18.0), @"", 12.0, NO, SVColText());
    _clientWhere.autoresizingMask = NSViewWidthSizable;
    _clientWhere.lineBreakMode = NSLineBreakByTruncatingHead;
    [client addSubview:_clientWhere];
    [client addSubview:[SVKeyButton keyWithFrame:NSMakeRect(12.0, 104.0, 260.0, 44.0) title:@"ИЗБЕРИ БАНКАТА НА КЛИЕНТА…" kind:0 target:self action:@selector(chooseClient:)]];
    SVKeyButton* upd = [SVKeyButton keyWithFrame:NSMakeRect(284.0, 104.0, 140.0, 44.0) title:@"ОБНОВИ" kind:1 target:self action:@selector(updateClientPressed:)];
    upd.textSize = 15.0;
    [client addSubview:upd];
    _last = SVLabel(NSMakeRect(12.0, 160.0, rw - 24.0, 36.0), @"", 11.0, NO, SVColGreen());
    _last.autoresizingMask = NSViewWidthSizable;
    _last.lineBreakMode = NSLineBreakByWordWrapping;
    [_last.cell setWraps:YES];
    [client addSubview:_last];
    [self addSubview:client];
}

// ---------------------------------------------------------------- data

- (void)refresh {
    [_table reloadData];
    BankProject* project = SVProjectOf(self.shell.documentModel);
    if (project == nullptr) { _totals.stringValue = @""; return; }
    unsigned long long bytes = 0ULL;
    for (const auto& s : project->samples) bytes += SVSampleBytes(s);
    std::set<std::uint16_t> used;
    for (const auto& snd : project->sounds) used.insert(snd.position);
    _totals.stringValue = [NSString stringWithFormat:@"Общо: %lu бленди · %lu семпла · %@   ·   свободни позиции: %lu   ·   еднакви семпли се пазят по веднъж",
                           static_cast<unsigned long>(project->sounds.size()), static_cast<unsigned long>(project->samples.size()), SVMegabytes(static_cast<double>(bytes)),
                           static_cast<unsigned long>(kMaxSoundPosition - used.size())];
    _where.stringValue = self.shell.bankPath.length > 0U ? [NSString stringWithFormat:@"Къде: %@", self.shell.bankPath] : @"Къде: още не е избрано – ЗАПИШИ пита къде.";
    _clientWhere.stringValue = _clientPath.length > 0U ? [NSString stringWithFormat:@"Банка на клиента: %@", _clientPath] : @"Банка на клиента: не е избрана.";
}

- (NSInteger)numberOfRowsInTableView:(NSTableView*)tableView { (void)tableView; return static_cast<NSInteger>([self.shell.documentModel soundCount]); }

- (id)tableView:(NSTableView*)tableView objectValueForTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView;
    BankProject* project = SVProjectOf(self.shell.documentModel);
    if (project == nullptr || row < 0 || static_cast<std::size_t>(row) >= project->sounds.size()) return nil;
    const auto& snd = project->sounds[static_cast<std::size_t>(row)];
    NSString* ident = tableColumn.identifier;
    if ([ident isEqualToString:@"pos"]) return [NSString stringWithFormat:@"%03u", snd.position];
    if ([ident isEqualToString:@"name"]) return SVNs(snd.name);
    if ([ident isEqualToString:@"layers"]) return [NSString stringWithFormat:@"%lu", static_cast<unsigned long>(snd.layers.size())];
    std::set<std::size_t> samples;
    for (const auto& layer : snd.layers) {
        if (layer.multisampleIndex >= project->multisamples.size()) continue;
        for (const auto& z : project->multisamples[layer.multisampleIndex].zones) if (z.sampleIndex < project->samples.size()) samples.insert(z.sampleIndex);
    }
    if ([ident isEqualToString:@"samples"]) return [NSString stringWithFormat:@"%lu", static_cast<unsigned long>(samples.size())];
    if ([ident isEqualToString:@"mb"]) {
        unsigned long long bytes = 0ULL;
        for (std::size_t i : samples) bytes += SVSampleBytes(project->samples[i]);
        return [NSString stringWithFormat:@"%.0f", static_cast<double>(bytes) / (1024.0 * 1024.0)];
    }
    if (samples.empty()) return @"–";
    bool all = true;
    for (std::size_t i : samples) if (![self.shell isSampleIdProcessed:@(project->samples[i].sampleId)]) { all = false; break; }
    return all ? @"да" : @"не";
}

- (BOOL)tableView:(NSTableView*)tableView shouldSelectRow:(NSInteger)row { (void)tableView; (void)row; return NO; }

- (void)tableView:(NSTableView*)tableView willDisplayCell:(id)cell forTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView; (void)row;
    if (![cell isKindOfClass:[NSTextFieldCell class]]) return;
    NSTextFieldCell* text = cell;
    if ([tableColumn.identifier isEqualToString:@"done"]) text.textColor = [[text stringValue] isEqualToString:@"да"] ? SVColGreen() : SVColAmber();
    else text.textColor = SVColText();
}

// ---------------------------------------------------------------- save / load

- (void)choosePlace:(id)sender {
    (void)sender;
    NSSavePanel* panel = [NSSavePanel savePanel];
    panel.title = @"Къде да се записва банката";
    panel.prompt = @"Тук";
    panel.allowedFileTypes = @[@"sv"];
    panel.nameFieldStringValue = self.shell.bankPath.length > 0U ? self.shell.bankPath.lastPathComponent : @"SILVETON_BANK.sv";
    if (self.shell.bankPath.length > 0U) panel.directoryURL = [NSURL fileURLWithPath:self.shell.bankPath.stringByDeletingLastPathComponent isDirectory:YES];
    if ([panel runModal] != NSModalResponseOK || panel.URL == nil) return;
    self.shell.bankPath = panel.URL.path;
    [self refresh];
    [self.shell refreshBars];
}

- (void)savePressed:(id)sender {
    (void)sender;
    SVManagerDocument* doc = self.shell.documentModel;
    if ([doc soundCount] == 0U) { SVAlert(self.window, @"ЗАПИШИ", @"Банката е празна. Първо внеси нещо (ВНАСЯНЕ).", NO); return; }
    if (self.shell.bankPath.length == 0U) { [self choosePlace:nil]; if (self.shell.bankPath.length == 0U) return; }
    NSString* path = self.shell.bankPath;
    SVProgressPanel* progress = [[SVProgressPanel alloc] initWithTitle:@"ЗАПИСВАНЕ НА БАНКАТА"];
    __block BOOL ok = NO;
    __block NSString* error = nil;
    __block NSString* summary = nil;
    [progress runWork:^(SVProgressPanel* p) {
        [p setFraction:0.5 text:[NSString stringWithFormat:@"Записва се %@ …", path.lastPathComponent]];
        ok = [doc buildBankAtPath:path error:&error summary:&summary];
        [p setFraction:1.0 text:@"Done"];
    }];
    if (!ok) { SVAlert(self.window, @"ЗАПИШИ", error, YES); return; }
    _last.stringValue = [NSString stringWithFormat:@"✓ Записана: %@ · %@", path.lastPathComponent, summary ?: @""];
    [self.shell refreshAll];
}

- (void)loadPressed:(id)sender {
    (void)sender;
    if (![self.shell confirmLosingChanges:@"Зареждането на друга банка"]) return;
    NSOpenPanel* panel = [NSOpenPanel openPanel];
    panel.title = @"Избери SILVETON банка (.sv)";
    panel.prompt = @"Зареди";
    panel.canChooseFiles = YES;
    panel.canChooseDirectories = NO;
    panel.allowsMultipleSelection = NO;
    panel.allowedFileTypes = @[@"sv", @"SV"];
    if ([panel runModal] != NSModalResponseOK || panel.URLs.count == 0U) return;
    NSString* path = ((NSURL*)panel.URLs.firstObject).path;
    SVManagerDocument* doc = self.shell.documentModel;
    SVProgressPanel* progress = [[SVProgressPanel alloc] initWithTitle:@"ЗАРЕЖДАНЕ НА БАНКА"];
    __block BOOL ok = NO;
    __block NSString* error = nil;
    __block NSString* summary = nil;
    [progress runWork:^(SVProgressPanel* p) {
        [p setFraction:0.5 text:[NSString stringWithFormat:@"Чете се %@ …", path.lastPathComponent]];
        ok = [doc loadBankAtPath:path error:&error summary:&summary];
        [p setFraction:1.0 text:@"Done"];
    }];
    if (!ok) { SVAlert(self.window, @"ЗАРЕДИ", error, YES); return; }
    self.shell.bankPath = path;
    [self.shell clearProcessedMarks];
    _last.stringValue = [NSString stringWithFormat:@"✓ Заредена: %@", summary ?: path.lastPathComponent];
    [self.shell refreshAll];
}

- (void)newProjectPressed:(id)sender {
    (void)sender;
    if (![self.shell confirmLosingChanges:@"Новият празен проект"]) return;
    if (!SVConfirm(self.window, @"Нов празен проект", @"Всичко в проекта се маха (файловете на диска и записаните банки остават).", @"Изчисти")) return;
    [self.shell.documentModel clearProject];
    self.shell.bankPath = nil;
    [self.shell clearProcessedMarks];
    _last.stringValue = @"";
    [self.shell refreshAll];
}

// ---------------------------------------------------------------- client bank

- (void)chooseClient:(id)sender {
    (void)sender;
    NSOpenPanel* panel = [NSOpenPanel openPanel];
    panel.title = @"Банката на клиента (.sv)";
    panel.prompt = @"Избери";
    panel.canChooseFiles = YES;
    panel.canChooseDirectories = NO;
    panel.allowsMultipleSelection = NO;
    panel.allowedFileTypes = @[@"sv", @"SV"];
    if ([panel runModal] != NSModalResponseOK || panel.URLs.count == 0U) return;
    _clientPath = ((NSURL*)panel.URLs.firstObject).path;
    [[NSUserDefaults standardUserDefaults] setObject:_clientPath forKey:kPrefClientBank];
    [self refresh];
}

- (void)updateClientPressed:(id)sender {
    (void)sender;
    if (_clientPath.length == 0U) { [self chooseClient:nil]; if (_clientPath.length == 0U) return; }
    BankProject* ours = SVProjectOf(self.shell.documentModel);
    if (ours == nullptr || ours->sounds.empty()) { SVAlert(self.window, @"ОБНОВИ", @"В проекта няма бленди за добавяне.", NO); return; }
    if (!SVConfirm(self.window, @"Обнови банката на клиента",
                   [NSString stringWithFormat:@"Блендите от проекта (%lu) се добавят в:\n%@\nСтарата банка се пази като копие до нея.", static_cast<unsigned long>(ours->sounds.size()), _clientPath],
                   @"Обнови")) return;
    NSString* clientPath = _clientPath;
    SVProgressPanel* progress = [[SVProgressPanel alloc] initWithTitle:@"ОБНОВЯВАНЕ НА БАНКАТА НА КЛИЕНТА"];
    __block std::string error;
    __block std::size_t added = 0U, skipped = 0U;
    __block BOOL ok = NO;
    [progress runWork:^(SVProgressPanel* p) {
        [p setFraction:0.2 text:@"Чете се банката на клиента …"];
        auto loaded = SvBankReader::readFile(std::string(clientPath.fileSystemRepresentation), true);
        if (!loaded.ok()) { error = loaded.error; return; }
        [p setFraction:0.5 text:@"Добавят се блендите …"];
        if (!mergeInto(loaded.project, *ours, added, skipped, error)) return;
        if (added == 0U) { ok = YES; return; }
        // keep the old bank next to the new one
        NSString* backup = [[clientPath stringByDeletingPathExtension] stringByAppendingString:@" (старо).sv"];
        [[NSFileManager defaultManager] removeItemAtPath:backup error:nil];
        [[NSFileManager defaultManager] copyItemAtPath:clientPath toPath:backup error:nil];
        [p setFraction:0.7 text:@"Записва се …"];
        SvBuildStats stats{};
        ok = SvBankBuilder::writeAtomic(std::string(clientPath.fileSystemRepresentation), loaded.project, stats, error) ? YES : NO;
        [p setFraction:1.0 text:@"Done"];
    }];
    if (!ok) { SVAlert(self.window, @"ОБНОВИ", SVNs(error), YES); return; }
    _last.stringValue = [NSString stringWithFormat:@"✓ Банката на клиента е обновена: добавени %lu, пропуснати (вече ги има) %lu.", static_cast<unsigned long>(added), static_cast<unsigned long>(skipped)];
}
@end
