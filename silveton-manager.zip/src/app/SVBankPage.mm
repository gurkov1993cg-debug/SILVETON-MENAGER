// SILVETON_LOOK_V1 - page 4 БАНКА: what is inside, the project (save / open), the bank for the tablet, update a client's bank.
// SILVETON_PROJECT_V1: a project = Documents/SILVETON/ПРОЕКТИ/<name>/ (manager.sv, sent.sv, project.txt, the sampler's LIST and settings).
// SILVETON_SEND_V1: ЗАПИШИ БАНКАТА ЗА ТАБЛЕТА = the sampler's bank + the sent sounds, written at the end, by hand.
#import "SVShell.h"
#import "SVDocument.h"
#import "SVTheme.h"
#import "SVProgress.h"
#import "SVSamplerPage.h"

#include "silveton/manager/SoundTransfer.h"
#include "silveton/manager/SvBankBuilder.h"
#include "silveton/manager/SvBankMerge.h"
#include "silveton/manager/SvBankReader.h"

#include <cstdint>
#include <utility>
#include <algorithm>
#include <limits>
#include <set>
#include <string>
#include <vector>

using silveton::manager::BankProject;
using silveton::manager::SentSound;
using silveton::manager::SvBankBuilder;
using silveton::manager::SvBankMerge;
using silveton::manager::SvMergeStats;
using silveton::manager::SvBankReader;
using silveton::manager::SvBuildStats;
using silveton::manager::kMaxSoundPosition;
using silveton::manager::kMinSoundPosition;

@interface SVProgressPanel : NSObject
- (instancetype)initWithTitle:(NSString*)title;
- (void)setFraction:(double)fraction text:(NSString*)text;
- (BOOL)stopRequested;
- (void)runWork:(void (^)(SVProgressPanel* progress))work;
@end

namespace {
NSString* const kPrefClientBank = @"SVClientBankPath";
NSString* const kPrefProjectDir = @"SVProjectFolder";   // SILVETON_PROJECT_V1: the project that is open

std::string svStr(NSString* s) { return s != nil ? std::string([s UTF8String]) : std::string(); }

// Adds every SOUND of `ours` (with its multisamples and samples) to `client`. SOUNDs whose name already exists are skipped.
bool mergeInto(BankProject& client, const BankProject& ours, std::size_t& added, std::size_t& skipped, std::string& error) {
    added = 0U; skipped = 0U;
    std::uint32_t sampleId = 0U, msId = 0U;
    for (const auto& s : client.samples) sampleId = std::max(sampleId, s.sampleId);
    for (const auto& m : client.multisamples) msId = std::max(msId, m.multisampleId);
    const std::uint32_t sampleBase = static_cast<std::uint32_t>(client.samples.size());
    const std::uint32_t msBase = static_cast<std::uint32_t>(client.multisamples.size());
    std::set<std::string> names;
    std::set<std::uint16_t> positions;
    for (const auto& snd : client.sounds) { names.insert(snd.name); positions.insert(snd.position); }
    std::vector<silveton::manager::SoundDefinition> newSounds;
    for (const auto& snd : ours.sounds) {
        if (names.count(snd.name) != 0U) { ++skipped; continue; }
        std::uint16_t position = 0U;
        for (std::uint16_t p = kMinSoundPosition; p <= kMaxSoundPosition; ++p) if (positions.count(p) == 0U) { position = p; break; }
        if (position == 0U) { error = "No free SOUND position remains in the client's bank (1...500)."; return false; }
        positions.insert(position);
        names.insert(snd.name);
        silveton::manager::SoundDefinition copy = snd;
        copy.position = position;
        for (auto& layer : copy.layers) layer.multisampleIndex += msBase;
        newSounds.push_back(std::move(copy));
        ++added;
    }
    if (added == 0U) return true;
    for (const auto& s : ours.samples) { auto copy = s; copy.sampleId = ++sampleId; client.samples.push_back(std::move(copy)); }
    for (const auto& m : ours.multisamples) {
        auto copy = m;
        copy.multisampleId = ++msId;
        for (auto& z : copy.zones) z.sampleIndex += sampleBase;
        client.multisamples.push_back(std::move(copy));
    }
    for (auto& snd : newSounds) {
        const std::size_t index = client.sounds.size();
        snd.slot = static_cast<std::uint16_t>(index % 128U);
        snd.page = static_cast<std::uint16_t>((index / 128U) % 128U);
        snd.bank = static_cast<std::uint16_t>(index / (128U * 128U));
        client.sounds.push_back(std::move(snd));
    }
    return true;
}
}

@interface SVBankPage : SVPageView <NSTableViewDataSource, NSTableViewDelegate>
@end

@implementation SVBankPage {
    NSTableView* _table;
    NSTextField* _totals;
    NSTextField* _clientWhere;
    NSTextField* _last;
    NSString* _clientPath;
    NSTextField* _projectLabel;
    NSTextField* _tabletLabel;
    NSString* _projectDir;      // nil = not saved as a project yet
}

- (instancetype)initWithShell:(SVShellWindowController*)shell frame:(NSRect)frame {
    self = [super initWithShell:shell frame:frame];
    if (self) {
        _clientPath = [[NSUserDefaults standardUserDefaults] stringForKey:kPrefClientBank];
        _projectDir = nil;   // a new start = a new project (the last one is opened with ОТВОРИ ПРОЕКТ)
        [self build];
    }
    return self;
}

- (void)build {
    const NSRect b = self.bounds;
    SVPanel* left = [[SVPanel alloc] initWithFrame:NSMakeRect(16.0, 16.0, 560.0, b.size.height - 32.0) title:@"СЪДЪРЖАНИЕ НА БАНКАТА"];
    left.autoresizingMask = NSViewHeightSizable;
    _table = [[NSTableView alloc] initWithFrame:NSZeroRect];
    SVStyleTable(_table);
    _table.dataSource = self;
    _table.delegate = self;
    [_table addTableColumn:SVTextColumn(@"pos", @"№", 44.0)];
    [_table addTableColumn:SVTextColumn(@"name", @"ЗВУК", 220.0)];
    [_table addTableColumn:SVTextColumn(@"layers", @"СЛОЕВЕ", 60.0)];
    [_table addTableColumn:SVTextColumn(@"samples", @"СЕМПЛИ", 60.0)];
    [_table addTableColumn:SVTextColumn(@"mb", @"MB", 60.0)];
    [_table addTableColumn:SVTextColumn(@"done", @"ОБРАБОТЕНА", 80.0)];
    NSScrollView* scroll = SVScroll(NSMakeRect(12.0, 32.0, 536.0, left.bounds.size.height - 32.0 - 70.0), _table);
    scroll.autoresizingMask = NSViewHeightSizable;
    [left addSubview:scroll];
    _totals = SVLabel(NSMakeRect(12.0, left.bounds.size.height - 52.0, 536.0, 40.0), @"", 12.0, NO, SVColDim());
    _totals.autoresizingMask = NSViewMinYMargin;
    _totals.lineBreakMode = NSLineBreakByWordWrapping;
    [_totals.cell setWraps:YES];
    [left addSubview:_totals];
    [self addSubview:left];

    const CGFloat rx = 592.0;
    const CGFloat rw = b.size.width - rx - 16.0;
    // ---- SILVETON_PROJECT_V1: the work is kept as a project, to go on from where it stopped
    SVPanel* proj = [[SVPanel alloc] initWithFrame:NSMakeRect(rx, 16.0, rw, 200.0) title:@"ПРОЕКТ"];
    proj.autoresizingMask = NSViewWidthSizable;
    _projectLabel = SVLabel(NSMakeRect(12.0, 34.0, rw - 24.0, 18.0), @"", 12.0, NO, SVColText());
    _projectLabel.autoresizingMask = NSViewWidthSizable;
    _projectLabel.lineBreakMode = NSLineBreakByTruncatingHead;
    [proj addSubview:_projectLabel];
    SVKeyButton* saveProj = [SVKeyButton keyWithFrame:NSMakeRect(12.0, 62.0, 200.0, 44.0) title:@"ЗАПАЗИ ПРОЕКТА" kind:1 target:self action:@selector(saveProjectPressed:)];
    saveProj.textSize = 15.0;
    [proj addSubview:saveProj];
    [proj addSubview:[SVKeyButton keyWithFrame:NSMakeRect(224.0, 67.0, 150.0, 34.0) title:@"ЗАПАЗИ КАТО…" kind:0 target:self action:@selector(saveProjectAsPressed:)]];
    [proj addSubview:[SVKeyButton keyWithFrame:NSMakeRect(386.0, 67.0, 170.0, 34.0) title:@"ОТВОРИ ПРОЕКТ…" kind:0 target:self action:@selector(openProjectPressed:)]];
    [proj addSubview:[SVKeyButton keyWithFrame:NSMakeRect(12.0, 116.0, 150.0, 34.0) title:@"НОВ ПРОЕКТ" kind:0 target:self action:@selector(newProjectPressed:)]];
    [proj addSubview:[SVKeyButton keyWithFrame:NSMakeRect(174.0, 116.0, 200.0, 34.0) title:@"ЗАРЕДИ БАНКА…" kind:0 target:self action:@selector(loadPressed:)]];
    NSTextField* ph = SVLabel(NSMakeRect(12.0, 158.0, rw - 24.0, 32.0), @"Пази звуците на мениджъра, пратените в семплера звуци и ЛИСТА с блендите, ефектите и настройките. ЗАРЕДИ БАНКА… отваря една SILVETON_BANK.sv в мениджъра.", 11.0, NO, SVColDim());
    ph.autoresizingMask = NSViewWidthSizable;
    ph.lineBreakMode = NSLineBreakByWordWrapping;
    [ph.cell setWraps:YES];
    [proj addSubview:ph];
    [self addSubview:proj];

    // ---- SILVETON_SEND_V1: the bank for the tablet, written at the end, by hand
    SVPanel* tablet = [[SVPanel alloc] initWithFrame:NSMakeRect(rx, 232.0, rw, 150.0) title:@"БАНКА ЗА ТАБЛЕТА"];
    tablet.autoresizingMask = NSViewWidthSizable;
    _tabletLabel = SVLabel(NSMakeRect(12.0, 34.0, rw - 24.0, 18.0), @"", 12.0, NO, SVColText());
    _tabletLabel.autoresizingMask = NSViewWidthSizable;
    _tabletLabel.lineBreakMode = NSLineBreakByTruncatingHead;
    [tablet addSubview:_tabletLabel];
    SVKeyButton* tabletKey = [SVKeyButton keyWithFrame:NSMakeRect(12.0, 60.0, 320.0, 44.0) title:@"ЗАПИШИ БАНКАТА ЗА ТАБЛЕТА" kind:1 target:self action:@selector(tabletBankPressed:)];
    tabletKey.textSize = 15.0;
    [tablet addSubview:tabletKey];
    NSTextField* th = SVLabel(NSMakeRect(12.0, 110.0, rw - 24.0, 32.0), @"Всичко, което е в семплера: банката му + пратените звуци. До нея: ЛИСТА, блендите, ефектите и настройките (SILVETON_BLENDS.SVSET). Двете копираш на таблета.", 11.0, NO, SVColDim());
    th.autoresizingMask = NSViewWidthSizable;
    th.lineBreakMode = NSLineBreakByWordWrapping;
    [th.cell setWraps:YES];
    [tablet addSubview:th];
    [self addSubview:tablet];

    SVPanel* client = [[SVPanel alloc] initWithFrame:NSMakeRect(rx, 398.0, rw, b.size.height - 398.0 - 16.0) title:@"ОБНОВИ БАНКА НА КЛИЕНТ"];
    client.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    NSTextField* ct = SVLabel(NSMakeRect(12.0, 34.0, rw - 24.0, 36.0), @"Добавя новите звуци от този проект в банката на клиента. Неговите звуци и позиции остават непокътнати; звук със същото име се пропуска. Старата банка се пази като копие.", 11.0, NO, SVColDim());
    ct.autoresizingMask = NSViewWidthSizable;
    ct.lineBreakMode = NSLineBreakByWordWrapping;
    [ct.cell setWraps:YES];
    [client addSubview:ct];
    _clientWhere = SVLabel(NSMakeRect(12.0, 76.0, rw - 24.0, 18.0), @"", 12.0, NO, SVColText());
    _clientWhere.autoresizingMask = NSViewWidthSizable;
    _clientWhere.lineBreakMode = NSLineBreakByTruncatingHead;
    [client addSubview:_clientWhere];
    [client addSubview:[SVKeyButton keyWithFrame:NSMakeRect(12.0, 104.0, 260.0, 44.0) title:@"ИЗБЕРИ БАНКАТА НА КЛИЕНТА…" kind:0 target:self action:@selector(chooseClient:)]];
    SVKeyButton* upd = [SVKeyButton keyWithFrame:NSMakeRect(284.0, 104.0, 140.0, 44.0) title:@"ОБНОВИ" kind:1 target:self action:@selector(updateClientPressed:)];
    upd.textSize = 15.0;
    [client addSubview:upd];
    _last = SVLabel(NSMakeRect(12.0, 160.0, rw - 24.0, 36.0), @"", 11.0, NO, SVColGreen());
    _last.autoresizingMask = NSViewWidthSizable;
    _last.lineBreakMode = NSLineBreakByWordWrapping;
    [_last.cell setWraps:YES];
    [client addSubview:_last];
    [self addSubview:client];
}

// ---------------------------------------------------------------- data

- (void)refresh {
    [_table reloadData];
    BankProject* project = SVProjectOf(self.shell.documentModel);
    if (project == nullptr) { _totals.stringValue = @""; return; }
    unsigned long long bytes = 0ULL;
    for (const auto& s : project->samples) bytes += SVSampleBytes(s);
    std::set<std::uint16_t> used;
    for (const auto& snd : project->sounds) used.insert(snd.position);
    _totals.stringValue = [NSString stringWithFormat:@"Общо: %lu звука · %lu семпла · %@   ·   свободни позиции: %lu   ·   еднакви семпли се пазят по веднъж",
                           static_cast<unsigned long>(project->sounds.size()), static_cast<unsigned long>(project->samples.size()), SVMegabytes(static_cast<double>(bytes)),
                           static_cast<unsigned long>(kMaxSoundPosition - used.size())];
    _projectLabel.stringValue = _projectDir.length > 0U ? [NSString stringWithFormat:@"Проект: %@", _projectDir.lastPathComponent]
                                                         : @"Проект: нов (още не е запазен) – отива в Документи → SILVETON → ПРОЕКТИ";
    SVSamplerHost* host = [SVSamplerHost shared];
    NSString* bank = [host currentBankPath] ?: [host defaultBankPath];
    const NSUInteger sent = [host sentFileCount];
    _tabletLabel.stringValue = [NSString stringWithFormat:@"%@   ·   %@", bank,
                                sent > 0U ? @"има пратени звуци, още не са в банката" : @"няма нови пратени звуци"];
    _clientWhere.stringValue = _clientPath.length > 0U ? [NSString stringWithFormat:@"Банка на клиента: %@", _clientPath] : @"Банка на клиента: не е избрана.";
}

- (NSInteger)numberOfRowsInTableView:(NSTableView*)tableView { (void)tableView; return static_cast<NSInteger>([self.shell.documentModel soundCount]); }

- (id)tableView:(NSTableView*)tableView objectValueForTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView;
    BankProject* project = SVProjectOf(self.shell.documentModel);
    if (project == nullptr || row < 0 || static_cast<std::size_t>(row) >= project->sounds.size()) return nil;
    const auto& snd = project->sounds[static_cast<std::size_t>(row)];
    NSString* ident = tableColumn.identifier;
    if ([ident isEqualToString:@"pos"]) return [NSString stringWithFormat:@"%03u", snd.position];
    if ([ident isEqualToString:@"name"]) return SVNs(snd.name);
    if ([ident isEqualToString:@"layers"]) return [NSString stringWithFormat:@"%lu", static_cast<unsigned long>(snd.layers.size())];
    std::set<std::size_t> samples;
    for (const auto& layer : snd.layers) {
        if (layer.multisampleIndex >= project->multisamples.size()) continue;
        for (const auto& z : project->multisamples[layer.multisampleIndex].zones) if (z.sampleIndex < project->samples.size()) samples.insert(z.sampleIndex);
    }
    if ([ident isEqualToString:@"samples"]) return [NSString stringWithFormat:@"%lu", static_cast<unsigned long>(samples.size())];
    if ([ident isEqualToString:@"mb"]) {
        unsigned long long bytes = 0ULL;
        for (std::size_t i : samples) bytes += SVSampleBytes(project->samples[i]);
        return [NSString stringWithFormat:@"%.0f", static_cast<double>(bytes) / (1024.0 * 1024.0)];
    }
    if (samples.empty()) return @"–";
    bool all = true;
    for (std::size_t i : samples) if (![self.shell isSampleIdProcessed:@(project->samples[i].sampleId)]) { all = false; break; }
    return all ? @"да" : @"не";
}

- (BOOL)tableView:(NSTableView*)tableView shouldSelectRow:(NSInteger)row { (void)tableView; (void)row; return NO; }

- (void)tableView:(NSTableView*)tableView willDisplayCell:(id)cell forTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView; (void)row;
    if (![cell isKindOfClass:[NSTextFieldCell class]]) return;
    NSTextFieldCell* text = cell;
    if ([tableColumn.identifier isEqualToString:@"done"]) text.textColor = [[text stringValue] isEqualToString:@"да"] ? SVColGreen() : SVColWarn();
    else text.textColor = SVColText();
}

// ---------------------------------------------------------------- save / load

// ---------------------------------------------------------------- SILVETON_PROJECT_V1: project

- (NSString*)projectsFolder {
    NSArray* dirs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString* documents = dirs.count > 0U ? dirs.firstObject : [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
    NSString* folder = [[documents stringByAppendingPathComponent:@"SILVETON"] stringByAppendingPathComponent:@"ПРОЕКТИ"];
    [[NSFileManager defaultManager] createDirectoryAtPath:folder withIntermediateDirectories:YES attributes:nil error:nil];
    return folder;
}

- (void)saveProjectPressed:(id)sender {
    (void)sender;
    if (_projectDir.length == 0U) { [self saveProjectAsPressed:nil]; return; }
    [self saveProjectTo:_projectDir];
}

- (void)saveProjectAsPressed:(id)sender {
    (void)sender;
    NSString* name = SVAskText(self.window, @"Запази проекта", @"Име на проекта:", _projectDir.length > 0U ? _projectDir.lastPathComponent : @"");
    if (name == nil) return;
    name = [[[name componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"/:\\"]] componentsJoinedByString:@"-"]
            stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (name.length == 0U || [name hasPrefix:@"."]) { SVFlash(@"Проект", @"Напиши име.", YES); return; }
    NSString* dir = [[self projectsFolder] stringByAppendingPathComponent:name];
    if (![dir isEqualToString:_projectDir] && [[NSFileManager defaultManager] fileExistsAtPath:dir] &&
        !SVConfirm(self.window, @"Има такъв проект", [NSString stringWithFormat:@"Проектът „%@“ вече го има. Да се запише ли върху него?", name], @"Запиши върху него")) return;
    [self saveProjectTo:dir];
}

- (void)saveProjectTo:(NSString*)dir {
    NSFileManager* fm = [NSFileManager defaultManager];
    if (![fm createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:nil error:nil]) { SVAlert(self.window, @"Проект", [NSString stringWithFormat:@"Няма достъп до %@", dir], YES); return; }
    [self.shell.audition stop];
    SVSamplerHost* host = [SVSamplerHost shared];
    SVManagerDocument* doc = self.shell.documentModel;
    BankProject* project = SVProjectOf(doc);
    const BOOL hasManager = project != nullptr && !project->samples.empty();
    const std::vector<std::string> sentFiles = [host sentFilePaths];
    NSString* managerFile = [dir stringByAppendingPathComponent:@"manager.sv"];
    NSString* sentFile = [dir stringByAppendingPathComponent:@"sent.sv"];
    const bool sentIsAlreadyThere = sentFiles.size() == 1U && sentFiles.front() == svStr(sentFile);

    // 1. the LIST, blends, effects, settings and the open COMBI of the sampler (first: the sampler may not be changed in between)
    if (NSString* why = [host saveSamplerStateTo:dir]) { SVAlert(self.window, @"Проект", why, YES); return; }

    // 2. the Manager's sounds and samples, 3. the sent sounds (all in one file)
    SVProgressPanel* progress = [[SVProgressPanel alloc] initWithTitle:@"ЗАПАЗВАНЕ НА ПРОЕКТА"];
    __block BOOL ok = YES;
    __block std::string error;
    [progress runWork:^(SVProgressPanel* p) {
        if (hasManager) {
            [p setFraction:0.0 text:@"Звуците на мениджъра …"];
            silveton::manager::SvBuildStats stats{};
            ok = SvBankBuilder::writeAtomic(svStr(managerFile), *project, stats, error, [p](double fraction, const std::string& text) -> bool {
                [p setFraction:0.6 * fraction text:[NSString stringWithUTF8String:text.c_str()] ?: @""];
                return ![p stopRequested];
            }) ? YES : NO;
            if (!ok) return;
        }
        if (!sentFiles.empty() && !sentIsAlreadyThere) {
            [p setFraction:0.6 text:@"Пратените звуци …"];
            SvMergeStats stats{};
            ok = SvBankMerge::merge("", sentFiles, {}, svStr(sentFile), "", stats, error, [p](double fraction, const std::string& text) -> bool {
                [p setFraction:0.6 + 0.4 * fraction text:[NSString stringWithUTF8String:text.c_str()] ?: @""];
                return ![p stopRequested];
            }) ? YES : NO;
        }
        [p setFraction:1.0 text:ok ? @"Готово" : @""];
    }];
    if (!ok) { SVAlert(self.window, @"Проект", error.empty() ? @"Спряно." : SVNs(error), YES); return; }
    if (!hasManager) [fm removeItemAtPath:managerFile error:nil];
    if (sentFiles.empty()) [fm removeItemAtPath:sentFile error:nil];

    // 4. project.txt: the sampler's bank and which Manager sound is at which place of the sampler
    std::string text = "SILVETON PROJECT 1\n";
    if (NSString* bank = [host currentBankPath]) text += "bank\t" + svStr(bank) + "\n";
    for (const auto& snd : [host sentSounds]) text += "sound\t" + std::to_string(snd.place) + "\t" + snd.samplerName + "\t" + snd.managerName + "\n";
    for (const int place : [host droppedPlaces]) text += "drop\t" + std::to_string(place) + "\n";
    if (![[NSString stringWithUTF8String:text.c_str()] writeToFile:[dir stringByAppendingPathComponent:@"project.txt"] atomically:YES encoding:NSUTF8StringEncoding error:nil]) {
        SVAlert(self.window, @"Проект", @"project.txt не се записа.", YES);
        return;
    }
    [doc markCurrentStateSaved];
    _projectDir = dir;
    [[NSUserDefaults standardUserDefaults] setObject:dir forKey:kPrefProjectDir];
    [self.shell refreshAll];
    SVFlash(@"Проект", [NSString stringWithFormat:@"Запазен: %@", dir.lastPathComponent], NO);
}

- (void)openProjectPressed:(id)sender {
    (void)sender;
    if (![self.shell confirmLosingChanges:@"Отварянето на проект"]) return;
    NSOpenPanel* panel = [NSOpenPanel openPanel];
    panel.title = @"Избери папката на проекта";
    panel.prompt = @"Отвори";
    panel.canChooseFiles = NO;
    panel.canChooseDirectories = YES;
    panel.allowsMultipleSelection = NO;
    panel.directoryURL = [NSURL fileURLWithPath:[self projectsFolder] isDirectory:YES];
    if ([panel runModal] != NSModalResponseOK || panel.URLs.count == 0U) return;
    NSString* dir = ((NSURL*)panel.URLs.firstObject).path;
    NSString* text = [NSString stringWithContentsOfFile:[dir stringByAppendingPathComponent:@"project.txt"] encoding:NSUTF8StringEncoding error:nil];
    if (text == nil) { SVAlert(self.window, @"Проект", @"Това не е папка на проект (няма project.txt вътре).", NO); return; }
    NSString* bank = nil;
    std::vector<SentSound> sounds;
    std::set<int> dropped;
    for (NSString* line in [text componentsSeparatedByString:@"\n"]) {
        NSArray<NSString*>* parts = [line componentsSeparatedByString:@"\t"];
        if (parts.count == 2U && [parts[0] isEqualToString:@"bank"]) bank = parts[1];
        else if (parts.count == 4U && [parts[0] isEqualToString:@"sound"]) {
            const int place = static_cast<int>([parts[1] integerValue]);
            if (place >= 1 && place <= 500) sounds.push_back(SentSound{svStr(parts[3]), svStr(parts[2]), place});
        } else if (parts.count == 2U && [parts[0] isEqualToString:@"drop"]) {
            const int place = static_cast<int>([parts[1] integerValue]);
            if (place >= 1 && place <= 500) dropped.insert(place);
        }
    }
    NSFileManager* fm = [NSFileManager defaultManager];
    if (bank.length > 0U && ![fm fileExistsAtPath:bank]) { SVAlert(self.window, @"Проект", [NSString stringWithFormat:@"Банката на проекта я няма:\n%@", bank], YES); return; }
    if (!SVConfirm(self.window, @"Отвори проект", [NSString stringWithFormat:@"Проектът „%@“ се отваря: звуците в мениджъра и ЛИСТА в семплера стават тези от проекта.", dir.lastPathComponent], @"Отвори")) return;

    // the Manager
    [self.shell.audition stop];
    SVManagerDocument* doc = self.shell.documentModel;
    NSString* managerFile = [dir stringByAppendingPathComponent:@"manager.sv"];
    if ([fm fileExistsAtPath:managerFile]) {
        SVProgressPanel* progress = [[SVProgressPanel alloc] initWithTitle:@"ОТВАРЯНЕ НА ПРОЕКТ"];
        __block BOOL ok = NO;
        __block NSString* error = nil;
        __block NSString* summary = nil;
        [progress runWork:^(SVProgressPanel* p) {
            [p setFraction:0.5 text:@"Чете се …"];
            ok = [doc loadBankAtPath:managerFile error:&error summary:&summary];
            [p setFraction:1.0 text:@"Готово"];
        }];
        if (!ok) { SVAlert(self.window, @"Проект", error, YES); return; }
    } else {
        [doc clearProject];
    }
    [doc markCurrentStateSaved];
    self.shell.bankPath = nil;
    [self.shell clearProcessedMarks];
    _projectDir = dir;
    [[NSUserDefaults standardUserDefaults] setObject:dir forKey:kPrefProjectDir];
    [self.shell refreshAll];

    // the sampler: its bank + the sent sounds + the LIST and settings of the project
    NSString* sentFile = [dir stringByAppendingPathComponent:@"sent.sv"];
    if (![fm fileExistsAtPath:sentFile]) sentFile = nil;
    __weak SVBankPage* weakSelf = self;
    NSString* name = dir.lastPathComponent;
    [[SVSamplerHost shared] openProjectBank:bank sentFile:sentFile sounds:sounds dropped:dropped stateDir:dir done:^(NSString* problem) {
        SVBankPage* page = weakSelf;
        if (problem != nil) { SVAlert(page.window, @"Проект", problem, YES); return; }
        [page refresh];
        SVFlash(@"Проект", [NSString stringWithFormat:@"Отворен: %@", name], NO);
    }];
}

// ---------------------------------------------------------------- SILVETON_SEND_V1: the bank for the tablet

- (void)tabletBankPressed:(id)sender {
    (void)sender;
    SVSamplerHost* host = [SVSamplerHost shared];
    NSString* base = [host currentBankPath];
    const std::vector<std::string> sentFiles = [host sentFilePaths];
    const std::set<int> dropped = [host droppedPlaces];
    if (base == nil && sentFiles.empty()) { SVFlash(@"Банка за таблета", @"В семплера още няма звуци – прати ги от страница ЗВУЦИ.", YES); return; }
    NSString* out = base ?: [host defaultBankPath];
    NSString* text = [NSString stringWithFormat:@"Записва се:\n%@\n\nВътре: банката на семплера%@. До нея: ЛИСТА, блендите, ефектите и настройките (SILVETON_BLENDS.SVSET).",
                      out, sentFiles.empty() ? @"" : @" + пратените звуци"];
    if (!dropped.empty()) text = [text stringByAppendingFormat:@"\n\nИзтритите като неизползвани (%lu) не влизат.", static_cast<unsigned long>(dropped.size())];
    if (!SVConfirm(self.window, @"Запиши банката за таблета", text, @"Запиши")) return;

    // the LIST and settings as they are now: they come back exactly so after the sampler loads the new bank
    NSString* state = [[host sendFolder] stringByAppendingPathComponent:@"ПРЕДИ-БАНКАТА"];
    NSFileManager* fm = [NSFileManager defaultManager];
    [fm removeItemAtPath:state error:nil];
    if (NSString* why = [host saveSamplerStateTo:state]) { SVAlert(self.window, @"Банка за таблета", why, YES); return; }

    __block BOOL ok = YES;
    __block std::string error;
    __block SvMergeStats stats{};
    if (!sentFiles.empty() || !dropped.empty()) {
        [[NSFileManager defaultManager] createDirectoryAtPath:out.stringByDeletingLastPathComponent withIntermediateDirectories:YES attributes:nil error:nil];
        SVProgressPanel* progress = [[SVProgressPanel alloc] initWithTitle:@"БАНКА ЗА ТАБЛЕТА"];
        const std::string basePath = svStr(base);
        const std::string outPath = svStr(out);
        [progress runWork:^(SVProgressPanel* p) {
            [p setFraction:0.0 text:@"Записва се …"];
            ok = SvBankMerge::merge(basePath, sentFiles, dropped, outPath, "", stats, error, [p](double fraction, const std::string& t) -> bool {
                [p setFraction:fraction text:[NSString stringWithUTF8String:t.c_str()] ?: @""];
                return ![p stopRequested];
            }) ? YES : NO;
            [p setFraction:1.0 text:ok ? @"Готово" : @""];
        }];
    }
    if (!ok) { [fm removeItemAtPath:state error:nil]; SVAlert(self.window, @"Банка за таблета", error.empty() ? @"Спряно." : SVNs(error), YES); return; }
    NSString* summary = stats.soundCount > 0U ? [NSString stringWithFormat:@"%u звука · %@", stats.soundCount, SVMegabytes(static_cast<double>(stats.audioBytes))] : @"";
    __weak SVBankPage* weakSelf = self;
    [host tabletBankWritten:out stateDir:state done:^(NSString* problem) {
        [[NSFileManager defaultManager] removeItemAtPath:state error:nil];
        SVBankPage* page = weakSelf;
        if (problem != nil) { SVAlert(page.window, @"Банка за таблета", problem, YES); return; }
        page.shell.bankPath = out;
        [page.shell refreshAll];
        SVFlash(@"Банка за таблета", [NSString stringWithFormat:@"✓ Записана: %@ %@ – копирай я на таблета заедно с SILVETON_BLENDS.SVSET", out.lastPathComponent, summary], NO);
    }];
}

- (void)loadPressed:(id)sender {
    (void)sender;
    if (![self.shell confirmLosingChanges:@"Зареждането на друга банка"]) return;
    NSOpenPanel* panel = [NSOpenPanel openPanel];
    panel.title = @"Избери SILVETON банка (.sv)";
    panel.prompt = @"Зареди";
    panel.canChooseFiles = YES;
    panel.canChooseDirectories = NO;
    panel.allowsMultipleSelection = NO;
    panel.allowedFileTypes = @[@"sv", @"SV"];
    if ([panel runModal] != NSModalResponseOK || panel.URLs.count == 0U) return;
    NSString* path = ((NSURL*)panel.URLs.firstObject).path;
    SVManagerDocument* doc = self.shell.documentModel;
    SVProgressPanel* progress = [[SVProgressPanel alloc] initWithTitle:@"ЗАРЕЖДАНЕ НА БАНКА"];
    __block BOOL ok = NO;
    __block NSString* error = nil;
    __block NSString* summary = nil;
    [progress runWork:^(SVProgressPanel* p) {
        [p setFraction:0.5 text:[NSString stringWithFormat:@"Чете се %@ …", path.lastPathComponent]];
        ok = [doc loadBankAtPath:path error:&error summary:&summary];
        [p setFraction:1.0 text:@"Done"];
    }];
    if (!ok) { SVAlert(self.window, @"ЗАРЕДИ", error, YES); return; }
    self.shell.bankPath = path;
    [self.shell clearProcessedMarks];
    _last.stringValue = [NSString stringWithFormat:@"✓ Заредена: %@", summary ?: path.lastPathComponent];
    [self.shell refreshAll];
}

- (void)newProjectPressed:(id)sender {
    (void)sender;
    if (![self.shell confirmLosingChanges:@"Новият проект"]) return;
    if (!SVConfirm(self.window, @"Нов проект", @"Всичко в мениджъра се маха (файловете на диска, семплерът и запазените проекти остават).", @"Изчисти")) return;
    [self.shell.documentModel clearProject];
    self.shell.bankPath = nil;
    [self.shell clearProcessedMarks];
    _projectDir = nil;
    _last.stringValue = @"";
    [self.shell refreshAll];
}

// ---------------------------------------------------------------- client bank

- (void)chooseClient:(id)sender {
    (void)sender;
    NSOpenPanel* panel = [NSOpenPanel openPanel];
    panel.title = @"Банката на клиента (.sv)";
    panel.prompt = @"Избери";
    panel.canChooseFiles = YES;
    panel.canChooseDirectories = NO;
    panel.allowsMultipleSelection = NO;
    panel.allowedFileTypes = @[@"sv", @"SV"];
    if ([panel runModal] != NSModalResponseOK || panel.URLs.count == 0U) return;
    _clientPath = ((NSURL*)panel.URLs.firstObject).path;
    [[NSUserDefaults standardUserDefaults] setObject:_clientPath forKey:kPrefClientBank];
    [self refresh];
}

- (void)updateClientPressed:(id)sender {
    (void)sender;
    if (_clientPath.length == 0U) { [self chooseClient:nil]; if (_clientPath.length == 0U) return; }
    BankProject* ours = SVProjectOf(self.shell.documentModel);
    if (ours == nullptr || ours->sounds.empty()) { SVFlash(@"ОБНОВИ", @"В проекта няма звуци за добавяне.", YES); return; }
    if (!SVConfirm(self.window, @"Обнови банката на клиента",
                   [NSString stringWithFormat:@"Звуците от проекта (%lu) се добавят в:\n%@\nСтарата банка се пази като копие до нея.", static_cast<unsigned long>(ours->sounds.size()), _clientPath],
                   @"Обнови")) return;
    NSString* clientPath = _clientPath;
    SVProgressPanel* progress = [[SVProgressPanel alloc] initWithTitle:@"ОБНОВЯВАНЕ НА БАНКАТА НА КЛИЕНТА"];
    __block std::string error;
    __block std::size_t added = 0U, skipped = 0U;
    __block BOOL ok = NO;
    [progress runWork:^(SVProgressPanel* p) {
        [p setFraction:0.2 text:@"Чете се банката на клиента …"];
        auto loaded = SvBankReader::readFile(std::string(clientPath.fileSystemRepresentation), true);
        if (!loaded.ok()) { error = loaded.error; return; }
        [p setFraction:0.5 text:@"Добавят се звуците …"];
        if (!mergeInto(loaded.project, *ours, added, skipped, error)) return;
        if (added == 0U) { ok = YES; return; }
        // keep the old bank next to the new one
        NSString* backup = [[clientPath stringByDeletingPathExtension] stringByAppendingString:@" (старо).sv"];
        [[NSFileManager defaultManager] removeItemAtPath:backup error:nil];
        [[NSFileManager defaultManager] copyItemAtPath:clientPath toPath:backup error:nil];
        [p setFraction:0.7 text:@"Записва се …"];
        SvBuildStats stats{};
        ok = SvBankBuilder::writeAtomic(std::string(clientPath.fileSystemRepresentation), loaded.project, stats, error,
                                        [p](double fraction, const std::string& text) -> bool {
                                            [p setFraction:0.7 + 0.3 * fraction text:[NSString stringWithUTF8String:text.c_str()] ?: @""];
                                            return ![p stopRequested];
                                        }) ? YES : NO;
        [p setFraction:1.0 text:@"Done"];
    }];
    if (!ok) { SVAlert(self.window, @"ОБНОВИ", SVNs(error), YES); return; }
    _last.stringValue = [NSString stringWithFormat:@"✓ Банката на клиента е обновена: добавени %lu, пропуснати (вече ги има) %lu.", static_cast<unsigned long>(added), static_cast<unsigned long>(skipped)];
}
@end
