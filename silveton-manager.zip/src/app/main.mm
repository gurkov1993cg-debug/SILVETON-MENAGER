// SILVETON_LOOK_V1 - entry point and the menu bar (only commands that work).
#import <AppKit/AppKit.h>

#import "SVSamplerPage.h"

@interface SVAppDelegate : NSObject <NSApplicationDelegate>
- (void)showPageCommand:(NSMenuItem*)sender;
- (void)undoSampleEdit:(id)sender;
- (void)redoSampleEdit:(id)sender;
- (void)newProject:(id)sender;
- (void)openProject:(id)sender;
- (void)saveProject:(id)sender;
- (void)saveProjectAs:(id)sender;
- (void)writeTabletBank:(id)sender;
@end

namespace {

NSMenuItem* AddMenuCommand(NSMenu* menu, NSString* title, SEL action, NSString* keyEquivalent, NSEventModifierFlags modifiers, id target) {
    NSMenuItem* item = [[NSMenuItem alloc] initWithTitle:title action:action keyEquivalent:keyEquivalent ?: @""];
    item.target = target;
    if (keyEquivalent.length > 0U) item.keyEquivalentModifierMask = modifiers;
    [menu addItem:item];
    return item;
}

NSMenu* AddTopLevelMenu(NSMenu* mainMenu, NSString* title) {
    NSMenuItem* item = [[NSMenuItem alloc] initWithTitle:@"" action:nullptr keyEquivalent:@""];
    [mainMenu addItem:item];
    NSMenu* menu = [[NSMenu alloc] initWithTitle:title ?: @""];
    item.submenu = menu;
    return menu;
}

void InstallMainMenu(NSApplication* app, SVAppDelegate* delegate) {
    NSMenu* mainMenu = [[NSMenu alloc] initWithTitle:@""];
    app.mainMenu = mainMenu;

    NSMenu* applicationMenu = AddTopLevelMenu(mainMenu, @"SILVETON Manager");
    AddMenuCommand(applicationMenu, @"За SILVETON Manager", @selector(orderFrontStandardAboutPanel:), @"", 0, app);
    [applicationMenu addItem:[NSMenuItem separatorItem]];
    AddMenuCommand(applicationMenu, @"Скрий SILVETON Manager", @selector(hide:), @"h", NSEventModifierFlagCommand, app);
    AddMenuCommand(applicationMenu, @"Скрий другите", @selector(hideOtherApplications:), @"h", NSEventModifierFlagCommand | NSEventModifierFlagOption, app);
    AddMenuCommand(applicationMenu, @"Покажи всички", @selector(unhideAllApplications:), @"", 0, app);
    [applicationMenu addItem:[NSMenuItem separatorItem]];
    AddMenuCommand(applicationMenu, @"Изход", @selector(terminate:), @"q", NSEventModifierFlagCommand, app);

    // SILVETON_WORKFLOW_V1: the project is kept and opened like in every Mac program
    NSMenu* fileMenu = AddTopLevelMenu(mainMenu, @"Файл");
    AddMenuCommand(fileMenu, @"Нов проект", @selector(newProject:), @"n", NSEventModifierFlagCommand, delegate);
    AddMenuCommand(fileMenu, @"Отвори проект…", @selector(openProject:), @"o", NSEventModifierFlagCommand, delegate);
    [fileMenu addItem:[NSMenuItem separatorItem]];
    AddMenuCommand(fileMenu, @"Запази проекта", @selector(saveProject:), @"s", NSEventModifierFlagCommand, delegate);
    AddMenuCommand(fileMenu, @"Запази като…", @selector(saveProjectAs:), @"S", NSEventModifierFlagCommand | NSEventModifierFlagShift, delegate);
    [fileMenu addItem:[NSMenuItem separatorItem]];
    AddMenuCommand(fileMenu, @"Запиши банката за таблета…", @selector(writeTabletBank:), @"", 0, delegate);

    NSMenu* editMenu = AddTopLevelMenu(mainMenu, @"Редакция");
    AddMenuCommand(editMenu, @"Отмени редакция на семпъл", @selector(undoSampleEdit:), @"z", NSEventModifierFlagCommand, delegate);
    AddMenuCommand(editMenu, @"Повтори редакция на семпъл", @selector(redoSampleEdit:), @"Z", NSEventModifierFlagCommand | NSEventModifierFlagShift, delegate);
    [editMenu addItem:[NSMenuItem separatorItem]];
    AddMenuCommand(editMenu, @"Изрежи", @selector(cut:), @"x", NSEventModifierFlagCommand, nil);
    AddMenuCommand(editMenu, @"Копирай", @selector(copy:), @"c", NSEventModifierFlagCommand, nil);
    AddMenuCommand(editMenu, @"Постави", @selector(paste:), @"v", NSEventModifierFlagCommand, nil);
    AddMenuCommand(editMenu, @"Избери всичко", @selector(selectAll:), @"a", NSEventModifierFlagCommand, nil);

    NSMenu* pages = AddTopLevelMenu(mainMenu, @"Страници");
    NSString* const names[SVPageCount] = {@"1  СЕМПЛИ", @"2  ЗВУЦИ", @"3  ОБРАБОТКА", @"4  БАНКА", @"5  СЕМПЛЕР"};
    for (NSInteger i = 0; i < SVPageCount; ++i) {
        NSMenuItem* item = AddMenuCommand(pages, names[i], @selector(showPageCommand:), [NSString stringWithFormat:@"%ld", static_cast<long>(i + 1)], NSEventModifierFlagCommand, delegate);
        item.tag = i;
    }

    // SILVETON_MERGE_V1: the sampler can play another bank too (as in the Mac sampler: File > Choose bank)
    NSMenu* samplerMenu = AddTopLevelMenu(mainMenu, @"Семплер");
    AddMenuCommand(samplerMenu, @"Избери банка за семплера (SILVETON_BANK.sv)…", @selector(chooseBank:), @"", 0, [SVSamplerHost shared]);

    NSMenu* windowMenu = AddTopLevelMenu(mainMenu, @"Прозорец");
    AddMenuCommand(windowMenu, @"Смали", @selector(performMiniaturize:), @"m", NSEventModifierFlagCommand, nil);
    AddMenuCommand(windowMenu, @"Увеличи", @selector(performZoom:), @"", 0, nil);
    app.windowsMenu = windowMenu;
}

} // namespace

int main(int argc, const char* argv[]) {
    (void)argc;
    (void)argv;
    @autoreleasepool {
        NSApplication* app = [NSApplication sharedApplication];
        [app setActivationPolicy:NSApplicationActivationPolicyRegular];
        SVAppDelegate* delegate = [[SVAppDelegate alloc] init];
        app.delegate = delegate;
        InstallMainMenu(app, delegate);
        [app run];
        app.delegate = nil;
        (void)delegate;
    }
    return 0;
}
