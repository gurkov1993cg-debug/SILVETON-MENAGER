// SILVETON_LOOK_V1 - the one window of the Manager: top bar, four page keys on the left,
// the current page in the middle, one status line at the bottom.
#pragma once
#import <AppKit/AppKit.h>

@class SVManagerDocument;
@class SVSampleAuditionPlayer;
@class SVShellWindowController;

// Every page is a flipped view with these two calls.
@interface SVPageView : NSView
@property(nonatomic, weak, readonly) SVShellWindowController* shell;
- (instancetype)initWithShell:(SVShellWindowController*)shell frame:(NSRect)frame;
- (void)refresh;        // reload everything from the document
- (void)pageWillHide;   // stop sounds / timers
- (void)pageDidShow;
@end

// SILVETON_FIND_V1: the import of files is part of the СЕМПЛИ page now (ВНАСЯНЕ ОТ ДИСКА), so there are four pages
enum SVPageIndex { SVPageSamples = 0, SVPageSounds = 1, SVPageProcessing = 2, SVPageBank = 3 };

@interface SVShellWindowController : NSWindowController
@property(nonatomic, readonly) SVManagerDocument* documentModel;
@property(nonatomic, readonly) SVSampleAuditionPlayer* audition;
@property(nonatomic, copy) NSString* bankPath;        // where the bank was saved / loaded from (may be nil)
+ (SVShellWindowController*)shared;
- (void)showPage:(NSInteger)index;
- (NSInteger)currentPage;
- (void)refreshAll;                                    // pages + bars after any change
- (void)refreshBars;                                   // only the top / bottom text
- (void)markSampleIdsProcessed:(NSArray<NSNumber*>*)ids;
- (BOOL)isSampleIdProcessed:(NSNumber*)sampleId;
- (void)clearProcessedMarks;
- (void)appendImportLog:(NSString*)line;
- (NSArray<NSString*>*)importLog;
- (BOOL)confirmLosingChanges:(NSString*)action;      // NO = the user cancelled
- (void)selectSampleIndex:(NSUInteger)index;          // open the SAMPLES page on this sample
- (void)selectSoundIndex:(NSUInteger)index;           // open the SOUNDS page on this sound
- (void)flashStatus:(NSString*)title text:(NSString*)text;   // a short message in the status line
@end

// SILVETON_LOOK_V1: short messages go to the status line, not into a window that needs an extra press
#ifdef __cplusplus
extern "C" {
#endif
void SVFlash(NSString* title, NSString* text, BOOL beep);
#ifdef __cplusplus
}
#endif
