// SILVETON_LOOK_V1 - the one window of the Manager: top bar, five page keys on the left,
// the current page in the middle, one status line at the bottom.
#pragma once
#import <AppKit/AppKit.h>

@class SVManagerDocument;
@class SVSampleAuditionPlayer;
@class SVShellWindowController;

// Every page is a flipped view with these two calls.
@interface SVPageView : NSView
@property(nonatomic, weak, readonly) SVShellWindowController* shell;
- (instancetype)initWithShell:(SVShellWindowController*)shell frame:(NSRect)frame;
- (void)refresh;        // reload everything from the document
- (void)pageWillHide;   // stop sounds / timers
- (void)pageDidShow;
@end

enum SVPageIndex { SVPageImport = 0, SVPageSamples = 1, SVPageSounds = 2, SVPageProcessing = 3, SVPageBank = 4 };

@interface SVShellWindowController : NSWindowController
@property(nonatomic, readonly) SVManagerDocument* documentModel;
@property(nonatomic, readonly) SVSampleAuditionPlayer* audition;
@property(nonatomic, copy) NSString* bankPath;        // where the bank was saved / loaded from (may be nil)
+ (SVShellWindowController*)shared;
- (void)showPage:(NSInteger)index;
- (NSInteger)currentPage;
- (void)refreshAll;                                    // pages + bars after any change
- (void)refreshBars;                                   // only the top / bottom text
- (void)markSampleIdsProcessed:(NSArray<NSNumber*>*)ids;
- (BOOL)isSampleIdProcessed:(NSNumber*)sampleId;
- (void)clearProcessedMarks;
- (void)appendImportLog:(NSString*)line;
- (NSArray<NSString*>*)importLog;
- (BOOL)confirmLosingChanges:(NSString*)action;      // NO = the user cancelled
- (void)selectSampleIndex:(NSUInteger)index;          // open the SAMPLES page on this sample
- (void)selectSoundIndex:(NSUInteger)index;           // open the SOUNDS page on this sound
@end
