// SILVETON_LOOK_V1 - page 4 ОБРАБОТКА: which sounds, which functions (every one with its switch), START, analyser.
#import "SVShell.h"
#import "SVDocument.h"
#import "SVTheme.h"
#import "SVProgress.h"

#include "silveton/manager/SampleProcessing.h"
#include "silveton/manager/SpectrumAnalyzer.h"

#include <cstdint>
#include <utility>
#include <algorithm>
#include <atomic>
#include <cmath>
#include <map>
#include <set>
#include <string>
#include <vector>

using silveton::manager::BankProject;
using silveton::manager::SampleProcessingOptions;
using silveton::manager::SampleProcessingReport;
using silveton::manager::SampleProcessor;
using silveton::manager::SpectrumAnalyzer;
using silveton::manager::SpectrumPower;

// implemented in ProcessingController.mm
@interface SVProgressPanel : NSObject
- (instancetype)initWithTitle:(NSString*)title;
- (void)setFraction:(double)fraction text:(NSString*)text;
- (BOOL)stopRequested;
- (const std::atomic<bool>*)stopFlag;
- (void)runWork:(void (^)(SVProgressPanel* progress))work;
@end

@interface SVSpectrumView : NSView
@property(nonatomic) double slope;
@property(nonatomic) double range;
@property(nonatomic) BOOL showMax;
@property(nonatomic) BOOL showBefore;
@property(nonatomic) BOOL live;
- (void)setMain:(const std::vector<float>&)main max:(const std::vector<float>&)max before:(const std::vector<float>&)before;
- (void)setMainOnly:(const std::vector<float>&)main;
@end

namespace {
NSString* const kPrefConvert = @"SVProcessConvert48k";
NSString* const kPrefNormalize = @"SVProcessNormalize";
NSString* const kPrefTone = @"SVProcessEvenTone";
NSString* const kPrefLimiter = @"SVProcessSoftLimiter";
constexpr double kSmooth = 1.0 / 6.0;

struct Before { std::uint32_t rate{0U}; std::vector<float> average; };
}

@interface SVProcessingPage : SVPageView <NSTableViewDataSource, NSTableViewDelegate>
@end

@implementation SVProcessingPage {
    NSTableView* _soundTable;
    std::vector<BOOL> _ticked;             // per sound index
    SVToggle* _convert; SVToggle* _normalize; SVToggle* _tone; SVToggle* _limiter;
    SVBar* _bar;
    NSTextField* _status;
    // analyser
    SVSpectrumView* _spectrum;
    NSPopUpButton* _samplePopup;
    std::vector<NSUInteger> _popupSamples;
    NSTextField* _analysisInfo;
    SVKeyButton* _liveKey;
    NSTimer* _timer;
    std::vector<float> _mono;
    SpectrumPower _now;
    std::map<unsigned long long, Before> _beforeById;
    unsigned long long _selectedId;
}

- (instancetype)initWithShell:(SVShellWindowController*)shell frame:(NSRect)frame {
    self = [super initWithShell:shell frame:frame];
    if (self) { _selectedId = 0ULL; [self build]; }
    return self;
}

- (void)build {
    const NSRect b = self.bounds;
    NSUserDefaults* prefs = [NSUserDefaults standardUserDefaults];
    // ---- sounds
    SVPanel* left = [[SVPanel alloc] initWithFrame:NSMakeRect(16.0, 16.0, 330.0, b.size.height - 32.0) title:@"КОИ БЛЕНДИ ДА СЕ ОБРАБОТЯТ"];
    left.autoresizingMask = NSViewHeightSizable;
    _soundTable = [[NSTableView alloc] initWithFrame:NSZeroRect];
    SVStyleTable(_soundTable);
    _soundTable.headerView = nil;
    _soundTable.dataSource = self;
    _soundTable.delegate = self;
    [_soundTable addTableColumn:SVCheckColumn(@"on", 24.0)];
    [_soundTable addTableColumn:SVTextColumn(@"name", @"", 180.0)];
    NSTableColumn* info = SVTextColumn(@"info", @"", 90.0);
    [(NSTextFieldCell*)info.dataCell setTextColor:SVColDim()];
    [(NSTextFieldCell*)info.dataCell setAlignment:NSTextAlignmentRight];
    [_soundTable addTableColumn:info];
    NSScrollView* scroll = SVScroll(NSMakeRect(12.0, 32.0, 306.0, left.bounds.size.height - 32.0 - 110.0), _soundTable);
    scroll.autoresizingMask = NSViewHeightSizable;
    [left addSubview:scroll];
    CGFloat by = left.bounds.size.height - 100.0;
    SVKeyButton* all = [SVKeyButton keyWithFrame:NSMakeRect(12.0, by, 100.0, 34.0) title:@"ВСИЧКИ" kind:0 target:self action:@selector(tickAll:)];
    all.autoresizingMask = NSViewMinYMargin; [left addSubview:all];
    SVKeyButton* none = [SVKeyButton keyWithFrame:NSMakeRect(120.0, by, 100.0, 34.0) title:@"НИЩО" kind:0 target:self action:@selector(tickNone:)];
    none.autoresizingMask = NSViewMinYMargin; [left addSubview:none];
    NSTextField* note = SVLabel(NSMakeRect(12.0, by + 44.0, 306.0, 40.0), @"Обработката е фина. Файловете на диска не се пипат – само копието в проекта.", 11.0, NO, SVColDim());
    note.autoresizingMask = NSViewMinYMargin;
    note.lineBreakMode = NSLineBreakByWordWrapping;
    [note.cell setWraps:YES];
    [left addSubview:note];
    [self addSubview:left];

    // ---- functions
    const CGFloat mx = 362.0;
    SVPanel* mid = [[SVPanel alloc] initWithFrame:NSMakeRect(mx, 16.0, 400.0, b.size.height - 32.0) title:@"КАКВО ДА СЕ НАПРАВИ (всяко с ключ)"];
    mid.autoresizingMask = NSViewHeightSizable;
    CGFloat y = 40.0;
    auto fn = [&](NSString* title, NSString* text, NSString* pref) -> SVToggle* {
        SVToggle* t = [[SVToggle alloc] initWithFrame:NSMakeRect(12.0, y + 6.0, 44.0, 22.0)];
        t.on = [prefs boolForKey:pref];
        t.target = self; t.action = @selector(togglePressed:);
        [mid addSubview:t];
        [mid addSubview:SVLabel(NSMakeRect(68.0, y, 320.0, 20.0), title, 14.0, NO, SVColText())];
        [mid addSubview:SVLabel(NSMakeRect(68.0, y + 22.0, 320.0, 16.0), text, 11.0, NO, SVColDim())];
        y += 56.0;
        return t;
    };
    _convert = fn(@"Преобразуване на 48 kHz", @"за семплера, най-добро качество", kPrefConvert);
    _normalize = fn(@"Изравняване на силата –6 dB", @"по инструмент, всички тонове еднакво силни", kPrefNormalize);
    _tone = fn(@"Изравняване на тона", @"средна крива на инструмента, всеки тон към нея", kPrefTone);
    _limiter = fn(@"Мек лимитер само за пиковете", @"еднакъв клип на всички семпли", kPrefLimiter);
    const CGFloat sy = mid.bounds.size.height - 110.0;
    _bar = [[SVBar alloc] initWithFrame:NSMakeRect(12.0, sy, 376.0, 14.0)];
    _bar.autoresizingMask = NSViewMinYMargin;
    [mid addSubview:_bar];
    _status = SVLabel(NSMakeRect(12.0, sy + 20.0, 376.0, 18.0), @"0 % – нищо не е пуснато", 11.0, NO, SVColDim());
    _status.autoresizingMask = NSViewMinYMargin;
    [mid addSubview:_status];
    SVKeyButton* start = [SVKeyButton keyWithFrame:NSMakeRect(12.0, sy + 50.0, 160.0, 44.0) title:@"START" kind:1 target:self action:@selector(startPressed:)];
    start.textSize = 15.0; start.autoresizingMask = NSViewMinYMargin;
    [mid addSubview:start];
    NSTextField* stopNote = SVLabel(NSMakeRect(182.0, sy + 64.0, 206.0, 18.0), @"прозорчето има STOP", 11.0, NO, SVColDim());
    stopNote.autoresizingMask = NSViewMinYMargin;
    [mid addSubview:stopNote];
    [self addSubview:mid];

    // ---- analyser
    const CGFloat ax = mx + 416.0;
    SVPanel* right = [[SVPanel alloc] initWithFrame:NSMakeRect(ax, 16.0, b.size.width - ax - 16.0, b.size.height - 32.0) title:@"АНАЛИЗАТОР – ПРЕДИ / СЛЕД"];
    right.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    _spectrum = [[SVSpectrumView alloc] initWithFrame:NSMakeRect(12.0, 32.0, right.bounds.size.width - 24.0, right.bounds.size.height - 32.0 - 130.0)];
    _spectrum.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    _spectrum.slope = 4.5; _spectrum.range = 72.0; _spectrum.showMax = NO; _spectrum.showBefore = YES;
    [right addSubview:_spectrum];
    CGFloat ry = right.bounds.size.height - 90.0;
    _samplePopup = SVPopup(NSMakeRect(12.0, ry, right.bounds.size.width - 24.0, 26.0));
    _samplePopup.autoresizingMask = NSViewMinYMargin | NSViewWidthSizable;
    _samplePopup.target = self; _samplePopup.action = @selector(sampleChosen:);
    [right addSubview:_samplePopup];
    ry += 32.0;
    _analysisInfo = SVLabel(NSMakeRect(12.0, ry, right.bounds.size.width - 24.0, 18.0), @"", 11.0, NO, SVColDim());
    _analysisInfo.autoresizingMask = NSViewMinYMargin | NSViewWidthSizable;
    [right addSubview:_analysisInfo];
    ry += 24.0;
    _liveKey = [SVKeyButton keyWithFrame:NSMakeRect(12.0, ry, 110.0, 30.0) title:@"▶ НА ЖИВО" kind:0 target:self action:@selector(livePressed:)];
    _liveKey.autoresizingMask = NSViewMinYMargin;
    [right addSubview:_liveKey];
    SVKeyButton* avg = [SVKeyButton keyWithFrame:NSMakeRect(130.0, ry, 210.0, 30.0) title:@"СРЕДНО ЗА БЛЕНДАТА" kind:0 target:self action:@selector(averagePressed:)];
    avg.textSize = 11.0; avg.autoresizingMask = NSViewMinYMargin;
    [right addSubview:avg];
    [self addSubview:right];
}

// ---------------------------------------------------------------- data

- (void)refresh {
    SVManagerDocument* doc = self.shell.documentModel;
    const NSUInteger n = [doc soundCount];
    _ticked.resize(n, NO);
    [_soundTable reloadData];
    [self fillSamplePopup];
}

- (void)fillSamplePopup {
    [self stopLive];
    SVManagerDocument* doc = self.shell.documentModel;
    BankProject* project = SVProjectOf(doc);
    const NSInteger keep = _samplePopup.indexOfSelectedItem;
    const NSUInteger keepSample = keep >= 0 && static_cast<std::size_t>(keep) < _popupSamples.size() ? _popupSamples[static_cast<std::size_t>(keep)] : NSNotFound;
    [_samplePopup removeAllItems];
    _popupSamples.clear();
    if (project == nullptr) return;
    // samples of the ticked sounds (all samples when nothing is ticked)
    std::set<std::size_t> wanted;
    for (std::size_t si = 0U; si < project->sounds.size() && si < _ticked.size(); ++si) {
        if (!_ticked[si]) continue;
        for (const auto& layer : project->sounds[si].layers) {
            if (layer.multisampleIndex >= project->multisamples.size()) continue;
            for (const auto& z : project->multisamples[layer.multisampleIndex].zones) if (z.sampleIndex < project->samples.size()) wanted.insert(z.sampleIndex);
        }
    }
    if (wanted.empty()) for (std::size_t i = 0U; i < project->samples.size(); ++i) wanted.insert(i);
    NSInteger select = 0;
    for (std::size_t idx : wanted) {
        const auto& s = project->samples[idx];
        [_samplePopup.menu addItemWithTitle:[NSString stringWithFormat:@"%@   ·   %@", SVNs(s.name), SVNoteName(s.rootKey)] action:nullptr keyEquivalent:@""];
        if (idx == keepSample) select = static_cast<NSInteger>(_popupSamples.size());
        _popupSamples.push_back(idx);
    }
    if (!_popupSamples.empty()) [_samplePopup selectItemAtIndex:select];
    [self loadSelectedSample];
}

- (std::vector<std::size_t>)tickedSampleIndexes {
    std::vector<std::size_t> out;
    BankProject* project = SVProjectOf(self.shell.documentModel);
    if (project == nullptr) return out;
    std::set<std::size_t> set;
    for (std::size_t si = 0U; si < project->sounds.size() && si < _ticked.size(); ++si) {
        if (!_ticked[si]) continue;
        for (const auto& layer : project->sounds[si].layers) {
            if (layer.multisampleIndex >= project->multisamples.size()) continue;
            for (const auto& z : project->multisamples[layer.multisampleIndex].zones) if (z.sampleIndex < project->samples.size()) set.insert(z.sampleIndex);
        }
    }
    out.assign(set.begin(), set.end());
    return out;
}

- (NSInteger)numberOfRowsInTableView:(NSTableView*)tableView { (void)tableView; return static_cast<NSInteger>([self.shell.documentModel soundCount]); }

- (id)tableView:(NSTableView*)tableView objectValueForTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView;
    if (row < 0 || static_cast<NSUInteger>(row) >= [self.shell.documentModel soundCount]) return nil;
    NSString* ident = tableColumn.identifier;
    if ([ident isEqualToString:@"on"]) return @(static_cast<std::size_t>(row) < _ticked.size() && _ticked[static_cast<std::size_t>(row)] ? 1 : 0);
    NSDictionary* st = [self.shell.documentModel soundStateAtIndex:static_cast<NSUInteger>(row)];
    if ([ident isEqualToString:@"name"]) return st[@"name"];
    BankProject* project = SVProjectOf(self.shell.documentModel);
    std::set<std::size_t> samples;
    if (project != nullptr && static_cast<std::size_t>(row) < project->sounds.size()) {
        for (const auto& layer : project->sounds[static_cast<std::size_t>(row)].layers) {
            if (layer.multisampleIndex >= project->multisamples.size()) continue;
            for (const auto& z : project->multisamples[layer.multisampleIndex].zones) samples.insert(z.sampleIndex);
        }
    }
    return [NSString stringWithFormat:@"%lu семпла", static_cast<unsigned long>(samples.size())];
}

- (void)tableView:(NSTableView*)tableView setObjectValue:(id)object forTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView;
    if (![tableColumn.identifier isEqualToString:@"on"] || row < 0 || static_cast<std::size_t>(row) >= _ticked.size()) return;
    _ticked[static_cast<std::size_t>(row)] = [object integerValue] != 0 ? YES : NO;
    [self fillSamplePopup];
}

- (BOOL)tableView:(NSTableView*)tableView shouldSelectRow:(NSInteger)row { (void)tableView; (void)row; return NO; }

// the tick box must work even though the row itself is not selected
- (BOOL)tableView:(NSTableView*)tableView shouldTrackCell:(NSCell*)cell forTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView; (void)cell; (void)tableColumn; (void)row;
    return YES;
}

- (void)tickAll:(id)sender { (void)sender; for (std::size_t i = 0U; i < _ticked.size(); ++i) _ticked[i] = YES; [_soundTable reloadData]; [self fillSamplePopup]; }
- (void)tickNone:(id)sender { (void)sender; for (std::size_t i = 0U; i < _ticked.size(); ++i) _ticked[i] = NO; [_soundTable reloadData]; [self fillSamplePopup]; }

- (void)togglePressed:(SVToggle*)sender {
    (void)sender;
    NSUserDefaults* prefs = [NSUserDefaults standardUserDefaults];
    [prefs setBool:_convert.on forKey:kPrefConvert];
    [prefs setBool:_normalize.on forKey:kPrefNormalize];
    [prefs setBool:_tone.on forKey:kPrefTone];
    [prefs setBool:_limiter.on forKey:kPrefLimiter];
}

// ---------------------------------------------------------------- START

- (void)startPressed:(id)sender {
    (void)sender;
    SVManagerDocument* document = self.shell.documentModel;
    BankProject* project = SVProjectOf(document);
    if (project == nullptr || project->samples.empty()) { SVFlash(@"ОБРАБОТКА", @"Няма семпли. Първо внеси нещо (ВНАСЯНЕ).", YES); return; }
    const std::vector<std::size_t> only = [self tickedSampleIndexes];
    if (only.empty()) { SVFlash(@"ОБРАБОТКА", @"Тикни поне една бленда отляво.", YES); return; }
    SampleProcessingOptions options;
    options.convertTo48k = _convert.on;
    options.normalize = _normalize.on;
    options.normalizePerInstrument = true;
    options.evenTone = _tone.on;
    options.softLimiter = _limiter.on;
    if (!options.convertTo48k && !options.normalize && !options.evenTone && !options.softLimiter) { SVFlash(@"ОБРАБОТКА", @"Всичко е изключено. Включи поне една функция.", YES); return; }
    [self stopLive];
    SVProgressPanel* progress = [[SVProgressPanel alloc] initWithTitle:@"ОБРАБОТКА"];
    __block bool ok = false;
    __block SampleProcessingReport report;
    __block std::string error;
    __block std::vector<SpectrumPower> before;
    __block std::vector<unsigned long long> beforeIds;
    [progress runWork:^(SVProgressPanel* p) {
        for (std::size_t k : only) beforeIds.push_back(project->samples[k].sampleId != 0U ? project->samples[k].sampleId : 0x80000000ULL + k);
        before = SpectrumAnalyzer::analyseMany(*project, only, [p](double f) { [p setFraction:0.3 * f text:@"Анализ на спектъра (ПРЕДИ)"]; }, [p stopFlag]);
        if ([p stopRequested]) { ok = true; report.cancelled = true; return; }
        ok = SampleProcessor::process(*project, only, options,
                                      [p](double f, const std::string& stage) { [p setFraction:0.3 + 0.7 * f text:SVNs(stage)]; },
                                      [p stopFlag], report, error);
    }];
    if (!ok) { SVAlert(self.window, @"ОБРАБОТКА", SVNs(error), YES); return; }
    if (report.cancelled) { _status.stringValue = @"Спряно. Нищо не е променено."; _bar.fraction = 0.0; return; }
    // the audio changed: the sample undo history points at old frames, reset it but keep the bank
    BankProject saved = std::move(*project);
    [document clearProject];
    project = SVProjectOf(document);
    if (project != nullptr) *project = std::move(saved);
    [document markCurrentStateChanged];
    NSMutableArray<NSNumber*>* ids = [NSMutableArray array];
    for (std::size_t k = 0U; k < before.size() && k < beforeIds.size(); ++k) {
        [ids addObject:@(beforeIds[k])];
        if (before[k].empty()) continue;
        Before b; b.rate = before[k].sampleRate; b.average = std::move(before[k].average);
        _beforeById[beforeIds[k]] = std::move(b);
    }
    [self.shell markSampleIdsProcessed:ids];
    _bar.fraction = 1.0;
    NSMutableArray<NSString*>* parts = [NSMutableArray array];
    if (options.convertTo48k) [parts addObject:[NSString stringWithFormat:@"48 kHz: %lu", static_cast<unsigned long>(report.converted)]];
    if (options.normalize) [parts addObject:[NSString stringWithFormat:@"−6 dB: %lu", static_cast<unsigned long>(report.normalized)]];
    if (options.evenTone) [parts addObject:[NSString stringWithFormat:@"тон: %lu (пропуснати %lu)", static_cast<unsigned long>(report.toneAdjusted), static_cast<unsigned long>(report.skipped)]];
    if (options.softLimiter) [parts addObject:[NSString stringWithFormat:@"лимитер: %lu", static_cast<unsigned long>(report.limited)]];
    _status.stringValue = [NSString stringWithFormat:@"100 % – готово.  %@", [parts componentsJoinedByString:@" · "]];
    [self.shell refreshAll];
}

// ---------------------------------------------------------------- analyser

- (void)sampleChosen:(id)sender { (void)sender; [self loadSelectedSample]; }

- (void)loadSelectedSample {
    [self stopLive];
    _mono.clear();
    _now = SpectrumPower{};
    _selectedId = 0ULL;
    BankProject* project = SVProjectOf(self.shell.documentModel);
    const NSInteger i = _samplePopup.indexOfSelectedItem;
    if (project == nullptr || i < 0 || static_cast<std::size_t>(i) >= _popupSamples.size()) { [self redraw]; _analysisInfo.stringValue = @""; return; }
    const std::size_t idx = _popupSamples[static_cast<std::size_t>(i)];
    if (idx >= project->samples.size()) { [self redraw]; return; }
    const auto& sample = project->samples[idx];
    _mono = SpectrumAnalyzer::monoMix(sample);
    _now = SpectrumAnalyzer::analyse(sample);
    _selectedId = sample.sampleId != 0U ? sample.sampleId : 0x80000000ULL + idx;
    const double peakDb = _now.peak > 1e-6F ? 20.0 * std::log10(static_cast<double>(_now.peak)) : -120.0;
    const auto found = _beforeById.find(_selectedId);
    _analysisInfo.stringValue = found != _beforeById.end()
        ? [NSString stringWithFormat:@"Семпъл: %@ · пик сега %.1f dB · сивата крива е преди обработката", SVNs(sample.name), peakDb]
        : [NSString stringWithFormat:@"Семпъл: %@ · пик %.1f dB · (още не е обработван)", SVNs(sample.name), peakDb];
    [self redraw];
}

- (void)redraw {
    std::vector<float> before;
    const auto found = _beforeById.find(_selectedId);
    if (found != _beforeById.end()) before = SpectrumAnalyzer::toCurve(found->second.average, found->second.rate, kSmooth);
    const std::vector<float> main = _now.empty() ? std::vector<float>() : SpectrumAnalyzer::toCurve(_now.average, _now.sampleRate, kSmooth);
    const std::vector<float> mx = _now.empty() ? std::vector<float>() : SpectrumAnalyzer::toCurve(_now.maximum, _now.sampleRate, kSmooth);
    _spectrum.live = NO;
    [_spectrum setMain:main max:mx before:before];
}

- (void)livePressed:(id)sender {
    (void)sender;
    if (_timer != nil) { [self stopLive]; return; }
    BankProject* project = SVProjectOf(self.shell.documentModel);
    const NSInteger i = _samplePopup.indexOfSelectedItem;
    if (project == nullptr || i < 0 || static_cast<std::size_t>(i) >= _popupSamples.size()) return;
    NSString* error = nil;
    NSDictionary* state = [self.shell.documentModel auditionStateAtIndex:_popupSamples[static_cast<std::size_t>(i)] error:&error];
    if (state == nil || ![self.shell.audition playState:state loopOnly:NO error:&error]) { SVAlert(self.window, @"Пускане", error, YES); return; }
    _liveKey.kind = 1; _liveKey.title = @"■ СТОП";
    _timer = [NSTimer scheduledTimerWithTimeInterval:1.0 / 25.0 target:self selector:@selector(tick:) userInfo:nil repeats:YES];
}

- (void)tick:(NSTimer*)timer {
    (void)timer;
    UInt64 frame = 0U;
    if (![self.shell.audition currentPlayFrame:&frame]) { [self stopLive]; return; }
    const std::vector<float> power = SpectrumAnalyzer::powerAt(_mono, frame);
    if (power.empty()) return;
    _spectrum.live = YES;
    [_spectrum setMainOnly:SpectrumAnalyzer::toCurve(power, _now.sampleRate, kSmooth)];
}

- (void)stopLive {
    [self.shell.audition stop];
    [_timer invalidate]; _timer = nil;
    _liveKey.kind = 0; _liveKey.title = @"▶ НА ЖИВО";
    [self redraw];
}

- (void)averagePressed:(id)sender {
    (void)sender;
    BankProject* project = SVProjectOf(self.shell.documentModel);
    if (project == nullptr || _popupSamples.empty()) return;
    [self stopLive];
    std::vector<std::size_t> idx(_popupSamples.begin(), _popupSamples.end());
    std::vector<SpectrumPower> all = SpectrumAnalyzer::analyseMany(*project, idx, [](double) {}, nullptr);
    std::vector<double> acc; std::uint32_t rate = 0U; std::size_t count = 0U;
    for (const auto& p : all) {
        if (p.empty()) continue;
        if (acc.empty()) { acc.assign(p.average.size(), 0.0); rate = p.sampleRate; }
        if (p.average.size() != acc.size()) continue;
        for (std::size_t k = 0U; k < acc.size(); ++k) acc[k] += p.average[k];
        ++count;
    }
    if (count == 0U) return;
    std::vector<float> mean(acc.size());
    for (std::size_t k = 0U; k < acc.size(); ++k) mean[k] = static_cast<float>(acc[k] / static_cast<double>(count));
    _spectrum.live = NO;
    [_spectrum setMain:SpectrumAnalyzer::toCurve(mean, rate, kSmooth) max:std::vector<float>() before:std::vector<float>()];
    _analysisInfo.stringValue = [NSString stringWithFormat:@"Средна крива на %lu семпла (това е кривата, към която „изравняване на тона“ ги дърпа).", static_cast<unsigned long>(count)];
}

- (void)pageWillHide { [self stopLive]; }
@end
