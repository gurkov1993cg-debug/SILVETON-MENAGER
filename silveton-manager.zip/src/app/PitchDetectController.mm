// SILVETON_PITCH_V1 - РАЗПОЗНАТИ ТОНОВЕ window: reads which note every sample in the project is (from the
// sound itself, with progress and STOP), shows it next to the current root key, and changes only the
// ticked samples when ПРИЕМИ ОТБЕЛЯЗАНИТЕ is pressed.
#import "SVDocument.h"
#import "SVProgress.h"
#import "SVTheme.h"

#include "silveton/manager/ManagerTypes.h"
#include "silveton/manager/PitchDetector.h"

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <string>
#include <utility>
#include <vector>

using silveton::manager::BankProject;
using silveton::manager::PitchDetector;
using silveton::manager::PitchResult;

@interface SVProgressPanel : NSObject
- (instancetype)initWithTitle:(NSString*)title;
- (void)setFraction:(double)fraction text:(NSString*)text;
- (BOOL)stopRequested;
- (void)runWork:(void (^)(SVProgressPanel* progress))work;
@end

namespace {

struct PitchRow {
    std::size_t sampleIndex{0U};
    NSString* name{nil};
    int rootKey{60};
    float fineNow{0.0F};
    PitchResult result{};
    BOOL ticked{NO};
};

} // namespace

@interface SVPitchResultsPanel : NSObject <NSTableViewDataSource, NSTableViewDelegate>
- (instancetype)initWithDocument:(SVManagerDocument*)document rows:(std::vector<PitchRow>)rows;
- (BOOL)run;   // modal; YES = something was changed
@end

@implementation SVPitchResultsPanel {
    SVManagerDocument* _document;
    std::vector<PitchRow> _rows;
    NSPanel* _panel;
    NSTableView* _table;
    NSTextField* _count;
    BOOL _changed;
}

- (instancetype)initWithDocument:(SVManagerDocument*)document rows:(std::vector<PitchRow>)rows {
    self = [super init];
    if (self) {
        _document = document;
        _rows = std::move(rows);
        _changed = NO;
        [self buildPanel];
    }
    return self;
}

- (void)buildPanel {
    _panel = [[NSPanel alloc] initWithContentRect:NSMakeRect(0.0, 0.0, 760.0, 560.0)
                                        styleMask:(NSWindowStyleMaskTitled | NSWindowStyleMaskResizable)
                                          backing:NSBackingStoreBuffered
                                            defer:NO];
    _panel.title = @"РАЗПОЗНАТИ ТОНОВЕ";
    _panel.minSize = NSMakeSize(700.0, 420.0);
    _panel.backgroundColor = SVColBackground();
    NSView* c = _panel.contentView;
    NSTextField* t = SVLabel(NSMakeRect(20.0, 524.0, 720.0, 22.0), @"РАЗПОЗНАТИ ТОНОВЕ", 16.0, YES, SVColAmber());
    t.autoresizingMask = NSViewMinYMargin | NSViewWidthSizable;
    [c addSubview:t];
    NSTextField* h = SVLabel(NSMakeRect(20.0, 502.0, 720.0, 18.0),
                             @"Тонът е прочетен от самия звук. Отметнати са семплите, при които разпознатият тон е различен от основния. Нищо не се променя без ПРИЕМИ.",
                             11.0, NO, SVColDim());
    h.autoresizingMask = NSViewMinYMargin | NSViewWidthSizable;
    [c addSubview:h];

    // column captions (the tables have no header in this look)
    struct Cap { CGFloat x; CGFloat w; NSString* text; };
    const Cap caps[] = {{54.0, 290.0, @"семпъл"}, {346.0, 96.0, @"сега"}, {448.0, 96.0, @"разпознат"}, {550.0, 80.0, @"отклонение"}, {636.0, 90.0, @"сигурност"}};
    for (const Cap& cap : caps) {
        NSTextField* l = SVLabel(NSMakeRect(cap.x, 478.0, cap.w, 16.0), cap.text, 10.0, YES, SVColDim());
        l.autoresizingMask = NSViewMinYMargin;
        [c addSubview:l];
    }

    _table = [[NSTableView alloc] initWithFrame:NSZeroRect];
    SVStyleTable(_table);
    _table.headerView = nil;
    _table.dataSource = self;
    _table.delegate = self;
    _table.allowsEmptySelection = YES;
    [_table addTableColumn:SVCheckColumn(@"on", 26.0)];
    [_table addTableColumn:SVTextColumn(@"name", @"", 286.0)];
    [_table addTableColumn:SVTextColumn(@"now", @"", 96.0)];
    [_table addTableColumn:SVTextColumn(@"found", @"", 96.0)];
    [_table addTableColumn:SVTextColumn(@"cents", @"", 80.0)];
    [_table addTableColumn:SVTextColumn(@"conf", @"", 90.0)];
    NSScrollView* scroll = SVScroll(NSMakeRect(20.0, 110.0, 720.0, 366.0), _table);
    scroll.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    [c addSubview:scroll];

    SVKeyButton* all = [SVKeyButton keyWithFrame:NSMakeRect(20.0, 66.0, 100.0, 34.0) title:@"ВСИЧКИ" kind:0 target:self action:@selector(tickAll:)];
    all.autoresizingMask = NSViewMaxYMargin; all.textSize = 11.0; [c addSubview:all];
    SVKeyButton* none = [SVKeyButton keyWithFrame:NSMakeRect(128.0, 66.0, 100.0, 34.0) title:@"НИКОЙ" kind:0 target:self action:@selector(tickNone:)];
    none.autoresizingMask = NSViewMaxYMargin; none.textSize = 11.0; [c addSubview:none];
    SVKeyButton* diff = [SVKeyButton keyWithFrame:NSMakeRect(236.0, 66.0, 150.0, 34.0) title:@"САМО РАЗЛИЧНИТЕ" kind:0 target:self action:@selector(tickDifferent:)];
    diff.autoresizingMask = NSViewMaxYMargin; diff.textSize = 11.0; [c addSubview:diff];
    _count = SVLabel(NSMakeRect(400.0, 74.0, 340.0, 18.0), @"", 11.0, NO, SVColDim());
    _count.autoresizingMask = NSViewMaxYMargin | NSViewWidthSizable;
    _count.alignment = NSTextAlignmentRight;
    [c addSubview:_count];

    SVKeyButton* close = [SVKeyButton keyWithFrame:NSMakeRect(440.0, 18.0, 110.0, 34.0) title:@"ЗАТВОРИ" kind:0 target:self action:@selector(closePressed:)];
    close.autoresizingMask = NSViewMaxYMargin | NSViewMinXMargin;
    close.keyEquivalent = @"\x1b";
    [c addSubview:close];
    SVKeyButton* accept = [SVKeyButton keyWithFrame:NSMakeRect(558.0, 18.0, 182.0, 34.0) title:@"ПРИЕМИ ОТБЕЛЯЗАНИТЕ" kind:1 target:self action:@selector(acceptPressed:)];
    accept.autoresizingMask = NSViewMaxYMargin | NSViewMinXMargin;
    accept.textSize = 11.0;
    [c addSubview:accept];
    [self updateCount];
}

- (void)updateCount {
    std::size_t ticked = 0U, found = 0U, different = 0U;
    for (const PitchRow& r : _rows) {
        if (r.ticked) ++ticked;
        if (r.result.found) { ++found; if (r.result.midi != r.rootKey) ++different; }
    }
    _count.stringValue = [NSString stringWithFormat:@"%lu семпла · разпознати %lu · различни от основния тон %lu · отбелязани %lu",
                                                    static_cast<unsigned long>(_rows.size()), static_cast<unsigned long>(found),
                                                    static_cast<unsigned long>(different), static_cast<unsigned long>(ticked)];
}

- (void)tickAll:(id)sender { (void)sender; for (PitchRow& r : _rows) r.ticked = r.result.found ? YES : NO; [_table reloadData]; [self updateCount]; }
- (void)tickNone:(id)sender { (void)sender; for (PitchRow& r : _rows) r.ticked = NO; [_table reloadData]; [self updateCount]; }
- (void)tickDifferent:(id)sender {
    (void)sender;
    for (PitchRow& r : _rows) r.ticked = (r.result.found && r.result.midi != r.rootKey) ? YES : NO;
    [_table reloadData]; [self updateCount];
}
- (void)closePressed:(id)sender { (void)sender; [NSApp stopModal]; }

// Root key = the detected note; fine tune against the detected offset (+4 c sharp -> fine -4 c).
- (void)acceptPressed:(id)sender {
    (void)sender;
    std::size_t changed = 0U;
    NSString* firstError = nil;
    for (PitchRow& r : _rows) {
        if (!r.ticked || !r.result.found) continue;
        const int midi = std::clamp(r.result.midi, 0, 127);
        const float fine = static_cast<float>(-std::lround(static_cast<double>(r.result.cents)));
        NSString* error = nil;
        if ([_document setTuningForSampleAtIndex:r.sampleIndex rootKey:static_cast<uint8_t>(midi) cents:fine error:&error]) {
            r.rootKey = midi; r.fineNow = fine; r.ticked = NO;
            ++changed;
        } else if (firstError == nil) {
            firstError = error ?: @"?";
        }
    }
    if (changed > 0U) _changed = YES;
    [_table reloadData];
    [self updateCount];
    if (firstError != nil) { SVAlert(_panel, @"Тон", firstError, YES); return; }
    if (changed == 0U) { SVAlert(_panel, @"Тон", @"Няма отбелязани семпли.", NO); return; }
    [NSApp stopModal];
}

- (BOOL)run {
    [_panel center];
    [NSApp runModalForWindow:_panel];
    [_panel orderOut:nil];
    return _changed;
}

// ---------------------------------------------------------------- table

- (NSInteger)numberOfRowsInTableView:(NSTableView*)tableView { (void)tableView; return static_cast<NSInteger>(_rows.size()); }

- (id)tableView:(NSTableView*)tableView objectValueForTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView;
    if (row < 0 || static_cast<std::size_t>(row) >= _rows.size()) return nil;
    const PitchRow& r = _rows[static_cast<std::size_t>(row)];
    NSString* ident = tableColumn.identifier;
    if ([ident isEqualToString:@"on"]) return r.result.found ? @(r.ticked ? 1 : 0) : nil;
    if ([ident isEqualToString:@"name"]) return r.name;
    if ([ident isEqualToString:@"now"]) {
        if (std::fabs(r.fineNow) >= 0.5F) return [NSString stringWithFormat:@"%@ (%d) %+.0f c", SVNoteName(r.rootKey), r.rootKey, static_cast<double>(r.fineNow)];
        return [NSString stringWithFormat:@"%@ (%d)", SVNoteName(r.rootKey), r.rootKey];
    }
    if (!r.result.found) return [ident isEqualToString:@"found"] ? @"— няма ясен тон" : @"";
    if ([ident isEqualToString:@"found"]) return [NSString stringWithFormat:@"%@ (%d)", SVNoteName(r.result.midi), r.result.midi];
    if ([ident isEqualToString:@"cents"]) return [NSString stringWithFormat:@"%+.0f c", static_cast<double>(r.result.cents)];
    if ([ident isEqualToString:@"conf"]) return [NSString stringWithFormat:@"%.0f %%", static_cast<double>(r.result.confidence) * 100.0];
    return nil;
}

- (void)tableView:(NSTableView*)tableView setObjectValue:(id)object forTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView;
    if (![tableColumn.identifier isEqualToString:@"on"]) return;
    if (row < 0 || static_cast<std::size_t>(row) >= _rows.size()) return;
    PitchRow& r = _rows[static_cast<std::size_t>(row)];
    if (!r.result.found) return;
    r.ticked = [object integerValue] != 0 ? YES : NO;
    [self updateCount];
}

- (BOOL)tableView:(NSTableView*)tableView shouldSelectRow:(NSInteger)row { (void)tableView; (void)row; return NO; }

// the tick box must work even though the row itself is not selected
- (BOOL)tableView:(NSTableView*)tableView shouldTrackCell:(NSCell*)cell forTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView; (void)cell; (void)tableColumn; (void)row;
    return YES;
}

- (void)tableView:(NSTableView*)tableView willDisplayCell:(id)cell forTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView;
    if (![cell isKindOfClass:[NSTextFieldCell class]] || row < 0 || static_cast<std::size_t>(row) >= _rows.size()) return;
    const PitchRow& r = _rows[static_cast<std::size_t>(row)];
    NSTextFieldCell* text = cell;
    NSString* ident = tableColumn.identifier;
    if ([ident isEqualToString:@"found"]) {
        if (!r.result.found) text.textColor = SVColDim();
        else text.textColor = r.result.midi == r.rootKey ? SVColGreen() : SVColAmberLight();
    } else if ([ident isEqualToString:@"conf"]) {
        text.textColor = (r.result.found && r.result.confidence < 0.5F) ? SVColRed() : SVColDim();
    } else {
        text.textColor = [ident isEqualToString:@"name"] ? SVColText() : SVColDim();
    }
}
@end

// ---------------------------------------------------------------- entry point

BOOL SVDetectPitchForAllSamples(SVManagerDocument* document, NSWindow* parent) {
    (void)parent;
    BankProject* project = SVProjectOf(document);
    if (project == nullptr || project->samples.empty()) return NO;
    const std::size_t count = project->samples.size();
    std::vector<PitchRow> rows(count);
    for (std::size_t i = 0U; i < count; ++i) {
        const auto& s = project->samples[i];
        rows[i].sampleIndex = i;
        rows[i].name = SVNs(s.name);
        rows[i].rootKey = static_cast<int>(s.rootKey);
        rows[i].fineNow = s.fineTuneCents;
    }
    // detection on a background thread; the project is only read while the progress window is up
    __block std::vector<PitchResult> results(count);
    __block BOOL stopped = NO;
    SVProgressPanel* progress = [[SVProgressPanel alloc] initWithTitle:@"РАЗПОЗНАВАНЕ НА ТОНА"];
    [progress runWork:^(SVProgressPanel* p) {
        for (std::size_t i = 0U; i < count; ++i) {
            if ([p stopRequested]) { stopped = YES; break; }
            [p setFraction:static_cast<double>(i) / static_cast<double>(count) text:[NSString stringWithFormat:@"%lu / %lu   %@", static_cast<unsigned long>(i + 1U), static_cast<unsigned long>(count), rows[i].name]];
            results[i] = PitchDetector::detect(project->samples[i]);
        }
        [p setFraction:1.0 text:stopped ? @"Спряно" : @"Готово"];
    }];
    if (stopped) return NO;
    for (std::size_t i = 0U; i < count; ++i) {
        rows[i].result = results[i];
        rows[i].ticked = (results[i].found && results[i].midi != rows[i].rootKey) ? YES : NO;
    }
    SVPitchResultsPanel* panel = [[SVPitchResultsPanel alloc] initWithDocument:document rows:std::move(rows)];
    return [panel run];
}
