// SILVETON_AUTOMAP_V1 - the window that shows which note every loose sample was heard as and where it lands
// on the keyboard. Returns the rows to build (notes may have been corrected by hand), or nil on cancel.
#pragma once
#import <AppKit/AppKit.h>

@class SVManagerDocument;

#ifdef __cplusplus
extern "C" {
#endif
NSArray<NSDictionary<NSString*, id>*>* SVReviewAutoMap(NSWindow* parent,
                                                       SVManagerDocument* document,
                                                       NSArray<NSDictionary<NSString*, id>*>* rows,
                                                       NSString** chosenName);
#ifdef __cplusplus
}
#endif
