// SILVETON_AUTOMAP_V1 - the window that shows which note every loose sample was heard as and where it lands
// on the keyboard. Returns the rows to build (notes may have been corrected by hand), or nil on cancel.
// SILVETON_THIN_V1 - by choice the window can also give notes away to a neighbour: those samples come back in
// `removeSamples` (empty unless the user chose to thin the notes) and are to leave the bank.
#pragma once
#import <AppKit/AppKit.h>

@class SVManagerDocument;

#ifdef __cplusplus
extern "C" {
#endif
NSArray<NSDictionary<NSString*, id>*>* SVReviewAutoMap(NSWindow* parent,
                                                       SVManagerDocument* document,
                                                       NSArray<NSDictionary<NSString*, id>*>* rows,
                                                       NSString** chosenName,
                                                       BOOL* removeOldSingles,
                                                       NSArray<NSNumber*>** removeSamples);
#ifdef __cplusplus
}
#endif
