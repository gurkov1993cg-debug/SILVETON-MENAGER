// SILVETON_LOOK_V1 - one shared declaration of the Manager document (implemented in ManagerDocument*.mm)
// and direct access to its project for the few things the pages compute themselves.
#pragma once
#import <Foundation/Foundation.h>
#import <objc/runtime.h>

#include "silveton/manager/ManagerTypes.h"

#include <cstddef>
#include <string>

@interface SVManagerDocument : NSObject
- (BOOL)importPaths:(NSArray<NSString*>*)paths error:(NSString**)error;
- (BOOL)buildBankAtPath:(NSString*)path error:(NSString**)error summary:(NSString**)summary;
- (BOOL)buildBankAtPath:(NSString*)path progress:(BOOL (^)(double fraction, NSString* text))progress error:(NSString**)error summary:(NSString**)summary;
- (BOOL)loadBankAtPath:(NSString*)path error:(NSString**)error summary:(NSString**)summary;
- (NSString*)statusSummary;
- (void)clearProject;
- (BOOL)hasUnsavedChanges;
- (void)markCurrentStateSaved;
- (void)markCurrentStateChanged;

- (NSUInteger)sampleCount;
- (NSDictionary<NSString*, id>*)sampleStateAtIndex:(NSUInteger)index;
- (NSDictionary<NSString*, id>*)auditionStateAtIndex:(NSUInteger)index error:(NSString**)error;
- (NSArray<NSNumber*>*)waveformAtIndex:(NSUInteger)index pointCount:(NSUInteger)pointCount error:(NSString**)error;
// SILVETON_ZOOM_V1: only frames [startFrame, endFrame); one point per frame when there are fewer frames than pointCount.
- (NSArray<NSNumber*>*)waveformAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame pointCount:(NSUInteger)pointCount error:(NSString**)error;
- (BOOL)trimSampleAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error;
// SILVETON_CUT_V1: the marked part is thrown away and what is left is joined
- (BOOL)cutOutSampleAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error;
// SILVETON_PITCHCURVE_V1: semitones at evenly spaced points over the whole sample (first = start, last = end)
- (BOOL)applyPitchCurveForSampleAtIndex:(NSUInteger)index curve:(NSArray<NSNumber*>*)curve error:(NSString**)error;
// SILVETON_CLEANWAVE_V1: write the sample out again as a clean wave; amount is 0...1 at evenly spaced points
- (BOOL)cleanWaveForSampleAtIndex:(NSUInteger)index amount:(NSArray<NSNumber*>*)amount overtones:(NSInteger)overtones edges:(float)edges error:(NSString**)error;
// SILVETON_ATTACK_V1: rows with index, name, leadIn, cut (0...1 inside the picture), window (seconds), points.
// SILVETON_ATTACK_V2: only for the samples in indexes (the marked blend), never for the whole project.
- (NSArray<NSDictionary<NSString*, id>*>*)lateStartReportForSampleIndexes:(NSArray<NSNumber*>*)indexes points:(NSUInteger)points;
// SILVETON_AUTOMAP_V1: loose samples (no multisample uses them), the heard plan, a re-arrange after a hand edit, and the build
- (NSArray<NSNumber*>*)looseSampleIndexes;
- (NSArray<NSDictionary<NSString*, id>*>*)autoMapPlanForSampleIndexes:(NSArray<NSNumber*>*)indexes;
- (NSArray<NSDictionary<NSString*, id>*>*)autoMapArrangeRows:(NSArray<NSDictionary<NSString*, id>*>*)rows;
- (BOOL)buildAutoMapWithRows:(NSArray<NSDictionary<NSString*, id>*>*)rows name:(NSString*)name createdIndex:(NSUInteger*)createdIndex error:(NSString**)error;
- (BOOL)buildAutoMapWithRows:(NSArray<NSDictionary<NSString*, id>*>*)rows name:(NSString*)name removeOldSingles:(BOOL)removeOldSingles createdIndex:(NSUInteger*)createdIndex removedOldCount:(NSUInteger*)removedOldCount error:(NSString**)error;
// SILVETON_THIN_V1: which notes a neighbour can play for (mode 0 every key, 1 one for 2 keys, 2 one for 3 keys, 3 manager decides).
// The rows come back in the same order with "drop", "why", "coverNote" added and the keys laid out over the samples that stay.
- (id)autoMapThinMemory;
- (NSArray<NSDictionary<NSString*, id>*>*)autoMapThinRows:(NSArray<NSDictionary<NSString*, id>*>*)rows ticked:(NSArray<NSNumber*>*)ticked mode:(NSInteger)mode memory:(id)memory summary:(NSDictionary<NSString*, id>**)summary;
- (BOOL)buildAutoMapWithRows:(NSArray<NSDictionary<NSString*, id>*>*)rows name:(NSString*)name removeOldSingles:(BOOL)removeOldSingles removeSamples:(NSArray<NSNumber*>*)removeSamples createdIndex:(NSUInteger*)createdIndex removedOldCount:(NSUInteger*)removedOldCount removedSampleCount:(NSUInteger*)removedSampleCount freedBytes:(double*)freedBytes error:(NSString**)error;
- (NSInteger)noteFromText:(NSString*)text;
- (NSDictionary<NSString*, id>*)trimLateStartsForSampleIndexes:(NSArray<NSNumber*>*)indexes;
// cut exactly where told (the hand-moved line), moved to the nearest zero crossing first
- (NSDictionary<NSString*, id>*)trimSampleStartsWithIndexes:(NSArray<NSNumber*>*)indexes startFrames:(NSArray<NSNumber*>*)startFrames;
- (NSArray<NSNumber*>*)cleanWavePreviewAtIndex:(NSUInteger)index amount:(NSArray<NSNumber*>*)amount overtones:(NSInteger)overtones edges:(float)edges startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame pointCount:(NSUInteger)pointCount error:(NSString**)error;
- (BOOL)setLoopForSampleAtIndex:(NSUInteger)index enabled:(BOOL)enabled startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error;
- (BOOL)applyLoopCrossfadeForSampleAtIndex:(NSUInteger)index frames:(uint32_t)frames error:(NSString**)error;
- (BOOL)reverseSampleAtIndex:(NSUInteger)index error:(NSString**)error;
- (BOOL)applyGainForSampleAtIndex:(NSUInteger)index gainDb:(float)gainDb error:(NSString**)error;
- (BOOL)normalizeSampleAtIndex:(NSUInteger)index targetPeakDb:(float)targetPeakDb error:(NSString**)error;
- (BOOL)fadeInSampleAtIndex:(NSUInteger)index frames:(uint64_t)frames error:(NSString**)error;
- (BOOL)fadeOutSampleAtIndex:(NSUInteger)index frames:(uint64_t)frames error:(NSString**)error;
- (BOOL)setTuningForSampleAtIndex:(NSUInteger)index rootKey:(uint8_t)rootKey cents:(float)cents error:(NSString**)error;
// SILVETON_PITCH_V1: which note the recording is (nil = no clear note). Keys hz, midi, cents, confidence, name. Changes nothing.
- (NSDictionary<NSString*, id>*)detectPitchForSampleAtIndex:(NSUInteger)index;
- (uint64_t)nearestZeroCrossingForSampleAtIndex:(NSUInteger)index frame:(uint64_t)frame radius:(uint64_t)radius;
- (BOOL)canUndoSampleEdit;
- (BOOL)canRedoSampleEdit;
- (BOOL)undoSampleEdit:(NSString**)error;
- (BOOL)redoSampleEdit:(NSString**)error;

- (NSUInteger)multisampleCount;
- (NSDictionary<NSString*, id>*)multisampleStateAtIndex:(NSUInteger)index;
- (NSArray<NSDictionary<NSString*, id>*>*)zoneStatesForMultisampleAtIndex:(NSUInteger)index;
- (BOOL)createMultisampleNamed:(NSString*)name sampleIndexes:(NSIndexSet*)sampleIndexes error:(NSString**)error createdIndex:(NSUInteger*)createdIndex;
- (BOOL)renameMultisampleAtIndex:(NSUInteger)index name:(NSString*)name error:(NSString**)error;
- (BOOL)addZoneToMultisampleAtIndex:(NSUInteger)multisampleIndex sampleIndex:(NSUInteger)sampleIndex error:(NSString**)error;
- (BOOL)removeZoneFromMultisampleAtIndex:(NSUInteger)multisampleIndex zoneIndex:(NSUInteger)zoneIndex error:(NSString**)error;
- (BOOL)updateZoneAtMultisampleIndex:(NSUInteger)multisampleIndex
                           zoneIndex:(NSUInteger)zoneIndex
                         sampleIndex:(NSUInteger)sampleIndex
                              keyLow:(NSUInteger)keyLow
                             keyHigh:(NSUInteger)keyHigh
                         velocityLow:(NSUInteger)velocityLow
                        velocityHigh:(NSUInteger)velocityHigh
                             rootKey:(NSUInteger)rootKey
                  transposeSemitones:(NSInteger)transposeSemitones
                           tuneCents:(float)tuneCents
                              gainDb:(float)gainDb
                                 pan:(float)pan
                               error:(NSString**)error;

- (NSUInteger)soundCount;
- (NSDictionary<NSString*, id>*)soundStateAtIndex:(NSUInteger)index;
- (NSArray<NSDictionary<NSString*, id>*>*)soundLayerStatesAtIndex:(NSUInteger)index;
- (BOOL)addSoundLayerAtIndex:(NSUInteger)soundIndex multisampleIndex:(NSUInteger)multisampleIndex error:(NSString**)error;
- (BOOL)removeSoundLayerAtIndex:(NSUInteger)soundIndex layerIndex:(NSUInteger)layerIndex error:(NSString**)error;
- (BOOL)updateSoundLayerAtIndex:(NSUInteger)soundIndex
                     layerIndex:(NSUInteger)layerIndex
               multisampleIndex:(NSUInteger)multisampleIndex
                        enabled:(BOOL)enabled
                         keyLow:(NSUInteger)keyLow
                        keyHigh:(NSUInteger)keyHigh
                    velocityLow:(NSUInteger)velocityLow
                   velocityHigh:(NSUInteger)velocityHigh
             transposeSemitones:(NSInteger)transposeSemitones
                      tuneCents:(float)tuneCents
                        levelDb:(float)levelDb
                            pan:(float)pan
                          error:(NSString**)error;
- (BOOL)updateSoundAtIndex:(NSUInteger)index name:(NSString*)name position:(NSUInteger)position bank:(NSUInteger)bank page:(NSUInteger)page slot:(NSUInteger)slot category:(NSUInteger)category error:(NSString**)error;

// ManagerDocumentObjects.mm: kind 0 = sample, 1 = multisample, 2 = SOUND
- (BOOL)renameObjectKind:(NSInteger)kind index:(NSUInteger)index name:(NSString*)name error:(NSString**)error;
- (BOOL)duplicateObjectKind:(NSInteger)kind index:(NSUInteger)index createdIndex:(NSUInteger*)createdIndex error:(NSString**)error;
// kind 0 sample, 1 multisample, 2 SOUND only (samples stay), 3 SOUND together with the layers and samples only it uses (SILVETON_DELETE_BLEND_V1)
- (BOOL)deleteObjectKind:(NSInteger)kind index:(NSUInteger)index summary:(NSString**)summary error:(NSString**)error;
- (BOOL)createSoundFromMultisampleIndex:(NSUInteger)multisampleIndex name:(NSString*)name createdIndex:(NSUInteger*)createdIndex error:(NSString**)error;
@end

@interface SVSampleAuditionPlayer : NSObject
- (BOOL)playState:(NSDictionary<NSString*, id>*)state loopOnly:(BOOL)loopOnly error:(NSString**)error;
- (void)stop;
- (BOOL)currentPlayFrame:(UInt64*)frame;
@end

// The live project behind the document (read for sizes and sums, written only through the document's own calls
// or the processing / bank code that already does so).
static inline silveton::manager::BankProject* SVProjectOf(SVManagerDocument* document) noexcept {
    if (document == nil) return nullptr;
    Ivar ivar = class_getInstanceVariable([SVManagerDocument class], "_project");
    if (ivar == nullptr) return nullptr;
    const ptrdiff_t offset = ivar_getOffset(ivar);
    if (offset <= 0) return nullptr;
    auto* base = reinterpret_cast<unsigned char*>((__bridge void*)document);
    return reinterpret_cast<silveton::manager::BankProject*>(base + offset);
}

static inline NSString* SVNs(const std::string& s) {
    NSString* out = [NSString stringWithUTF8String:s.c_str()];
    if (out == nil) out = [[NSString alloc] initWithBytes:s.data() length:s.size() encoding:NSISOLatin1StringEncoding];
    return out ?: @"";
}

static inline std::size_t SVSampleBytes(const silveton::manager::ImportedSample& s) noexcept { return s.audioData.size(); }
