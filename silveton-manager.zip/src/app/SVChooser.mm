// SILVETON_LOOK_V1 - modal chooser list.
#import "SVChooser.h"
#import "SVTheme.h"

@interface SVChooserPanel : NSObject <NSTableViewDataSource, NSTableViewDelegate, NSTextFieldDelegate>
@end

@implementation SVChooserPanel {
    NSPanel* _panel;
    NSTableView* _table;
    NSTextField* _search;
    NSArray<NSString*>* _all;
    NSMutableArray<NSNumber*>* _visible;   // indexes into _all
    NSInteger _result;
}

- (instancetype)initWithTitle:(NSString*)title hint:(NSString*)hint items:(NSArray<NSString*>*)items initial:(NSInteger)initial {
    self = [super init];
    if (self) {
        _all = [items copy];
        _visible = [NSMutableArray array];
        _result = -1;
        _panel = [[NSPanel alloc] initWithContentRect:NSMakeRect(0.0, 0.0, 560.0, 520.0) styleMask:(NSWindowStyleMaskTitled | NSWindowStyleMaskResizable) backing:NSBackingStoreBuffered defer:NO];
        _panel.title = title ?: @"";
        _panel.backgroundColor = SVColBackground();
        NSView* c = _panel.contentView;
        NSTextField* t = SVLabel(NSMakeRect(20.0, 484.0, 520.0, 22.0), title, 16.0, YES, SVColText());
        t.autoresizingMask = NSViewMinYMargin | NSViewWidthSizable;
        [c addSubview:t];
        NSTextField* h = SVLabel(NSMakeRect(20.0, 462.0, 520.0, 18.0), hint, 11.0, NO, SVColDim());
        h.autoresizingMask = NSViewMinYMargin | NSViewWidthSizable;
        [c addSubview:h];
        _search = SVField(NSMakeRect(20.0, 428.0, 520.0, 26.0), @"");
        _search.placeholderString = @"търси…";
        _search.delegate = self;
        _search.autoresizingMask = NSViewMinYMargin | NSViewWidthSizable;
        [c addSubview:_search];
        _table = [[NSTableView alloc] initWithFrame:NSZeroRect];
        SVStyleTable(_table);
        _table.headerView = nil;
        _table.dataSource = self;
        _table.delegate = self;
        _table.target = self;
        _table.doubleAction = @selector(okPressed:);
        [_table addTableColumn:SVTextColumn(@"name", @"", 500.0)];
        NSScrollView* scroll = SVScroll(NSMakeRect(20.0, 64.0, 520.0, 354.0), _table);
        scroll.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
        [c addSubview:scroll];
        SVKeyButton* cancel = [SVKeyButton keyWithFrame:NSMakeRect(320.0, 18.0, 100.0, 34.0) title:@"ОТКАЗ" kind:0 target:self action:@selector(cancelPressed:)];
        cancel.autoresizingMask = NSViewMaxYMargin | NSViewMinXMargin;
        cancel.keyEquivalent = @"\x1b";
        [c addSubview:cancel];
        SVKeyButton* ok = [SVKeyButton keyWithFrame:NSMakeRect(430.0, 18.0, 110.0, 34.0) title:@"ИЗБЕРИ" kind:1 target:self action:@selector(okPressed:)];
        ok.autoresizingMask = NSViewMaxYMargin | NSViewMinXMargin;
        ok.keyEquivalent = @"\r";
        [c addSubview:ok];
        [self filter];
        if (initial >= 0 && static_cast<NSUInteger>(initial) < _all.count) {
            [_table selectRowIndexes:[NSIndexSet indexSetWithIndex:static_cast<NSUInteger>(initial)] byExtendingSelection:NO];
            [_table scrollRowToVisible:initial];
        }
    }
    return self;
}

- (void)filter {
    [_visible removeAllObjects];
    NSString* q = [_search.stringValue stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    for (NSUInteger i = 0U; i < _all.count; ++i) {
        if (q.length == 0U || [_all[i] rangeOfString:q options:NSCaseInsensitiveSearch].location != NSNotFound) [_visible addObject:@(i)];
    }
    [_table reloadData];
}

- (void)controlTextDidChange:(NSNotification*)notification { (void)notification; [self filter]; }

- (NSInteger)run {
    [_panel center];
    [_panel makeFirstResponder:_search];
    [NSApp runModalForWindow:_panel];
    [_panel orderOut:nil];
    return _result;
}

- (void)okPressed:(id)sender {
    (void)sender;
    const NSInteger row = _table.selectedRow;
    if (row < 0 || static_cast<NSUInteger>(row) >= _visible.count) { NSBeep(); return; }
    _result = _visible[static_cast<NSUInteger>(row)].integerValue;
    [NSApp stopModal];
}
- (void)cancelPressed:(id)sender { (void)sender; _result = -1; [NSApp stopModal]; }

- (NSInteger)numberOfRowsInTableView:(NSTableView*)tableView { (void)tableView; return static_cast<NSInteger>(_visible.count); }
- (id)tableView:(NSTableView*)tableView objectValueForTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView; (void)tableColumn;
    if (row < 0 || static_cast<NSUInteger>(row) >= _visible.count) return nil;
    return _all[_visible[static_cast<NSUInteger>(row)].unsignedIntegerValue];
}
@end

NSInteger SVChooseFromList(NSWindow* parent, NSString* title, NSString* hint, NSArray<NSString*>* items, NSInteger initial) {
    (void)parent;
    if (items.count == 0U) return -1;
    SVChooserPanel* panel = [[SVChooserPanel alloc] initWithTitle:title hint:hint items:items initial:initial];
    return [panel run];
}
