// SILVETON_WORKFLOW_V1 - page 4 БАНКА; its project / tablet-bank commands are also in the menu Файл (main.mm).
#pragma once
#import "SVShell.h"

@interface SVBankPage : SVPageView
- (void)newProjectPressed:(id)sender;
- (void)openProjectPressed:(id)sender;
- (void)saveProjectPressed:(id)sender;
- (void)saveProjectAsPressed:(id)sender;
- (void)tabletBankPressed:(id)sender;
@end
