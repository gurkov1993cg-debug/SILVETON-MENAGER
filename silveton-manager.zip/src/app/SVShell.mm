// SILVETON_LOOK_V1 - the Manager window.
#import "SVShell.h"
#import "SVDocument.h"
#import "SVTheme.h"
#import "SVSamplerPage.h"

#include <set>
#include <string>

using silveton::manager::BankProject;

// pages (each in its own file)
@interface SVSamplesPage : SVPageView
- (void)selectSampleIndex:(NSUInteger)index;
@end
@interface SVSoundsPage : SVPageView
- (void)selectSoundIndex:(NSUInteger)index;
@end
@interface SVProcessingPage : SVPageView
@end
@interface SVBankPage : SVPageView
@end

namespace {
constexpr CGFloat kTopBar = 52.0;
constexpr CGFloat kSideBar = 210.0;
constexpr CGFloat kStatusBar = 36.0;
SVShellWindowController* gShell = nil;

NSString* const kPageNames[SVPageCount] = {@"СЕМПЛИ", @"ЗВУЦИ", @"ОБРАБОТКА", @"БАНКА", @"СЕМПЛЕР"};
NSString* const kPageHints[SVPageCount] = {
    @"ВНАСЯНЕ ОТ ДИСКА: избираш папка, ТЪРСИ в под-папките, тикваш и ВНЕСИ. Избереш ли семпъл отляво - чуваш го и го оправяш.",
    @"Кой звук какви слоеве има, при каква сила свири всеки слой и кой семпъл на кой клавиш. Маркираш звуци, Cmd+C (Копирай) – после на СЕМПЛЕР ги поставяш в ЛИСТА с Cmd+V.",
    @"Избираш звуци, включваш какво да се направи, START. Преди това нищо не се променя.",
    @"ЗАПАЗИ ПРОЕКТА / ОТВОРИ ПРОЕКТ – продължаваш оттам, докъдето си стигнал. Накрая: ЗАПИШИ БАНКАТА ЗА ТАБЛЕТА.",
    @"Семплерът: свириш, правиш блендите, пишеш в ЛИСТА. Cmd+V – копираните звуци стават нови бленди от цъкнатия ред нататък."};
}

@implementation SVPageView
- (instancetype)initWithShell:(SVShellWindowController*)shell frame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) { _shell = shell; }
    return self;
}
- (BOOL)isFlipped { return YES; }
- (void)refresh {}
- (void)pageWillHide {}
- (void)pageDidShow {}
@end

@interface SVBarView : NSView
@end
@implementation SVBarView
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    [SVColBar() setFill];
    NSRectFill(self.bounds);
    [SVColBorder() setFill];
    NSRectFill(NSMakeRect(0.0, 0.0, self.bounds.size.width, 1.0));
    NSRectFill(NSMakeRect(0.0, self.bounds.size.height - 1.0, self.bounds.size.width, 1.0));
}
@end

@interface SVSideView : NSView
@end
@implementation SVSideView
- (BOOL)isFlipped { return YES; }
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    [[NSColor colorWithCalibratedRed:0.071 green:0.086 blue:0.098 alpha:1.0] setFill];
    NSRectFill(self.bounds);
    [SVColBorder() setFill];
    NSRectFill(NSMakeRect(self.bounds.size.width - 1.0, 0.0, 1.0, self.bounds.size.height));
}
@end

@implementation SVShellWindowController {
    SVManagerDocument* _documentModel;
    SVSampleAuditionPlayer* _audition;
    NSView* _content;
    NSMutableArray<SVNavButton*>* _nav;
    NSMutableDictionary<NSNumber*, SVPageView*>* _pages;
    NSInteger _current;
    NSTextField* _bankLabel;
    NSTextField* _statusTitle;
    NSTextField* _statusText;
    std::set<unsigned long long> _processed;
    NSMutableArray<NSString*>* _importLog;
}

+ (SVShellWindowController*)shared { return gShell; }

- (instancetype)init {
    NSWindow* window = [[NSWindow alloc] initWithContentRect:NSMakeRect(0.0, 0.0, 1280.0, 800.0)
                                                  styleMask:(NSWindowStyleMaskTitled | NSWindowStyleMaskClosable |
                                                             NSWindowStyleMaskMiniaturizable | NSWindowStyleMaskResizable)
                                                    backing:NSBackingStoreBuffered
                                                      defer:NO];
    window.title = @"SILVETON Manager";
    window.minSize = NSMakeSize(1280.0, 800.0);   // the pages are drawn for this size; smaller cuts the right panels off
    window.backgroundColor = SVColBackground();
    self = [super initWithWindow:window];
    if (self) {
        gShell = self;
        _documentModel = [[SVManagerDocument alloc] init];
        _audition = [[SVSampleAuditionPlayer alloc] init];
        _current = -1;
        _nav = [NSMutableArray array];
        _pages = [NSMutableDictionary dictionary];
        _importLog = [NSMutableArray array];
        [self buildInterface];
        [self showPage:SVPageSamples];
    }
    return self;
}

- (SVManagerDocument*)documentModel { return _documentModel; }
- (SVSampleAuditionPlayer*)audition { return _audition; }

- (void)buildInterface {
    NSView* root = self.window.contentView;
    const NSRect b = root.bounds;

    // top bar
    SVBarView* top = [[SVBarView alloc] initWithFrame:NSMakeRect(0.0, b.size.height - kTopBar, b.size.width, kTopBar)];
    top.autoresizingMask = NSViewWidthSizable | NSViewMinYMargin;
    NSTextField* logo = SVLabel(NSMakeRect(20.0, 14.0, 300.0, 26.0), @"SILVETON MANAGER", 18.0, YES, SVColText());
    NSMutableAttributedString* spaced = [[NSMutableAttributedString alloc] initWithString:@"SILVETON MANAGER"];
    [spaced addAttributes:@{NSKernAttributeName: @2.0, NSFontAttributeName: [NSFont systemFontOfSize:18.0 weight:NSFontWeightBold], NSForegroundColorAttributeName: SVColText()}
                    range:NSMakeRange(0, spaced.length)];
    logo.attributedStringValue = spaced;
    [top addSubview:logo];
    _bankLabel = SVLabel(NSMakeRect(330.0, 17.0, b.size.width - 350.0, 20.0), @"", 13.0, NO, SVColDim());
    _bankLabel.alignment = NSTextAlignmentRight;
    _bankLabel.autoresizingMask = NSViewWidthSizable;
    [top addSubview:_bankLabel];
    [root addSubview:top];

    // left page keys
    SVSideView* side = [[SVSideView alloc] initWithFrame:NSMakeRect(0.0, kStatusBar, kSideBar, b.size.height - kTopBar - kStatusBar)];
    side.autoresizingMask = NSViewHeightSizable;
    for (NSInteger i = 0; i < SVPageCount; ++i) {
        SVNavButton* key = [[SVNavButton alloc] initWithFrame:NSMakeRect(12.0, 14.0 + static_cast<CGFloat>(i) * 74.0, kSideBar - 24.0, 64.0)];
        key.title = kPageNames[i];
        key.number = i + 1;
        key.tag = i;
        key.target = self;
        key.action = @selector(navPressed:);
        [side addSubview:key];
        [_nav addObject:key];
    }
    NSTextField* hint = SVLabel(NSMakeRect(14.0, 14.0 + static_cast<CGFloat>(SVPageCount) * 74.0 + 6.0, kSideBar - 28.0, 70.0),
                                @"Редът е редът на работата: внасяш и оправяш семплите, нареждаш звуците, обработваш, записваш банката, правиш блендите в семплера.",
                                11.0, NO, [NSColor colorWithCalibratedWhite:0.42 alpha:1.0]);
    hint.lineBreakMode = NSLineBreakByWordWrapping;
    [hint.cell setWraps:YES];
    [side addSubview:hint];
    [root addSubview:side];

    // status line
    SVBarView* status = [[SVBarView alloc] initWithFrame:NSMakeRect(0.0, 0.0, b.size.width, kStatusBar)];
    status.autoresizingMask = NSViewWidthSizable | NSViewMaxYMargin;
    _statusTitle = SVLabel(NSMakeRect(20.0, 9.0, 130.0, 18.0), @"", 13.0, YES, SVColText());
    [status addSubview:_statusTitle];
    _statusText = SVLabel(NSMakeRect(150.0, 9.0, b.size.width - 170.0, 18.0), @"", 13.0, NO, SVColDim());
    _statusText.autoresizingMask = NSViewWidthSizable;
    [status addSubview:_statusText];
    [root addSubview:status];

    // page area
    _content = [[NSView alloc] initWithFrame:NSMakeRect(kSideBar, kStatusBar, b.size.width - kSideBar, b.size.height - kTopBar - kStatusBar)];
    _content.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    [root addSubview:_content];
}

- (SVPageView*)pageAt:(NSInteger)index {
    if (index < 0 || index >= SVPageCount) return nil;
    SVPageView* existing = _pages[@(index)];
    if (existing != nil) return existing;
    const NSRect frame = _content.bounds;
    SVPageView* page = nil;
    switch (index) {
        case SVPageSamples: page = [[SVSamplesPage alloc] initWithShell:self frame:frame]; break;
        case SVPageSounds: page = [[SVSoundsPage alloc] initWithShell:self frame:frame]; break;
        case SVPageProcessing: page = [[SVProcessingPage alloc] initWithShell:self frame:frame]; break;
        case SVPageSampler: page = [[SVSamplerPage alloc] initWithShell:self frame:frame]; break;
        default: page = [[SVBankPage alloc] initWithShell:self frame:frame]; break;
    }
    page.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    _pages[@(index)] = page;
    return page;
}

- (void)navPressed:(SVNavButton*)sender { [self showPage:sender.tag]; }

- (void)showPage:(NSInteger)index {
    if (index < 0 || index >= SVPageCount) return;
    if (_current == index) { [_pages[@(index)] refresh]; return; }
    SVPageView* old = _current >= 0 ? _pages[@(_current)] : nil;
    if (old != nil) {
        [old pageWillHide];
        [old removeFromSuperview];
    }
    _current = index;
    for (NSInteger i = 0; i < SVPageCount; ++i) _nav[static_cast<NSUInteger>(i)].on = (i == index);
    SVPageView* page = [self pageAt:index];
    page.frame = _content.bounds;
    [_content addSubview:page];
    [page refresh];
    [page pageDidShow];
    _statusTitle.stringValue = kPageNames[index];
    _statusTitle.textColor = SVColText();
    _statusText.stringValue = kPageHints[index];
    _statusText.textColor = SVColDim();
    [self refreshBars];
}

- (NSInteger)currentPage { return _current; }

// SILVETON_LOOK_V1: what used to be a window with an OK button is one line at the bottom now, so every
// function is one press. The line stays until the next message or until another page is opened.
- (void)flashStatus:(NSString*)title text:(NSString*)text {
    if (text.length == 0U) return;
    _statusTitle.stringValue = title.length > 0U ? title : @"";
    _statusTitle.textColor = SVColText();
    _statusText.stringValue = text;
    _statusText.textColor = SVColText();
}

- (void)refreshAll {
    for (SVPageView* page in _pages.allValues) [page refresh];
    [self refreshBars];
}

- (void)refreshBars {
    BankProject* project = SVProjectOf(_documentModel);
    unsigned long long bytes = 0ULL;
    std::size_t layers = 0U;
    if (project != nullptr) {
        for (const auto& s : project->samples) bytes += SVSampleBytes(s);
        for (const auto& snd : project->sounds) layers += snd.layers.size();
    }
    NSString* bank = _bankPath.length > 0U ? _bankPath.lastPathComponent : @"нова (незаписана)";
    NSString* dirty = [_documentModel hasUnsavedChanges] ? @"   ·   незаписани промени" : @"";
    _bankLabel.stringValue = [NSString stringWithFormat:@"банка: %@   ·   %lu звука · %lu слоя · %lu семпла · %@%@", bank,
                              static_cast<unsigned long>([_documentModel soundCount]), static_cast<unsigned long>(layers),
                              static_cast<unsigned long>([_documentModel sampleCount]), SVMegabytes(static_cast<double>(bytes)), dirty];
}

- (void)markSampleIdsProcessed:(NSArray<NSNumber*>*)ids {
    for (NSNumber* n in ids) _processed.insert(n.unsignedLongLongValue);
}
- (BOOL)isSampleIdProcessed:(NSNumber*)sampleId { return _processed.count(sampleId.unsignedLongLongValue) != 0U ? YES : NO; }
- (void)clearProcessedMarks { _processed.clear(); }

- (void)appendImportLog:(NSString*)line { if (line.length > 0U) [_importLog addObject:line]; }
- (NSArray<NSString*>*)importLog { return _importLog; }

- (BOOL)confirmLosingChanges:(NSString*)action {
    if (![_documentModel hasUnsavedChanges]) return YES;
    return SVConfirm(self.window, @"Има незаписани промени",
                     [NSString stringWithFormat:@"%@ ще изгуби промените, които не са запазени в проект. Продължаваш ли?", action ?: @"Това"],
                     @"Продължи без запис");
}

- (void)selectSampleIndex:(NSUInteger)index {
    [self showPage:SVPageSamples];
    [(SVSamplesPage*)_pages[@(SVPageSamples)] selectSampleIndex:index];
}

- (void)selectSoundIndex:(NSUInteger)index {
    [self showPage:SVPageSounds];
    [(SVSoundsPage*)_pages[@(SVPageSounds)] selectSoundIndex:index];
}
@end

// SILVETON_LOOK_V1: one short message in the status line instead of a window that has to be clicked away
void SVFlash(NSString* title, NSString* text, BOOL beep) {
    [[SVShellWindowController shared] flashStatus:title text:text];
    if (beep) NSBeep();
}
