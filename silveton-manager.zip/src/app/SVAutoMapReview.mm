// SILVETON_AUTOMAP_V1 - look at what was heard before the blend is made, and correct a note by typing it.
#import "SVAutoMapReview.h"
#import "SVDocument.h"
#import "SVTheme.h"

#include <algorithm>

// ---------------------------------------------------------------- where every sample sits on the keyboard

@interface SVMapStripCell : NSCell
@end

@implementation SVMapStripCell

- (void)drawInteriorWithFrame:(NSRect)frame inView:(NSView*)view {
    (void)view;
    NSDictionary* row = [self objectValue];
    if (![row isKindOfClass:[NSDictionary class]]) return;
    const NSRect box = NSInsetRect(frame, 2.0, 5.0);
    [SVColField() setFill];
    NSRectFill(box);

    // the octaves, so the eye can find middle C
    [[SVColBorder() colorWithAlphaComponent:0.6] setFill];
    for (int key = 0; key <= 127; key += 12) {
        const CGFloat x = box.origin.x + box.size.width * static_cast<CGFloat>(key) / 127.0;
        NSRectFill(NSMakeRect(x, box.origin.y, key == 60 ? 2.0 : 1.0, box.size.height));
    }

    const int low = [row[@"keyLow"] intValue], high = [row[@"keyHigh"] intValue], note = [row[@"note"] intValue];
    const CGFloat x0 = box.origin.x + box.size.width * static_cast<CGFloat>(std::max(0, low)) / 127.0;
    const CGFloat x1 = box.origin.x + box.size.width * static_cast<CGFloat>(std::min(127, high) + 1) / 127.0;
    [[SVColAmber() colorWithAlphaComponent:0.35] setFill];
    NSRectFill(NSMakeRect(x0, box.origin.y, std::max<CGFloat>(2.0, x1 - x0), box.size.height));
    const CGFloat nx = box.origin.x + box.size.width * static_cast<CGFloat>(std::max(0, std::min(127, note))) / 127.0;
    [SVColGreen() setFill];
    NSRectFill(NSMakeRect(nx - 1.0, box.origin.y, 2.0, box.size.height));
    [SVColBorder() setStroke];
    [[NSBezierPath bezierPathWithRect:NSInsetRect(box, 0.5, 0.5)] stroke];
}

@end

// ---------------------------------------------------------------- the window

@interface SVAutoMapPanel : NSObject <NSTableViewDataSource, NSTableViewDelegate>
@end

@implementation SVAutoMapPanel {
    NSPanel* _panel;
    NSTableView* _table;
    NSTextField* _nameField;
    NSTextField* _count;
    SVToggle* _dropOld;
    SVManagerDocument* _doc;
    NSArray<NSDictionary<NSString*, id>*>* _rows;
    NSMutableArray<NSNumber*>* _ticked;
    BOOL _accepted;
}

- (instancetype)initWithDocument:(SVManagerDocument*)document rows:(NSArray<NSDictionary<NSString*, id>*>*)rows {
    self = [super init];
    if (self) {
        _doc = document;
        _rows = [rows copy];
        _accepted = NO;
        _ticked = [NSMutableArray arrayWithCapacity:_rows.count];
        for (NSUInteger i = 0U; i < _rows.count; ++i) [_ticked addObject:@(YES)];

        _panel = [[NSPanel alloc] initWithContentRect:NSMakeRect(0.0, 0.0, 940.0, 640.0)
                                            styleMask:(NSWindowStyleMaskTitled | NSWindowStyleMaskResizable)
                                              backing:NSBackingStoreBuffered
                                                defer:NO];
        _panel.title = @"Бленда от семплите";
        _panel.backgroundColor = SVColBackground();
        NSView* c = _panel.contentView;

        NSTextField* title = SVLabel(NSMakeRect(20.0, 604.0, 900.0, 22.0), @"КОЙ ТОН Е ВСЕКИ СЕМПЪЛ", 16.0, YES, SVColAmber());
        title.autoresizingMask = NSViewMinYMargin | NSViewWidthSizable;
        [c addSubview:title];
        NSTextField* hint = SVLabel(NSMakeRect(20.0, 580.0, 900.0, 18.0),
                                    @"Тонът е чут от самия звук, с октавата. Ако някой е сбъркан, пиши го в колоната ТОН (например C4, A#3 или 60) и клавишите се пренареждат.",
                                    11.0, NO, SVColDim());
        hint.autoresizingMask = NSViewMinYMargin | NSViewWidthSizable;
        [c addSubview:hint];

        _table = [[NSTableView alloc] initWithFrame:NSZeroRect];
        SVStyleTable(_table);
        _table.rowHeight = 26.0;
        _table.dataSource = self;
        _table.delegate = self;
        [_table addTableColumn:SVCheckColumn(@"on", 26.0)];
        [_table addTableColumn:SVTextColumn(@"name", @"СЕМПЪЛ", 250.0)];
        NSTableColumn* noteColumn = SVTextColumn(@"note", @"ТОН", 70.0);
        [(NSTextFieldCell*)noteColumn.dataCell setEditable:YES];
        [(NSTextFieldCell*)noteColumn.dataCell setSelectable:YES];
        noteColumn.editable = YES;
        [_table addTableColumn:noteColumn];
        NSTableColumn* keys = SVTextColumn(@"keys", @"КЛАВИШИ", 90.0);
        [(NSTextFieldCell*)keys.dataCell setTextColor:SVColDim()];
        [_table addTableColumn:keys];
        NSTableColumn* layer = SVTextColumn(@"layer", @"СЛОЙ", 60.0);
        [(NSTextFieldCell*)layer.dataCell setTextColor:SVColDim()];
        [_table addTableColumn:layer];
        NSTableColumn* strip = [[NSTableColumn alloc] initWithIdentifier:@"strip"];
        strip.title = @"КЪДЕ СТОИ НА КЛАВИАТУРАТА";
        strip.width = 400.0;
        strip.dataCell = [[SVMapStripCell alloc] init];
        [_table addTableColumn:strip];
        NSScrollView* scroll = SVScroll(NSMakeRect(20.0, 110.0, 900.0, 458.0), _table);
        scroll.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
        [c addSubview:scroll];

        [c addSubview:SVLabel(NSMakeRect(20.0, 78.0, 98.0, 18.0), @"ИМЕ НА БЛЕНДАТА", 10.0, YES, SVColDim())];
        _nameField = SVField(NSMakeRect(120.0, 74.0, 300.0, 26.0), @"НОВА БЛЕНДА");
        _nameField.autoresizingMask = NSViewMaxYMargin;
        [c addSubview:_nameField];
        _count = SVLabel(NSMakeRect(440.0, 78.0, 470.0, 18.0), @"", 11.0, NO, SVColDim());
        _count.autoresizingMask = NSViewMaxYMargin | NSViewWidthSizable;
        [c addSubview:_count];

        SVKeyButton* all = [SVKeyButton keyWithFrame:NSMakeRect(20.0, 20.0, 110.0, 34.0) title:@"ВСИЧКИ" kind:0 target:self action:@selector(tickAll:)];
        all.textSize = 11.0; all.autoresizingMask = NSViewMaxYMargin; [c addSubview:all];
        SVKeyButton* none = [SVKeyButton keyWithFrame:NSMakeRect(138.0, 20.0, 110.0, 34.0) title:@"НИЩО" kind:0 target:self action:@selector(tickNone:)];
        none.textSize = 11.0; none.autoresizingMask = NSViewMaxYMargin; [c addSubview:none];
        // the one-file blends that the import leaves behind: off by hand if they are wanted kept
        _dropOld = [[SVToggle alloc] initWithFrame:NSMakeRect(266.0, 26.0, 44.0, 22.0)];
        _dropOld.on = YES;
        _dropOld.autoresizingMask = NSViewMaxYMargin;
        [c addSubview:_dropOld];
        NSTextField* dropLabel = SVLabel(NSMakeRect(318.0, 29.0, 320.0, 18.0), @"махни старите бленди от по един семпъл", 11.0, NO, SVColText());
        dropLabel.autoresizingMask = NSViewMaxYMargin;
        [c addSubview:dropLabel];

        SVKeyButton* cancel = [SVKeyButton keyWithFrame:NSMakeRect(650.0, 20.0, 110.0, 34.0) title:@"ОТКАЗ" kind:0 target:self action:@selector(cancelPressed:)];
        cancel.autoresizingMask = NSViewMaxYMargin | NSViewMinXMargin;
        cancel.keyEquivalent = @"\x1b";
        [c addSubview:cancel];
        SVKeyButton* ok = [SVKeyButton keyWithFrame:NSMakeRect(770.0, 20.0, 150.0, 34.0) title:@"НАПРАВИ БЛЕНДАТА" kind:1 target:self action:@selector(okPressed:)];
        ok.textSize = 11.0;
        ok.autoresizingMask = NSViewMaxYMargin | NSViewMinXMargin;
        ok.keyEquivalent = @"\r";
        [c addSubview:ok];
        [self updateCount];
    }
    return self;
}

- (void)updateCount {
    NSUInteger on = 0U, guessed = 0U;
    int layers = 1;
    for (NSUInteger i = 0U; i < _rows.count; ++i) {
        if (!_ticked[i].boolValue) continue;
        ++on;
        if (![_rows[i][@"heard"] boolValue] || [_rows[i][@"confidence"] doubleValue] < 0.5) ++guessed;
        layers = std::max(layers, [_rows[i][@"layers"] intValue]);
    }
    _count.stringValue = [NSString stringWithFormat:@"Отметнати %lu от %lu · слоеве по сила: %d%@",
                          static_cast<unsigned long>(on), static_cast<unsigned long>(_rows.count), layers,
                          guessed > 0U ? [NSString stringWithFormat:@" · %lu тона са несигурни, виж ги", static_cast<unsigned long>(guessed)] : @""];
}

- (NSArray<NSDictionary<NSString*, id>*>*)chosenRows {
    NSMutableArray<NSDictionary<NSString*, id>*>* chosen = [NSMutableArray array];
    for (NSUInteger i = 0U; i < _rows.count; ++i) if (_ticked[i].boolValue) [chosen addObject:_rows[i]];
    return chosen;
}

- (void)rearrange {
    NSArray<NSDictionary<NSString*, id>*>* again = [_doc autoMapArrangeRows:_rows];
    if (again.count == _rows.count) _rows = again;
    [_table reloadData];
    [self updateCount];
}

- (NSArray<NSDictionary<NSString*, id>*>*)runWithName:(NSString**)chosenName removeOldSingles:(BOOL*)removeOldSingles {
    [_panel center];
    [NSApp runModalForWindow:_panel];
    [_panel orderOut:nil];
    if (!_accepted) return nil;
    if (chosenName != nullptr) *chosenName = _nameField.stringValue;
    if (removeOldSingles != nullptr) *removeOldSingles = _dropOld.on;
    return [self chosenRows];
}

- (void)tickAll:(id)sender {
    (void)sender;
    for (NSUInteger i = 0U; i < _ticked.count; ++i) _ticked[i] = @(YES);
    [_table reloadData];
    [self updateCount];
}
- (void)tickNone:(id)sender {
    (void)sender;
    for (NSUInteger i = 0U; i < _ticked.count; ++i) _ticked[i] = @(NO);
    [_table reloadData];
    [self updateCount];
}
- (void)okPressed:(id)sender {
    (void)sender;
    if ([self chosenRows].count == 0U) { NSBeep(); return; }
    _accepted = YES;
    [NSApp stopModal];
}
- (void)cancelPressed:(id)sender { (void)sender; _accepted = NO; [NSApp stopModal]; }

- (NSInteger)numberOfRowsInTableView:(NSTableView*)tableView { (void)tableView; return static_cast<NSInteger>(_rows.count); }

- (id)tableView:(NSTableView*)tableView objectValueForTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView;
    if (row < 0 || static_cast<NSUInteger>(row) >= _rows.count) return nil;
    NSDictionary<NSString*, id>* item = _rows[static_cast<NSUInteger>(row)];
    NSString* identifier = tableColumn.identifier;
    if ([identifier isEqualToString:@"on"]) return _ticked[static_cast<NSUInteger>(row)];
    if ([identifier isEqualToString:@"name"]) return item[@"name"];
    if ([identifier isEqualToString:@"note"]) return item[@"noteName"];
    if ([identifier isEqualToString:@"keys"]) return [NSString stringWithFormat:@"%d – %d", [item[@"keyLow"] intValue], [item[@"keyHigh"] intValue]];
    if ([identifier isEqualToString:@"layer"]) {
        const int layers = [item[@"layers"] intValue];
        return layers <= 1 ? @"—" : [NSString stringWithFormat:@"%d / %d", [item[@"layer"] intValue] + 1, layers];
    }
    return item;
}

- (void)tableView:(NSTableView*)tableView setObjectValue:(id)object forTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView;
    if (row < 0 || static_cast<NSUInteger>(row) >= _rows.count) return;
    NSString* identifier = tableColumn.identifier;
    if ([identifier isEqualToString:@"on"]) {
        _ticked[static_cast<NSUInteger>(row)] = @([object boolValue]);
        [self updateCount];
        return;
    }
    if (![identifier isEqualToString:@"note"]) return;
    const NSInteger typed = [_doc noteFromText:[object description]];
    if (typed < 0) { NSBeep(); [_table reloadData]; return; }      // not a note: leave it as it was
    NSMutableArray<NSDictionary<NSString*, id>*>* next = [_rows mutableCopy];
    NSMutableDictionary<NSString*, id>* item = [next[static_cast<NSUInteger>(row)] mutableCopy];
    item[@"note"] = @(typed);
    item[@"heard"] = @(YES);
    item[@"confidence"] = @(1.0);                                  // typed by hand: no longer a guess
    next[static_cast<NSUInteger>(row)] = item;
    _rows = next;
    [self rearrange];
}

- (void)tableView:(NSTableView*)tableView willDisplayCell:(id)cell forTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView;
    if (row < 0 || static_cast<NSUInteger>(row) >= _rows.count) return;
    if (![cell isKindOfClass:[NSTextFieldCell class]]) return;
    if (![tableColumn.identifier isEqualToString:@"note"]) return;
    NSDictionary<NSString*, id>* item = _rows[static_cast<NSUInteger>(row)];
    const BOOL sure = [item[@"heard"] boolValue] && [item[@"confidence"] doubleValue] >= 0.5;
    [(NSTextFieldCell*)cell setTextColor:sure ? SVColText() : SVColAmber()];   // a guess stands out
}

@end

NSArray<NSDictionary<NSString*, id>*>* SVReviewAutoMap(NSWindow* parent,
                                                       SVManagerDocument* document,
                                                       NSArray<NSDictionary<NSString*, id>*>* rows,
                                                       NSString** chosenName,
                                                       BOOL* removeOldSingles) {
    (void)parent;
    if (rows.count == 0U || document == nil) return nil;
    SVAutoMapPanel* panel = [[SVAutoMapPanel alloc] initWithDocument:document rows:rows];
    return [panel runWithName:chosenName removeOldSingles:removeOldSingles];
}
