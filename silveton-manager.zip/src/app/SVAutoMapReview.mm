// SILVETON_AUTOMAP_V1 - look at what was heard before the blend is made, and correct a note by typing it.
// SILVETON_THIN_V1 - the same window lets the manager advise, and the user choose, which notes a neighbour plays for.
#import "SVAutoMapReview.h"
#import "SVDocument.h"
#import "SVTheme.h"

#include <algorithm>

// ---------------------------------------------------------------- where every sample sits on the keyboard

@interface SVMapStripCell : NSCell
@end

@implementation SVMapStripCell

- (void)drawInteriorWithFrame:(NSRect)frame inView:(NSView*)view {
    (void)view;
    NSDictionary* row = [self objectValue];
    if (![row isKindOfClass:[NSDictionary class]]) return;
    const NSRect box = NSInsetRect(frame, 2.0, 5.0);
    [SVColField() setFill];
    NSRectFill(box);

    // the octaves, so the eye can find middle C
    [[SVColBorder() colorWithAlphaComponent:0.6] setFill];
    for (int key = 0; key <= 127; key += 12) {
        const CGFloat x = box.origin.x + box.size.width * static_cast<CGFloat>(key) / 127.0;
        NSRectFill(NSMakeRect(x, box.origin.y, key == 60 ? 2.0 : 1.0, box.size.height));
    }

    const int low = [row[@"keyLow"] intValue], high = [row[@"keyHigh"] intValue], note = [row[@"note"] intValue];
    const BOOL dropped = [row[@"drop"] boolValue];
    if (!dropped) {
        const CGFloat x0 = box.origin.x + box.size.width * static_cast<CGFloat>(std::max(0, low)) / 127.0;
        const CGFloat x1 = box.origin.x + box.size.width * static_cast<CGFloat>(std::min(127, high) + 1) / 127.0;
        [[SVColWave() colorWithAlphaComponent:0.30] setFill];
        NSRectFill(NSMakeRect(x0, box.origin.y, std::max<CGFloat>(2.0, x1 - x0), box.size.height));
    }
    const CGFloat nx = box.origin.x + box.size.width * static_cast<CGFloat>(std::max(0, std::min(127, note))) / 127.0;
    NSColor* mark = dropped ? SVColRed() : SVColGreen();               // a dropped note is only marked, a neighbour plays it
    [mark setFill];
    NSRectFill(NSMakeRect(nx - 1.0, box.origin.y, 2.0, box.size.height));
    [SVColBorder() setStroke];
    [[NSBezierPath bezierPathWithRect:NSInsetRect(box, 0.5, 0.5)] stroke];
}

@end

// ---------------------------------------------------------------- the window

@interface SVAutoMapPanel : NSObject <NSTableViewDataSource, NSTableViewDelegate>
@end

@implementation SVAutoMapPanel {
    NSPanel* _panel;
    NSTableView* _table;
    NSTextField* _nameField;
    NSTextField* _count;
    NSTextField* _advice;                                   // what the manager thinks about thinning the notes
    NSTextField* _thinInfo;                                 // what the chosen way would throw away
    NSPopUpButton* _thinPopup;
    SVToggle* _dropOld;
    SVManagerDocument* _doc;
    NSArray<NSDictionary<NSString*, id>*>* _rows;           // as heard (a note may have been corrected by hand)
    NSArray<NSDictionary<NSString*, id>*>* _shown;          // the same rows with the thinning added
    NSDictionary<NSString*, id>* _summary;
    id _memory;                                             // what was already measured, so a tick is quick
    NSMutableArray<NSNumber*>* _ticked;
    BOOL _accepted;
}

- (instancetype)initWithDocument:(SVManagerDocument*)document rows:(NSArray<NSDictionary<NSString*, id>*>*)rows {
    self = [super init];
    if (self) {
        _doc = document;
        _rows = [rows copy];
        _shown = _rows;
        _summary = nil;
        _memory = [document autoMapThinMemory];
        _accepted = NO;
        _ticked = [NSMutableArray arrayWithCapacity:_rows.count];
        for (NSUInteger i = 0U; i < _rows.count; ++i) [_ticked addObject:@(YES)];

        _panel = [[NSPanel alloc] initWithContentRect:NSMakeRect(0.0, 0.0, 1040.0, 704.0)
                                            styleMask:(NSWindowStyleMaskTitled | NSWindowStyleMaskResizable)
                                              backing:NSBackingStoreBuffered
                                                defer:NO];
        _panel.title = @"Звук от семплите";
        _panel.backgroundColor = SVColBackground();
        NSView* c = _panel.contentView;

        NSTextField* title = SVLabel(NSMakeRect(20.0, 668.0, 1000.0, 22.0), @"КОЙ ТОН Е ВСЕКИ СЕМПЪЛ", 16.0, YES, SVColText());
        title.autoresizingMask = NSViewMinYMargin | NSViewWidthSizable;
        [c addSubview:title];
        NSTextField* hint = SVLabel(NSMakeRect(20.0, 644.0, 1000.0, 18.0),
                                    @"Тонът е чут от самия звук, с октавата. Ако някой е сбъркан, пиши го в колоната ТОН (например C4, A#3 или 60) и клавишите се пренареждат.",
                                    11.0, NO, SVColDim());
        hint.autoresizingMask = NSViewMinYMargin | NSViewWidthSizable;
        [c addSubview:hint];

        // the manager's advice on thinning the notes: only advice, nothing is thrown away until it is chosen below
        _advice = SVLabel(NSMakeRect(20.0, 600.0, 1000.0, 38.0), @"", 12.0, NO, SVColText());
        _advice.autoresizingMask = NSViewMinYMargin | NSViewWidthSizable;
        _advice.lineBreakMode = NSLineBreakByWordWrapping;
        _advice.maximumNumberOfLines = 2;
        [c addSubview:_advice];

        _table = [[NSTableView alloc] initWithFrame:NSZeroRect];
        SVStyleTable(_table);
        _table.rowHeight = 26.0;
        _table.dataSource = self;
        _table.delegate = self;
        [_table addTableColumn:SVCheckColumn(@"on", 26.0)];
        [_table addTableColumn:SVTextColumn(@"name", @"СЕМПЪЛ", 210.0)];
        NSTableColumn* noteColumn = SVTextColumn(@"note", @"ТОН", 60.0);
        [(NSTextFieldCell*)noteColumn.dataCell setEditable:YES];
        [(NSTextFieldCell*)noteColumn.dataCell setSelectable:YES];
        noteColumn.editable = YES;
        [_table addTableColumn:noteColumn];
        NSTableColumn* keys = SVTextColumn(@"keys", @"КЛАВИШИ", 90.0);
        [(NSTextFieldCell*)keys.dataCell setTextColor:SVColDim()];
        [_table addTableColumn:keys];
        NSTableColumn* layer = SVTextColumn(@"layer", @"СЛОЙ", 55.0);
        [(NSTextFieldCell*)layer.dataCell setTextColor:SVColDim()];
        [_table addTableColumn:layer];
        NSTableColumn* why = SVTextColumn(@"why", @"РЕШЕНИЕ", 240.0);
        [(NSTextFieldCell*)why.dataCell setTextColor:SVColDim()];
        [_table addTableColumn:why];
        NSTableColumn* strip = [[NSTableColumn alloc] initWithIdentifier:@"strip"];
        strip.title = @"КЪДЕ СТОИ НА КЛАВИАТУРАТА";
        strip.width = 300.0;
        strip.dataCell = [[SVMapStripCell alloc] init];
        [_table addTableColumn:strip];
        NSScrollView* scroll = SVScroll(NSMakeRect(20.0, 150.0, 1000.0, 444.0), _table);
        scroll.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
        [c addSubview:scroll];

        // thinning: by choice only. The first item (every key) throws nothing away.
        [c addSubview:SVLabel(NSMakeRect(20.0, 124.0, 150.0, 18.0), @"РАЗРЕДИ ТОНОВЕТЕ", 10.0, YES, SVColDim())];
        _thinPopup = SVPopup(NSMakeRect(170.0, 119.0, 270.0, 26.0));
        _thinPopup.autoresizingMask = NSViewMaxYMargin;
        [_thinPopup addItemsWithTitles:@[@"на всеки клавиш (нищо не се маха)", @"1 семпъл на 2 клавиша", @"1 семпъл на 3 клавиша", @"Мениджърът решава сам"]];
        _thinPopup.target = self;
        _thinPopup.action = @selector(thinChanged:);
        [c addSubview:_thinPopup];
        _thinInfo = SVLabel(NSMakeRect(452.0, 124.0, 568.0, 18.0), @"", 11.0, NO, SVColDim());
        _thinInfo.autoresizingMask = NSViewMaxYMargin | NSViewWidthSizable;
        _thinInfo.lineBreakMode = NSLineBreakByTruncatingTail;
        [c addSubview:_thinInfo];

        [c addSubview:SVLabel(NSMakeRect(20.0, 78.0, 98.0, 18.0), @"ИМЕ НА ЗВУКА", 10.0, YES, SVColDim())];
        _nameField = SVField(NSMakeRect(120.0, 74.0, 300.0, 26.0), @"НОВ ЗВУК");
        _nameField.autoresizingMask = NSViewMaxYMargin;
        [c addSubview:_nameField];
        _count = SVLabel(NSMakeRect(440.0, 78.0, 580.0, 18.0), @"", 11.0, NO, SVColDim());
        _count.autoresizingMask = NSViewMaxYMargin | NSViewWidthSizable;
        [c addSubview:_count];

        SVKeyButton* all = [SVKeyButton keyWithFrame:NSMakeRect(20.0, 20.0, 110.0, 34.0) title:@"ВСИЧКИ" kind:0 target:self action:@selector(tickAll:)];
        all.textSize = 11.0; all.autoresizingMask = NSViewMaxYMargin; [c addSubview:all];
        SVKeyButton* none = [SVKeyButton keyWithFrame:NSMakeRect(138.0, 20.0, 110.0, 34.0) title:@"НИЩО" kind:0 target:self action:@selector(tickNone:)];
        none.textSize = 11.0; none.autoresizingMask = NSViewMaxYMargin; [c addSubview:none];
        // the one-file blends that the import leaves behind: off by hand if they are wanted kept
        _dropOld = [[SVToggle alloc] initWithFrame:NSMakeRect(266.0, 26.0, 44.0, 22.0)];
        _dropOld.on = YES;
        _dropOld.autoresizingMask = NSViewMaxYMargin;
        [c addSubview:_dropOld];
        NSTextField* dropLabel = SVLabel(NSMakeRect(318.0, 29.0, 320.0, 18.0), @"махни старите звуци от по един семпъл", 11.0, NO, SVColText());
        dropLabel.autoresizingMask = NSViewMaxYMargin;
        [c addSubview:dropLabel];

        SVKeyButton* cancel = [SVKeyButton keyWithFrame:NSMakeRect(750.0, 20.0, 110.0, 34.0) title:@"ОТКАЗ" kind:0 target:self action:@selector(cancelPressed:)];
        cancel.autoresizingMask = NSViewMaxYMargin | NSViewMinXMargin;
        cancel.keyEquivalent = @"\x1b";
        [c addSubview:cancel];
        SVKeyButton* ok = [SVKeyButton keyWithFrame:NSMakeRect(870.0, 20.0, 150.0, 34.0) title:@"НАПРАВИ ЗВУКА" kind:1 target:self action:@selector(okPressed:)];
        ok.textSize = 11.0;
        ok.autoresizingMask = NSViewMaxYMargin | NSViewMinXMargin;
        ok.keyEquivalent = @"\r";
        [c addSubview:ok];
        [self updateCount];
    }
    return self;
}

- (void)updateCount {
    NSUInteger on = 0U, guessed = 0U;
    int layers = 1;
    for (NSUInteger i = 0U; i < _shown.count; ++i) {
        if (!_ticked[i].boolValue) continue;
        ++on;
        if ([_shown[i][@"drop"] boolValue]) continue;                    // a dropped note is not heard any more
        if (![_shown[i][@"heard"] boolValue] || [_shown[i][@"confidence"] doubleValue] < 0.5) ++guessed;
        layers = std::max(layers, [_shown[i][@"layers"] intValue]);
    }
    _count.stringValue = [NSString stringWithFormat:@"Отметнати %lu от %lu · слоеве по сила: %d%@",
                          static_cast<unsigned long>(on), static_cast<unsigned long>(_rows.count), layers,
                          guessed > 0U ? [NSString stringWithFormat:@" · %lu тона са несигурни, виж ги", static_cast<unsigned long>(guessed)] : @""];
}

// The manager's own opinion on thinning, always shown; and what the chosen way would do. Nothing here changes anything.
- (void)updateAdvice {
    NSUInteger on = 0U;
    for (NSUInteger i = 0U; i < _ticked.count; ++i) if (_ticked[i].boolValue) ++on;
    if (_summary == nil || on == 0U) {
        _advice.stringValue = @"";
        _thinInfo.stringValue = @"";
        return;
    }
    const NSUInteger notes = [_summary[@"notes"] unsignedIntegerValue];
    const NSUInteger adviceSamples = [_summary[@"adviceSamples"] unsignedIntegerValue];
    const NSUInteger spread = [_summary[@"spread"] unsignedIntegerValue];
    const double allBytes = [_summary[@"allBytes"] doubleValue];
    if (adviceSamples > 0U) {
        _advice.stringValue = [NSString stringWithFormat:@"СЪВЕТ НА МЕНИДЖЪРА: има смисъл. Могат да се махнат %lu семпъла (около %@ от %@), защото съседният тон, преместен с един клавиш, звучи същото. "
                               @"Ако искаш, избери „Мениджърът решава сам“. Докато не избереш, нищо не се маха.",
                               static_cast<unsigned long>(adviceSamples), SVMegabytes([_summary[@"adviceBytes"] doubleValue]), SVMegabytes(allBytes)];
    } else if (spread > 0U) {
        _advice.stringValue = [NSString stringWithFormat:@"СЪВЕТ НА МЕНИДЖЪРА: няма нужда. Тоновете вече са разредени — %lu от %lu тона са на по 3 клавиша един от друг, нищо излишно не виждам.",
                               static_cast<unsigned long>(spread), static_cast<unsigned long>(notes)];
    } else {
        _advice.stringValue = @"СЪВЕТ НА МЕНИДЖЪРА: няма нужда. Съседните тонове не звучат достатъчно еднакво (или не са чути ясно), затова всеки клавиш пази своя семпъл.";
    }

    const NSUInteger dropped = [_summary[@"droppedSamples"] unsignedIntegerValue];
    if (_thinPopup.indexOfSelectedItem == 0) {
        _thinInfo.stringValue = @"нищо не се маха — всеки клавиш пази своя семпъл";
    } else if (dropped == 0U) {
        _thinInfo.stringValue = @"при този избор няма какво да се махне";
    } else {
        _thinInfo.stringValue = [NSString stringWithFormat:@"махат се %lu семпъла (%lu тона) · спестяват около %@ от %@ · излизат от банката",
                                 static_cast<unsigned long>(dropped), static_cast<unsigned long>([_summary[@"droppedNotes"] unsignedIntegerValue]),
                                 SVMegabytes([_summary[@"droppedBytes"] doubleValue]), SVMegabytes(allBytes)];
    }
}

// the rows with the thinning of the chosen way worked out; the window shows these
- (void)refresh {
    NSDictionary<NSString*, id>* summary = nil;
    NSArray<NSDictionary<NSString*, id>*>* shown = [_doc autoMapThinRows:_rows
                                                                 ticked:_ticked
                                                                   mode:_thinPopup.indexOfSelectedItem
                                                                 memory:_memory
                                                                summary:&summary];
    _shown = shown.count == _rows.count ? shown : _rows;
    _summary = summary;
    [_table reloadData];
    [self updateCount];
    [self updateAdvice];
}

- (void)thinChanged:(id)sender {
    (void)sender;
    [self refresh];
}

// the rows that go into the blend: ticked, and not given away to a neighbour
- (NSArray<NSDictionary<NSString*, id>*>*)chosenRows {
    NSMutableArray<NSDictionary<NSString*, id>*>* chosen = [NSMutableArray array];
    for (NSUInteger i = 0U; i < _shown.count; ++i) {
        if (_ticked[i].boolValue && ![_shown[i][@"drop"] boolValue]) [chosen addObject:_shown[i]];
    }
    return chosen;
}

// the samples that a neighbour plays for: they leave the bank
- (NSArray<NSNumber*>*)droppedSamples {
    NSMutableArray<NSNumber*>* gone = [NSMutableArray array];
    for (NSUInteger i = 0U; i < _shown.count; ++i) {
        if (_ticked[i].boolValue && [_shown[i][@"drop"] boolValue]) [gone addObject:_shown[i][@"index"]];
    }
    return gone;
}

- (void)rearrange {
    NSArray<NSDictionary<NSString*, id>*>* again = [_doc autoMapArrangeRows:_rows];
    if (again.count == _rows.count) _rows = again;
    [self refresh];
}

- (NSArray<NSDictionary<NSString*, id>*>*)runWithName:(NSString**)chosenName
                                     removeOldSingles:(BOOL*)removeOldSingles
                                        removeSamples:(NSArray<NSNumber*>**)removeSamples {
    [_panel center];
    [_panel makeKeyAndOrderFront:nil];
    _advice.stringValue = @"Мениджърът слуша съседните тонове, за да прецени дали има смисъл да се махат…";
    [_panel display];                       // shown first: the listening can take a moment on a big set
    [self refresh];
    [NSApp runModalForWindow:_panel];
    [_panel orderOut:nil];
    if (!_accepted) return nil;
    if (chosenName != nullptr) *chosenName = _nameField.stringValue;
    if (removeOldSingles != nullptr) *removeOldSingles = _dropOld.on;
    if (removeSamples != nullptr) *removeSamples = [self droppedSamples];
    return [self chosenRows];
}

- (void)tickAll:(id)sender {
    (void)sender;
    for (NSUInteger i = 0U; i < _ticked.count; ++i) _ticked[i] = @(YES);
    [self refresh];
}
- (void)tickNone:(id)sender {
    (void)sender;
    for (NSUInteger i = 0U; i < _ticked.count; ++i) _ticked[i] = @(NO);
    [self refresh];
}
- (void)okPressed:(id)sender {
    (void)sender;
    if ([self chosenRows].count == 0U) { NSBeep(); return; }
    _accepted = YES;
    [NSApp stopModal];
}
- (void)cancelPressed:(id)sender { (void)sender; _accepted = NO; [NSApp stopModal]; }

- (NSInteger)numberOfRowsInTableView:(NSTableView*)tableView { (void)tableView; return static_cast<NSInteger>(_shown.count); }

- (id)tableView:(NSTableView*)tableView objectValueForTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView;
    if (row < 0 || static_cast<NSUInteger>(row) >= _shown.count) return nil;
    NSDictionary<NSString*, id>* item = _shown[static_cast<NSUInteger>(row)];
    NSString* identifier = tableColumn.identifier;
    const BOOL dropped = [item[@"drop"] boolValue];
    if ([identifier isEqualToString:@"on"]) return _ticked[static_cast<NSUInteger>(row)];
    if ([identifier isEqualToString:@"name"]) return item[@"name"];
    if ([identifier isEqualToString:@"note"]) return item[@"noteName"];
    if ([identifier isEqualToString:@"keys"]) {
        if (dropped) return [NSString stringWithFormat:@"→ свири %@", item[@"coverNote"]];
        return [NSString stringWithFormat:@"%d – %d", [item[@"keyLow"] intValue], [item[@"keyHigh"] intValue]];
    }
    if ([identifier isEqualToString:@"layer"]) {
        const int layers = [item[@"layers"] intValue];
        return dropped || layers <= 1 ? @"—" : [NSString stringWithFormat:@"%d / %d", [item[@"layer"] intValue] + 1, layers];
    }
    if ([identifier isEqualToString:@"why"]) return item[@"why"] != nil ? item[@"why"] : @"";
    return item;
}

- (void)tableView:(NSTableView*)tableView setObjectValue:(id)object forTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView;
    if (row < 0 || static_cast<NSUInteger>(row) >= _rows.count) return;
    NSString* identifier = tableColumn.identifier;
    if ([identifier isEqualToString:@"on"]) {
        _ticked[static_cast<NSUInteger>(row)] = @([object boolValue]);
        [self refresh];
        return;
    }
    if (![identifier isEqualToString:@"note"]) return;
    const NSInteger typed = [_doc noteFromText:[object description]];
    if (typed < 0) { NSBeep(); [_table reloadData]; return; }      // not a note: leave it as it was
    NSMutableArray<NSDictionary<NSString*, id>*>* next = [_rows mutableCopy];
    NSMutableDictionary<NSString*, id>* item = [next[static_cast<NSUInteger>(row)] mutableCopy];
    item[@"note"] = @(typed);
    item[@"heard"] = @(YES);
    item[@"confidence"] = @(1.0);                                  // typed by hand: no longer a guess
    next[static_cast<NSUInteger>(row)] = item;
    _rows = next;
    [self rearrange];
}

- (void)tableView:(NSTableView*)tableView willDisplayCell:(id)cell forTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView;
    if (row < 0 || static_cast<NSUInteger>(row) >= _shown.count) return;
    if (![cell isKindOfClass:[NSTextFieldCell class]]) return;
    NSDictionary<NSString*, id>* item = _shown[static_cast<NSUInteger>(row)];
    NSString* identifier = tableColumn.identifier;
    const BOOL dropped = [item[@"drop"] boolValue];
    if ([identifier isEqualToString:@"note"]) {
        const BOOL sure = [item[@"heard"] boolValue] && [item[@"confidence"] doubleValue] >= 0.5;
        [(NSTextFieldCell*)cell setTextColor:(dropped || sure) ? (dropped ? SVColDim() : SVColText()) : SVColWarn()];   // a guess stands out
        return;
    }
    if ([identifier isEqualToString:@"why"]) {
        [(NSTextFieldCell*)cell setTextColor:dropped ? SVColRed() : SVColDim()];
        return;
    }
    if ([identifier isEqualToString:@"name"]) {
        [(NSTextFieldCell*)cell setTextColor:dropped ? SVColDim() : SVColText()];
    }
}

@end

NSArray<NSDictionary<NSString*, id>*>* SVReviewAutoMap(NSWindow* parent,
                                                       SVManagerDocument* document,
                                                       NSArray<NSDictionary<NSString*, id>*>* rows,
                                                       NSString** chosenName,
                                                       BOOL* removeOldSingles,
                                                       NSArray<NSNumber*>** removeSamples) {
    (void)parent;
    if (removeSamples != nullptr) *removeSamples = @[];
    if (rows.count == 0U || document == nil) return nil;
    SVAutoMapPanel* panel = [[SVAutoMapPanel alloc] initWithDocument:document rows:rows];
    return [panel runWithName:chosenName removeOldSingles:removeOldSingles removeSamples:removeSamples];
}
