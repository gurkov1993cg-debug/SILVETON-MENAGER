// SILVETON_PROCESSING_V1
// PROCESSING page: 48 kHz convert, -6 dB equal loudness, even tone low -> high.
// Every function has its own ON/OFF switch. Nothing runs before START.
#import <AppKit/AppKit.h>
#import <objc/runtime.h>

#import "SVProgress.h"

#include "silveton/manager/ManagerTypes.h"
#include "silveton/manager/SampleProcessing.h"
#include "silveton/manager/SpectrumAnalyzer.h"

#include <algorithm>
#include <atomic>
#include <cmath>
#include <map>
#include <memory>
#include <string>
#include <vector>

using silveton::manager::BankProject;
using silveton::manager::SampleProcessingOptions;
using silveton::manager::SampleProcessingReport;
using silveton::manager::SampleProcessor;
using silveton::manager::SpectrumAnalyzer;
using silveton::manager::SpectrumPower;

@interface SVManagerDocument : NSObject
- (BOOL)importPaths:(NSArray<NSString*>*)paths error:(NSString**)error;
- (void)clearProject;
- (void)markCurrentStateChanged;
- (NSArray<NSString*>*)sampleDisplayRows;
- (NSDictionary<NSString*, id>*)auditionStateAtIndex:(NSUInteger)index error:(NSString**)error;
@end

@interface SVSampleAuditionPlayer : NSObject
- (BOOL)playState:(NSDictionary<NSString*, id>*)state loopOnly:(BOOL)loopOnly error:(NSString**)error;
- (void)stop;
- (BOOL)currentPlayFrame:(UInt64*)frame;
@end

@interface SVShellWindowController : NSWindowController
+ (SVShellWindowController*)shared;
- (void)showPage:(NSInteger)index;
@end

// ---------------------------------------------------------------- progress window

@interface SVProgressPanel : NSObject
@property(nonatomic, readonly) NSPanel* panel;
- (instancetype)initWithTitle:(NSString*)title;
- (void)setFraction:(double)fraction text:(NSString*)text;   // any thread
- (BOOL)stopRequested;
- (const std::atomic<bool>*)stopFlag;
// Runs work on a background thread; returns when it is finished.
- (void)runWork:(void (^)(SVProgressPanel* progress))work;
@end

@implementation SVProgressPanel {
    NSProgressIndicator* _bar;
    NSTextField* _percent;
    NSTextField* _text;
    NSButton* _stop;
    std::atomic<bool> _stopFlag;
}

static NSTextField* SVPLabel(NSRect frame, NSString* text, CGFloat size, NSFontWeight weight) {
    NSTextField* label = [[NSTextField alloc] initWithFrame:frame];
    label.stringValue = text ?: @"";
    label.editable = NO;
    label.selectable = NO;
    label.bezeled = NO;
    label.drawsBackground = NO;
    label.font = [NSFont systemFontOfSize:size weight:weight];
    label.textColor = [NSColor colorWithCalibratedWhite:0.90 alpha:1.0];
    label.lineBreakMode = NSLineBreakByTruncatingMiddle;
    return label;
}

- (instancetype)initWithTitle:(NSString*)title {
    self = [super init];
    if (self) {
        _stopFlag.store(false);
        _panel = [[NSPanel alloc] initWithContentRect:NSMakeRect(0.0, 0.0, 520.0, 170.0)
                                            styleMask:NSWindowStyleMaskTitled
                                              backing:NSBackingStoreBuffered
                                                defer:NO];
        _panel.title = title ?: @"SILVETON";
        _panel.backgroundColor = [NSColor colorWithCalibratedRed:0.050 green:0.061 blue:0.073 alpha:1.0];
        NSView* c = _panel.contentView;
        [c addSubview:SVPLabel(NSMakeRect(24.0, 126.0, 380.0, 26.0), title, 16.0, NSFontWeightSemibold)];
        _percent = SVPLabel(NSMakeRect(400.0, 120.0, 96.0, 34.0), @"0 %", 24.0, NSFontWeightBold);
        _percent.alignment = NSTextAlignmentRight;
        _percent.textColor = [NSColor colorWithCalibratedRed:0.45 green:0.72 blue:0.96 alpha:1.0];
        [c addSubview:_percent];
        _bar = [[NSProgressIndicator alloc] initWithFrame:NSMakeRect(24.0, 92.0, 472.0, 20.0)];
        _bar.style = NSProgressIndicatorStyleBar;
        _bar.indeterminate = NO;
        _bar.minValue = 0.0;
        _bar.maxValue = 100.0;
        _bar.doubleValue = 0.0;
        [c addSubview:_bar];
        _text = SVPLabel(NSMakeRect(24.0, 62.0, 472.0, 20.0), @"", 11.0, NSFontWeightRegular);
        [c addSubview:_text];
        _stop = [[NSButton alloc] initWithFrame:NSMakeRect(376.0, 16.0, 120.0, 32.0)];
        _stop.title = @"STOP";
        _stop.bezelStyle = NSBezelStyleRounded;
        _stop.target = self;
        _stop.action = @selector(stopPressed:);
        [c addSubview:_stop];
    }
    return self;
}

- (void)stopPressed:(id)sender {
    (void)sender;
    _stopFlag.store(true);
    _stop.enabled = NO;
    _stop.title = @"Stopping…";
}

- (BOOL)stopRequested { return _stopFlag.load() ? YES : NO; }
- (const std::atomic<bool>*)stopFlag { return &_stopFlag; }

- (void)setFraction:(double)fraction text:(NSString*)text {
    const double pct = std::max(0.0, std::min(100.0, fraction * 100.0));
    NSString* copy = [text copy];
    dispatch_async(dispatch_get_main_queue(), ^{
        self->_bar.doubleValue = pct;
        self->_percent.stringValue = [NSString stringWithFormat:@"%d %%", static_cast<int>(pct)];
        if (copy != nil) self->_text.stringValue = copy;
    });
}

- (void)runWork:(void (^)(SVProgressPanel* progress))work {
    [_panel center];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        work(self);
        dispatch_async(dispatch_get_main_queue(), ^{ [NSApp abortModal]; });
    });
    [NSApp runModalForWindow:_panel];
    [_panel orderOut:nil];
}
@end

// ---------------------------------------------------------------- helpers

namespace {

}

// ---------------------------------------------------------------- import with progress

BOOL SVImportPathsWithProgress(SVManagerDocument* document, NSArray<NSString*>* paths, NSWindow* parent, NSString** details) {
    (void)parent;
    if (document == nil || paths.count == 0U) {
        if (details != nullptr) *details = @"No sampler material was imported.";
        return NO;
    }
    // SILVETON_KONTAKT_V1: Kontakt instruments (.nki) open their own window, the other files go on as before
    {
        NSMutableArray<NSString*>* kontakt = [NSMutableArray array];
        NSMutableArray<NSString*>* others = [NSMutableArray array];
        for (NSString* path in paths) {
            if ([path.pathExtension.lowercaseString isEqualToString:@"nki"]) [kontakt addObject:path]; else [others addObject:path];
        }
        if (kontakt.count > 0U) {
            NSMutableArray<NSString*>* messages = [NSMutableArray array];
            BOOL any = NO;
            for (NSString* path in kontakt) {
                NSString* message = nil;
                if (SVImportKontaktFile(document, path, parent, &message)) any = YES;
                if (message.length > 0U) [messages addObject:message];
            }
            if (others.count > 0U) {
                NSString* message = nil;
                if (SVImportPathsWithProgress(document, others, parent, &message)) any = YES;
                if (message.length > 0U) [messages addObject:message];
            }
            if (details != nullptr) *details = messages.count > 0U ? [messages componentsJoinedByString:@"\n"] : nil;
            if (!any && details != nullptr && *details == nil) *details = @"No sampler material was imported.";
            return any;
        }
    }
    if (paths.count == 1U) {
        // one file: same as before, the window would only flash
        return [document importPaths:paths error:details];
    }
    SVProgressPanel* progress = [[SVProgressPanel alloc] initWithTitle:@"IMPORT"];
    __block NSUInteger imported = 0U;
    NSMutableArray<NSString*>* messages = [NSMutableArray array];
    __block BOOL stopped = NO;
    [progress runWork:^(SVProgressPanel* p) {
        const NSUInteger total = paths.count;
        for (NSUInteger i = 0; i < total; ++i) {
            if ([p stopRequested]) { stopped = YES; break; }
            NSString* path = paths[i];
            [p setFraction:static_cast<double>(i) / static_cast<double>(total)
                      text:[NSString stringWithFormat:@"%lu / %lu   %@", (unsigned long)(i + 1U), (unsigned long)total, path.lastPathComponent]];
            NSString* message = nil;
            if ([document importPaths:@[path] error:&message]) ++imported;
            if (message.length > 0U) [messages addObject:message];
        }
        [p setFraction:1.0 text:@"Done"];
    }];
    if (stopped) [messages addObject:[NSString stringWithFormat:@"Import stopped. %lu of %lu files were imported.", (unsigned long)imported, (unsigned long)paths.count]];
    if (details != nullptr) *details = messages.count > 0U ? [messages componentsJoinedByString:@"\n"] : nil;
    if (imported == 0U && details != nullptr && *details == nil) *details = @"No sampler material was imported.";
    return imported > 0U ? YES : NO;
}

void SVOpenProcessingPage(void) {
    [[SVShellWindowController shared] showPage:2];   // SILVETON_FIND_V1: ОБРАБОТКА is the third of four pages now
}

// ---------------------------------------------------------------- SAMPLER LOOK (SILVETON_ANALYZER_V2)
// Colours taken from the SILVETON sampler screen: graphite board, light / dark keys,
// amber text on dark "on" keys, orange action key, LCD style display.

namespace {
NSColor* SVRGB(int r, int g, int b, CGFloat a = 1.0) {
    return [NSColor colorWithCalibratedRed:r / 255.0 green:g / 255.0 blue:b / 255.0 alpha:a];
}
// SILVETON_MERGE_V1: the display in the colours of the sampler's LCD (white / grey; green stays for BEFORE)
NSColor* CAmber() { return SVRGB(232, 235, 240); }
NSColor* CLcdValue() { return SVRGB(248, 249, 251); }
NSColor* CLcdDim() { return SVRGB(138, 144, 154); }
NSColor* CLcdOk() { return SVRGB(123, 216, 143); }
NSColor* CLabel() { return SVRGB(170, 176, 184); }
NSColor* CTitle() { return SVRGB(232, 235, 240); }

double MidiOf(double hz) { return 69.0 + 12.0 * std::log2(hz / 440.0); }
NSString* NoteText(double hz) {
    static NSString* const names[12] = {@"C", @"C#", @"D", @"D#", @"E", @"F", @"F#", @"G", @"G#", @"A", @"A#", @"B"};
    const double m = MidiOf(hz);
    const long n = std::lround(m);
    const int cents = static_cast<int>(std::lround((m - static_cast<double>(n)) * 100.0));
    const long idx = ((n % 12) + 12) % 12;
    return [NSString stringWithFormat:@"%@%ld %+d ct", names[idx], n / 12 - 1, cents];
}
NSString* HzText(double hz) {
    return hz >= 1000.0 ? [NSString stringWithFormat:@"%.2f kHz", hz / 1000.0] : [NSString stringWithFormat:@"%.0f Hz", hz];
}
}

// ---------------------------------------------------------------- ANALYZER display

@interface SVSpectrumView : NSView
@property(nonatomic) double slope;      // dB per octave, like SPAN (4.5)
@property(nonatomic) double range;      // dB shown below 0
@property(nonatomic) BOOL showMax;
@property(nonatomic) BOOL showBefore;
@property(nonatomic) BOOL live;         // main curve is LIVE (else NOW = whole sample)
- (void)setMain:(const std::vector<float>&)main max:(const std::vector<float>&)max before:(const std::vector<float>&)before;
- (void)setMainOnly:(const std::vector<float>&)main;
@end

@implementation SVSpectrumView {
    std::vector<float> _main;
    std::vector<float> _max;
    std::vector<float> _before;
    NSTrackingArea* _tracking;
    BOOL _mouseInside;
    CGFloat _mouseX;
}

- (instancetype)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) { _slope = 4.5; _range = 72.0; _showMax = YES; _showBefore = YES; }
    return self;
}

- (void)setMain:(const std::vector<float>&)main max:(const std::vector<float>&)max before:(const std::vector<float>&)before {
    _main = main; _max = max; _before = before;
    [self setNeedsDisplay:YES];
}
- (void)setMainOnly:(const std::vector<float>&)main { _main = main; [self setNeedsDisplay:YES]; }

- (void)updateTrackingAreas {
    [super updateTrackingAreas];
    if (_tracking != nil) [self removeTrackingArea:_tracking];
    _tracking = [[NSTrackingArea alloc] initWithRect:NSZeroRect
                                             options:(NSTrackingMouseMoved | NSTrackingMouseEnteredAndExited | NSTrackingActiveInKeyWindow | NSTrackingInVisibleRect)
                                               owner:self userInfo:nil];
    [self addTrackingArea:_tracking];
}
- (void)mouseEntered:(NSEvent*)e { _mouseInside = YES; _mouseX = [self convertPoint:e.locationInWindow fromView:nil].x; [self setNeedsDisplay:YES]; }
- (void)mouseMoved:(NSEvent*)e { _mouseInside = YES; _mouseX = [self convertPoint:e.locationInWindow fromView:nil].x; [self setNeedsDisplay:YES]; }
- (void)mouseExited:(NSEvent*)e { (void)e; _mouseInside = NO; [self setNeedsDisplay:YES]; }

- (NSRect)plot { return NSMakeRect(44.0, 26.0, self.bounds.size.width - 54.0, self.bounds.size.height - 36.0); }
- (double)tilt:(double)hz { return (_slope - 3.0) * std::log2(hz / 1000.0); }  // band energy -> SPAN look
- (CGFloat)xOf:(double)hz plot:(NSRect)r { return r.origin.x + r.size.width * std::log10(hz / 20.0) / 3.0; }
- (CGFloat)yOf:(double)db plot:(NSRect)r {
    const double t = (std::max(-_range, std::min(0.0, db)) + _range) / _range;
    return r.origin.y + r.size.height * t;
}

- (NSBezierPath*)pathFor:(const std::vector<float>&)c plot:(NSRect)r {
    NSBezierPath* path = [NSBezierPath bezierPath];
    bool started = false;
    for (std::size_t i = 0U; i < c.size(); ++i) {
        const double hz = SpectrumAnalyzer::pointHz(i);
        const NSPoint p = NSMakePoint([self xOf:hz plot:r], [self yOf:c[i] + [self tilt:hz] plot:r]);
        if (!started) { [path moveToPoint:p]; started = true; } else { [path lineToPoint:p]; }
    }
    path.lineJoinStyle = NSLineJoinStyleRound;
    return path;
}

- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    // LCD body
    NSBezierPath* body = [NSBezierPath bezierPathWithRoundedRect:NSInsetRect(self.bounds, 0.5, 0.5) xRadius:10.0 yRadius:10.0];
    [[[NSGradient alloc] initWithStartingColor:SVRGB(23, 26, 22) endingColor:SVRGB(13, 15, 13)] drawInBezierPath:body angle:-90.0];
    [SVRGB(72, 76, 82) setStroke];
    [body stroke];

    const NSRect r = [self plot];
    NSDictionary* small = @{NSFontAttributeName: [NSFont monospacedDigitSystemFontOfSize:9.5 weight:NSFontWeightMedium], NSForegroundColorAttributeName: CLcdDim()};
    // grid
    const double minors[] = {30, 40, 60, 70, 80, 90, 300, 400, 600, 700, 800, 900, 3000, 4000, 6000, 7000, 8000, 9000};
    [SVRGB(255, 179, 71, 0.045) setStroke];
    for (double hz : minors) { const CGFloat x = [self xOf:hz plot:r]; [NSBezierPath strokeLineFromPoint:NSMakePoint(x, r.origin.y) toPoint:NSMakePoint(x, NSMaxY(r))]; }
    const double majors[] = {20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000};
    NSString* const majorNames[] = {@"20", @"50", @"100", @"200", @"500", @"1k", @"2k", @"5k", @"10k", @"20k"};
    for (int k = 0; k < 10; ++k) {
        const CGFloat x = [self xOf:majors[k] plot:r];
        [SVRGB(255, 179, 71, 0.12) setStroke];
        [NSBezierPath strokeLineFromPoint:NSMakePoint(x, r.origin.y) toPoint:NSMakePoint(x, NSMaxY(r))];
        const NSSize sz = [majorNames[k] sizeWithAttributes:small];
        const CGFloat lx = std::max(r.origin.x, std::min(x - sz.width / 2.0, NSMaxX(r) - sz.width));
        [majorNames[k] drawAtPoint:NSMakePoint(lx, 8.0) withAttributes:small];
    }
    for (double db = 0.0; db >= -_range - 0.1; db -= 6.0) {
        const CGFloat y = [self yOf:db plot:r];
        const bool major = std::fmod(-db, 12.0) < 0.1;
        [SVRGB(255, 179, 71, major ? 0.12 : 0.045) setStroke];
        [NSBezierPath strokeLineFromPoint:NSMakePoint(r.origin.x, y) toPoint:NSMakePoint(NSMaxX(r), y)];
        if (major) {
            NSString* t = [NSString stringWithFormat:@"%d", static_cast<int>(db)];
            const NSSize sz = [t sizeWithAttributes:small];
            [t drawAtPoint:NSMakePoint(r.origin.x - sz.width - 6.0, y - sz.height / 2.0) withAttributes:small];
        }
    }

    [NSGraphicsContext saveGraphicsState];
    NSRectClip(r);
    if (_main.size() == SpectrumAnalyzer::kPoints) {
        NSBezierPath* fill = [self pathFor:_main plot:r];
        [fill lineToPoint:NSMakePoint(NSMaxX(r), r.origin.y)];
        [fill lineToPoint:NSMakePoint(r.origin.x, r.origin.y)];
        [fill closePath];
        [[[NSGradient alloc] initWithStartingColor:SVRGB(255, 179, 71, 0.50) endingColor:SVRGB(255, 122, 26, 0.02)] drawInBezierPath:fill angle:-90.0];
    }
    if (_showMax && _max.size() == SpectrumAnalyzer::kPoints) {
        NSBezierPath* p = [self pathFor:_max plot:r];
        p.lineWidth = 1.0;
        [SVRGB(184, 132, 60, 0.85) setStroke];
        [p stroke];
    }
    if (_showBefore && _before.size() == SpectrumAnalyzer::kPoints) {
        NSBezierPath* p = [self pathFor:_before plot:r];
        const CGFloat dash[2] = {5.0, 4.0};
        [p setLineDash:dash count:2 phase:0.0];
        p.lineWidth = 1.4;
        [CLcdOk() setStroke];
        [p stroke];
    }
    if (_main.size() == SpectrumAnalyzer::kPoints) {
        NSBezierPath* p = [self pathFor:_main plot:r];
        p.lineWidth = 1.7;
        [CLcdValue() setStroke];
        [p stroke];
    }
    [NSGraphicsContext restoreGraphicsState];

    // legend
    NSFont* lf = [NSFont systemFontOfSize:10.5 weight:NSFontWeightBold];
    CGFloat lx = r.origin.x + 12.0;
    const CGFloat ly = NSMaxY(r) - 20.0;
    NSArray* legend = @[@[_live ? @"━ LIVE" : @"━ NOW", CLcdValue()], @[@"━ MAX", CLcdDim()], @[@"╍ BEFORE", CLcdOk()]];
    for (NSUInteger k = 0; k < legend.count; ++k) {
        if (k == 1 && !(_showMax && !_max.empty())) continue;
        if (k == 2 && !(_showBefore && !_before.empty())) continue;
        NSDictionary* a = @{NSFontAttributeName: lf, NSForegroundColorAttributeName: legend[k][1]};
        [legend[k][0] drawAtPoint:NSMakePoint(lx, ly) withAttributes:a];
        lx += [legend[k][0] sizeWithAttributes:a].width + 16.0;
    }

    if (_main.empty()) {
        NSDictionary* a = @{NSFontAttributeName: [NSFont systemFontOfSize:14.0 weight:NSFontWeightSemibold], NSForegroundColorAttributeName: CLcdDim()};
        NSString* t = @"Choose a sample above";
        const NSSize sz = [t sizeWithAttributes:a];
        [t drawAtPoint:NSMakePoint(NSMidX(r) - sz.width / 2.0, NSMidY(r)) withAttributes:a];
        return;
    }

    // mouse readout: frequency · note · level
    if (_mouseInside && _mouseX >= r.origin.x && _mouseX <= NSMaxX(r)) {
        const double hz = 20.0 * std::pow(10.0, 3.0 * (_mouseX - r.origin.x) / r.size.width);
        std::size_t idx = static_cast<std::size_t>(std::lround(std::log(hz / 20.0) / std::log(1000.0) * static_cast<double>(SpectrumAnalyzer::kPoints - 1U)));
        idx = std::min(idx, SpectrumAnalyzer::kPoints - 1U);
        const double db = _main[idx] + [self tilt:SpectrumAnalyzer::pointHz(idx)];
        const CGFloat y = [self yOf:db plot:r];
        NSBezierPath* line = [NSBezierPath bezierPath];
        [line moveToPoint:NSMakePoint(_mouseX, r.origin.y)];
        [line lineToPoint:NSMakePoint(_mouseX, NSMaxY(r))];
        const CGFloat dot[2] = {2.0, 3.0};
        [line setLineDash:dot count:2 phase:0.0];
        [SVRGB(255, 207, 138, 0.55) setStroke];
        [line stroke];
        [NSColor.whiteColor setFill];
        [[NSBezierPath bezierPathWithOvalInRect:NSMakeRect(_mouseX - 3.5, y - 3.5, 7.0, 7.0)] fill];
        NSString* t = [NSString stringWithFormat:@"%@   %@   %.1f dB", HzText(hz), NoteText(hz), db];
        NSDictionary* a = @{NSFontAttributeName: [NSFont monospacedDigitSystemFontOfSize:11.0 weight:NSFontWeightBold], NSForegroundColorAttributeName: NSColor.whiteColor};
        const NSSize sz = [t sizeWithAttributes:a];
        CGFloat bx = _mouseX + 12.0;
        if (bx + sz.width + 16.0 > NSMaxX(r)) bx = _mouseX - sz.width - 28.0;
        const CGFloat by = std::min(std::max(y + 10.0, r.origin.y + 4.0), NSMaxY(r) - sz.height - 12.0);
        NSBezierPath* box = [NSBezierPath bezierPathWithRoundedRect:NSMakeRect(bx, by, sz.width + 16.0, sz.height + 8.0) xRadius:6.0 yRadius:6.0];
        [SVRGB(13, 15, 13, 0.94) setFill];
        [box fill];
        [CAmber() setStroke];
        [box stroke];
        [t drawAtPoint:NSMakePoint(bx + 8.0, by + 4.0) withAttributes:a];
    }
}
@end
