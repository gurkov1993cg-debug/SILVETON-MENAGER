// SILVETON_PROCESSING_V1
// PROCESSING page: 48 kHz convert, -6 dB equal loudness, even tone low -> high.
// Every function has its own ON/OFF switch. Nothing runs before START.
#import <AppKit/AppKit.h>
#import <objc/runtime.h>

#import "SVProgress.h"

#include "silveton/manager/ManagerTypes.h"
#include "silveton/manager/SampleProcessing.h"
#include "silveton/manager/SpectrumAnalyzer.h"

#include <algorithm>
#include <atomic>
#include <cmath>
#include <map>
#include <memory>
#include <string>
#include <vector>

using silveton::manager::BankProject;
using silveton::manager::SampleProcessingOptions;
using silveton::manager::SampleProcessingReport;
using silveton::manager::SampleProcessor;
using silveton::manager::SpectrumAnalyzer;
using silveton::manager::SpectrumPower;

@interface SVManagerDocument : NSObject
- (BOOL)importPaths:(NSArray<NSString*>*)paths error:(NSString**)error;
- (void)clearProject;
- (void)markCurrentStateChanged;
- (NSArray<NSString*>*)sampleDisplayRows;
- (NSDictionary<NSString*, id>*)auditionStateAtIndex:(NSUInteger)index error:(NSString**)error;
@end

@interface SVSampleAuditionPlayer : NSObject
- (BOOL)playState:(NSDictionary<NSString*, id>*)state loopOnly:(BOOL)loopOnly error:(NSString**)error;
- (void)stop;
- (BOOL)currentPlayFrame:(UInt64*)frame;
@end

@interface SVAppDelegate : NSObject
- (void)refreshAllEditors;
- (void)showMultisampleEditor:(id)sender;
@end

@interface SVMainWindowController : NSWindowController
- (void)showEmbeddedWorkspaceView:(NSView*)view identifier:(NSString*)identifier;
@end

@interface SVAppDelegate (Processing)
- (void)showProcessingCommand:(id)sender;
@end

// ---------------------------------------------------------------- progress window

@interface SVProgressPanel : NSObject
@property(nonatomic, readonly) NSPanel* panel;
- (instancetype)initWithTitle:(NSString*)title;
- (void)setFraction:(double)fraction text:(NSString*)text;   // any thread
- (BOOL)stopRequested;
- (const std::atomic<bool>*)stopFlag;
// Runs work on a background thread; returns when it is finished.
- (void)runWork:(void (^)(SVProgressPanel* progress))work;
@end

@implementation SVProgressPanel {
    NSProgressIndicator* _bar;
    NSTextField* _percent;
    NSTextField* _text;
    NSButton* _stop;
    std::atomic<bool> _stopFlag;
}

static NSTextField* SVPLabel(NSRect frame, NSString* text, CGFloat size, NSFontWeight weight) {
    NSTextField* label = [[NSTextField alloc] initWithFrame:frame];
    label.stringValue = text ?: @"";
    label.editable = NO;
    label.selectable = NO;
    label.bezeled = NO;
    label.drawsBackground = NO;
    label.font = [NSFont systemFontOfSize:size weight:weight];
    label.textColor = [NSColor colorWithCalibratedWhite:0.90 alpha:1.0];
    label.lineBreakMode = NSLineBreakByTruncatingMiddle;
    return label;
}

- (instancetype)initWithTitle:(NSString*)title {
    self = [super init];
    if (self) {
        _stopFlag.store(false);
        _panel = [[NSPanel alloc] initWithContentRect:NSMakeRect(0.0, 0.0, 520.0, 170.0)
                                            styleMask:NSWindowStyleMaskTitled
                                              backing:NSBackingStoreBuffered
                                                defer:NO];
        _panel.title = title ?: @"SILVETON";
        _panel.backgroundColor = [NSColor colorWithCalibratedRed:0.050 green:0.061 blue:0.073 alpha:1.0];
        NSView* c = _panel.contentView;
        [c addSubview:SVPLabel(NSMakeRect(24.0, 126.0, 380.0, 26.0), title, 16.0, NSFontWeightSemibold)];
        _percent = SVPLabel(NSMakeRect(400.0, 120.0, 96.0, 34.0), @"0 %", 24.0, NSFontWeightBold);
        _percent.alignment = NSTextAlignmentRight;
        _percent.textColor = [NSColor colorWithCalibratedRed:0.45 green:0.72 blue:0.96 alpha:1.0];
        [c addSubview:_percent];
        _bar = [[NSProgressIndicator alloc] initWithFrame:NSMakeRect(24.0, 92.0, 472.0, 20.0)];
        _bar.style = NSProgressIndicatorStyleBar;
        _bar.indeterminate = NO;
        _bar.minValue = 0.0;
        _bar.maxValue = 100.0;
        _bar.doubleValue = 0.0;
        [c addSubview:_bar];
        _text = SVPLabel(NSMakeRect(24.0, 62.0, 472.0, 20.0), @"", 11.0, NSFontWeightRegular);
        [c addSubview:_text];
        _stop = [[NSButton alloc] initWithFrame:NSMakeRect(376.0, 16.0, 120.0, 32.0)];
        _stop.title = @"STOP";
        _stop.bezelStyle = NSBezelStyleRounded;
        _stop.target = self;
        _stop.action = @selector(stopPressed:);
        [c addSubview:_stop];
    }
    return self;
}

- (void)stopPressed:(id)sender {
    (void)sender;
    _stopFlag.store(true);
    _stop.enabled = NO;
    _stop.title = @"Stopping…";
}

- (BOOL)stopRequested { return _stopFlag.load() ? YES : NO; }
- (const std::atomic<bool>*)stopFlag { return &_stopFlag; }

- (void)setFraction:(double)fraction text:(NSString*)text {
    const double pct = std::max(0.0, std::min(100.0, fraction * 100.0));
    NSString* copy = [text copy];
    dispatch_async(dispatch_get_main_queue(), ^{
        self->_bar.doubleValue = pct;
        self->_percent.stringValue = [NSString stringWithFormat:@"%d %%", static_cast<int>(pct)];
        if (copy != nil) self->_text.stringValue = copy;
    });
}

- (void)runWork:(void (^)(SVProgressPanel* progress))work {
    [_panel center];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        work(self);
        dispatch_async(dispatch_get_main_queue(), ^{ [NSApp abortModal]; });
    });
    [NSApp runModalForWindow:_panel];
    [_panel orderOut:nil];
}
@end

// ---------------------------------------------------------------- helpers

namespace {
static const void* kSVProcessingPageKey = &kSVProcessingPageKey;

NSString* const kPrefConvert = @"SVProcessConvert48k";
NSString* const kPrefNormalize = @"SVProcessNormalize";
NSString* const kPrefPerInstrument = @"SVProcessNormalizePerInstrument";
NSString* const kPrefTone = @"SVProcessEvenTone";
NSString* const kPrefLimiter = @"SVProcessSoftLimiter";

SVAppDelegate* ProcessingDelegate() { return (SVAppDelegate*)NSApp.delegate; }
id ProcessingMain() { return [ProcessingDelegate() valueForKey:@"mainWindowController"]; }
SVManagerDocument* ProcessingDocument() { return [ProcessingMain() valueForKey:@"documentModel"]; }

BankProject* ProcessingProject(SVManagerDocument* document) noexcept {
    if (document == nil) return nullptr;
    Ivar ivar = class_getInstanceVariable([SVManagerDocument class], "_project");
    if (ivar == nullptr) return nullptr;
    const ptrdiff_t offset = ivar_getOffset(ivar);
    if (offset <= 0) return nullptr;
    auto* base = reinterpret_cast<unsigned char*>((__bridge void*)document);
    return reinterpret_cast<BankProject*>(base + offset);
}

void ProcessingMessage(NSString* title, NSString* text, NSAlertStyle style) {
    NSAlert* alert = [[NSAlert alloc] init];
    alert.messageText = title ?: @"PROCESSING";
    alert.informativeText = text ?: @"";
    alert.alertStyle = style;
    NSWindow* w = [ProcessingMain() window];
    if (w != nil) [alert beginSheetModalForWindow:w completionHandler:nil];
    else [alert runModal];
}

NSString* ns(const std::string& s) { return [NSString stringWithUTF8String:s.c_str()] ?: @""; }
}

// ---------------------------------------------------------------- import with progress

BOOL SVImportPathsWithProgress(SVManagerDocument* document, NSArray<NSString*>* paths, NSWindow* parent, NSString** details) {
    (void)parent;
    if (document == nil || paths.count == 0U) {
        if (details != nullptr) *details = @"No sampler material was imported.";
        return NO;
    }
    // SILVETON_KONTAKT_V1: Kontakt instruments (.nki) open their own window, the other files go on as before
    {
        NSMutableArray<NSString*>* kontakt = [NSMutableArray array];
        NSMutableArray<NSString*>* others = [NSMutableArray array];
        for (NSString* path in paths) {
            if ([path.pathExtension.lowercaseString isEqualToString:@"nki"]) [kontakt addObject:path]; else [others addObject:path];
        }
        if (kontakt.count > 0U) {
            NSMutableArray<NSString*>* messages = [NSMutableArray array];
            BOOL any = NO;
            for (NSString* path in kontakt) {
                NSString* message = nil;
                if (SVImportKontaktFile(document, path, parent, &message)) any = YES;
                if (message.length > 0U) [messages addObject:message];
            }
            if (others.count > 0U) {
                NSString* message = nil;
                if (SVImportPathsWithProgress(document, others, parent, &message)) any = YES;
                if (message.length > 0U) [messages addObject:message];
            }
            if (details != nullptr) *details = messages.count > 0U ? [messages componentsJoinedByString:@"\n"] : nil;
            if (!any && details != nullptr && *details == nil) *details = @"No sampler material was imported.";
            return any;
        }
    }
    if (paths.count == 1U) {
        // one file: same as before, the window would only flash
        return [document importPaths:paths error:details];
    }
    SVProgressPanel* progress = [[SVProgressPanel alloc] initWithTitle:@"IMPORT"];
    __block NSUInteger imported = 0U;
    NSMutableArray<NSString*>* messages = [NSMutableArray array];
    __block BOOL stopped = NO;
    [progress runWork:^(SVProgressPanel* p) {
        const NSUInteger total = paths.count;
        for (NSUInteger i = 0; i < total; ++i) {
            if ([p stopRequested]) { stopped = YES; break; }
            NSString* path = paths[i];
            [p setFraction:static_cast<double>(i) / static_cast<double>(total)
                      text:[NSString stringWithFormat:@"%lu / %lu   %@", (unsigned long)(i + 1U), (unsigned long)total, path.lastPathComponent]];
            NSString* message = nil;
            if ([document importPaths:@[path] error:&message]) ++imported;
            if (message.length > 0U) [messages addObject:message];
        }
        [p setFraction:1.0 text:@"Done"];
    }];
    if (stopped) [messages addObject:[NSString stringWithFormat:@"Import stopped. %lu of %lu files were imported.", (unsigned long)imported, (unsigned long)paths.count]];
    if (details != nullptr) *details = messages.count > 0U ? [messages componentsJoinedByString:@"\n"] : nil;
    if (imported == 0U && details != nullptr && *details == nil) *details = @"No sampler material was imported.";
    return imported > 0U ? YES : NO;
}

void SVOpenProcessingPage(void) {
    SVAppDelegate* d = ProcessingDelegate();
    if ([d respondsToSelector:@selector(showProcessingCommand:)]) [d showProcessingCommand:nil];
}

// ---------------------------------------------------------------- SAMPLER LOOK (SILVETON_ANALYZER_V2)
// Colours taken from the SILVETON sampler screen: graphite board, light / dark keys,
// amber text on dark "on" keys, orange action key, LCD style display.

namespace {
NSColor* SVRGB(int r, int g, int b, CGFloat a = 1.0) {
    return [NSColor colorWithCalibratedRed:r / 255.0 green:g / 255.0 blue:b / 255.0 alpha:a];
}
NSColor* CAmber() { return SVRGB(255, 179, 71); }
NSColor* CLcdValue() { return SVRGB(255, 207, 138); }
NSColor* CLcdDim() { return SVRGB(184, 132, 60); }
NSColor* CLcdOk() { return SVRGB(123, 216, 143); }
NSColor* CLabel() { return SVRGB(170, 176, 184); }
NSColor* CTitle() { return SVRGB(233, 196, 106); }

double MidiOf(double hz) { return 69.0 + 12.0 * std::log2(hz / 440.0); }
NSString* NoteText(double hz) {
    static NSString* const names[12] = {@"C", @"C#", @"D", @"D#", @"E", @"F", @"F#", @"G", @"G#", @"A", @"A#", @"B"};
    const double m = MidiOf(hz);
    const long n = std::lround(m);
    const int cents = static_cast<int>(std::lround((m - static_cast<double>(n)) * 100.0));
    const long idx = ((n % 12) + 12) % 12;
    return [NSString stringWithFormat:@"%@%ld %+d ct", names[idx], n / 12 - 1, cents];
}
NSString* HzText(double hz) {
    return hz >= 1000.0 ? [NSString stringWithFormat:@"%.2f kHz", hz / 1000.0] : [NSString stringWithFormat:@"%.0f Hz", hz];
}
}

// A key like on the sampler: kind 0 = ON/OFF key with LED, 1 = orange action key, 2 = plain key.
@interface SVKey : NSButton
@property(nonatomic) BOOL on;
@property(nonatomic) NSInteger kind;
@property(nonatomic) CGFloat textSize;
@end

@implementation SVKey
- (instancetype)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) { self.bordered = NO; self.textSize = 12.0; }
    return self;
}
- (BOOL)isFlipped { return NO; }
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    const NSRect r = NSInsetRect(self.bounds, 1.0, 2.0);
    const BOOL down = self.cell.isHighlighted;
    // shadow
    [SVRGB(0, 0, 0, 0.45) setFill];
    [[NSBezierPath bezierPathWithRoundedRect:NSOffsetRect(r, 0.0, -1.5) xRadius:8.0 yRadius:8.0] fill];
    NSColor* top; NSColor* bottom; NSColor* text;
    if (self.kind == 1) {
        top = self.enabled ? SVRGB(255, 146, 62) : SVRGB(96, 99, 105);
        bottom = self.enabled ? SVRGB(214, 92, 10) : SVRGB(80, 83, 89);
        text = NSColor.whiteColor;
    } else if (self.kind == 0 && self.on) {
        top = SVRGB(40, 42, 47); bottom = SVRGB(28, 30, 34); text = CAmber();
    } else {
        top = SVRGB(74, 78, 85); bottom = SVRGB(58, 61, 67); text = SVRGB(205, 209, 215);
    }
    NSBezierPath* face = [NSBezierPath bezierPathWithRoundedRect:r xRadius:8.0 yRadius:8.0];
    [[[NSGradient alloc] initWithStartingColor:top endingColor:bottom] drawInBezierPath:face angle:-90.0];
    [SVRGB(20, 22, 25) setStroke];
    face.lineWidth = 1.0;
    [face stroke];
    [SVRGB(255, 255, 255, 0.10) setStroke];
    [NSBezierPath strokeLineFromPoint:NSMakePoint(NSMinX(r) + 8.0, NSMaxY(r) - 1.0) toPoint:NSMakePoint(NSMaxX(r) - 8.0, NSMaxY(r) - 1.0)];
    if (down) { [SVRGB(0, 0, 0, 0.28) setFill]; [face fill]; }
    if (!self.enabled) { [SVRGB(39, 41, 46, 0.6) setFill]; [face fill]; }
    CGFloat textLeft = NSMinX(r);
    if (self.kind == 0) {
        const NSRect led = NSMakeRect(NSMinX(r) + 10.0, NSMidY(r) - 4.0, 8.0, 8.0);
        if (self.on) {
            [SVRGB(255, 140, 30, 0.35) setFill];
            [[NSBezierPath bezierPathWithOvalInRect:NSInsetRect(led, -3.0, -3.0)] fill];
            [SVRGB(255, 170, 60) setFill];
        } else {
            [SVRGB(85, 85, 85) setFill];
        }
        [[NSBezierPath bezierPathWithOvalInRect:led] fill];
        textLeft += 14.0;
    }
    NSMutableParagraphStyle* ps = [[NSMutableParagraphStyle alloc] init];
    ps.alignment = NSTextAlignmentCenter;
    ps.lineBreakMode = NSLineBreakByTruncatingTail;
    NSDictionary* attrs = @{NSFontAttributeName: [NSFont systemFontOfSize:self.textSize weight:NSFontWeightBold],
                            NSForegroundColorAttributeName: text, NSParagraphStyleAttributeName: ps};
    const CGFloat h = self.textSize + 6.0;
    [self.title drawInRect:NSMakeRect(textLeft + 4.0, NSMidY(r) - h / 2.0 - 1.0, NSMaxX(r) - textLeft - 8.0, h) withAttributes:attrs];
}
@end

// ---------------------------------------------------------------- ANALYZER display

@interface SVSpectrumView : NSView
@property(nonatomic) double slope;      // dB per octave, like SPAN (4.5)
@property(nonatomic) double range;      // dB shown below 0
@property(nonatomic) BOOL showMax;
@property(nonatomic) BOOL showBefore;
@property(nonatomic) BOOL live;         // main curve is LIVE (else NOW = whole sample)
- (void)setMain:(const std::vector<float>&)main max:(const std::vector<float>&)max before:(const std::vector<float>&)before;
- (void)setMainOnly:(const std::vector<float>&)main;
@end

@implementation SVSpectrumView {
    std::vector<float> _main;
    std::vector<float> _max;
    std::vector<float> _before;
    NSTrackingArea* _tracking;
    BOOL _mouseInside;
    CGFloat _mouseX;
}

- (instancetype)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) { _slope = 4.5; _range = 72.0; _showMax = YES; _showBefore = YES; }
    return self;
}

- (void)setMain:(const std::vector<float>&)main max:(const std::vector<float>&)max before:(const std::vector<float>&)before {
    _main = main; _max = max; _before = before;
    [self setNeedsDisplay:YES];
}
- (void)setMainOnly:(const std::vector<float>&)main { _main = main; [self setNeedsDisplay:YES]; }

- (void)updateTrackingAreas {
    [super updateTrackingAreas];
    if (_tracking != nil) [self removeTrackingArea:_tracking];
    _tracking = [[NSTrackingArea alloc] initWithRect:NSZeroRect
                                             options:(NSTrackingMouseMoved | NSTrackingMouseEnteredAndExited | NSTrackingActiveInKeyWindow | NSTrackingInVisibleRect)
                                               owner:self userInfo:nil];
    [self addTrackingArea:_tracking];
}
- (void)mouseEntered:(NSEvent*)e { _mouseInside = YES; _mouseX = [self convertPoint:e.locationInWindow fromView:nil].x; [self setNeedsDisplay:YES]; }
- (void)mouseMoved:(NSEvent*)e { _mouseInside = YES; _mouseX = [self convertPoint:e.locationInWindow fromView:nil].x; [self setNeedsDisplay:YES]; }
- (void)mouseExited:(NSEvent*)e { (void)e; _mouseInside = NO; [self setNeedsDisplay:YES]; }

- (NSRect)plot { return NSMakeRect(44.0, 26.0, self.bounds.size.width - 54.0, self.bounds.size.height - 36.0); }
- (double)tilt:(double)hz { return (_slope - 3.0) * std::log2(hz / 1000.0); }  // band energy -> SPAN look
- (CGFloat)xOf:(double)hz plot:(NSRect)r { return r.origin.x + r.size.width * std::log10(hz / 20.0) / 3.0; }
- (CGFloat)yOf:(double)db plot:(NSRect)r {
    const double t = (std::max(-_range, std::min(0.0, db)) + _range) / _range;
    return r.origin.y + r.size.height * t;
}

- (NSBezierPath*)pathFor:(const std::vector<float>&)c plot:(NSRect)r {
    NSBezierPath* path = [NSBezierPath bezierPath];
    bool started = false;
    for (std::size_t i = 0U; i < c.size(); ++i) {
        const double hz = SpectrumAnalyzer::pointHz(i);
        const NSPoint p = NSMakePoint([self xOf:hz plot:r], [self yOf:c[i] + [self tilt:hz] plot:r]);
        if (!started) { [path moveToPoint:p]; started = true; } else { [path lineToPoint:p]; }
    }
    path.lineJoinStyle = NSLineJoinStyleRound;
    return path;
}

- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    // LCD body
    NSBezierPath* body = [NSBezierPath bezierPathWithRoundedRect:NSInsetRect(self.bounds, 0.5, 0.5) xRadius:10.0 yRadius:10.0];
    [[[NSGradient alloc] initWithStartingColor:SVRGB(23, 26, 22) endingColor:SVRGB(13, 15, 13)] drawInBezierPath:body angle:-90.0];
    [SVRGB(72, 76, 82) setStroke];
    [body stroke];

    const NSRect r = [self plot];
    NSDictionary* small = @{NSFontAttributeName: [NSFont monospacedDigitSystemFontOfSize:9.5 weight:NSFontWeightMedium], NSForegroundColorAttributeName: CLcdDim()};
    // grid
    const double minors[] = {30, 40, 60, 70, 80, 90, 300, 400, 600, 700, 800, 900, 3000, 4000, 6000, 7000, 8000, 9000};
    [SVRGB(255, 179, 71, 0.045) setStroke];
    for (double hz : minors) { const CGFloat x = [self xOf:hz plot:r]; [NSBezierPath strokeLineFromPoint:NSMakePoint(x, r.origin.y) toPoint:NSMakePoint(x, NSMaxY(r))]; }
    const double majors[] = {20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000};
    NSString* const majorNames[] = {@"20", @"50", @"100", @"200", @"500", @"1k", @"2k", @"5k", @"10k", @"20k"};
    for (int k = 0; k < 10; ++k) {
        const CGFloat x = [self xOf:majors[k] plot:r];
        [SVRGB(255, 179, 71, 0.12) setStroke];
        [NSBezierPath strokeLineFromPoint:NSMakePoint(x, r.origin.y) toPoint:NSMakePoint(x, NSMaxY(r))];
        const NSSize sz = [majorNames[k] sizeWithAttributes:small];
        const CGFloat lx = std::max(r.origin.x, std::min(x - sz.width / 2.0, NSMaxX(r) - sz.width));
        [majorNames[k] drawAtPoint:NSMakePoint(lx, 8.0) withAttributes:small];
    }
    for (double db = 0.0; db >= -_range - 0.1; db -= 6.0) {
        const CGFloat y = [self yOf:db plot:r];
        const bool major = std::fmod(-db, 12.0) < 0.1;
        [SVRGB(255, 179, 71, major ? 0.12 : 0.045) setStroke];
        [NSBezierPath strokeLineFromPoint:NSMakePoint(r.origin.x, y) toPoint:NSMakePoint(NSMaxX(r), y)];
        if (major) {
            NSString* t = [NSString stringWithFormat:@"%d", static_cast<int>(db)];
            const NSSize sz = [t sizeWithAttributes:small];
            [t drawAtPoint:NSMakePoint(r.origin.x - sz.width - 6.0, y - sz.height / 2.0) withAttributes:small];
        }
    }

    [NSGraphicsContext saveGraphicsState];
    NSRectClip(r);
    if (_main.size() == SpectrumAnalyzer::kPoints) {
        NSBezierPath* fill = [self pathFor:_main plot:r];
        [fill lineToPoint:NSMakePoint(NSMaxX(r), r.origin.y)];
        [fill lineToPoint:NSMakePoint(r.origin.x, r.origin.y)];
        [fill closePath];
        [[[NSGradient alloc] initWithStartingColor:SVRGB(255, 179, 71, 0.50) endingColor:SVRGB(255, 122, 26, 0.02)] drawInBezierPath:fill angle:-90.0];
    }
    if (_showMax && _max.size() == SpectrumAnalyzer::kPoints) {
        NSBezierPath* p = [self pathFor:_max plot:r];
        p.lineWidth = 1.0;
        [SVRGB(184, 132, 60, 0.85) setStroke];
        [p stroke];
    }
    if (_showBefore && _before.size() == SpectrumAnalyzer::kPoints) {
        NSBezierPath* p = [self pathFor:_before plot:r];
        const CGFloat dash[2] = {5.0, 4.0};
        [p setLineDash:dash count:2 phase:0.0];
        p.lineWidth = 1.4;
        [CLcdOk() setStroke];
        [p stroke];
    }
    if (_main.size() == SpectrumAnalyzer::kPoints) {
        NSBezierPath* p = [self pathFor:_main plot:r];
        p.lineWidth = 1.7;
        [CLcdValue() setStroke];
        [p stroke];
    }
    [NSGraphicsContext restoreGraphicsState];

    // legend
    NSFont* lf = [NSFont systemFontOfSize:10.5 weight:NSFontWeightBold];
    CGFloat lx = r.origin.x + 12.0;
    const CGFloat ly = NSMaxY(r) - 20.0;
    NSArray* legend = @[@[_live ? @"━ LIVE" : @"━ NOW", CLcdValue()], @[@"━ MAX", CLcdDim()], @[@"╍ BEFORE", CLcdOk()]];
    for (NSUInteger k = 0; k < legend.count; ++k) {
        if (k == 1 && !(_showMax && !_max.empty())) continue;
        if (k == 2 && !(_showBefore && !_before.empty())) continue;
        NSDictionary* a = @{NSFontAttributeName: lf, NSForegroundColorAttributeName: legend[k][1]};
        [legend[k][0] drawAtPoint:NSMakePoint(lx, ly) withAttributes:a];
        lx += [legend[k][0] sizeWithAttributes:a].width + 16.0;
    }

    if (_main.empty()) {
        NSDictionary* a = @{NSFontAttributeName: [NSFont systemFontOfSize:14.0 weight:NSFontWeightSemibold], NSForegroundColorAttributeName: CLcdDim()};
        NSString* t = @"Choose a sample above";
        const NSSize sz = [t sizeWithAttributes:a];
        [t drawAtPoint:NSMakePoint(NSMidX(r) - sz.width / 2.0, NSMidY(r)) withAttributes:a];
        return;
    }

    // mouse readout: frequency · note · level
    if (_mouseInside && _mouseX >= r.origin.x && _mouseX <= NSMaxX(r)) {
        const double hz = 20.0 * std::pow(10.0, 3.0 * (_mouseX - r.origin.x) / r.size.width);
        std::size_t idx = static_cast<std::size_t>(std::lround(std::log(hz / 20.0) / std::log(1000.0) * static_cast<double>(SpectrumAnalyzer::kPoints - 1U)));
        idx = std::min(idx, SpectrumAnalyzer::kPoints - 1U);
        const double db = _main[idx] + [self tilt:SpectrumAnalyzer::pointHz(idx)];
        const CGFloat y = [self yOf:db plot:r];
        NSBezierPath* line = [NSBezierPath bezierPath];
        [line moveToPoint:NSMakePoint(_mouseX, r.origin.y)];
        [line lineToPoint:NSMakePoint(_mouseX, NSMaxY(r))];
        const CGFloat dot[2] = {2.0, 3.0};
        [line setLineDash:dot count:2 phase:0.0];
        [SVRGB(255, 207, 138, 0.55) setStroke];
        [line stroke];
        [NSColor.whiteColor setFill];
        [[NSBezierPath bezierPathWithOvalInRect:NSMakeRect(_mouseX - 3.5, y - 3.5, 7.0, 7.0)] fill];
        NSString* t = [NSString stringWithFormat:@"%@   %@   %.1f dB", HzText(hz), NoteText(hz), db];
        NSDictionary* a = @{NSFontAttributeName: [NSFont monospacedDigitSystemFontOfSize:11.0 weight:NSFontWeightBold], NSForegroundColorAttributeName: NSColor.whiteColor};
        const NSSize sz = [t sizeWithAttributes:a];
        CGFloat bx = _mouseX + 12.0;
        if (bx + sz.width + 16.0 > NSMaxX(r)) bx = _mouseX - sz.width - 28.0;
        const CGFloat by = std::min(std::max(y + 10.0, r.origin.y + 4.0), NSMaxY(r) - sz.height - 12.0);
        NSBezierPath* box = [NSBezierPath bezierPathWithRoundedRect:NSMakeRect(bx, by, sz.width + 16.0, sz.height + 8.0) xRadius:6.0 yRadius:6.0];
        [SVRGB(13, 15, 13, 0.94) setFill];
        [box fill];
        [CAmber() setStroke];
        [box stroke];
        [t drawAtPoint:NSMakePoint(bx + 8.0, by + 4.0) withAttributes:a];
    }
}
@end

// PEAK / RMS meters (dBFS), sampler meter colours.
@interface SVMeterView : NSView
- (void)setPeakDb:(double)peak rmsDb:(double)rms;
@end

@implementation SVMeterView {
    double _peak;
    double _rms;
}
- (instancetype)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) { _peak = -120.0; _rms = -120.0; }
    return self;
}
- (void)setPeakDb:(double)peak rmsDb:(double)rms { _peak = peak; _rms = rms; [self setNeedsDisplay:YES]; }
- (void)drawBar:(NSRect)bar value:(double)db name:(NSString*)name {
    [SVRGB(27, 29, 32) setFill];
    [[NSBezierPath bezierPathWithRoundedRect:bar xRadius:3.0 yRadius:3.0] fill];
    const double t = std::max(0.0, std::min(1.0, (db + 60.0) / 60.0));
    const NSRect lit = NSMakeRect(bar.origin.x, bar.origin.y, bar.size.width, bar.size.height * t);
    [NSGraphicsContext saveGraphicsState];
    NSRectClip(lit);
    NSGradient* g = [[NSGradient alloc] initWithColorsAndLocations:SVRGB(60, 157, 90), 0.0, SVRGB(60, 157, 90), 0.70,
                                                                    SVRGB(233, 196, 106), 0.85, SVRGB(255, 107, 61), 1.0, nil];
    [g drawInRect:bar angle:90.0];
    [NSGraphicsContext restoreGraphicsState];
    NSDictionary* a = @{NSFontAttributeName: [NSFont systemFontOfSize:8.5 weight:NSFontWeightBold], NSForegroundColorAttributeName: CLabel()};
    NSDictionary* v = @{NSFontAttributeName: [NSFont monospacedDigitSystemFontOfSize:9.0 weight:NSFontWeightBold], NSForegroundColorAttributeName: CLcdValue()};
    const NSSize ns1 = [name sizeWithAttributes:a];
    [name drawAtPoint:NSMakePoint(NSMidX(bar) - ns1.width / 2.0, 8.0) withAttributes:a];
    NSString* val = db <= -99.0 ? @"-inf" : [NSString stringWithFormat:@"%.1f", db];
    const NSSize vs = [val sizeWithAttributes:v];
    [val drawAtPoint:NSMakePoint(NSMidX(bar) - vs.width / 2.0, NSMaxY(bar) + 3.0) withAttributes:v];
}
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    const CGFloat h = self.bounds.size.height - 46.0;
    [self drawBar:NSMakeRect(2.0, 26.0, 20.0, h) value:_peak name:@"PEAK"];
    [self drawBar:NSMakeRect(30.0, 26.0, 20.0, h) value:_rms name:@"RMS"];
}
@end

// ---------------------------------------------------------------- PROCESSING page

namespace {
NSString* const kPrefSlope = @"SVAnalyzerSlope";
NSString* const kPrefSmooth = @"SVAnalyzerSmooth";
NSString* const kPrefRange = @"SVAnalyzerRange";
NSString* const kPrefShowMax = @"SVAnalyzerShowMax";
NSString* const kPrefShowBefore = @"SVAnalyzerShowBefore";
const double kSlopes[] = {0.0, 3.0, 4.5, 6.0};
const double kSmooths[] = {1.0 / 3.0, 1.0 / 6.0, 1.0 / 12.0, 1.0 / 24.0};
NSString* const kSmoothNames[] = {@"1/3", @"1/6", @"1/12", @"1/24"};
const double kRanges[] = {48.0, 72.0, 96.0, 120.0};

struct BeforeSpectrum {
    std::uint32_t rate{0U};
    std::vector<float> average;
};

double ToDb(double v) { return v > 1e-6 ? 20.0 * std::log10(v) : -120.0; }
}

@interface SVProcessingPage : NSView
- (void)refresh;
@end

@implementation SVProcessingPage {
    SVKey* _convert;
    SVKey* _normalize;
    SVKey* _perSample;
    SVKey* _perInstrument;
    SVKey* _tone;
    SVKey* _limiter;
    NSTextField* _info;
    NSTextField* _status;
    // analyzer
    NSPopUpButton* _samplePopup;
    SVKey* _play;
    SVKey* _hold;
    SVKey* _beforeKey;
    SVKey* _maxKey;
    SVKey* _slopeKey;
    SVKey* _smoothKey;
    SVKey* _rangeKey;
    SVSpectrumView* _spectrum;
    SVMeterView* _meter;
    SVSampleAuditionPlayer* _player;
    NSTimer* _timer;
    NSInteger _idleTicks;
    int _slopeIndex;
    int _smoothIndex;
    int _rangeIndex;
    std::vector<float> _mono;
    SpectrumPower _now;
    std::vector<float> _livePower;
    double _livePeakDb;
    double _liveRmsDb;
    std::map<std::uint32_t, BeforeSpectrum> _beforeById;
    std::uint32_t _selectedKey;
}

static SVKey* MakeKey(NSRect frame, NSString* title, NSInteger kind, CGFloat size, id target, SEL action) {
    SVKey* k = [[SVKey alloc] initWithFrame:frame];
    k.title = title;
    k.kind = kind;
    k.textSize = size;
    k.target = target;
    k.action = action;
    return k;
}

static NSTextField* PageLabel(NSRect frame, NSString* text, CGFloat size, NSFontWeight weight, NSColor* color) {
    NSTextField* l = SVPLabel(frame, text, size, weight);
    l.textColor = color;
    return l;
}

- (BOOL)isFlipped { return NO; }

- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    // graphite board like the sampler
    [[[NSGradient alloc] initWithStartingColor:SVRGB(52, 55, 61) endingColor:SVRGB(39, 41, 46)] drawInRect:self.bounds angle:-90.0];
    NSBezierPath* strip = [NSBezierPath bezierPathWithRoundedRect:NSMakeRect(14.0, 552.0, self.bounds.size.width - 28.0, 130.0) xRadius:12.0 yRadius:12.0];
    [SVRGB(0, 0, 0, 0.15) setFill];
    [strip fill];
    [SVRGB(85, 89, 95) setStroke];
    [strip stroke];
}

- (instancetype)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;
    NSUserDefaults* prefs = [NSUserDefaults standardUserDefaults];

    // ---- processing strip
    [self addSubview:PageLabel(NSMakeRect(28.0, 646.0, 220.0, 28.0), @"3  PROCESSING", 18.0, NSFontWeightBold, CTitle())];
    [self addSubview:PageLabel(NSMakeRect(214.0, 651.0, 520.0, 18.0), @"nothing runs by itself — switch ON, then press START", 10.5, NSFontWeightMedium, CLabel())];
    _convert = MakeKey(NSMakeRect(26.0, 604.0, 250.0, 36.0), @"CONVERT TO 48 kHz", 0, 12.0, self, @selector(togglePressed:));
    _normalize = MakeKey(NSMakeRect(284.0, 604.0, 250.0, 36.0), @"EQUAL LOUDNESS  -6 dB", 0, 12.0, self, @selector(togglePressed:));
    _perSample = MakeKey(NSMakeRect(542.0, 604.0, 168.0, 36.0), @"per SAMPLE", 0, 11.0, self, @selector(modePressed:));
    _perInstrument = MakeKey(NSMakeRect(716.0, 604.0, 168.0, 36.0), @"per INSTRUMENT", 0, 11.0, self, @selector(modePressed:));
    _tone = MakeKey(NSMakeRect(26.0, 562.0, 250.0, 36.0), @"EVEN TONE  LOW → HIGH", 0, 12.0, self, @selector(togglePressed:));
    _limiter = MakeKey(NSMakeRect(284.0, 562.0, 250.0, 36.0), @"SOFT PEAK LIMITER", 0, 12.0, self, @selector(togglePressed:));
    for (SVKey* k in @[_convert, _normalize, _perSample, _perInstrument, _tone, _limiter]) [self addSubview:k];
    _info = PageLabel(NSMakeRect(544.0, 580.0, 346.0, 16.0), @"", 10.5, NSFontWeightMedium, CLabel());
    [self addSubview:_info];
    _status = PageLabel(NSMakeRect(544.0, 562.0, 346.0, 16.0), @"", 10.0, NSFontWeightBold, CAmber());
    [self addSubview:_status];
    [self addSubview:MakeKey(NSMakeRect(896.0, 562.0, 96.0, 78.0), @"START", 1, 15.0, self, @selector(startPressed:))];
    [self addSubview:MakeKey(NSMakeRect(998.0, 562.0, 96.0, 78.0), @"SKIP →", 2, 13.0, self, @selector(skipPressed:))];

    _convert.on = [prefs boolForKey:kPrefConvert];
    _normalize.on = [prefs boolForKey:kPrefNormalize];
    _tone.on = [prefs boolForKey:kPrefTone];
    _limiter.on = [prefs boolForKey:kPrefLimiter];
    const BOOL perInstrument = [prefs boolForKey:kPrefPerInstrument];
    _perSample.on = !perInstrument;
    _perInstrument.on = perInstrument;
    [self updateEnabled];

    // ---- analyzer toolbar
    [self addSubview:PageLabel(NSMakeRect(24.0, 512.0, 110.0, 24.0), @"ANALYZER", 15.0, NSFontWeightBold, CTitle())];
    _samplePopup = [[NSPopUpButton alloc] initWithFrame:NSMakeRect(130.0, 511.0, 330.0, 26.0) pullsDown:NO];
    _samplePopup.target = self;
    _samplePopup.action = @selector(sampleChanged:);
    [self addSubview:_samplePopup];
    _play = MakeKey(NSMakeRect(466.0, 508.0, 66.0, 32.0), @"▶ PLAY", 0, 11.0, self, @selector(playPressed:));
    SVKey* stop = MakeKey(NSMakeRect(536.0, 508.0, 66.0, 32.0), @"■ STOP", 2, 11.0, self, @selector(stopPlayPressed:));
    _hold = MakeKey(NSMakeRect(610.0, 508.0, 72.0, 32.0), @"HOLD", 0, 11.0, self, @selector(holdPressed:));
    _beforeKey = MakeKey(NSMakeRect(686.0, 508.0, 86.0, 32.0), @"BEFORE", 0, 11.0, self, @selector(curvePressed:));
    _maxKey = MakeKey(NSMakeRect(776.0, 508.0, 66.0, 32.0), @"MAX", 0, 11.0, self, @selector(curvePressed:));
    _slopeKey = MakeKey(NSMakeRect(848.0, 508.0, 82.0, 32.0), @"", 2, 10.5, self, @selector(slopePressed:));
    _smoothKey = MakeKey(NSMakeRect(934.0, 508.0, 82.0, 32.0), @"", 2, 10.5, self, @selector(smoothPressed:));
    _rangeKey = MakeKey(NSMakeRect(1020.0, 508.0, 76.0, 32.0), @"", 2, 10.5, self, @selector(rangePressed:));
    for (SVKey* k in @[_play, stop, _hold, _beforeKey, _maxKey, _slopeKey, _smoothKey, _rangeKey]) [self addSubview:k];

    _spectrum = [[SVSpectrumView alloc] initWithFrame:NSMakeRect(18.0, 34.0, 1018.0, 466.0)];
    [self addSubview:_spectrum];
    _meter = [[SVMeterView alloc] initWithFrame:NSMakeRect(1042.0, 34.0, 54.0, 466.0)];
    [self addSubview:_meter];
    [self addSubview:PageLabel(NSMakeRect(24.0, 10.0, 1070.0, 16.0),
                               @"EVEN TONE: every KMP alone, 2 passes, max ±6 dB.  LIMITER: rounded, only the peaks, max 3 dB.  Mouse over the picture: frequency · note · level.  BEFORE = before the last START.",
                               9.5, NSFontWeightMedium, CLabel())];

    _slopeIndex = 2; _smoothIndex = 1; _rangeIndex = 1;
    if ([prefs objectForKey:kPrefSlope] != nil) _slopeIndex = static_cast<int>(std::max<NSInteger>(0, std::min<NSInteger>(3, [prefs integerForKey:kPrefSlope])));
    if ([prefs objectForKey:kPrefSmooth] != nil) _smoothIndex = static_cast<int>(std::max<NSInteger>(0, std::min<NSInteger>(3, [prefs integerForKey:kPrefSmooth])));
    if ([prefs objectForKey:kPrefRange] != nil) _rangeIndex = static_cast<int>(std::max<NSInteger>(0, std::min<NSInteger>(3, [prefs integerForKey:kPrefRange])));
    _maxKey.on = [prefs objectForKey:kPrefShowMax] != nil ? [prefs boolForKey:kPrefShowMax] : YES;
    _beforeKey.on = [prefs objectForKey:kPrefShowBefore] != nil ? [prefs boolForKey:kPrefShowBefore] : YES;
    _player = [[SVSampleAuditionPlayer alloc] init];
    _livePeakDb = -120.0;
    _liveRmsDb = -120.0;
    _selectedKey = 0U;
    [self applyDisplaySettings];

    for (NSView* v in self.subviews) v.autoresizingMask = NSViewMinYMargin;
    _spectrum.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    _meter.autoresizingMask = NSViewMinXMargin | NSViewHeightSizable;
    return self;
}

// ---- processing switches

- (void)updateEnabled {
    _perSample.enabled = _normalize.on;
    _perInstrument.enabled = _normalize.on;
    for (SVKey* k in @[_convert, _normalize, _perSample, _perInstrument, _tone, _limiter]) [k setNeedsDisplay:YES];
}

- (void)save {
    NSUserDefaults* prefs = [NSUserDefaults standardUserDefaults];
    [prefs setBool:_convert.on forKey:kPrefConvert];
    [prefs setBool:_normalize.on forKey:kPrefNormalize];
    [prefs setBool:_tone.on forKey:kPrefTone];
    [prefs setBool:_limiter.on forKey:kPrefLimiter];
    [prefs setBool:_perInstrument.on forKey:kPrefPerInstrument];
}

- (void)togglePressed:(SVKey*)sender {
    sender.on = !sender.on;
    [self updateEnabled];
    [self save];
}

- (void)modePressed:(SVKey*)sender {
    _perSample.on = (sender == _perSample);
    _perInstrument.on = (sender == _perInstrument);
    [self updateEnabled];
    [self save];
}

- (void)skipPressed:(id)sender {
    (void)sender;
    [ProcessingDelegate() showMultisampleEditor:nil];
}

// ---- analyzer settings

- (void)applyDisplaySettings {
    _slopeKey.title = [NSString stringWithFormat:@"SLOPE %g", kSlopes[_slopeIndex]];
    _smoothKey.title = [NSString stringWithFormat:@"SMOOTH %@", kSmoothNames[_smoothIndex]];
    _rangeKey.title = [NSString stringWithFormat:@"RANGE %d", static_cast<int>(kRanges[_rangeIndex])];
    _spectrum.slope = kSlopes[_slopeIndex];
    _spectrum.range = kRanges[_rangeIndex];
    _spectrum.showMax = _maxKey.on;
    _spectrum.showBefore = _beforeKey.on;
    for (SVKey* k in @[_slopeKey, _smoothKey, _rangeKey, _maxKey, _beforeKey]) [k setNeedsDisplay:YES];
    NSUserDefaults* prefs = [NSUserDefaults standardUserDefaults];
    [prefs setInteger:_slopeIndex forKey:kPrefSlope];
    [prefs setInteger:_smoothIndex forKey:kPrefSmooth];
    [prefs setInteger:_rangeIndex forKey:kPrefRange];
    [prefs setBool:_maxKey.on forKey:kPrefShowMax];
    [prefs setBool:_beforeKey.on forKey:kPrefShowBefore];
    [self redrawStatic];
}

- (void)slopePressed:(id)sender { (void)sender; _slopeIndex = (_slopeIndex + 1) % 4; [self applyDisplaySettings]; }
- (void)smoothPressed:(id)sender { (void)sender; _smoothIndex = (_smoothIndex + 1) % 4; [self applyDisplaySettings]; }
- (void)rangePressed:(id)sender { (void)sender; _rangeIndex = (_rangeIndex + 1) % 4; [self applyDisplaySettings]; }
- (void)curvePressed:(SVKey*)sender { sender.on = !sender.on; [self applyDisplaySettings]; }
- (void)holdPressed:(SVKey*)sender { sender.on = !sender.on; [sender setNeedsDisplay:YES]; }

- (void)redrawStatic {
    const double smooth = kSmooths[_smoothIndex];
    std::vector<float> before;
    const auto found = _beforeById.find(_selectedKey);
    if (found != _beforeById.end()) before = SpectrumAnalyzer::toCurve(found->second.average, found->second.rate, smooth);
    const BOOL live = (_timer != nil && !_livePower.empty());
    const std::vector<float> main = live ? SpectrumAnalyzer::toCurve(_livePower, _now.sampleRate, smooth)
                                         : (_now.empty() ? std::vector<float>() : SpectrumAnalyzer::toCurve(_now.average, _now.sampleRate, smooth));
    const std::vector<float> mx = _now.empty() ? std::vector<float>() : SpectrumAnalyzer::toCurve(_now.maximum, _now.sampleRate, smooth);
    _spectrum.live = live;
    [_spectrum setMain:main max:mx before:before];
    if (live) [_meter setPeakDb:_livePeakDb rmsDb:_liveRmsDb];
    else if (_now.empty()) [_meter setPeakDb:-120.0 rmsDb:-120.0];
    else [_meter setPeakDb:ToDb(_now.peak) rmsDb:ToDb(_now.rms)];
}

// ---- sample choice

- (void)refresh {
    BankProject* project = ProcessingProject(ProcessingDocument());
    if (project == nullptr) { _info.stringValue = @""; return; }
    std::size_t not48 = 0U;
    for (const auto& s : project->samples) if (s.sampleRate != 48000U) ++not48;
    _info.stringValue = [NSString stringWithFormat:@"%lu samples  ·  %lu instruments  ·  %lu not 48 kHz",
                         (unsigned long)project->samples.size(), (unsigned long)project->multisamples.size(), (unsigned long)not48];
    const NSInteger keep = _samplePopup.indexOfSelectedItem;
    [_samplePopup removeAllItems];
    NSArray<NSString*>* rows = [ProcessingDocument() sampleDisplayRows];
    for (NSString* row in rows) [_samplePopup.menu addItemWithTitle:row action:nil keyEquivalent:@""];  // menu keeps equal names
    if (rows.count > 0U) [_samplePopup selectItemAtIndex:(keep >= 0 && keep < static_cast<NSInteger>(rows.count)) ? keep : 0];
    [self loadSelected];
}

- (void)stopLive {
    [_player stop];
    [_timer invalidate];
    _timer = nil;
    _livePower.clear();
    _play.on = NO;
    [_play setNeedsDisplay:YES];
}

- (void)loadSelected {
    [self stopLive];
    _mono.clear();
    _now = SpectrumPower{};
    _selectedKey = 0U;
    BankProject* project = ProcessingProject(ProcessingDocument());
    const NSInteger i = _samplePopup.indexOfSelectedItem;
    if (project != nullptr && i >= 0 && static_cast<std::size_t>(i) < project->samples.size()) {
        const auto& sample = project->samples[static_cast<std::size_t>(i)];
        _mono = SpectrumAnalyzer::monoMix(sample);
        _now = SpectrumAnalyzer::analyse(sample);
        _selectedKey = sample.sampleId != 0U ? sample.sampleId : 0x80000000U + static_cast<std::uint32_t>(i);
    }
    [self redrawStatic];
}

- (void)sampleChanged:(id)sender {
    (void)sender;
    [self loadSelected];
}

// ---- live

- (void)playPressed:(id)sender {
    (void)sender;
    const NSInteger i = _samplePopup.indexOfSelectedItem;
    if (i < 0) return;
    NSString* error = nil;
    NSDictionary* state = [ProcessingDocument() auditionStateAtIndex:static_cast<NSUInteger>(i) error:&error];
    if (state == nil || ![_player playState:state loopOnly:NO error:&error]) {
        ProcessingMessage(@"PLAY", error ?: @"The sample cannot be played.", NSAlertStyleWarning);
        return;
    }
    _play.on = YES;
    [_play setNeedsDisplay:YES];
    _idleTicks = 0;
    _livePower.clear();
    _livePeakDb = -120.0;
    _liveRmsDb = -120.0;
    if (_timer == nil) {
        _timer = [NSTimer timerWithTimeInterval:1.0 / 30.0 target:self selector:@selector(tick:) userInfo:nil repeats:YES];
        [[NSRunLoop mainRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes];
    }
}

- (void)stopPlayPressed:(id)sender {
    (void)sender;
    [self stopLive];
    [self redrawStatic];
}

- (void)tick:(NSTimer*)timer {
    (void)timer;
    if (_hold.on) return;  // picture frozen
    UInt64 frame = 0U;
    const BOOL playing = !_mono.empty() && [_player currentPlayFrame:&frame];
    if (!playing) {
        if (++_idleTicks > 20) { [self stopLive]; [self redrawStatic]; }
        return;
    }
    _idleTicks = 0;
    // time averaging ~200 ms (like an analyser plug-in, no jumping)
    const std::vector<float> fresh = SpectrumAnalyzer::powerAt(_mono, frame);
    if (_livePower.size() != fresh.size()) _livePower = fresh;
    else for (std::size_t k = 0; k < fresh.size(); ++k) _livePower[k] = 0.85F * _livePower[k] + 0.15F * fresh[k];
    // meters over the last 4096 frames
    const std::size_t end = std::min<std::size_t>(static_cast<std::size_t>(frame), _mono.size());
    const std::size_t begin = end > 4096U ? end - 4096U : 0U;
    double sq = 0.0; float pk = 0.0F;
    for (std::size_t f = begin; f < end; ++f) { sq += static_cast<double>(_mono[f]) * _mono[f]; pk = std::max(pk, std::fabs(_mono[f])); }
    const double rmsDb = end > begin ? ToDb(std::sqrt(sq / static_cast<double>(end - begin))) : -120.0;
    _livePeakDb = std::max(ToDb(pk), _livePeakDb - 0.8);   // peak falls slowly
    _liveRmsDb = 0.8 * _liveRmsDb + 0.2 * rmsDb;
    [self redrawStatic];
}

- (void)viewDidMoveToWindow {
    [super viewDidMoveToWindow];
    if (self.window == nil) [self stopLive];
}

// ---- START

- (void)startPressed:(id)sender {
    (void)sender;
    SVManagerDocument* document = ProcessingDocument();
    BankProject* project = ProcessingProject(document);
    if (project == nullptr || project->samples.empty()) {
        ProcessingMessage(@"PROCESSING", @"There are no samples yet. Import first (1 MEDIA).", NSAlertStyleWarning);
        return;
    }
    SampleProcessingOptions options;
    options.convertTo48k = _convert.on;
    options.normalize = _normalize.on;
    options.normalizePerInstrument = _perInstrument.on;
    options.evenTone = _tone.on;
    options.softLimiter = _limiter.on;
    if (!options.convertTo48k && !options.normalize && !options.evenTone && !options.softLimiter) {
        ProcessingMessage(@"PROCESSING", @"Everything is OFF. Switch ON at least one function, or press SKIP.", NSAlertStyleInformational);
        return;
    }

    [self stopLive];
    SVProgressPanel* progress = [[SVProgressPanel alloc] initWithTitle:@"PROCESSING"];
    __block bool ok = false;
    __block SampleProcessingReport report;
    __block std::string error;
    __block std::vector<SpectrumPower> before;
    __block std::vector<std::uint32_t> beforeIds;
    [progress runWork:^(SVProgressPanel* p) {
        // 1. analyse and keep the spectrum BEFORE processing (for the comparison)
        std::vector<std::size_t> all(project->samples.size());
        for (std::size_t k = 0; k < all.size(); ++k) {
            all[k] = k;
            beforeIds.push_back(project->samples[k].sampleId != 0U ? project->samples[k].sampleId : 0x80000000U + static_cast<std::uint32_t>(k));
        }
        before = SpectrumAnalyzer::analyseMany(*project, all, [p](double f) { [p setFraction:0.3 * f text:@"Analyzing spectrum (BEFORE)"]; }, [p stopFlag]);
        if ([p stopRequested]) { ok = true; report.cancelled = true; return; }
        // 2. processing
        ok = SampleProcessor::process(*project, {}, options,
                                      [p](double f, const std::string& stage) { [p setFraction:0.3 + 0.7 * f text:ns(stage)]; },
                                      [p stopFlag], report, error);
    }];

    if (!ok) {
        ProcessingMessage(@"PROCESSING failed", ns(error), NSAlertStyleCritical);
        return;
    }
    if (report.cancelled) {
        _status.stringValue = @"Stopped. Nothing was changed.";
        return;
    }
    // Audio changed: editor undo/clipboard point at old frames, reset them but keep the bank.
    BankProject saved = std::move(*project);
    [document clearProject];
    project = ProcessingProject(document);
    if (project != nullptr) *project = std::move(saved);
    [document markCurrentStateChanged];
    for (std::size_t k = 0; k < before.size() && k < beforeIds.size(); ++k) {
        if (before[k].empty()) continue;
        BeforeSpectrum b;
        b.rate = before[k].sampleRate;
        b.average = std::move(before[k].average);
        _beforeById[beforeIds[k]] = std::move(b);
    }
    [ProcessingDelegate() refreshAllEditors];
    [self refresh];
    NSMutableArray<NSString*>* parts = [NSMutableArray array];
    if (options.convertTo48k) [parts addObject:[NSString stringWithFormat:@"48 kHz: %lu", (unsigned long)report.converted]];
    if (options.evenTone) [parts addObject:[NSString stringWithFormat:@"tone: %lu (skipped %lu)", (unsigned long)report.toneAdjusted, (unsigned long)report.skipped]];
    if (options.softLimiter) [parts addObject:[NSString stringWithFormat:@"limiter: %lu", (unsigned long)report.limited]];
    if (options.normalize) [parts addObject:[NSString stringWithFormat:@"-6 dB: %lu", (unsigned long)report.normalized]];
    _status.stringValue = [NSString stringWithFormat:@"Done.  %@", [parts componentsJoinedByString:@" · "]];
}
@end

@implementation SVAppDelegate (Processing)
- (void)showProcessingCommand:(id)sender {
    (void)sender;
    SVProcessingPage* page = objc_getAssociatedObject(self, kSVProcessingPageKey);
    if (page == nil) {
        page = [[SVProcessingPage alloc] initWithFrame:NSMakeRect(0.0, 0.0, 1114.0, 694.0)];
        objc_setAssociatedObject(self, kSVProcessingPageKey, page, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
    [page refresh];
    id main = [self valueForKey:@"mainWindowController"];
    [(SVMainWindowController*)main showEmbeddedWorkspaceView:page identifier:@"PROCESSING"];
}
@end
