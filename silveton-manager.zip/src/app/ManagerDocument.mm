#import <Foundation/Foundation.h>

#include "silveton/manager/AudioFileLoader.h"
#include "silveton/manager/KorgImporter.h"
#include "silveton/manager/PitchDetector.h"
#include "silveton/manager/SampleEditor.h"
#include "silveton/manager/AutoMapper.h"
#include "silveton/manager/WaveSmoother.h"
#include "silveton/manager/SoundEditor.h"
#include "silveton/manager/SvBankBuilder.h"

#include <cstddef>
#include <algorithm>
#include <array>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <deque>
#include <limits>
#include <sstream>
#include <string>
#include <utility>
#include <vector>

namespace {
using namespace silveton::manager;

struct SampleHistoryEntry {
    std::size_t sampleIndex{0U};
    ImportedSample sample{};
    std::size_t storageBytes{0U};
};

constexpr std::size_t kMaxSampleHistoryEntries = 16U;
constexpr std::size_t kMaxSampleHistoryBytes = 256U * 1024U * 1024U;
constexpr std::uint16_t kLibraryAxisMaximum = 127U;

std::size_t filenameStart(const std::string& path) noexcept {
    const std::size_t slash = path.find_last_of("/\\");
    return slash == std::string::npos ? 0U : slash + 1U;
}

std::string filenameOnly(const std::string& path) {
    return path.substr(filenameStart(path));
}

std::string lowerExtension(const std::string& path) {
    const std::size_t start = filenameStart(path);
    const std::size_t dot = path.find_last_of('.');
    std::string ext;
    if (dot != std::string::npos && dot >= start) ext = path.substr(dot);
    std::transform(ext.begin(), ext.end(), ext.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    return ext;
}

NSString* nsString(const std::string& value) {
    // SILVETON_STABLE_V1: names from KMP/KSF files are not always UTF-8. A nil string inside
    // @{...} or @[...] crashes the app, so fall back to Latin-1 and never return nil.
    NSString* s = [NSString stringWithUTF8String:value.c_str()];
    if (s == nil) s = [[NSString alloc] initWithBytes:value.data() length:value.size() encoding:NSISOLatin1StringEncoding];
    return s ?: @"";
}

void setError(NSString** error, const std::string& message) {
    if (error != nullptr) *error = nsString(message);
}

void clearError(NSString** error) {
    if (error != nullptr) *error = nil;
}

std::size_t sampleStorageBytes(const ImportedSample& sample) noexcept {
    return sizeof(ImportedSample) + sample.audioData.size() + sample.name.size() + sample.sourcePath.size() + sample.sourceIdentity.size();
}

void clearHistory(std::deque<SampleHistoryEntry>& history, std::size_t& historyBytes) noexcept {
    history.clear();
    historyBytes = 0U;
}

void trimHistory(std::deque<SampleHistoryEntry>& history, std::size_t& historyBytes) noexcept {
    while (history.size() > kMaxSampleHistoryEntries ||
           (historyBytes > kMaxSampleHistoryBytes && history.size() > 1U)) {
        historyBytes -= history.front().storageBytes;
        history.pop_front();
    }
}

void pushHistory(std::deque<SampleHistoryEntry>& history,
                 std::size_t& historyBytes,
                 std::size_t sampleIndex,
                 const ImportedSample& sample) {
    SampleHistoryEntry entry{};
    entry.sampleIndex = sampleIndex;
    entry.sample = sample;
    entry.storageBytes = sampleStorageBytes(entry.sample);
    historyBytes += entry.storageBytes;
    history.push_back(std::move(entry));
    trimHistory(history, historyBytes);
}

void commitSampleEdit(BankProject& project,
                      std::size_t sampleIndex,
                      ImportedSample edited,
                      std::deque<SampleHistoryEntry>& undoHistory,
                      std::size_t& undoBytes,
                      std::deque<SampleHistoryEntry>& redoHistory,
                      std::size_t& redoBytes) {
    pushHistory(undoHistory, undoBytes, sampleIndex, project.samples[sampleIndex]);
    clearHistory(redoHistory, redoBytes);
    project.samples[sampleIndex] = std::move(edited);
}

bool validSampleIndex(const BankProject& project, NSUInteger index) noexcept {
    return static_cast<std::size_t>(index) < project.samples.size();
}

bool validMultisampleIndex(const BankProject& project, NSUInteger index) noexcept {
    return static_cast<std::size_t>(index) < project.multisamples.size();
}

bool validZoneIndex(const BankProject& project, NSUInteger multisampleIndex, NSUInteger zoneIndex) noexcept {
    if (!validMultisampleIndex(project, multisampleIndex)) return false;
    return static_cast<std::size_t>(zoneIndex) < project.multisamples[static_cast<std::size_t>(multisampleIndex)].zones.size();
}

bool validSoundIndex(const BankProject& project, NSUInteger index) noexcept {
    return static_cast<std::size_t>(index) < project.sounds.size();
}

bool validSoundLayerIndex(const BankProject& project, NSUInteger soundIndex, NSUInteger layerIndex) noexcept {
    if (!validSoundIndex(project, soundIndex)) return false;
    return static_cast<std::size_t>(layerIndex) < project.sounds[static_cast<std::size_t>(soundIndex)].layers.size();
}

template <typename EditFunction>
bool applySampleEdit(BankProject& project,
                     NSUInteger index,
                     std::deque<SampleHistoryEntry>& undoHistory,
                     std::size_t& undoBytes,
                     std::deque<SampleHistoryEntry>& redoHistory,
                     std::size_t& redoBytes,
                     NSString** error,
                     EditFunction&& edit) {
    if (!validSampleIndex(project, index)) {
        if (error != nullptr) *error = @"No sample is selected.";
        return false;
    }
    const std::size_t sampleIndex = static_cast<std::size_t>(index);
    ImportedSample edited = project.samples[sampleIndex];
    std::string editError;
    if (!edit(edited, editError)) {
        setError(error, editError);
        return false;
    }
    commitSampleEdit(project, sampleIndex, std::move(edited), undoHistory, undoBytes, redoHistory, redoBytes);
    clearError(error);
    return true;
}

std::uint32_t nextSampleIdValue(const BankProject& project) noexcept {
    std::uint32_t maxId = 0U;
    for (const auto& sample : project.samples) maxId = std::max(maxId, sample.sampleId);
    return maxId == std::numeric_limits<std::uint32_t>::max() ? 0U : maxId + 1U;
}

std::uint32_t nextMultisampleIdValue(const BankProject& project) noexcept {
    std::uint32_t maxId = 0U;
    for (const auto& multisample : project.multisamples) maxId = std::max(maxId, multisample.multisampleId);
    return maxId == std::numeric_limits<std::uint32_t>::max() ? 0U : maxId + 1U;
}

std::uint16_t nextFreeSoundPositionValue(const BankProject& project, std::size_t excludingIndex = std::numeric_limits<std::size_t>::max()) noexcept {
    for (std::uint16_t position = kMinSoundPosition; position <= kMaxSoundPosition; ++position) {
        bool used = false;
        for (std::size_t i = 0U; i < project.sounds.size(); ++i) {
            if (i == excludingIndex) continue;
            if (project.sounds[i].position == position) { used = true; break; }
        }
        if (!used) return position;
    }
    return 0U;
}

bool soundPositionInUse(const BankProject& project, std::uint16_t position, std::size_t excludingIndex) noexcept {
    for (std::size_t i = 0U; i < project.sounds.size(); ++i) {
        if (i == excludingIndex) continue;
        if (project.sounds[i].position == position) return true;
    }
    return false;
}

void assignAutomaticAddress(SoundDefinition& sound, std::size_t index) {
    constexpr std::size_t kSlotsPerPage = 128U;
    constexpr std::size_t kPagesPerBank = 128U;
    sound.slot = static_cast<std::uint16_t>(index % kSlotsPerPage);
    const std::size_t pageIndex = index / kSlotsPerPage;
    sound.page = static_cast<std::uint16_t>(pageIndex % kPagesPerBank);
    sound.bank = static_cast<std::uint16_t>(pageIndex / kPagesPerBank);
}

void appendSoundForMultisample(BankProject& project, std::uint32_t multisampleIndex, const std::string& name) {
    SoundDefinition sound{};
    sound.name = name.empty() ? std::string("Imported SOUND") : name;
    sound.position = nextFreeSoundPositionValue(project);
    assignAutomaticAddress(sound, project.sounds.size());
    SoundLayer layer{};
    layer.multisampleIndex = multisampleIndex;
    sound.layers.push_back(layer);
    project.sounds.push_back(std::move(sound));
}

void appendKmp(BankProject& project, KorgImportResult imported) {
    const std::uint32_t sampleBase = static_cast<std::uint32_t>(project.samples.size());
    std::uint32_t sampleId = nextSampleIdValue(project);
    for (auto& zone : imported.multisample.zones) zone.sampleIndex += sampleBase;
    for (auto& sample : imported.samples) { sample.sampleId = sampleId++; project.samples.push_back(std::move(sample)); }
    const std::uint32_t multisampleIndex = static_cast<std::uint32_t>(project.multisamples.size());
    imported.multisample.multisampleId = nextMultisampleIdValue(project);
    const std::string name = imported.multisample.name;
    project.multisamples.push_back(std::move(imported.multisample));
    appendSoundForMultisample(project, multisampleIndex, name);
}

void appendKsc(BankProject& project, KorgCollectionResult imported) {
    const std::uint32_t sampleBase = static_cast<std::uint32_t>(project.samples.size());
    const std::uint32_t multisampleBase = static_cast<std::uint32_t>(project.multisamples.size());
    std::uint32_t sampleId = nextSampleIdValue(project);
    std::uint32_t multisampleId = nextMultisampleIdValue(project);
    for (auto& multisample : imported.multisamples) {
        for (auto& zone : multisample.zones) zone.sampleIndex += sampleBase;
    }
    for (auto& sample : imported.samples) { sample.sampleId = sampleId++; project.samples.push_back(std::move(sample)); }
    for (std::size_t i = 0U; i < imported.multisamples.size(); ++i) {
        const std::string name = imported.multisamples[i].name;
        imported.multisamples[i].multisampleId = multisampleId++;
        project.multisamples.push_back(std::move(imported.multisamples[i]));
        appendSoundForMultisample(project, multisampleBase + static_cast<std::uint32_t>(i), name);
    }
}

void appendSingleSample(BankProject& project, ImportedSample sample) {
    const std::uint32_t sampleIndex = static_cast<std::uint32_t>(project.samples.size());
    sample.sampleId = nextSampleIdValue(project);
    const std::string name = sample.name.empty() ? std::string("Imported Sample") : sample.name;
    const std::uint8_t root = sample.rootKey;
    project.samples.push_back(std::move(sample));

    ImportedMultisample multisample{};
    multisample.multisampleId = nextMultisampleIdValue(project);
    multisample.name = name;
    multisample.sourceIdentity = std::string("single:") + project.samples.back().sourceIdentity;
    ImportedZone zone{};
    zone.sampleIndex = sampleIndex;
    zone.rootKey = root;
    multisample.zones.push_back(zone);

    const std::uint32_t multisampleIndex = static_cast<std::uint32_t>(project.multisamples.size());
    project.multisamples.push_back(std::move(multisample));
    appendSoundForMultisample(project, multisampleIndex, name);
}

std::string joinMessages(const std::vector<std::string>& messages) {
    std::ostringstream stream;
    for (std::size_t i = 0U; i < messages.size(); ++i) {
        if (i != 0U) stream << '\n';
        stream << messages[i];
    }
    return stream.str();
}

bool soundAddressInUse(const BankProject& project,
                       std::uint16_t bank,
                       std::uint16_t page,
                       std::uint16_t slot,
                       std::size_t excludingIndex) noexcept {
    for (std::size_t i = 0U; i < project.sounds.size(); ++i) {
        if (i == excludingIndex) continue;
        const auto& sound = project.sounds[i];
        if (sound.bank == bank && sound.page == page && sound.slot == slot) return true;
    }
    return false;
}

bool nextLibraryAddress(std::uint16_t& bank, std::uint16_t& page, std::uint16_t& slot) noexcept {
    if (slot < kLibraryAxisMaximum) { ++slot; return true; }
    slot = 0U;
    if (page < kLibraryAxisMaximum) { ++page; return true; }
    page = 0U;
    if (bank < kLibraryAxisMaximum) { ++bank; return true; }
    return false;
}

} // namespace

@interface SVManagerDocument : NSObject {
@private
    silveton::manager::BankProject _project;
    std::deque<SampleHistoryEntry> _undoHistory;
    std::deque<SampleHistoryEntry> _redoHistory;
    std::size_t _undoHistoryBytes;
    std::size_t _redoHistoryBytes;
    silveton::manager::SampleRegion _sampleClipboard;
    bool _hasSampleClipboard;
}
- (BOOL)importPaths:(NSArray<NSString*>*)paths error:(NSString**)error;
- (BOOL)buildBankAtPath:(NSString*)path error:(NSString**)error summary:(NSString**)summary;
- (BOOL)buildBankAtPath:(NSString*)path progress:(BOOL (^)(double fraction, NSString* text))progress error:(NSString**)error summary:(NSString**)summary;
- (NSArray<NSString*>*)displayRows;
- (NSString*)statusSummary;
- (void)clearProject;

- (NSUInteger)sampleCount;
- (NSArray<NSString*>*)sampleDisplayRows;
- (NSDictionary<NSString*, id>*)sampleStateAtIndex:(NSUInteger)index;
- (NSDictionary<NSString*, id>*)auditionStateAtIndex:(NSUInteger)index error:(NSString**)error;
- (NSArray<NSNumber*>*)waveformAtIndex:(NSUInteger)index pointCount:(NSUInteger)pointCount error:(NSString**)error;
- (NSArray<NSNumber*>*)waveformAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame pointCount:(NSUInteger)pointCount error:(NSString**)error;
- (BOOL)trimSampleAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error;
- (BOOL)cutOutSampleAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error;
- (BOOL)applyPitchCurveForSampleAtIndex:(NSUInteger)index curve:(NSArray<NSNumber*>*)curve error:(NSString**)error;
- (BOOL)cleanWaveForSampleAtIndex:(NSUInteger)index amount:(NSArray<NSNumber*>*)amount overtones:(NSInteger)overtones edges:(float)edges error:(NSString**)error;
- (NSArray<NSDictionary<NSString*, id>*>*)lateStartReportWithPoints:(NSUInteger)points;
- (NSArray<NSNumber*>*)looseSampleIndexes;
- (NSArray<NSDictionary<NSString*, id>*>*)autoMapPlanForSampleIndexes:(NSArray<NSNumber*>*)indexes;
- (NSArray<NSDictionary<NSString*, id>*>*)autoMapArrangeRows:(NSArray<NSDictionary<NSString*, id>*>*)rows;
- (BOOL)buildAutoMapWithRows:(NSArray<NSDictionary<NSString*, id>*>*)rows name:(NSString*)name createdIndex:(NSUInteger*)createdIndex error:(NSString**)error;
- (NSInteger)noteFromText:(NSString*)text;
- (NSDictionary<NSString*, id>*)trimLateStartsForSampleIndexes:(NSArray<NSNumber*>*)indexes;
- (NSDictionary<NSString*, id>*)trimSampleStartsWithIndexes:(NSArray<NSNumber*>*)indexes startFrames:(NSArray<NSNumber*>*)startFrames;
- (void)markCurrentStateChanged;   // lives in ManagerDocumentDirty.mm
- (NSArray<NSNumber*>*)cleanWavePreviewAtIndex:(NSUInteger)index amount:(NSArray<NSNumber*>*)amount overtones:(NSInteger)overtones edges:(float)edges startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame pointCount:(NSUInteger)pointCount error:(NSString**)error;
- (BOOL)setLoopForSampleAtIndex:(NSUInteger)index enabled:(BOOL)enabled startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error;
- (BOOL)applyLoopCrossfadeForSampleAtIndex:(NSUInteger)index frames:(uint32_t)frames error:(NSString**)error;
- (BOOL)reverseSampleAtIndex:(NSUInteger)index error:(NSString**)error;
- (BOOL)applyGainForSampleAtIndex:(NSUInteger)index gainDb:(float)gainDb error:(NSString**)error;
- (BOOL)normalizeSampleAtIndex:(NSUInteger)index targetPeakDb:(float)targetPeakDb error:(NSString**)error;
- (BOOL)fadeInSampleAtIndex:(NSUInteger)index frames:(uint64_t)frames error:(NSString**)error;
- (BOOL)fadeOutSampleAtIndex:(NSUInteger)index frames:(uint64_t)frames error:(NSString**)error;
- (BOOL)setRootKeyForSampleAtIndex:(NSUInteger)index rootKey:(uint8_t)rootKey error:(NSString**)error;
- (BOOL)setFineTuneForSampleAtIndex:(NSUInteger)index cents:(float)cents error:(NSString**)error;
- (BOOL)setTuningForSampleAtIndex:(NSUInteger)index rootKey:(uint8_t)rootKey cents:(float)cents error:(NSString**)error;
- (NSDictionary<NSString*, id>*)detectPitchForSampleAtIndex:(NSUInteger)index;
- (uint64_t)nearestZeroCrossingForSampleAtIndex:(NSUInteger)index frame:(uint64_t)frame radius:(uint64_t)radius;
- (BOOL)canUndoSampleEdit;
- (BOOL)canRedoSampleEdit;
- (BOOL)undoSampleEdit:(NSString**)error;
- (BOOL)redoSampleEdit:(NSString**)error;

- (BOOL)copySampleRangeAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error;
- (BOOL)cutSampleRangeAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error;
- (BOOL)deleteSampleRangeAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error;
- (BOOL)silenceSampleRangeAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error;
- (BOOL)pasteSampleRangeAtIndex:(NSUInteger)index atFrame:(uint64_t)atFrame error:(NSString**)error;
- (BOOL)reverseSampleRangeAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error;
- (BOOL)applyGainForSampleRangeAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame gainDb:(float)gainDb error:(NSString**)error;
- (BOOL)normalizeSampleRangeAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame targetPeakDb:(float)targetPeakDb error:(NSString**)error;
- (BOOL)fadeInSampleRangeAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error;
- (BOOL)fadeOutSampleRangeAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error;
- (BOOL)hasSampleClipboard;
- (NSString*)sampleClipboardSummary;

- (NSUInteger)multisampleCount;
- (NSArray<NSString*>*)multisampleDisplayRows;
- (NSDictionary<NSString*, id>*)multisampleStateAtIndex:(NSUInteger)index;
- (NSArray<NSDictionary<NSString*, id>*>*)zoneStatesForMultisampleAtIndex:(NSUInteger)index;
- (BOOL)createMultisampleNamed:(NSString*)name sampleIndexes:(NSIndexSet*)sampleIndexes error:(NSString**)error createdIndex:(NSUInteger*)createdIndex;
- (BOOL)renameMultisampleAtIndex:(NSUInteger)index name:(NSString*)name error:(NSString**)error;
- (BOOL)addZoneToMultisampleAtIndex:(NSUInteger)multisampleIndex sampleIndex:(NSUInteger)sampleIndex error:(NSString**)error;
- (BOOL)removeZoneFromMultisampleAtIndex:(NSUInteger)multisampleIndex zoneIndex:(NSUInteger)zoneIndex error:(NSString**)error;
- (BOOL)updateZoneAtMultisampleIndex:(NSUInteger)multisampleIndex
                           zoneIndex:(NSUInteger)zoneIndex
                         sampleIndex:(NSUInteger)sampleIndex
                              keyLow:(NSUInteger)keyLow
                             keyHigh:(NSUInteger)keyHigh
                         velocityLow:(NSUInteger)velocityLow
                        velocityHigh:(NSUInteger)velocityHigh
                             rootKey:(NSUInteger)rootKey
                  transposeSemitones:(NSInteger)transposeSemitones
                           tuneCents:(float)tuneCents
                              gainDb:(float)gainDb
                                 pan:(float)pan
                               error:(NSString**)error;

- (NSUInteger)soundCount;
- (NSArray<NSString*>*)soundDisplayRows;
- (NSDictionary<NSString*, id>*)soundStateAtIndex:(NSUInteger)index;
- (NSArray<NSDictionary<NSString*, id>*>*)soundLayerStatesAtIndex:(NSUInteger)index;
- (BOOL)addSoundLayerAtIndex:(NSUInteger)soundIndex multisampleIndex:(NSUInteger)multisampleIndex error:(NSString**)error;
- (BOOL)removeSoundLayerAtIndex:(NSUInteger)soundIndex layerIndex:(NSUInteger)layerIndex error:(NSString**)error;
- (BOOL)updateSoundLayerAtIndex:(NSUInteger)soundIndex
                     layerIndex:(NSUInteger)layerIndex
               multisampleIndex:(NSUInteger)multisampleIndex
                        enabled:(BOOL)enabled
                         keyLow:(NSUInteger)keyLow
                        keyHigh:(NSUInteger)keyHigh
                    velocityLow:(NSUInteger)velocityLow
                   velocityHigh:(NSUInteger)velocityHigh
             transposeSemitones:(NSInteger)transposeSemitones
                      tuneCents:(float)tuneCents
                        levelDb:(float)levelDb
                            pan:(float)pan
                          error:(NSString**)error;
- (BOOL)updateSoundAtIndex:(NSUInteger)index name:(NSString*)name position:(NSUInteger)position bank:(NSUInteger)bank page:(NSUInteger)page slot:(NSUInteger)slot category:(NSUInteger)category error:(NSString**)error;
- (NSNumber*)nextFreeSoundPositionExcludingIndex:(NSUInteger)excludingIndex error:(NSString**)error;

- (NSDictionary<NSString*, NSNumber*>*)nextFreeSoundAddressFromBank:(NSUInteger)bank page:(NSUInteger)page slot:(NSUInteger)slot excludingIndex:(NSUInteger)excludingIndex error:(NSString**)error;
- (BOOL)autoPackSoundAddressesFromBank:(NSUInteger)bank page:(NSUInteger)page slot:(NSUInteger)slot error:(NSString**)error;
@end

@implementation SVManagerDocument

- (instancetype)init {
    self = [super init];
    if (self) {
        _project.name = "SILVETON BANK";
        _undoHistoryBytes = 0U;
        _redoHistoryBytes = 0U;
        _hasSampleClipboard = false;
    }
    return self;
}

- (BOOL)importPaths:(NSArray<NSString*>*)paths error:(NSString**)error {
    std::size_t importedObjects = 0U;
    std::vector<std::string> messages;
    for (NSString* nsPath in paths) {
        if (nsPath.length == 0U) continue;
        const std::string path([nsPath fileSystemRepresentation]);
        const std::string ext = lowerExtension(path);
        if (ext == ".kmp") {
            auto result = KorgImporter::loadKmp(path);
            if (!result.ok()) { messages.push_back(filenameOnly(path) + ": " + result.error); continue; }
            if (_project.sounds.size() >= static_cast<std::size_t>(kMaxSoundPosition)) { messages.push_back("No free SOUND position remains (1...500)."); continue; }
            for (const auto& warning : result.warnings) messages.push_back(warning);
            appendKmp(_project, std::move(result)); ++importedObjects; continue;
        }
        if (ext == ".ksc") {
            auto result = KorgImporter::loadKsc(path);
            if (!result.ok()) { messages.push_back(filenameOnly(path) + ": " + result.error); continue; }
            if (_project.sounds.size() + result.multisamples.size() > static_cast<std::size_t>(kMaxSoundPosition)) {
                messages.push_back(filenameOnly(path) + ": import would exceed 500 SOUND positions.");
                continue;
            }
            for (const auto& warning : result.warnings) messages.push_back(warning);
            importedObjects += result.multisamples.size(); appendKsc(_project, std::move(result)); continue;
        }
        if (ext == ".ksf") {
            auto result = KorgImporter::loadKsf(path);
            if (!result.ok()) { messages.push_back(filenameOnly(path) + ": " + result.error); continue; }
            if (_project.sounds.size() >= static_cast<std::size_t>(kMaxSoundPosition)) { messages.push_back("No free SOUND position remains (1...500)."); continue; }
            appendSingleSample(_project, std::move(result.sample)); ++importedObjects; continue;
        }
        if (ext == ".wav" || ext == ".wave" || ext == ".aif" || ext == ".aiff" || ext == ".aifc") {
            auto result = AudioFileLoader::load(path);
            if (!result.ok()) { messages.push_back(filenameOnly(path) + ": " + result.error); continue; }
            if (_project.sounds.size() >= static_cast<std::size_t>(kMaxSoundPosition)) { messages.push_back("No free SOUND position remains (1...500)."); continue; }
            appendSingleSample(_project, std::move(result.sample)); ++importedObjects; continue;
        }
        messages.push_back(filenameOnly(path) + ": unsupported file type");
    }
    if (importedObjects == 0U) {
        setError(error, messages.empty() ? std::string("No supported files were selected") : joinMessages(messages));
        return NO;
    }
    clearHistory(_undoHistory, _undoHistoryBytes);
    clearHistory(_redoHistory, _redoHistoryBytes);
    if (error != nullptr) *error = messages.empty() ? nil : nsString(joinMessages(messages));
    return YES;
}

- (BOOL)buildBankAtPath:(NSString*)path error:(NSString**)error summary:(NSString**)summary {
    return [self buildBankAtPath:path progress:nil error:error summary:summary];
}

// SILVETON_LOOK_V1: the same build with a progress block (fraction 0..1, text); the block returns NO to stop.
- (BOOL)buildBankAtPath:(NSString*)path progress:(BOOL (^)(double fraction, NSString* text))progress error:(NSString**)error summary:(NSString**)summary {
    if (_project.sounds.empty() || _project.multisamples.empty() || _project.samples.empty()) {
        if (error != nullptr) *error = @"Nothing has been imported yet.";
        return NO;
    }
    if (path.length == 0U) {
        if (error != nullptr) *error = @"No output path was selected.";
        return NO;
    }
    SvBuildStats stats{};
    std::string buildError;
    SvBuildProgress report = nullptr;
    if (progress != nil) {
        report = [progress](double fraction, const std::string& text) -> bool {
            return progress(fraction, [NSString stringWithUTF8String:text.c_str()] ?: @"") ? true : false;
        };
    }
    if (!SvBankBuilder::writeAtomic([path fileSystemRepresentation], _project, stats, buildError, report)) {
        setError(error, buildError);
        return NO;
    }
    if (summary != nullptr) {
        const double beforeMiB = static_cast<double>(stats.audioBytesBeforeDedup) / (1024.0 * 1024.0);
        const double afterMiB = static_cast<double>(stats.audioBytesAfterDedup) / (1024.0 * 1024.0);
        *summary = [NSString stringWithFormat:@"Built %u SOUNDs · %u multisamples · %u samples · %u unique audio payloads · %.1f -> %.1f MiB",
                    stats.soundCount, stats.multisampleCount, stats.sampleCount, stats.uniqueAudioPayloadCount, beforeMiB, afterMiB];
    }
    clearError(error);
    return YES;
}

- (NSArray<NSString*>*)displayRows {
    NSMutableArray<NSString*>* rows = [NSMutableArray arrayWithCapacity:_project.sounds.size()];
    for (std::size_t i = 0U; i < _project.sounds.size(); ++i) {
        const auto& sound = _project.sounds[i];
        std::size_t zones = 0U;
        for (const auto& layer : sound.layers) {
            if (layer.multisampleIndex < _project.multisamples.size()) zones += _project.multisamples[layer.multisampleIndex].zones.size();
        }
        [rows addObject:[NSString stringWithFormat:@"SOUND %03u   %@   ·   %zu layer%@   ·   %zu zone%@   ·   B%u P%u S%u   ·   C%u",
                         sound.position, nsString(sound.name), sound.layers.size(), sound.layers.size() == 1U ? @"" : @"s",
                         zones, zones == 1U ? @"" : @"s", sound.bank, sound.page, sound.slot, sound.category]];
    }
    return rows;
}

- (NSString*)statusSummary {
    std::uint64_t audioBytes = 0U;
    for (const auto& sample : _project.samples) audioBytes += static_cast<std::uint64_t>(sample.audioData.size());
    const double mib = static_cast<double>(audioBytes) / (1024.0 * 1024.0);
    return [NSString stringWithFormat:@"%zu SOUNDs   ·   %zu multisamples   ·   %zu samples   ·   %.1f MiB source audio",
            _project.sounds.size(), _project.multisamples.size(), _project.samples.size(), mib];
}

- (void)clearProject {
    _project = BankProject{};
    _project.name = "SILVETON BANK";
    clearHistory(_undoHistory, _undoHistoryBytes);
    clearHistory(_redoHistory, _redoHistoryBytes);
    _sampleClipboard = SampleRegion{};
    _hasSampleClipboard = false;
}

- (NSUInteger)sampleCount { return static_cast<NSUInteger>(_project.samples.size()); }

- (NSArray<NSString*>*)sampleDisplayRows {
    NSMutableArray<NSString*>* rows = [NSMutableArray arrayWithCapacity:_project.samples.size()];
    for (std::size_t i = 0U; i < _project.samples.size(); ++i) {
        const auto& sample = _project.samples[i];
        const double seconds = sample.sampleRate == 0U ? 0.0 : static_cast<double>(sample.totalFrames) / static_cast<double>(sample.sampleRate);
        [rows addObject:[NSString stringWithFormat:@"%03zu   %@   ·   %u Hz   ·   %u ch   ·   %.3f s",
                         i + 1U, nsString(sample.name.empty() ? std::string("Unnamed Sample") : sample.name), sample.sampleRate, sample.channels, seconds]];
    }
    return rows;
}

- (NSDictionary<NSString*, id>*)sampleStateAtIndex:(NSUInteger)index {
    if (!validSampleIndex(_project, index)) return nil;
    const auto& sample = _project.samples[static_cast<std::size_t>(index)];
    const float peak = SampleEditor::peakLinear(sample);
    const float peakDb = peak > 0.0F ? static_cast<float>(20.0 * std::log10(static_cast<double>(peak))) : -120.0F;
    return @{@"name": nsString(sample.name), @"sampleId": @(sample.sampleId), @"sampleRate": @(sample.sampleRate), @"channels": @(sample.channels), @"totalFrames": @(sample.totalFrames),
             @"rootKey": @(sample.rootKey), @"fineTuneCents": @(sample.fineTuneCents), @"loopEnabled": @(sample.loop.enabled), @"loopStart": @(sample.loop.startFrame),
             @"loopEnd": @(sample.loop.endFrame), @"crossfadeFrames": @(sample.loop.crossfadeFrames), @"peakDb": @(peakDb)};
}

- (NSDictionary<NSString*, id>*)auditionStateAtIndex:(NSUInteger)index error:(NSString**)error {
    if (!validSampleIndex(_project, index)) { if (error != nullptr) *error = @"No sample is selected."; return nil; }
    const auto& sample = _project.samples[static_cast<std::size_t>(index)];
    if (!sample.valid() || sample.audioData.empty()) { if (error != nullptr) *error = @"The selected sample has no valid audio data."; return nil; }
    NSData* audio = [NSData dataWithBytes:sample.audioData.data() length:static_cast<NSUInteger>(sample.audioData.size())];
    clearError(error);
    return @{@"name": nsString(sample.name), @"audioData": audio, @"sampleRate": @(sample.sampleRate), @"channels": @(sample.channels),
             @"encoding": @(static_cast<unsigned int>(sample.encoding)), @"bitsPerSample": @(sample.bitsPerSample), @"totalFrames": @(sample.totalFrames),
             @"loopEnabled": @(sample.loop.enabled), @"loopStart": @(sample.loop.startFrame), @"loopEnd": @(sample.loop.endFrame)};
}

- (NSArray<NSNumber*>*)waveformAtIndex:(NSUInteger)index pointCount:(NSUInteger)pointCount error:(NSString**)error {
    if (!validSampleIndex(_project, index)) { if (error != nullptr) *error = @"No sample is selected."; return nil; }
    return [self waveformAtIndex:index startFrame:0U endFrame:_project.samples[static_cast<std::size_t>(index)].totalFrames pointCount:pointCount error:error];
}

// SILVETON_ZOOM_V1: min, max, min, max ... for frames [startFrame, endFrame) only (one point per frame when deeply zoomed).
- (NSArray<NSNumber*>*)waveformAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame pointCount:(NSUInteger)pointCount error:(NSString**)error {
    if (!validSampleIndex(_project, index)) { if (error != nullptr) *error = @"No sample is selected."; return nil; }
    std::vector<WaveformPoint> points;
    std::string editError;
    if (!SampleEditor::buildWaveformRange(_project.samples[static_cast<std::size_t>(index)], startFrame, endFrame, static_cast<std::size_t>(pointCount), points, editError)) {
        setError(error, editError);
        return nil;
    }
    NSMutableArray<NSNumber*>* flattened = [NSMutableArray arrayWithCapacity:points.size() * 2U];
    for (const auto& point : points) { [flattened addObject:@(point.minimum)]; [flattened addObject:@(point.maximum)]; }
    clearError(error);
    return flattened;
}

- (BOOL)trimSampleAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error {
    return applySampleEdit(_project, index, _undoHistory, _undoHistoryBytes, _redoHistory, _redoHistoryBytes, error,
                           [startFrame, endFrame](ImportedSample& sample, std::string& e) { return SampleEditor::trim(sample, startFrame, endFrame, e); }) ? YES : NO;
}

// SILVETON_CUT_V1: throw the marked part away and join what is left
- (BOOL)cutOutSampleAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error {
    return applySampleEdit(_project, index, _undoHistory, _undoHistoryBytes, _redoHistory, _redoHistoryBytes, error,
                           [startFrame, endFrame](ImportedSample& sample, std::string& e) { return SampleEditor::cutOut(sample, startFrame, endFrame, e); }) ? YES : NO;
}

// SILVETON_PITCHCURVE_V1: write the drawn note movement into the audio
- (BOOL)applyPitchCurveForSampleAtIndex:(NSUInteger)index curve:(NSArray<NSNumber*>*)curve error:(NSString**)error {
    std::vector<float> points;
    points.reserve(curve.count);
    for (NSNumber* n in curve) points.push_back(n.floatValue);
    return applySampleEdit(_project, index, _undoHistory, _undoHistoryBytes, _redoHistory, _redoHistoryBytes, error,
                           [&points](ImportedSample& sample, std::string& e) { return SampleEditor::applyPitchCurve(sample, points, e); }) ? YES : NO;
}

// SILVETON_AUTOMAP_V1 ------------------------------------------------------------------------------------
// Samples that no multisample uses yet: the ones that came in on their own, without a mapping file.
- (NSArray<NSNumber*>*)looseSampleIndexes {
    std::vector<bool> used(_project.samples.size(), false);
    for (const auto& ms : _project.multisamples) {
        for (const auto& zone : ms.zones) {
            if (zone.sampleIndex < used.size()) used[zone.sampleIndex] = true;
        }
    }
    NSMutableArray<NSNumber*>* loose = [NSMutableArray array];
    for (std::size_t i = 0U; i < used.size(); ++i) if (!used[i]) [loose addObject:@(i)];
    return loose;
}

static NSArray<NSDictionary<NSString*, id>*>* SVAutoMapRows(const silveton::manager::AutoMapPlan& plan) {
    NSMutableArray<NSDictionary<NSString*, id>*>* rows = [NSMutableArray arrayWithCapacity:plan.entries.size()];
    for (const auto& entry : plan.entries) {
        [rows addObject:@{@"index": @(entry.sampleIndex),
                          @"name": nsString(entry.name),
                          @"note": @(entry.rootKey),
                          @"noteName": nsString(silveton::manager::PitchDetector::noteName(entry.rootKey)),
                          @"heard": @(entry.heard),
                          @"confidence": @(entry.confidence),
                          @"keyLow": @(entry.keyLow),
                          @"keyHigh": @(entry.keyHigh),
                          @"layer": @(entry.layer),
                          @"layers": @(plan.layers),
                          @"peak": @(entry.peak)}];
    }
    return rows;
}

static silveton::manager::AutoMapPlan SVAutoMapPlanFromRows(NSArray<NSDictionary<NSString*, id>*>* rows) {
    silveton::manager::AutoMapPlan plan;
    for (NSDictionary<NSString*, id>* row in rows) {
        silveton::manager::AutoMapEntry entry;
        entry.sampleIndex = [row[@"index"] unsignedLongValue];
        entry.name = row[@"name"] != nil ? std::string([row[@"name"] UTF8String]) : std::string();
        entry.rootKey = [row[@"note"] intValue];
        entry.confidence = [row[@"confidence"] floatValue];
        entry.peak = [row[@"peak"] floatValue];
        entry.heard = [row[@"heard"] boolValue];
        plan.entries.push_back(entry);
    }
    silveton::manager::AutoMapper::arrange(plan);
    return plan;
}

- (NSArray<NSDictionary<NSString*, id>*>*)autoMapPlanForSampleIndexes:(NSArray<NSNumber*>*)indexes {
    std::vector<std::size_t> wanted;
    wanted.reserve(indexes.count);
    for (NSNumber* n in indexes) wanted.push_back(static_cast<std::size_t>(n.unsignedLongValue));
    return SVAutoMapRows(silveton::manager::AutoMapper::listen(_project, wanted));
}

- (NSArray<NSDictionary<NSString*, id>*>*)autoMapArrangeRows:(NSArray<NSDictionary<NSString*, id>*>*)rows {
    return SVAutoMapRows(SVAutoMapPlanFromRows(rows));
}

- (BOOL)buildAutoMapWithRows:(NSArray<NSDictionary<NSString*, id>*>*)rows name:(NSString*)name createdIndex:(NSUInteger*)createdIndex error:(NSString**)error {
    const silveton::manager::AutoMapPlan plan = SVAutoMapPlanFromRows(rows);
    std::size_t created = 0U;
    std::string e;
    if (!silveton::manager::AutoMapper::build(_project, plan, name.length > 0U ? std::string(name.UTF8String) : std::string("НОВА БЛЕНДА"), created, e)) {
        setError(error, e);
        return NO;
    }
    if (createdIndex != nullptr) *createdIndex = static_cast<NSUInteger>(created);
    [self markCurrentStateChanged];
    clearError(error);
    return YES;
}

- (NSInteger)noteFromText:(NSString*)text {
    return static_cast<NSInteger>(silveton::manager::AutoMapper::noteFromText(text.length > 0U ? std::string(text.UTF8String) : std::string()));
}

// SILVETON_ATTACK_V1: what the cut would be on every sample that starts late, with a picture of its first
// moments, so it can be looked at before anything is changed. The picture ends a little after the first hit.
- (NSArray<NSDictionary<NSString*, id>*>*)lateStartReportWithPoints:(NSUInteger)points {
    NSMutableArray<NSDictionary<NSString*, id>*>* rows = [NSMutableArray array];
    for (std::size_t i = 0U; i < _project.samples.size(); ++i) {
        const ImportedSample& sample = _project.samples[i];
        const SampleEditor::AttackPoint attack = SampleEditor::findAttack(sample);
        if (!attack.found || !attack.hasLateStart || attack.startFrame == 0U) continue;
        const double rate = static_cast<double>(std::max<std::uint32_t>(1U, sample.sampleRate));
        const std::uint64_t afterHit = attack.startFrame + static_cast<std::uint64_t>((attack.riseSeconds + 0.08) * rate);   // show the attack itself after the line
        const std::uint64_t window = std::min<std::uint64_t>(sample.totalFrames, std::max<std::uint64_t>(afterHit, static_cast<std::uint64_t>(rate * 0.06)));
        std::vector<WaveformPoint> picture;
        std::string editError;
        if (!SampleEditor::buildWaveformRange(sample, 0U, window, static_cast<std::size_t>(points), picture, editError)) continue;
        NSMutableArray<NSNumber*>* flattened = [NSMutableArray arrayWithCapacity:picture.size() * 2U];
        for (const auto& point : picture) { [flattened addObject:@(point.minimum)]; [flattened addObject:@(point.maximum)]; }
        [rows addObject:@{@"index": @(i),
                          @"name": nsString(sample.name),
                          @"leadIn": @(attack.leadInSeconds),
                          @"cut": @(window > 0U ? static_cast<double>(attack.startFrame) / static_cast<double>(window) : 0.0),
                          @"window": @(static_cast<double>(window) / rate),
                          @"windowFrames": @(window),
                          @"rate": @(rate),
                          @"points": flattened}];
    }
    return rows;
}

// SILVETON_ATTACK_V1: cut each sample exactly where it was told to, after moving that point to the nearest
// zero crossing so the cut cannot click. This is what the review window uses, including hand-moved lines.
- (NSDictionary<NSString*, id>*)trimSampleStartsWithIndexes:(NSArray<NSNumber*>*)indexes startFrames:(NSArray<NSNumber*>*)startFrames {
    NSUInteger touched = 0U;
    double removed = 0.0;
    const NSUInteger count = std::min(indexes.count, startFrames.count);
    for (NSUInteger k = 0U; k < count; ++k) {
        const NSUInteger index = indexes[k].unsignedIntegerValue;
        if (!validSampleIndex(_project, index)) continue;
        ImportedSample& sample = _project.samples[static_cast<std::size_t>(index)];
        std::uint64_t start = startFrames[k].unsignedLongLongValue;
        if (start == 0U || start >= sample.totalFrames) continue;
        const std::uint64_t radius = static_cast<std::uint64_t>(std::max(8.0, static_cast<double>(sample.sampleRate) * 0.001));
        start = SampleEditor::nearestZeroCrossing(sample, start, radius);
        if (start == 0U || start >= sample.totalFrames) continue;
        std::string editError;
        if (!SampleEditor::trim(sample, start, sample.totalFrames, editError)) continue;
        ++touched;
        removed += static_cast<double>(start) / static_cast<double>(std::max<std::uint32_t>(1U, sample.sampleRate));
    }
    if (touched > 0U) [self markCurrentStateChanged];
    return @{@"trimmed": @(touched), @"secondsRemoved": @(removed)};
}

- (NSDictionary<NSString*, id>*)trimLateStartsForSampleIndexes:(NSArray<NSNumber*>*)indexes {
    NSUInteger touched = 0U;
    double removed = 0.0;
    for (NSNumber* n in indexes) {
        const NSUInteger index = n.unsignedIntegerValue;
        if (!validSampleIndex(_project, index)) continue;
        ImportedSample& sample = _project.samples[static_cast<std::size_t>(index)];
        const SampleEditor::AttackPoint attack = SampleEditor::findAttack(sample);
        if (!attack.found || !attack.hasLateStart || attack.startFrame == 0U) continue;
        std::string editError;
        if (!SampleEditor::trim(sample, attack.startFrame, sample.totalFrames, editError)) continue;
        ++touched;
        removed += attack.leadInSeconds;
    }
    if (touched > 0U) [self markCurrentStateChanged];
    return @{@"trimmed": @(touched), @"secondsRemoved": @(removed)};
}

// SILVETON_CLEANWAVE_V1: write the sample out again as a clean, rounded wave
static silveton::manager::WaveCleanOptions SVCleanOptions(NSArray<NSNumber*>* amount, NSInteger overtones, float edges) {
    silveton::manager::WaveCleanOptions options;
    options.amount.reserve(amount.count);
    for (NSNumber* n in amount) options.amount.push_back(std::max(0.0F, std::min(1.0F, n.floatValue)));
    if (options.amount.empty()) options.amount.push_back(0.0F);
    options.overtones = static_cast<int>(std::max<NSInteger>(1, std::min<NSInteger>(silveton::manager::WaveSmoother::kMaxOvertones, overtones)));
    options.edges = std::max(0.0F, std::min(1.0F, edges));
    return options;
}

- (BOOL)cleanWaveForSampleAtIndex:(NSUInteger)index amount:(NSArray<NSNumber*>*)amount overtones:(NSInteger)overtones edges:(float)edges error:(NSString**)error {
    const silveton::manager::WaveCleanOptions options = SVCleanOptions(amount, overtones, edges);
    return applySampleEdit(_project, index, _undoHistory, _undoHistoryBytes, _redoHistory, _redoHistoryBytes, error,
                           [&options](ImportedSample& sample, std::string& e) { return silveton::manager::WaveSmoother::clean(sample, options, e); }) ? YES : NO;
}

// the same work, but nothing is changed: just the picture of what it would become
- (NSArray<NSNumber*>*)cleanWavePreviewAtIndex:(NSUInteger)index amount:(NSArray<NSNumber*>*)amount overtones:(NSInteger)overtones edges:(float)edges startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame pointCount:(NSUInteger)pointCount error:(NSString**)error {
    if (!validSampleIndex(_project, index)) { if (error != nullptr) *error = @"No sample is selected."; return nil; }
    const ImportedSample& sample = _project.samples[static_cast<std::size_t>(index)];
    std::vector<float> mono;
    std::string e;
    if (!silveton::manager::WaveSmoother::preview(sample, SVCleanOptions(amount, overtones, edges), mono, e)) {
        setError(error, e);
        return nil;
    }
    const std::uint64_t last = std::min<std::uint64_t>(endFrame, mono.size());
    if (startFrame >= last || pointCount == 0U) { setError(error, "Waveform range is empty"); return nil; }
    const std::size_t count = static_cast<std::size_t>(std::min<std::uint64_t>(last - startFrame, static_cast<std::uint64_t>(pointCount)));
    NSMutableArray<NSNumber*>* flattened = [NSMutableArray arrayWithCapacity:count * 2U];
    for (std::size_t point = 0U; point < count; ++point) {
        const std::uint64_t from = startFrame + static_cast<std::uint64_t>((static_cast<long double>(point) * (last - startFrame)) / count);
        std::uint64_t to = startFrame + static_cast<std::uint64_t>((static_cast<long double>(point + 1U) * (last - startFrame)) / count);
        if (to <= from) to = from + 1U;
        to = std::min(to, last);
        float minimum = 1.0F, maximum = -1.0F;
        for (std::uint64_t f = from; f < to; ++f) {
            minimum = std::min(minimum, mono[static_cast<std::size_t>(f)]);
            maximum = std::max(maximum, mono[static_cast<std::size_t>(f)]);
        }
        [flattened addObject:@(minimum)];
        [flattened addObject:@(maximum)];
    }
    clearError(error);
    return flattened;
}

- (BOOL)setLoopForSampleAtIndex:(NSUInteger)index enabled:(BOOL)enabled startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error {
    const bool on = enabled == YES;
    return applySampleEdit(_project, index, _undoHistory, _undoHistoryBytes, _redoHistory, _redoHistoryBytes, error,
                           [on, startFrame, endFrame](ImportedSample& sample, std::string& e) { return SampleEditor::setLoop(sample, on, startFrame, endFrame, 0U, e); }) ? YES : NO;
}

- (BOOL)applyLoopCrossfadeForSampleAtIndex:(NSUInteger)index frames:(uint32_t)frames error:(NSString**)error {
    return applySampleEdit(_project, index, _undoHistory, _undoHistoryBytes, _redoHistory, _redoHistoryBytes, error,
                           [frames](ImportedSample& sample, std::string& e) { return SampleEditor::applyLoopCrossfade(sample, frames, e); }) ? YES : NO;
}

- (BOOL)reverseSampleAtIndex:(NSUInteger)index error:(NSString**)error {
    return applySampleEdit(_project, index, _undoHistory, _undoHistoryBytes, _redoHistory, _redoHistoryBytes, error,
                           [](ImportedSample& sample, std::string& e) { return SampleEditor::reverse(sample, e); }) ? YES : NO;
}

- (BOOL)applyGainForSampleAtIndex:(NSUInteger)index gainDb:(float)gainDb error:(NSString**)error {
    return applySampleEdit(_project, index, _undoHistory, _undoHistoryBytes, _redoHistory, _redoHistoryBytes, error,
                           [gainDb](ImportedSample& sample, std::string& e) { return SampleEditor::applyGainDb(sample, gainDb, e); }) ? YES : NO;
}

- (BOOL)normalizeSampleAtIndex:(NSUInteger)index targetPeakDb:(float)targetPeakDb error:(NSString**)error {
    return applySampleEdit(_project, index, _undoHistory, _undoHistoryBytes, _redoHistory, _redoHistoryBytes, error,
                           [targetPeakDb](ImportedSample& sample, std::string& e) { return SampleEditor::normalize(sample, targetPeakDb, e); }) ? YES : NO;
}

- (BOOL)fadeInSampleAtIndex:(NSUInteger)index frames:(uint64_t)frames error:(NSString**)error {
    return applySampleEdit(_project, index, _undoHistory, _undoHistoryBytes, _redoHistory, _redoHistoryBytes, error,
                           [frames](ImportedSample& sample, std::string& e) { return SampleEditor::fadeIn(sample, frames, e); }) ? YES : NO;
}

- (BOOL)fadeOutSampleAtIndex:(NSUInteger)index frames:(uint64_t)frames error:(NSString**)error {
    return applySampleEdit(_project, index, _undoHistory, _undoHistoryBytes, _redoHistory, _redoHistoryBytes, error,
                           [frames](ImportedSample& sample, std::string& e) { return SampleEditor::fadeOut(sample, frames, e); }) ? YES : NO;
}

- (BOOL)setRootKeyForSampleAtIndex:(NSUInteger)index rootKey:(uint8_t)rootKey error:(NSString**)error {
    return applySampleEdit(_project, index, _undoHistory, _undoHistoryBytes, _redoHistory, _redoHistoryBytes, error,
                           [rootKey](ImportedSample& sample, std::string& e) { return SampleEditor::setRootKey(sample, rootKey, e); }) ? YES : NO;
}

- (BOOL)setFineTuneForSampleAtIndex:(NSUInteger)index cents:(float)cents error:(NSString**)error {
    return applySampleEdit(_project, index, _undoHistory, _undoHistoryBytes, _redoHistory, _redoHistoryBytes, error,
                           [cents](ImportedSample& sample, std::string& e) { return SampleEditor::setFineTuneCents(sample, cents, e); }) ? YES : NO;
}

- (BOOL)setTuningForSampleAtIndex:(NSUInteger)index rootKey:(uint8_t)rootKey cents:(float)cents error:(NSString**)error {
    return applySampleEdit(_project, index, _undoHistory, _undoHistoryBytes, _redoHistory, _redoHistoryBytes, error,
                           [rootKey, cents](ImportedSample& sample, std::string& e) {
                               if (!SampleEditor::setRootKey(sample, rootKey, e)) return false;
                               return SampleEditor::setFineTuneCents(sample, cents, e);
                           }) ? YES : NO;
}

// SILVETON_PITCH_V1 - which note the recording is, read from the audio itself. Changes nothing.
// nil = no sample or no clear note. Keys: hz, midi, cents (how far above the note, -50..50), confidence (0..1), name ("A0").
- (NSDictionary<NSString*, id>*)detectPitchForSampleAtIndex:(NSUInteger)index {
    if (!validSampleIndex(_project, index)) return nil;
    const PitchResult r = PitchDetector::detect(_project.samples[static_cast<std::size_t>(index)]);
    if (!r.found) return nil;
    return @{@"hz": @(r.hz), @"midi": @(r.midi), @"cents": @(r.cents), @"confidence": @(r.confidence), @"name": nsString(r.noteName())};
}

- (uint64_t)nearestZeroCrossingForSampleAtIndex:(NSUInteger)index frame:(uint64_t)frame radius:(uint64_t)radius {
    if (!validSampleIndex(_project, index)) return frame;
    return SampleEditor::nearestZeroCrossing(_project.samples[static_cast<std::size_t>(index)], frame, radius);
}

- (BOOL)canUndoSampleEdit { return _undoHistory.empty() ? NO : YES; }
- (BOOL)canRedoSampleEdit { return _redoHistory.empty() ? NO : YES; }

- (BOOL)undoSampleEdit:(NSString**)error {
    if (_undoHistory.empty()) { if (error != nullptr) *error = @"There is no sample edit to undo."; return NO; }
    SampleHistoryEntry entry = std::move(_undoHistory.back());
    _undoHistoryBytes -= entry.storageBytes;
    _undoHistory.pop_back();
    if (entry.sampleIndex >= _project.samples.size()) {
        if (error != nullptr) *error = @"Undo history points to a sample that no longer exists.";
        clearHistory(_undoHistory, _undoHistoryBytes);
        clearHistory(_redoHistory, _redoHistoryBytes);
        return NO;
    }
    pushHistory(_redoHistory, _redoHistoryBytes, entry.sampleIndex, _project.samples[entry.sampleIndex]);
    _project.samples[entry.sampleIndex] = std::move(entry.sample);
    clearError(error);
    return YES;
}

- (BOOL)redoSampleEdit:(NSString**)error {
    if (_redoHistory.empty()) { if (error != nullptr) *error = @"There is no sample edit to redo."; return NO; }
    SampleHistoryEntry entry = std::move(_redoHistory.back());
    _redoHistoryBytes -= entry.storageBytes;
    _redoHistory.pop_back();
    if (entry.sampleIndex >= _project.samples.size()) {
        if (error != nullptr) *error = @"Redo history points to a sample that no longer exists.";
        clearHistory(_undoHistory, _undoHistoryBytes);
        clearHistory(_redoHistory, _redoHistoryBytes);
        return NO;
    }
    pushHistory(_undoHistory, _undoHistoryBytes, entry.sampleIndex, _project.samples[entry.sampleIndex]);
    _project.samples[entry.sampleIndex] = std::move(entry.sample);
    clearError(error);
    return YES;
}

- (BOOL)copySampleRangeAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error {
    if (!validSampleIndex(_project, index)) { if (error != nullptr) *error = @"No sample is selected."; return NO; }
    SampleRegion copied{};
    std::string e;
    if (!SampleEditor::copyRegion(_project.samples[static_cast<std::size_t>(index)], startFrame, endFrame, copied, e)) { setError(error, e); return NO; }
    _sampleClipboard = std::move(copied);
    _hasSampleClipboard = true;
    clearError(error);
    return YES;
}

- (BOOL)cutSampleRangeAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error {
    if (!validSampleIndex(_project, index)) { if (error != nullptr) *error = @"No sample is selected."; return NO; }
    SampleRegion copied{};
    std::string e;
    if (!SampleEditor::copyRegion(_project.samples[static_cast<std::size_t>(index)], startFrame, endFrame, copied, e)) { setError(error, e); return NO; }
    const BOOL ok = applySampleEdit(_project, index, _undoHistory, _undoHistoryBytes, _redoHistory, _redoHistoryBytes, error,
                                    [startFrame, endFrame](ImportedSample& sample, std::string& editError) {
                                        return SampleEditor::deleteRegion(sample, startFrame, endFrame, editError);
                                    }) ? YES : NO;
    if (ok == YES) { _sampleClipboard = std::move(copied); _hasSampleClipboard = true; }
    return ok;
}

- (BOOL)deleteSampleRangeAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error {
    return applySampleEdit(_project, index, _undoHistory, _undoHistoryBytes, _redoHistory, _redoHistoryBytes, error,
                           [startFrame, endFrame](ImportedSample& sample, std::string& e) { return SampleEditor::deleteRegion(sample, startFrame, endFrame, e); }) ? YES : NO;
}

- (BOOL)silenceSampleRangeAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error {
    return applySampleEdit(_project, index, _undoHistory, _undoHistoryBytes, _redoHistory, _redoHistoryBytes, error,
                           [startFrame, endFrame](ImportedSample& sample, std::string& e) { return SampleEditor::silenceRegion(sample, startFrame, endFrame, e); }) ? YES : NO;
}

- (BOOL)pasteSampleRangeAtIndex:(NSUInteger)index atFrame:(uint64_t)atFrame error:(NSString**)error {
    if (!_hasSampleClipboard) { if (error != nullptr) *error = @"The sample clipboard is empty."; return NO; }
    const SampleRegion clipboard = _sampleClipboard;
    return applySampleEdit(_project, index, _undoHistory, _undoHistoryBytes, _redoHistory, _redoHistoryBytes, error,
                           [atFrame, clipboard](ImportedSample& sample, std::string& e) { return SampleEditor::insertRegion(sample, atFrame, clipboard, e); }) ? YES : NO;
}

- (BOOL)reverseSampleRangeAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error {
    return applySampleEdit(_project, index, _undoHistory, _undoHistoryBytes, _redoHistory, _redoHistoryBytes, error,
                           [startFrame, endFrame](ImportedSample& sample, std::string& e) { return SampleEditor::reverseRegion(sample, startFrame, endFrame, e); }) ? YES : NO;
}

- (BOOL)applyGainForSampleRangeAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame gainDb:(float)gainDb error:(NSString**)error {
    return applySampleEdit(_project, index, _undoHistory, _undoHistoryBytes, _redoHistory, _redoHistoryBytes, error,
                           [startFrame, endFrame, gainDb](ImportedSample& sample, std::string& e) { return SampleEditor::applyGainDbRegion(sample, startFrame, endFrame, gainDb, e); }) ? YES : NO;
}

- (BOOL)normalizeSampleRangeAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame targetPeakDb:(float)targetPeakDb error:(NSString**)error {
    return applySampleEdit(_project, index, _undoHistory, _undoHistoryBytes, _redoHistory, _redoHistoryBytes, error,
                           [startFrame, endFrame, targetPeakDb](ImportedSample& sample, std::string& e) { return SampleEditor::normalizeRegion(sample, startFrame, endFrame, targetPeakDb, e); }) ? YES : NO;
}

- (BOOL)fadeInSampleRangeAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error {
    return applySampleEdit(_project, index, _undoHistory, _undoHistoryBytes, _redoHistory, _redoHistoryBytes, error,
                           [startFrame, endFrame](ImportedSample& sample, std::string& e) { return SampleEditor::fadeInRegion(sample, startFrame, endFrame, e); }) ? YES : NO;
}

- (BOOL)fadeOutSampleRangeAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error {
    return applySampleEdit(_project, index, _undoHistory, _undoHistoryBytes, _redoHistory, _redoHistoryBytes, error,
                           [startFrame, endFrame](ImportedSample& sample, std::string& e) { return SampleEditor::fadeOutRegion(sample, startFrame, endFrame, e); }) ? YES : NO;
}

- (BOOL)hasSampleClipboard { return _hasSampleClipboard ? YES : NO; }

- (NSString*)sampleClipboardSummary {
    if (!_hasSampleClipboard) return @"Clipboard empty";
    return [NSString stringWithFormat:@"Clipboard: %llu frames · %u Hz · %u ch",
            static_cast<unsigned long long>(_sampleClipboard.frameCount), _sampleClipboard.sampleRate, _sampleClipboard.channels];
}

- (NSUInteger)multisampleCount { return static_cast<NSUInteger>(_project.multisamples.size()); }

- (NSArray<NSString*>*)multisampleDisplayRows {
    NSMutableArray<NSString*>* rows = [NSMutableArray arrayWithCapacity:_project.multisamples.size()];
    for (std::size_t i = 0U; i < _project.multisamples.size(); ++i) {
        const auto& multisample = _project.multisamples[i];
        [rows addObject:[NSString stringWithFormat:@"%03zu   %@   ·   %zu zone%@", i + 1U,
                         nsString(multisample.name.empty() ? std::string("Unnamed Multisample") : multisample.name),
                         multisample.zones.size(), multisample.zones.size() == 1U ? @"" : @"s"]];
    }
    return rows;
}

- (NSDictionary<NSString*, id>*)multisampleStateAtIndex:(NSUInteger)index {
    if (!validMultisampleIndex(_project, index)) return nil;
    const auto& multisample = _project.multisamples[static_cast<std::size_t>(index)];
    return @{@"name": nsString(multisample.name), @"multisampleId": @(multisample.multisampleId), @"sourceIdentity": nsString(multisample.sourceIdentity),
             @"zoneCount": @(static_cast<unsigned long long>(multisample.zones.size()))};
}

- (NSArray<NSDictionary<NSString*, id>*>*)zoneStatesForMultisampleAtIndex:(NSUInteger)index {
    if (!validMultisampleIndex(_project, index)) return @[];
    const auto& multisample = _project.multisamples[static_cast<std::size_t>(index)];
    NSMutableArray<NSDictionary<NSString*, id>*>* rows = [NSMutableArray arrayWithCapacity:multisample.zones.size()];
    for (std::size_t zoneIndex = 0U; zoneIndex < multisample.zones.size(); ++zoneIndex) {
        const auto& zone = multisample.zones[zoneIndex];
        NSString* sampleName = zone.sampleIndex < _project.samples.size() ? nsString(_project.samples[zone.sampleIndex].name) : @"Invalid sample";
        [rows addObject:@{@"zoneIndex": @(static_cast<unsigned long long>(zoneIndex)), @"sampleIndex": @(zone.sampleIndex), @"sampleName": sampleName,
                          @"keyLow": @(zone.keyLow), @"keyHigh": @(zone.keyHigh), @"velocityLow": @(zone.velocityLow), @"velocityHigh": @(zone.velocityHigh),
                          @"rootKey": @(zone.rootKey), @"transposeSemitones": @(zone.transposeSemitones), @"tuneCents": @(zone.tuneCents), @"gainDb": @(zone.gainDb),
                          @"pan": @(zone.pan), @"oneShot": @(zone.oneShot), @"reverse": @(zone.reverse), @"nonTranspose": @(zone.nonTranspose)}];
    }
    return rows;
}

- (BOOL)createMultisampleNamed:(NSString*)name sampleIndexes:(NSIndexSet*)sampleIndexes error:(NSString**)error createdIndex:(NSUInteger*)createdIndex {
    if (sampleIndexes == nil || sampleIndexes.count == 0U) {
        if (error != nullptr) *error = @"Select at least one sample for the new multisample.";
        return NO;
    }
    std::vector<std::size_t> indexes;
    indexes.reserve(sampleIndexes.count);
    NSUInteger current = sampleIndexes.firstIndex;
    while (current != NSNotFound) {
        if (!validSampleIndex(_project, current)) {
            if (error != nullptr) *error = @"The selected sample list contains an invalid sample index.";
            return NO;
        }
        indexes.push_back(static_cast<std::size_t>(current));
        current = [sampleIndexes indexGreaterThanIndex:current];
    }
    auto* project = &_project;
    std::sort(indexes.begin(), indexes.end(), [project](std::size_t a, std::size_t b) {
        const auto rootA = project->samples[a].rootKey;
        const auto rootB = project->samples[b].rootKey;
        return rootA == rootB ? a < b : rootA < rootB;
    });
    for (std::size_t i = 1U; i < indexes.size(); ++i) {
        if (_project.samples[indexes[i - 1U]].rootKey == _project.samples[indexes[i]].rootKey) {
            if (error != nullptr) *error = @"Automatic key mapping requires unique Root Key values. Change one of the duplicate sample Root Keys first.";
            return NO;
        }
    }
    if (_project.sounds.size() >= static_cast<std::size_t>(kMaxSoundPosition)) {
        if (error != nullptr) *error = @"No free SOUND position remains (1...500).";
        return NO;
    }
    ImportedMultisample multisample{};
    multisample.multisampleId = nextMultisampleIdValue(_project);
    NSString* trimmed = [name stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    const std::string multisampleName = trimmed.length == 0U ? std::string("New Multisample") : std::string(trimmed.UTF8String);
    multisample.name = multisampleName;
    multisample.sourceIdentity = std::string("manager:multisample:") + std::to_string(_project.multisamples.size());
    multisample.zones.reserve(indexes.size());
    std::uint16_t nextLow = 0U;
    for (std::size_t i = 0U; i < indexes.size(); ++i) {
        const std::size_t sampleIndex = indexes[i];
        const auto root = _project.samples[sampleIndex].rootKey;
        std::uint16_t high = 127U;
        if (i + 1U < indexes.size()) {
            const auto nextRoot = _project.samples[indexes[i + 1U]].rootKey;
            high = static_cast<std::uint16_t>((static_cast<unsigned int>(root) + static_cast<unsigned int>(nextRoot)) / 2U);
        }
        ImportedZone zone{};
        zone.sampleIndex = static_cast<std::uint32_t>(sampleIndex);
        zone.keyLow = static_cast<std::uint8_t>(nextLow);
        zone.keyHigh = static_cast<std::uint8_t>(high);
        zone.velocityLow = 1U;
        zone.velocityHigh = 127U;
        zone.rootKey = root;
        multisample.zones.push_back(zone);
        nextLow = static_cast<std::uint16_t>(high + 1U);
    }
    const std::uint32_t multisampleIndex = static_cast<std::uint32_t>(_project.multisamples.size());
    _project.multisamples.push_back(std::move(multisample));
    appendSoundForMultisample(_project, multisampleIndex, multisampleName);
    if (createdIndex != nullptr) *createdIndex = static_cast<NSUInteger>(multisampleIndex);
    clearError(error);
    return YES;
}

- (BOOL)renameMultisampleAtIndex:(NSUInteger)index name:(NSString*)name error:(NSString**)error {
    if (!validMultisampleIndex(_project, index)) { if (error != nullptr) *error = @"No multisample is selected."; return NO; }
    NSString* trimmed = [name stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (trimmed.length == 0U) { if (error != nullptr) *error = @"Multisample name cannot be empty."; return NO; }
    _project.multisamples[static_cast<std::size_t>(index)].name = std::string(trimmed.UTF8String);
    clearError(error);
    return YES;
}

- (BOOL)addZoneToMultisampleAtIndex:(NSUInteger)multisampleIndex sampleIndex:(NSUInteger)sampleIndex error:(NSString**)error {
    if (!validMultisampleIndex(_project, multisampleIndex)) { if (error != nullptr) *error = @"No multisample is selected."; return NO; }
    if (!validSampleIndex(_project, sampleIndex)) { if (error != nullptr) *error = @"Select a valid sample to assign to the new zone."; return NO; }
    ImportedZone zone{};
    zone.sampleIndex = static_cast<std::uint32_t>(sampleIndex);
    zone.rootKey = _project.samples[static_cast<std::size_t>(sampleIndex)].rootKey;
    zone.keyLow = zone.rootKey;
    zone.keyHigh = zone.rootKey;
    zone.velocityLow = 1U;
    zone.velocityHigh = 127U;
    _project.multisamples[static_cast<std::size_t>(multisampleIndex)].zones.push_back(zone);
    clearError(error);
    return YES;
}

- (BOOL)removeZoneFromMultisampleAtIndex:(NSUInteger)multisampleIndex zoneIndex:(NSUInteger)zoneIndex error:(NSString**)error {
    if (!validZoneIndex(_project, multisampleIndex, zoneIndex)) { if (error != nullptr) *error = @"No valid zone is selected."; return NO; }
    auto& zones = _project.multisamples[static_cast<std::size_t>(multisampleIndex)].zones;
    if (zones.size() <= 1U) { if (error != nullptr) *error = @"A multisample must contain at least one zone."; return NO; }
    zones.erase(zones.begin() + static_cast<std::ptrdiff_t>(zoneIndex));
    clearError(error);
    return YES;
}

- (BOOL)updateZoneAtMultisampleIndex:(NSUInteger)multisampleIndex
                           zoneIndex:(NSUInteger)zoneIndex
                         sampleIndex:(NSUInteger)sampleIndex
                              keyLow:(NSUInteger)keyLow
                             keyHigh:(NSUInteger)keyHigh
                         velocityLow:(NSUInteger)velocityLow
                        velocityHigh:(NSUInteger)velocityHigh
                             rootKey:(NSUInteger)rootKey
                  transposeSemitones:(NSInteger)transposeSemitones
                           tuneCents:(float)tuneCents
                              gainDb:(float)gainDb
                                 pan:(float)pan
                               error:(NSString**)error {
    if (!validZoneIndex(_project, multisampleIndex, zoneIndex)) { if (error != nullptr) *error = @"No valid zone is selected."; return NO; }
    if (!validSampleIndex(_project, sampleIndex)) { if (error != nullptr) *error = @"Zone sample assignment is invalid."; return NO; }
    if (keyLow > 127U || keyHigh > 127U || keyLow > keyHigh) { if (error != nullptr) *error = @"Key range must be 0...127 and Low cannot exceed High."; return NO; }
    if (velocityLow < 1U || velocityLow > 127U || velocityHigh < 1U || velocityHigh > 127U || velocityLow > velocityHigh) {
        if (error != nullptr) *error = @"Velocity range must be 1...127 and Low cannot exceed High.";
        return NO;
    }
    if (rootKey > 127U) { if (error != nullptr) *error = @"Root Key must be 0...127."; return NO; }
    if (transposeSemitones < -127 || transposeSemitones > 127) { if (error != nullptr) *error = @"Transpose must be between -127 and +127 semitones."; return NO; }
    if (!std::isfinite(tuneCents) || !std::isfinite(gainDb) || !std::isfinite(pan) || pan < -1.0F || pan > 1.0F) {
        if (error != nullptr) *error = @"Tune/Gain must be finite and Pan must be between -1.0 and +1.0.";
        return NO;
    }
    auto& zone = _project.multisamples[static_cast<std::size_t>(multisampleIndex)].zones[static_cast<std::size_t>(zoneIndex)];
    zone.sampleIndex = static_cast<std::uint32_t>(sampleIndex);
    zone.keyLow = static_cast<std::uint8_t>(keyLow);
    zone.keyHigh = static_cast<std::uint8_t>(keyHigh);
    zone.velocityLow = static_cast<std::uint8_t>(velocityLow);
    zone.velocityHigh = static_cast<std::uint8_t>(velocityHigh);
    zone.rootKey = static_cast<std::uint8_t>(rootKey);
    zone.transposeSemitones = static_cast<std::int8_t>(transposeSemitones);
    zone.tuneCents = tuneCents;
    zone.gainDb = gainDb;
    zone.pan = pan;
    clearError(error);
    return YES;
}

- (NSUInteger)soundCount { return static_cast<NSUInteger>(_project.sounds.size()); }
- (NSArray<NSString*>*)soundDisplayRows { return [self displayRows]; }

- (NSDictionary<NSString*, id>*)soundStateAtIndex:(NSUInteger)index {
    if (!validSoundIndex(_project, index)) return nil;
    const auto& sound = _project.sounds[static_cast<std::size_t>(index)];
    NSString* multisampleName = @"No multisample";
    std::size_t zoneCount = 0U;
    if (!sound.layers.empty()) {
        const std::uint32_t multisampleIndex = sound.layers.front().multisampleIndex;
        if (multisampleIndex < _project.multisamples.size()) {
            const auto& multisample = _project.multisamples[multisampleIndex];
            multisampleName = nsString(multisample.name);
            zoneCount = multisample.zones.size();
        }
    }
    return @{@"name": nsString(sound.name), @"position": @(sound.position), @"bank": @(sound.bank), @"page": @(sound.page), @"slot": @(sound.slot), @"category": @(sound.category),
             @"multisampleName": multisampleName, @"zoneCount": @(static_cast<unsigned long long>(zoneCount)),
             @"layerCount": @(static_cast<unsigned long long>(sound.layers.size()))};
}

- (NSArray<NSDictionary<NSString*, id>*>*)soundLayerStatesAtIndex:(NSUInteger)index {
    if (!validSoundIndex(_project, index)) return @[];
    const auto& sound = _project.sounds[static_cast<std::size_t>(index)];
    NSMutableArray<NSDictionary<NSString*, id>*>* rows = [NSMutableArray arrayWithCapacity:sound.layers.size()];
    for (std::size_t layerIndex = 0U; layerIndex < sound.layers.size(); ++layerIndex) {
        const auto& layer = sound.layers[layerIndex];
        NSString* multisampleName = @"Invalid multisample";
        std::size_t zoneCount = 0U;
        if (layer.multisampleIndex < _project.multisamples.size()) {
            const auto& multisample = _project.multisamples[layer.multisampleIndex];
            multisampleName = nsString(multisample.name);
            zoneCount = multisample.zones.size();
        }
        [rows addObject:@{@"layerIndex": @(static_cast<unsigned long long>(layerIndex)),
                          @"multisampleIndex": @(layer.multisampleIndex),
                          @"multisampleName": multisampleName,
                          @"zoneCount": @(static_cast<unsigned long long>(zoneCount)),
                          @"enabled": @(layer.enabled),
                          @"keyLow": @(layer.keyLow), @"keyHigh": @(layer.keyHigh),
                          @"velocityLow": @(layer.velocityLow), @"velocityHigh": @(layer.velocityHigh),
                          @"transposeSemitones": @(layer.transposeSemitones),
                          @"tuneCents": @(layer.tuneCents), @"levelDb": @(layer.levelDb), @"pan": @(layer.pan)}];
    }
    return rows;
}

- (BOOL)addSoundLayerAtIndex:(NSUInteger)soundIndex multisampleIndex:(NSUInteger)multisampleIndex error:(NSString**)error {
    if (multisampleIndex > UINT32_MAX) { if (error != nullptr) *error = @"Multisample index is too large."; return NO; }
    std::string editError;
    if (!SoundEditor::addLayer(_project, static_cast<std::size_t>(soundIndex), static_cast<std::uint32_t>(multisampleIndex), editError)) {
        setError(error, editError);
        return NO;
    }
    clearError(error);
    return YES;
}

- (BOOL)removeSoundLayerAtIndex:(NSUInteger)soundIndex layerIndex:(NSUInteger)layerIndex error:(NSString**)error {
    std::string editError;
    if (!SoundEditor::removeLayer(_project, static_cast<std::size_t>(soundIndex), static_cast<std::size_t>(layerIndex), editError)) {
        setError(error, editError);
        return NO;
    }
    clearError(error);
    return YES;
}

- (BOOL)updateSoundLayerAtIndex:(NSUInteger)soundIndex
                     layerIndex:(NSUInteger)layerIndex
               multisampleIndex:(NSUInteger)multisampleIndex
                        enabled:(BOOL)enabled
                         keyLow:(NSUInteger)keyLow
                        keyHigh:(NSUInteger)keyHigh
                    velocityLow:(NSUInteger)velocityLow
                   velocityHigh:(NSUInteger)velocityHigh
             transposeSemitones:(NSInteger)transposeSemitones
                      tuneCents:(float)tuneCents
                        levelDb:(float)levelDb
                            pan:(float)pan
                          error:(NSString**)error {
    if (!validSoundLayerIndex(_project, soundIndex, layerIndex)) { if (error != nullptr) *error = @"No valid SOUND layer is selected."; return NO; }
    if (multisampleIndex > UINT32_MAX || keyLow > 127U || keyHigh > 127U || velocityLow > 127U || velocityHigh > 127U) {
        if (error != nullptr) *error = @"SOUND layer values are outside their supported range.";
        return NO;
    }
    if (transposeSemitones < -127 || transposeSemitones > 127) {
        if (error != nullptr) *error = @"Transpose must be between -127 and +127 semitones.";
        return NO;
    }
    std::string editError;
    if (!SoundEditor::updateLayer(_project,
                                  static_cast<std::size_t>(soundIndex),
                                  static_cast<std::size_t>(layerIndex),
                                  static_cast<std::uint32_t>(multisampleIndex),
                                  enabled == YES,
                                  static_cast<std::uint8_t>(keyLow),
                                  static_cast<std::uint8_t>(keyHigh),
                                  static_cast<std::uint8_t>(velocityLow),
                                  static_cast<std::uint8_t>(velocityHigh),
                                  static_cast<std::int8_t>(transposeSemitones),
                                  tuneCents,
                                  levelDb,
                                  pan,
                                  editError)) {
        setError(error, editError);
        return NO;
    }
    clearError(error);
    return YES;
}

- (BOOL)updateSoundAtIndex:(NSUInteger)index name:(NSString*)name position:(NSUInteger)position bank:(NSUInteger)bank page:(NSUInteger)page slot:(NSUInteger)slot category:(NSUInteger)category error:(NSString**)error {
    if (!validSoundIndex(_project, index)) { if (error != nullptr) *error = @"No bank/library entry is selected."; return NO; }
    if (position < kMinSoundPosition || position > kMaxSoundPosition) {
        if (error != nullptr) *error = @"SOUND position must be between 1 and 500.";
        return NO;
    }
    if (bank > kLibraryAxisMaximum || page > kLibraryAxisMaximum || slot > kLibraryAxisMaximum || category > kLibraryAxisMaximum) {
        if (error != nullptr) *error = @"Bank, Page, Slot and Category must each be between 0 and 127.";
        return NO;
    }
    NSString* trimmed = [name stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (trimmed.length == 0U) { if (error != nullptr) *error = @"Library entry name cannot be empty."; return NO; }
    const auto soundPosition = static_cast<std::uint16_t>(position);
    if (soundPositionInUse(_project, soundPosition, static_cast<std::size_t>(index))) {
        if (error != nullptr) *error = [NSString stringWithFormat:@"SOUND position %03lu is already occupied.", (unsigned long)position];
        return NO;
    }
    const auto b = static_cast<std::uint16_t>(bank);
    const auto p = static_cast<std::uint16_t>(page);
    const auto s = static_cast<std::uint16_t>(slot);
    if (soundAddressInUse(_project, b, p, s, static_cast<std::size_t>(index))) {
        if (error != nullptr) *error = [NSString stringWithFormat:@"Bank %lu / Page %lu / Slot %lu is already occupied.",
                                        (unsigned long)bank, (unsigned long)page, (unsigned long)slot];
        return NO;
    }
    auto& sound = _project.sounds[static_cast<std::size_t>(index)];
    sound.name = std::string(trimmed.UTF8String);
    sound.position = soundPosition;
    sound.bank = b;
    sound.page = p;
    sound.slot = s;
    sound.category = static_cast<std::uint16_t>(category);
    clearError(error);
    return YES;
}


- (NSNumber*)nextFreeSoundPositionExcludingIndex:(NSUInteger)excludingIndex error:(NSString**)error {
    const std::size_t excluded = excludingIndex == NSNotFound ? _project.sounds.size() : static_cast<std::size_t>(excludingIndex);
    const std::uint16_t position = nextFreeSoundPositionValue(_project, excluded);
    if (position == 0U) {
        if (error != nullptr) *error = @"All SILVETON SOUND positions 001...500 are occupied.";
        return nil;
    }
    clearError(error);
    return @(position);
}

- (NSDictionary<NSString*, NSNumber*>*)nextFreeSoundAddressFromBank:(NSUInteger)bank page:(NSUInteger)page slot:(NSUInteger)slot excludingIndex:(NSUInteger)excludingIndex error:(NSString**)error {
    if (bank > kLibraryAxisMaximum || page > kLibraryAxisMaximum || slot > kLibraryAxisMaximum) {
        if (error != nullptr) *error = @"Bank, Page and Slot must each be between 0 and 127.";
        return nil;
    }
    std::uint16_t b = static_cast<std::uint16_t>(bank);
    std::uint16_t p = static_cast<std::uint16_t>(page);
    std::uint16_t s = static_cast<std::uint16_t>(slot);
    const std::size_t excluded = excludingIndex == NSNotFound ? _project.sounds.size() : static_cast<std::size_t>(excludingIndex);
    while (true) {
        if (!soundAddressInUse(_project, b, p, s, excluded)) {
            clearError(error);
            return @{@"bank": @(b), @"page": @(p), @"slot": @(s)};
        }
        if (!nextLibraryAddress(b, p, s)) break;
    }
    if (error != nullptr) *error = @"No free Bank/Page/Slot address exists at or after the requested position.";
    return nil;
}

- (BOOL)autoPackSoundAddressesFromBank:(NSUInteger)bank page:(NSUInteger)page slot:(NSUInteger)slot error:(NSString**)error {
    if (bank > kLibraryAxisMaximum || page > kLibraryAxisMaximum || slot > kLibraryAxisMaximum) {
        if (error != nullptr) *error = @"Bank, Page and Slot must each be between 0 and 127.";
        return NO;
    }
    if (_project.sounds.empty()) { if (error != nullptr) *error = @"There are no library entries to pack."; return NO; }
    std::uint16_t b = static_cast<std::uint16_t>(bank);
    std::uint16_t p = static_cast<std::uint16_t>(page);
    std::uint16_t s = static_cast<std::uint16_t>(slot);
    std::vector<std::array<std::uint16_t, 3U>> addresses;
    addresses.reserve(_project.sounds.size());
    for (std::size_t i = 0U; i < _project.sounds.size(); ++i) {
        addresses.push_back({b, p, s});
        if (i + 1U < _project.sounds.size() && !nextLibraryAddress(b, p, s)) {
            if (error != nullptr) *error = @"There is not enough Bank/Page/Slot space to pack all entries from this starting address.";
            return NO;
        }
    }
    for (std::size_t i = 0U; i < _project.sounds.size(); ++i) {
        _project.sounds[i].bank = addresses[i][0];
        _project.sounds[i].page = addresses[i][1];
        _project.sounds[i].slot = addresses[i][2];
    }
    clearError(error);
    return YES;
}

@end
