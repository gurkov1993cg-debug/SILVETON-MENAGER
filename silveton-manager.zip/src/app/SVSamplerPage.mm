// SILVETON_MERGE_V1 - page 5 СЕМПЛЕР. The window part of the Mac sampler (IMAK2011OO app/mac/main.mm) moved into the Manager:
// the picture the screens draw (SilvetonSamplerView), the mouse / keyboard / scroll wheel handed to them, and the clock.
// Sound comes from CoreAudio, the keyboard from CoreMIDI (sampler/host). Nothing of the sampler itself is changed.
#import <Cocoa/Cocoa.h>

#import "SVSamplerPage.h"
#import "SVTheme.h"
#include "SVUsedSounds.h"

#include "silveton/host/HostIo.h"
#include "silveton/sampler/SamplerTypes.h"
#include "silveton/sampler/SetPackage.h"
#include "silveton/ui/Gfx.h"
#include "silveton/ui/SamplerAppController.h"
#include "silveton/ui/SilvetonSamplerView.h"
#include "silveton/ui/Support.h"

#include <atomic>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

using silveton::ui::Canvas;
using silveton::ui::ControllerEnv;
using silveton::ui::FrameRenderer;
using silveton::ui::SamplerAppController;
using silveton::ui::SilvetonSamplerView;

namespace {
std::string svStd(NSString* s) { return s != nil ? std::string([s UTF8String]) : std::string(); }
}

// ---------------------------------------------------------------------------------------------------- the picture
@interface SilvetonPictureView : NSView {
    SilvetonSamplerView* screens_;               // not owned
    std::unique_ptr<FrameRenderer> renderer_;     // the finished picture; only the parts that changed are drawn again
}
- (instancetype)initWithFrame:(NSRect)frame screens:(SilvetonSamplerView*)screens;
- (void)clockTick;
- (void)refresh;                                // draw the next picture and mark the changed parts of the window
@end

@implementation SilvetonPictureView

- (instancetype)initWithFrame:(NSRect)frame screens:(SilvetonSamplerView*)screens {
    self = [super initWithFrame:frame];
    if (self != nil) {
        screens_ = screens;
    }
    return self;
}

- (BOOL)isOpaque { return YES; }
- (BOOL)acceptsFirstResponder { return YES; }
- (BOOL)acceptsFirstMouse:(NSEvent*)event { (void)event; return YES; }
- (NSMenu*)menuForEvent:(NSEvent*)event { (void)event; return nil; }   // the right button is the "reset" of a control

// picture pixels (origin top left), the same pixels the canvas has
- (NSPoint)picturePoint:(NSEvent*)event {
    const NSPoint inView = [self convertPoint:[event locationInWindow] fromView:nil];
    const NSPoint backing = [self convertPointToBacking:inView];
    const NSRect bounds = [self convertRectToBacking:[self bounds]];
    return NSMakePoint(backing.x, bounds.size.height - backing.y);
}

// Draws the next picture (the screens run once) and marks only the parts of the window that look different now.
- (void)refresh {
    if (self.window == nil) return;   // the page is not shown: nothing to draw
    const NSRect backing = [self convertRectToBacking:[self bounds]];
    const int w = static_cast<int>(backing.size.width + 0.5);
    const int h = static_cast<int>(backing.size.height + 0.5);
    if (w <= 0 || h <= 0) return;
    if (!renderer_ || renderer_->width() != w || renderer_->height() != h) {
        renderer_ = std::make_unique<FrameRenderer>(w, h);
        [self setNeedsDisplay:YES];
    }
    SilvetonSamplerView* screens = screens_;
    const std::vector<silveton::ui::IRect>& changed = renderer_->update([screens](Canvas& c) { screens->draw(c); });
    for (const silveton::ui::IRect& r : changed) {
        // picture pixels (origin top left) -> window coordinates (origin bottom left)
        const NSRect inBacking = NSMakeRect(r.left, h - r.bottom, r.right - r.left, r.bottom - r.top);
        [self setNeedsDisplayInRect:NSInsetRect([self convertRectFromBacking:inBacking], -1.0, -1.0)];
    }
}

- (void)drawRect:(NSRect)dirtyRect {
    (void)dirtyRect;   // (the picture is always complete; the system only paints the part that is dirty)
    const NSRect backing = [self convertRectToBacking:[self bounds]];
    const int w = static_cast<int>(backing.size.width + 0.5);
    const int h = static_cast<int>(backing.size.height + 0.5);
    if (w <= 0 || h <= 0) return;
    if (!renderer_ || renderer_->width() != w || renderer_->height() != h) {
        renderer_ = std::make_unique<FrameRenderer>(w, h);
        SilvetonSamplerView* screens = screens_;
        renderer_->update([screens](Canvas& c) { screens->draw(c); });
    }
    const Canvas& picture = renderer_->picture();

    CGContextRef context = [[NSGraphicsContext currentContext] CGContext];
    CGColorSpaceRef space = CGColorSpaceCreateDeviceRGB();
    CGDataProviderRef provider = CGDataProviderCreateWithData(NULL, picture.pixels(), static_cast<size_t>(w) * static_cast<size_t>(h) * 4U, NULL);
    CGImageRef image = CGImageCreate(static_cast<size_t>(w), static_cast<size_t>(h), 8, 32, static_cast<size_t>(w) * 4U, space,
                                     static_cast<CGBitmapInfo>(kCGBitmapByteOrder32Little | kCGImageAlphaNoneSkipFirst), provider, NULL, false, kCGRenderingIntentDefault);
    if (image != NULL) {
        CGContextSetInterpolationQuality(context, kCGInterpolationNone);
        CGContextDrawImage(context, NSRectToCGRect([self bounds]), image);
        CGImageRelease(image);
    }
    CGDataProviderRelease(provider);
    CGColorSpaceRelease(space);
}

// ---- the clock (about 60 times a second; the screens run even while another page is shown, they are only drawn on this page)
- (void)clockTick {
    const std::int64_t now = silveton::ui::nowMs();
    screens_->tick(now);
    if (self.window != nil && screens_->redrawDue(now)) [self refresh];
}

// ---- mouse
- (void)mouseDown:(NSEvent*)event {
    [self.window makeFirstResponder:self];
    const NSPoint p = [self picturePoint:event];
    if (([event modifierFlags] & NSEventModifierFlagControl) != 0) {   // Ctrl + click = the right button
        screens_->secondaryClick(static_cast<float>(p.x), static_cast<float>(p.y));
    } else {
        screens_->pointer(SilvetonSamplerView::PointerAction::Down, static_cast<float>(p.x), static_cast<float>(p.y));
    }
    [self refresh];
}

- (void)mouseDragged:(NSEvent*)event {
    if (([event modifierFlags] & NSEventModifierFlagControl) != 0) return;
    const NSPoint p = [self picturePoint:event];
    screens_->pointer(SilvetonSamplerView::PointerAction::Move, static_cast<float>(p.x), static_cast<float>(p.y));
    [self refresh];
}

- (void)mouseUp:(NSEvent*)event {
    const NSPoint p = [self picturePoint:event];
    if (([event modifierFlags] & NSEventModifierFlagControl) != 0) {
        screens_->pointer(SilvetonSamplerView::PointerAction::Cancel, static_cast<float>(p.x), static_cast<float>(p.y));
    } else {
        screens_->pointer(SilvetonSamplerView::PointerAction::Up, static_cast<float>(p.x), static_cast<float>(p.y));
    }
    [self refresh];
}

- (void)rightMouseDown:(NSEvent*)event {
    const NSPoint p = [self picturePoint:event];
    screens_->secondaryClick(static_cast<float>(p.x), static_cast<float>(p.y));
    [self refresh];
}

- (void)rightMouseUp:(NSEvent*)event { (void)event; }
- (void)rightMouseDragged:(NSEvent*)event { (void)event; }

- (void)scrollWheel:(NSEvent*)event {
    const NSPoint p = [self picturePoint:event];
    // a notch of a mouse wheel = one step; a finger on the trackpad = the distance it moved (in picture pixels)
    const CGFloat scale = [self convertSizeToBacking:NSMakeSize(1.0, 1.0)].height;
    const CGFloat dy = [event hasPreciseScrollingDeltas] ? -[event scrollingDeltaY] * scale : -[event deltaY] * 24.0;
    screens_->wheel(static_cast<float>(p.x), static_cast<float>(p.y), static_cast<float>(dy));
    [self refresh];
}

// ---- keyboard (the text and number pages)
- (void)keyDown:(NSEvent*)event {
    SilvetonSamplerView::Key key = SilvetonSamplerView::Key::None;
    switch ([event keyCode]) {
        case 36: case 76: key = SilvetonSamplerView::Key::Enter; break;       // Return, keypad Enter
        case 53: key = SilvetonSamplerView::Key::Escape; break;
        case 51: key = SilvetonSamplerView::Key::Backspace; break;
        case 117: key = SilvetonSamplerView::Key::Delete; break;
        case 123: key = SilvetonSamplerView::Key::Left; break;
        case 124: key = SilvetonSamplerView::Key::Right; break;
        case 125: key = SilvetonSamplerView::Key::Down; break;
        case 126: key = SilvetonSamplerView::Key::Up; break;
        case 48: key = SilvetonSamplerView::Key::Tab; break;
        default: break;
    }
    if (key != SilvetonSamplerView::Key::None) {
        screens_->keyDown(key);
    } else if (([event modifierFlags] & (NSEventModifierFlagCommand | NSEventModifierFlagControl)) == 0) {
        [self interpretKeyEvents:[NSArray arrayWithObject:event]];   // letters (also Cyrillic and accents) arrive in insertText:
    }
    [self refresh];
}

- (void)insertText:(id)text {
    NSString* s = [text isKindOfClass:[NSAttributedString class]] ? [(NSAttributedString*)text string] : (NSString*)text;
    screens_->typeText(svStd(s));
}

- (void)doCommandBySelector:(SEL)selector { (void)selector; }   // keys that are no letters are handled in keyDown:

@end

// ---------------------------------------------------------------------------------------------------- the sampler of the program
@implementation SVSamplerHost {
    std::unique_ptr<SamplerAppController> controller_;
    std::unique_ptr<SilvetonSamplerView> screens_;
    std::shared_ptr<std::atomic<SilvetonSamplerView*>> screensCell_;   // the sound threads reach the screens only through this
    SilvetonPictureView* picture_;
    NSTimer* clock_;
    id<NSObject> activity_;
    dispatch_queue_t lifecycle_;
    BOOL started_;
}

+ (SVSamplerHost*)shared {
    static SVSamplerHost* host = nil;
    if (host == nil) host = [[SVSamplerHost alloc] init];
    return host;
}

- (NSString*)documentsFolder {
    NSArray* dirs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    return dirs.count > 0 ? [dirs objectAtIndex:0] : [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
}

- (void)start {
    if (started_) return;
    started_ = YES;
    NSString* resources = [[NSBundle mainBundle] resourcePath];
    silveton::ui::setFontDirectory(svStd([resources stringByAppendingPathComponent:@"fonts"]));

    // where the sampler keeps its own small files (the same folder as the Mac sampler)
    NSString* support = [NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES) firstObject];
    NSString* dataDir = [support stringByAppendingPathComponent:@"SILVETON SAMPLER"];
    [[NSFileManager defaultManager] createDirectoryAtPath:dataDir withIntermediateDirectories:YES attributes:nil error:nil];

    // where SILVETON_BANK.sv may be (the first one found wins; a bank written by the Manager or chosen in the menu is remembered)
    NSString* home = NSHomeDirectory();
    NSString* documents = [self documentsFolder];
    ControllerEnv env;
    env.dataDir = svStd(dataDir);
    for (NSString* folder in @[[documents stringByAppendingPathComponent:@"SILVETON"], [home stringByAppendingPathComponent:@"SILVETON"], documents,
                               [home stringByAppendingPathComponent:@"Downloads"], [home stringByAppendingPathComponent:@"Desktop"]]) {
        env.bankCandidates.push_back(svStd([folder stringByAppendingPathComponent:@"SILVETON_BANK.sv"]));
    }
    screensCell_ = std::make_shared<std::atomic<SilvetonSamplerView*>>(nullptr);
    const auto cell = screensCell_;
    env.statusChanged = [cell](const std::string& message) {
        if (SilvetonSamplerView* v = cell->load()) v->setWarning(message);
    };
    env.midiConnectionChanged = [cell](int count) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (SilvetonSamplerView* v = cell->load()) v->setMidiConnections(count);
        });
    };
    controller_ = std::make_unique<SamplerAppController>(env);
    screens_ = std::make_unique<SilvetonSamplerView>(*controller_);
    screensCell_->store(screens_.get());
    picture_ = [[SilvetonPictureView alloc] initWithFrame:NSMakeRect(0.0, 0.0, 1340.0, 800.0) screens:screens_.get()];
    [picture_ setAutoresizingMask:(NSViewWidthSizable | NSViewHeightSizable)];

    // the sound must never be slowed down by the system's power saving
    activity_ = [[NSProcessInfo processInfo] beginActivityWithOptions:(NSActivityUserInitiatedAllowingIdleSystemSleep | NSActivityLatencyCritical)
                                                               reason:@"SILVETON SAMPLER plays sound and listens to MIDI"];

    // the sound starts on its own thread, like the tablet's audio lifecycle
    lifecycle_ = dispatch_queue_create("SilvetonAudioLifecycle", DISPATCH_QUEUE_SERIAL);
    SamplerAppController* controller = controller_.get();
    dispatch_async(lifecycle_, ^{ controller->start(); });

    clock_ = [NSTimer timerWithTimeInterval:(1.0 / 60.0) target:self selector:@selector(clockTick:) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:clock_ forMode:NSRunLoopCommonModes];
}

- (void)clockTick:(NSTimer*)timer {
    (void)timer;
    if (!controller_) return;
    controller_->housekeeping();
    [picture_ clockTick];
}

- (void)stop {
    if (!started_) return;
    [clock_ invalidate];
    clock_ = nil;
    if (screensCell_) screensCell_->store(nullptr);
    if (controller_) controller_->close();
    if (activity_ != nil) [[NSProcessInfo processInfo] endActivity:activity_];
    activity_ = nil;
}

- (NSView*)pictureView { return picture_; }

- (void)useBankFile:(NSString*)path {
    if (!controller_ || path.length == 0U) return;
    const std::string p = svStd(path);
    SamplerAppController* controller = controller_.get();
    dispatch_async(lifecycle_, ^{ controller->useBankFile(p); });   // the screens read everything again when it is ready
}

- (void)chooseBank:(id)sender {
    (void)sender;
    if (!controller_) return;
    NSOpenPanel* panel = [NSOpenPanel openPanel];
    [panel setMessage:@"Избери файла SILVETON_BANK.sv за семплера"];
    [panel setPrompt:@"Избери"];
    [panel setCanChooseFiles:YES];
    [panel setCanChooseDirectories:NO];
    [panel setAllowsMultipleSelection:NO];
    if ([panel runModal] != NSModalResponseOK || [[panel URLs] count] == 0) return;
    [self useBankFile:[[[panel URLs] objectAtIndex:0] path]];
}

// SILVETON_UNUSED_SOUNDS_V1 (the rule itself is in SVUsedSounds.h, plain C++)
- (BOOL)usedSoundPositions:(const std::vector<std::pair<int, std::string>>&)sounds used:(std::set<int>&)used why:(std::string&)why {
    used.clear();
    if (!controller_) { why = "Семплерът не е пуснат."; return NO; }
    return SVUsedSoundPositions(*controller_, sounds, used, why) ? YES : NO;
}

@end

// ---------------------------------------------------------------------------------------------------- the page
@implementation SVSamplerPage

- (instancetype)initWithShell:(SVShellWindowController*)shell frame:(NSRect)frame {
    self = [super initWithShell:shell frame:frame];
    if (self) {
        NSView* picture = [[SVSamplerHost shared] pictureView];
        if (picture != nil) {
            picture.frame = self.bounds;
            picture.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
            [self addSubview:picture];
        }
    }
    return self;
}

- (BOOL)isOpaque { return YES; }

- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    [[NSColor blackColor] setFill];
    NSRectFill(self.bounds);
}

- (void)pageDidShow {
    NSView* picture = [[SVSamplerHost shared] pictureView];
    if (picture == nil) return;
    if (picture.superview != self) {
        picture.frame = self.bounds;
        [self addSubview:picture];
    }
    [self.window makeFirstResponder:picture];
    [(SilvetonPictureView*)picture refresh];
    [picture setNeedsDisplay:YES];
}

@end
