// SILVETON_MERGE_V1 - page 5 СЕМПЛЕР. The window part of the Mac sampler (IMAK2011OO app/mac/main.mm) moved into the Manager:
// the picture the screens draw (SilvetonSamplerView), the mouse / keyboard / scroll wheel handed to them, and the clock.
// Sound comes from CoreAudio, the keyboard from CoreMIDI (sampler/host). Nothing of the sampler itself is changed.
#import <Cocoa/Cocoa.h>

#import "SVSamplerPage.h"
#import "SVDocument.h"
#import "SVTheme.h"
#include "SVUsedSounds.h"

#include "silveton/manager/SvBankBuilder.h"

#include "silveton/host/HostIo.h"
#include "silveton/sampler/SamplerTypes.h"
#include "silveton/sampler/SetPackage.h"
#include "silveton/ui/Gfx.h"
#include "silveton/ui/SamplerAppController.h"
#include "silveton/ui/SilvetonSamplerView.h"
#include "silveton/ui/Support.h"

#include <atomic>
#include <cstdint>
#include <memory>
#include <set>
#include <string>
#include <vector>

using silveton::ui::Canvas;
using silveton::ui::ControllerEnv;
using silveton::ui::FrameRenderer;
using silveton::ui::SamplerAppController;
using silveton::ui::SilvetonSamplerView;
using silveton::manager::BankProject;
using silveton::manager::SentSound;

namespace {
std::string svStd(NSString* s) { return s != nil ? std::string([s UTF8String]) : std::string(); }
std::string svClean(const std::string& s) {   // one line, no tabs (SILVETON_SEND_V1)
    std::string out = s;
    for (auto& c : out) if (c == '\t' || c == '\n' || c == '\r') c = ' ';
    return out;
}
}

// the progress window of the БАНКА page (implemented in ProcessingController.mm)
@interface SVProgressPanel : NSObject
- (instancetype)initWithTitle:(NSString*)title;
- (void)setFraction:(double)fraction text:(NSString*)text;
- (BOOL)stopRequested;
- (void)runWork:(void (^)(SVProgressPanel* progress))work;
@end

// ---------------------------------------------------------------------------------------------------- the picture
@interface SilvetonPictureView : NSView {
    SilvetonSamplerView* screens_;               // not owned
    std::unique_ptr<FrameRenderer> renderer_;     // the finished picture; only the parts that changed are drawn again
}
- (instancetype)initWithFrame:(NSRect)frame screens:(SilvetonSamplerView*)screens;
- (void)clockTick;
- (void)refresh;                                // draw the next picture and mark the changed parts of the window
@end

@implementation SilvetonPictureView

- (instancetype)initWithFrame:(NSRect)frame screens:(SilvetonSamplerView*)screens {
    self = [super initWithFrame:frame];
    if (self != nil) {
        screens_ = screens;
    }
    return self;
}

- (BOOL)isOpaque { return YES; }
- (BOOL)acceptsFirstResponder { return YES; }
- (BOOL)acceptsFirstMouse:(NSEvent*)event { (void)event; return YES; }
- (NSMenu*)menuForEvent:(NSEvent*)event { (void)event; return nil; }   // the right button is the "reset" of a control

// picture pixels (origin top left), the same pixels the canvas has
- (NSPoint)picturePoint:(NSEvent*)event {
    const NSPoint inView = [self convertPoint:[event locationInWindow] fromView:nil];
    const NSPoint backing = [self convertPointToBacking:inView];
    const NSRect bounds = [self convertRectToBacking:[self bounds]];
    return NSMakePoint(backing.x, bounds.size.height - backing.y);
}

// Draws the next picture (the screens run once) and marks only the parts of the window that look different now.
- (void)refresh {
    if (self.window == nil) return;   // the page is not shown: nothing to draw
    const NSRect backing = [self convertRectToBacking:[self bounds]];
    const int w = static_cast<int>(backing.size.width + 0.5);
    const int h = static_cast<int>(backing.size.height + 0.5);
    if (w <= 0 || h <= 0) return;
    if (!renderer_ || renderer_->width() != w || renderer_->height() != h) {
        renderer_ = std::make_unique<FrameRenderer>(w, h);
        [self setNeedsDisplay:YES];
    }
    SilvetonSamplerView* screens = screens_;
    const std::vector<silveton::ui::IRect>& changed = renderer_->update([screens](Canvas& c) { screens->draw(c); });
    for (const silveton::ui::IRect& r : changed) {
        // picture pixels (origin top left) -> window coordinates (origin bottom left)
        const NSRect inBacking = NSMakeRect(r.left, h - r.bottom, r.right - r.left, r.bottom - r.top);
        [self setNeedsDisplayInRect:NSInsetRect([self convertRectFromBacking:inBacking], -1.0, -1.0)];
    }
}

- (void)drawRect:(NSRect)dirtyRect {
    (void)dirtyRect;   // (the picture is always complete; the system only paints the part that is dirty)
    const NSRect backing = [self convertRectToBacking:[self bounds]];
    const int w = static_cast<int>(backing.size.width + 0.5);
    const int h = static_cast<int>(backing.size.height + 0.5);
    if (w <= 0 || h <= 0) return;
    if (!renderer_ || renderer_->width() != w || renderer_->height() != h) {
        renderer_ = std::make_unique<FrameRenderer>(w, h);
        SilvetonSamplerView* screens = screens_;
        renderer_->update([screens](Canvas& c) { screens->draw(c); });
    }
    const Canvas& picture = renderer_->picture();

    CGContextRef context = [[NSGraphicsContext currentContext] CGContext];
    CGColorSpaceRef space = CGColorSpaceCreateDeviceRGB();
    CGDataProviderRef provider = CGDataProviderCreateWithData(NULL, picture.pixels(), static_cast<size_t>(w) * static_cast<size_t>(h) * 4U, NULL);
    CGImageRef image = CGImageCreate(static_cast<size_t>(w), static_cast<size_t>(h), 8, 32, static_cast<size_t>(w) * 4U, space,
                                     static_cast<CGBitmapInfo>(kCGBitmapByteOrder32Little | kCGImageAlphaNoneSkipFirst), provider, NULL, false, kCGRenderingIntentDefault);
    if (image != NULL) {
        CGContextSetInterpolationQuality(context, kCGInterpolationNone);
        CGContextDrawImage(context, NSRectToCGRect([self bounds]), image);
        CGImageRelease(image);
    }
    CGDataProviderRelease(provider);
    CGColorSpaceRelease(space);
}

// ---- the clock (about 60 times a second; the screens run even while another page is shown, they are only drawn on this page)
- (void)clockTick {
    const std::int64_t now = silveton::ui::nowMs();
    screens_->tick(now);
    if (self.window != nil && screens_->redrawDue(now)) [self refresh];
}

// ---- mouse
- (void)mouseDown:(NSEvent*)event {
    [self.window makeFirstResponder:self];
    const NSPoint p = [self picturePoint:event];
    if (([event modifierFlags] & NSEventModifierFlagControl) != 0) {   // Ctrl + click = the right button
        screens_->secondaryClick(static_cast<float>(p.x), static_cast<float>(p.y));
    } else {
        screens_->pointer(SilvetonSamplerView::PointerAction::Down, static_cast<float>(p.x), static_cast<float>(p.y));
    }
    [self refresh];
}

- (void)mouseDragged:(NSEvent*)event {
    if (([event modifierFlags] & NSEventModifierFlagControl) != 0) return;
    const NSPoint p = [self picturePoint:event];
    screens_->pointer(SilvetonSamplerView::PointerAction::Move, static_cast<float>(p.x), static_cast<float>(p.y));
    [self refresh];
}

- (void)mouseUp:(NSEvent*)event {
    const NSPoint p = [self picturePoint:event];
    if (([event modifierFlags] & NSEventModifierFlagControl) != 0) {
        screens_->pointer(SilvetonSamplerView::PointerAction::Cancel, static_cast<float>(p.x), static_cast<float>(p.y));
    } else {
        screens_->pointer(SilvetonSamplerView::PointerAction::Up, static_cast<float>(p.x), static_cast<float>(p.y));
    }
    [self refresh];
}

- (void)rightMouseDown:(NSEvent*)event {
    const NSPoint p = [self picturePoint:event];
    screens_->secondaryClick(static_cast<float>(p.x), static_cast<float>(p.y));
    [self refresh];
}

- (void)rightMouseUp:(NSEvent*)event { (void)event; }
- (void)rightMouseDragged:(NSEvent*)event { (void)event; }

- (void)scrollWheel:(NSEvent*)event {
    const NSPoint p = [self picturePoint:event];
    // a notch of a mouse wheel = one step; a finger on the trackpad = the distance it moved (in picture pixels)
    const CGFloat scale = [self convertSizeToBacking:NSMakeSize(1.0, 1.0)].height;
    const CGFloat dy = [event hasPreciseScrollingDeltas] ? -[event scrollingDeltaY] * scale : -[event deltaY] * 24.0;
    screens_->wheel(static_cast<float>(p.x), static_cast<float>(p.y), static_cast<float>(dy));
    [self refresh];
}

// ---- keyboard (the text and number pages)
- (void)keyDown:(NSEvent*)event {
    SilvetonSamplerView::Key key = SilvetonSamplerView::Key::None;
    switch ([event keyCode]) {
        case 36: case 76: key = SilvetonSamplerView::Key::Enter; break;       // Return, keypad Enter
        case 53: key = SilvetonSamplerView::Key::Escape; break;
        case 51: key = SilvetonSamplerView::Key::Backspace; break;
        case 117: key = SilvetonSamplerView::Key::Delete; break;
        case 123: key = SilvetonSamplerView::Key::Left; break;
        case 124: key = SilvetonSamplerView::Key::Right; break;
        case 125: key = SilvetonSamplerView::Key::Down; break;
        case 126: key = SilvetonSamplerView::Key::Up; break;
        case 48: key = SilvetonSamplerView::Key::Tab; break;
        default: break;
    }
    if (key != SilvetonSamplerView::Key::None) {
        screens_->keyDown(key);
    } else if (([event modifierFlags] & (NSEventModifierFlagCommand | NSEventModifierFlagControl)) == 0) {
        [self interpretKeyEvents:[NSArray arrayWithObject:event]];   // letters (also Cyrillic and accents) arrive in insertText:
    }
    [self refresh];
}

- (void)insertText:(id)text {
    NSString* s = [text isKindOfClass:[NSAttributedString class]] ? [(NSAttributedString*)text string] : (NSString*)text;
    screens_->typeText(svStd(s));
}

- (void)doCommandBySelector:(SEL)selector { (void)selector; }   // keys that are no letters are handled in keyDown:

@end

// ---------------------------------------------------------------------------------------------------- the sampler of the program
@implementation SVSamplerHost {
    std::unique_ptr<SamplerAppController> controller_;
    std::unique_ptr<SilvetonSamplerView> screens_;
    std::shared_ptr<std::atomic<SilvetonSamplerView*>> screensCell_;   // the sound threads reach the screens only through this
    SilvetonPictureView* picture_;
    NSTimer* clock_;
    id<NSObject> activity_;
    dispatch_queue_t lifecycle_;
    BOOL started_;
    std::vector<SentSound> sent_;          // SILVETON_SEND_V1
    std::vector<std::string> sentFiles_;
    std::set<int> dropped_;
}

+ (SVSamplerHost*)shared {
    static SVSamplerHost* host = nil;
    if (host == nil) host = [[SVSamplerHost alloc] init];
    return host;
}

- (NSString*)documentsFolder {
    NSArray* dirs = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    return dirs.count > 0 ? [dirs objectAtIndex:0] : [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
}

- (void)start {
    if (started_) return;
    started_ = YES;
    NSString* resources = [[NSBundle mainBundle] resourcePath];
    silveton::ui::setFontDirectory(svStd([resources stringByAppendingPathComponent:@"fonts"]));

    // where the sampler keeps its own small files (the same folder as the Mac sampler)
    NSString* support = [NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES) firstObject];
    NSString* dataDir = [support stringByAppendingPathComponent:@"SILVETON SAMPLER"];
    [[NSFileManager defaultManager] createDirectoryAtPath:dataDir withIntermediateDirectories:YES attributes:nil error:nil];

    // where SILVETON_BANK.sv may be (the first one found wins; a bank written by the Manager or chosen in the menu is remembered)
    NSString* home = NSHomeDirectory();
    NSString* documents = [self documentsFolder];
    ControllerEnv env;
    env.dataDir = svStd(dataDir);
    for (NSString* folder in @[[documents stringByAppendingPathComponent:@"SILVETON"], [home stringByAppendingPathComponent:@"SILVETON"], documents,
                               [home stringByAppendingPathComponent:@"Downloads"], [home stringByAppendingPathComponent:@"Desktop"]]) {
        env.bankCandidates.push_back(svStd([folder stringByAppendingPathComponent:@"SILVETON_BANK.sv"]));
    }
    screensCell_ = std::make_shared<std::atomic<SilvetonSamplerView*>>(nullptr);
    const auto cell = screensCell_;
    env.statusChanged = [cell](const std::string& message) {
        if (SilvetonSamplerView* v = cell->load()) v->setWarning(message);
    };
    env.midiConnectionChanged = [cell](int count) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (SilvetonSamplerView* v = cell->load()) v->setMidiConnections(count);
        });
    };
    controller_ = std::make_unique<SamplerAppController>(env);
    [self readSentList];                                   // SILVETON_SEND_V1: what was sent before (also before a restart)
    controller_->setExtraBankFiles(sentFiles_);
    screens_ = std::make_unique<SilvetonSamplerView>(*controller_);
    screensCell_->store(screens_.get());
    picture_ = [[SilvetonPictureView alloc] initWithFrame:NSMakeRect(0.0, 0.0, 1340.0, 800.0) screens:screens_.get()];
    [picture_ setAutoresizingMask:(NSViewWidthSizable | NSViewHeightSizable)];

    // the sound must never be slowed down by the system's power saving
    activity_ = [[NSProcessInfo processInfo] beginActivityWithOptions:(NSActivityUserInitiatedAllowingIdleSystemSleep | NSActivityLatencyCritical)
                                                               reason:@"SILVETON SAMPLER plays sound and listens to MIDI"];

    // the sound starts on its own thread, like the tablet's audio lifecycle
    lifecycle_ = dispatch_queue_create("SilvetonAudioLifecycle", DISPATCH_QUEUE_SERIAL);
    SamplerAppController* controller = controller_.get();
    dispatch_async(lifecycle_, ^{ controller->start(); });

    clock_ = [NSTimer timerWithTimeInterval:(1.0 / 60.0) target:self selector:@selector(clockTick:) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:clock_ forMode:NSRunLoopCommonModes];
}

- (void)clockTick:(NSTimer*)timer {
    (void)timer;
    if (!controller_) return;
    controller_->housekeeping();
    [picture_ clockTick];
}

- (void)stop {
    if (!started_) return;
    [clock_ invalidate];
    clock_ = nil;
    if (screensCell_) screensCell_->store(nullptr);
    if (controller_) controller_->close();
    if (activity_ != nil) [[NSProcessInfo processInfo] endActivity:activity_];
    activity_ = nil;
}

- (NSView*)pictureView { return picture_; }

- (void)useBankFile:(NSString*)path {
    if (!controller_ || path.length == 0U) return;
    const std::string p = svStd(path);
    SamplerAppController* controller = controller_.get();
    dispatch_async(lifecycle_, ^{ controller->useBankFile(p); });   // the screens read everything again when it is ready
}

- (void)chooseBank:(id)sender {
    (void)sender;
    if (!controller_) return;
    if (!sentFiles_.empty()) {   // SILVETON_SEND_V1: the sent SOUNDs belong to the bank the sampler plays now
        NSAlert* alert = [[NSAlert alloc] init];
        alert.messageText = @"Има пратени звуци";
        alert.informativeText = @"Има пратени звуци, които още не са записани в банка (ЗАПИШИ БАНКАТА ЗА ТАБЛЕТА на страница БАНКА). С друга банка те излизат от семплера. Продължаваш ли?";
        [alert addButtonWithTitle:@"Смени банката"];
        [alert addButtonWithTitle:@"Остави"];
        if ([alert runModal] != NSAlertFirstButtonReturn) return;
    }
    NSOpenPanel* panel = [NSOpenPanel openPanel];
    [panel setMessage:@"Избери файла SILVETON_BANK.sv за семплера"];
    [panel setPrompt:@"Избери"];
    [panel setCanChooseFiles:YES];
    [panel setCanChooseDirectories:NO];
    [panel setAllowsMultipleSelection:NO];
    if ([panel runModal] != NSModalResponseOK || [[panel URLs] count] == 0) return;
    const std::vector<std::string> old = sentFiles_;
    sent_.clear();
    sentFiles_.clear();
    dropped_.clear();
    controller_->setExtraBankFiles({});
    [self writeSentList];
    [self useBankFile:[[[panel URLs] objectAtIndex:0] path]];
    [self removeSendFiles:old];
}

// ---------------------------------------------------------------------------------------------------- SILVETON_SEND_V1
- (NSString*)sendFolder {
    NSString* support = [NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES) firstObject];
    NSString* folder = [[support stringByAppendingPathComponent:@"SILVETON SAMPLER"] stringByAppendingPathComponent:@"ПРАТЕНИ"];
    [[NSFileManager defaultManager] createDirectoryAtPath:folder withIntermediateDirectories:YES attributes:nil error:nil];
    return folder;
}

- (NSString*)sentListFile { return [[self sendFolder] stringByAppendingPathComponent:@"ПРАТЕНИ.txt"]; }

- (NSString*)currentBankPath {
    if (!controller_) return nil;
    const std::string f = controller_->currentBankFile();
    return f.empty() ? nil : [NSString stringWithUTF8String:f.c_str()];
}

- (NSString*)defaultBankPath {
    return [[[self documentsFolder] stringByAppendingPathComponent:@"SILVETON"] stringByAppendingPathComponent:@"SILVETON_BANK.sv"];
}

- (NSString*)nextSendFilePath {
    NSString* folder = [self sendFolder];
    NSFileManager* fm = [NSFileManager defaultManager];
    for (NSUInteger n = 1U;; ++n) {
        NSString* path = [folder stringByAppendingPathComponent:[NSString stringWithFormat:@"ПРАТЕНИ-%lu.sv", static_cast<unsigned long>(n)]];
        BOOL listed = NO;
        for (const auto& f : sentFiles_) if (f == svStd(path)) { listed = YES; break; }
        if (!listed && ![fm fileExistsAtPath:path]) return path;
    }
}

- (NSUInteger)sentFileCount { return static_cast<NSUInteger>(sentFiles_.size()); }

- (std::vector<std::pair<int, std::string>>)samplerSounds {
    std::vector<std::pair<int, std::string>> out;
    if (!controller_) return out;
    for (const auto& item : controller_->soundCatalog()) {
        if (item.slot < 1 || item.slot > 500 || item.name.rfind("~ ", 0) == 0U) continue;
        out.emplace_back(item.slot, item.name);
    }
    return out;
}

- (std::vector<SentSound>)sentSounds { return sent_; }
- (std::vector<std::string>)sentFilePaths { return sentFiles_; }
- (std::set<int>)droppedPlaces { return dropped_; }

// ПРАТЕНИ.txt: "file<TAB>path", "sound<TAB>place<TAB>sampler name<TAB>Manager name", "drop<TAB>place"
- (void)writeSentList {
    std::string text = "SILVETON SENT 1\n";
    for (const auto& f : sentFiles_) text += "file\t" + svClean(f) + "\n";
    for (const auto& s : sent_) text += "sound\t" + std::to_string(s.place) + "\t" + svClean(s.samplerName) + "\t" + svClean(s.managerName) + "\n";
    for (const int p : dropped_) text += "drop\t" + std::to_string(p) + "\n";
    [[NSString stringWithUTF8String:text.c_str()] writeToFile:[self sentListFile] atomically:YES encoding:NSUTF8StringEncoding error:nil];
}

- (void)readSentList {
    sent_.clear();
    sentFiles_.clear();
    dropped_.clear();
    NSString* text = [NSString stringWithContentsOfFile:[self sentListFile] encoding:NSUTF8StringEncoding error:nil];
    if (text == nil) return;
    for (NSString* line in [text componentsSeparatedByString:@"\n"]) {
        NSArray<NSString*>* parts = [line componentsSeparatedByString:@"\t"];
        if (parts.count == 2U && [parts[0] isEqualToString:@"file"]) {
            if ([[NSFileManager defaultManager] fileExistsAtPath:parts[1]]) sentFiles_.push_back(svStd(parts[1]));
        } else if (parts.count == 4U && [parts[0] isEqualToString:@"sound"]) {
            const int place = static_cast<int>([parts[1] integerValue]);
            if (place >= 1 && place <= 500) sent_.push_back(SentSound{svStd(parts[3]), svStd(parts[2]), place});
        } else if (parts.count == 2U && [parts[0] isEqualToString:@"drop"]) {
            const int place = static_cast<int>([parts[1] integerValue]);
            if (place >= 1 && place <= 500) dropped_.insert(place);
        }
    }
}

// only files of the send folder are deleted (a project keeps its own)
- (void)removeSendFiles:(const std::vector<std::string>&)files {
    NSString* folder = [[self sendFolder] stringByAppendingString:@"/"];
    for (const auto& f : files) {
        NSString* path = [NSString stringWithUTF8String:f.c_str()];
        if (path != nil && [path hasPrefix:folder]) [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
    }
}

- (void)rememberPlan:(const std::vector<SentSound>&)plan {
    for (const auto& p : plan) {
        bool found = false;
        for (auto& s : sent_) if (s.managerName == p.managerName) { s = p; found = true; break; }
        if (!found) sent_.push_back(p);
        dropped_.erase(p.place);
    }
}

- (void)takeSentFile:(NSString*)path asBank:(BOOL)asBank plan:(const std::vector<SentSound>&)plan done:(void (^)(NSString* error))done {
    if (!controller_) { if (done) done(@"Семплерът не е пуснат."); return; }
    [self rememberPlan:plan];
    const std::string p = svStd(path);
    if (!asBank) {
        sentFiles_.push_back(p);
        controller_->setExtraBankFiles(sentFiles_);
    }
    [self writeSentList];
    SamplerAppController* controller = controller_.get();
    dispatch_async(lifecycle_, ^{
        controller->waitForBankLoad();
        std::string error;
        if (asBank) {
            if (!controller->useBankFile(p)) error = "Семплерът не зареди " + p;
        } else if (const auto why = controller->addSoundsFromBank(p)) {
            error = *why;
        }
        NSString* message = error.empty() ? nil : [NSString stringWithUTF8String:error.c_str()];
        dispatch_async(dispatch_get_main_queue(), ^{ if (done) done(message); });
    });
}

- (void)pasteIntoList:(const std::vector<SentSound>&)plan done:(void (^)(NSString* problem, NSInteger first, NSInteger count))done {
    if (!controller_) { if (done) done(@"Семплерът не е пуснат.", -1, 0); return; }
    std::vector<std::pair<int, std::string>> sounds;
    for (const auto& p : plan) sounds.emplace_back(p.place, p.samplerName);
    int first = -1, count = 0;
    const int start = screens_ ? screens_->chosenListPosition() : -1;
    const auto problem = controller_->pasteSoundsToList(sounds, start, first, count);
    if (count > 0 && screens_) screens_->listPasted(first, count);
    [picture_ refresh];
    [picture_ setNeedsDisplay:YES];
    if (done) done(problem ? [NSString stringWithUTF8String:problem->c_str()] : nil, first, count);
}

- (void)dropSentManagerNames:(const std::set<std::string>&)names {
    if (names.empty()) return;
    std::vector<SentSound> keep;
    for (const auto& s : sent_) {
        if (names.count(s.managerName) != 0U) dropped_.insert(s.place);
        else keep.push_back(s);
    }
    if (keep.size() == sent_.size()) return;
    sent_ = keep;
    [self writeSentList];
}

- (NSString*)saveSamplerStateTo:(NSString*)dir {
    if (!controller_) return @"Семплерът не е пуснат.";
    const std::string d = svStd(dir);
    SamplerAppController* controller = controller_.get();
    __block std::string error;
    dispatch_sync(lifecycle_, ^{
        controller->waitForBankLoad();
        if (const auto why = controller->saveProjectState(d)) error = *why;
    });
    return error.empty() ? nil : [NSString stringWithUTF8String:error.c_str()];
}

- (void)tabletBankWritten:(NSString*)bank stateDir:(NSString*)dir done:(void (^)(NSString* error))done {
    if (!controller_) { if (done) done(@"Семплерът не е пуснат."); return; }
    const std::vector<std::string> old = sentFiles_;
    sentFiles_.clear();
    dropped_.clear();          // they are out of the bank now; the SOUNDs keep their places (a new send replaces them there)
    controller_->setExtraBankFiles({});
    [self writeSentList];
    const std::string b = svStd(bank);
    const std::string d = svStd(dir);
    SamplerAppController* controller = controller_.get();
    __weak SVSamplerHost* weakSelf = self;
    dispatch_async(lifecycle_, ^{
        controller->waitForBankLoad();
        std::string error;
        if (!controller->useBankFile(b)) error = "Семплерът не зареди " + b;
        else if (const auto why = controller->loadProjectState(d)) error = *why;
        NSString* message = error.empty() ? nil : [NSString stringWithUTF8String:error.c_str()];
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf removeSendFiles:old];
            if (done) done(message);
        });
    });
}

- (void)openProjectBank:(NSString*)bank sentFile:(NSString*)sentFile sounds:(const std::vector<SentSound>&)sounds
                dropped:(const std::set<int>&)dropped stateDir:(NSString*)dir done:(void (^)(NSString* error))done {
    if (!controller_) { if (done) done(@"Семплерът не е пуснат."); return; }
    const std::vector<std::string> old = sentFiles_;
    sent_ = sounds;
    dropped_ = dropped;
    sentFiles_.clear();
    if (sentFile.length > 0U) sentFiles_.push_back(svStd(sentFile));
    controller_->setExtraBankFiles(sentFiles_);
    [self writeSentList];
    const std::string b = svStd(bank);
    const std::string d = svStd(dir);
    SamplerAppController* controller = controller_.get();
    __weak SVSamplerHost* weakSelf = self;
    dispatch_async(lifecycle_, ^{
        controller->waitForBankLoad();
        std::string error;
        if (!b.empty() && !controller->useBankFile(b)) error = "Семплерът не зареди " + b;
        else if (const auto why = controller->loadProjectState(d)) error = *why;
        NSString* message = error.empty() ? nil : [NSString stringWithUTF8String:error.c_str()];
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf removeSendFiles:old];
            if (done) done(message);
        });
    });
}

// SILVETON_UNUSED_SOUNDS_V1 (the rule itself is in SVUsedSounds.h, plain C++)
- (BOOL)usedSoundPositions:(const std::vector<std::pair<int, std::string>>&)sounds used:(std::set<int>&)used why:(std::string&)why {
    used.clear();
    if (!controller_) { why = "Семплерът не е пуснат."; return NO; }
    return SVUsedSoundPositions(*controller_, sounds, used, why) ? YES : NO;
}

@end

// ---------------------------------------------------------------------------------------------------- the page
@implementation SVSamplerPage

- (instancetype)initWithShell:(SVShellWindowController*)shell frame:(NSRect)frame {
    self = [super initWithShell:shell frame:frame];
    if (self) {
        NSView* picture = [[SVSamplerHost shared] pictureView];
        if (picture != nil) {
            picture.frame = self.bounds;
            picture.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
            [self addSubview:picture];
        }
    }
    return self;
}

- (BOOL)isOpaque { return YES; }

- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    [[NSColor blackColor] setFill];
    NSRectFill(self.bounds);
}

// ---- SILVETON_PASTE_V1: Постави (Cmd+V) - the sounds copied on ЗВУЦИ go into the sampler and each one becomes a new blend in the LIST
- (BOOL)validateMenuItem:(NSMenuItem*)item {
    if (item.action == @selector(paste:)) return [SVSamplerHost shared].copiedSounds.count > 0U;
    return YES;
}

- (void)paste:(id)sender {
    (void)sender;
    SVSamplerHost* host = [SVSamplerHost shared];
    NSArray<NSString*>* copied = host.copiedSounds;
    BankProject* project = SVProjectOf(self.shell.documentModel);
    if (copied.count == 0U || project == nullptr) { SVFlash(@"Постави", @"Първо копирай звуци на страница ЗВУЦИ (Cmd+C).", YES); return; }
    std::vector<std::string> names;
    NSMutableArray<NSString*>* missing = [NSMutableArray array];
    for (NSString* n in copied) {
        const std::string name = svStd(n);
        std::size_t same = 0U;
        const silveton::manager::SoundDefinition* found = nullptr;
        for (const auto& snd : project->sounds) if (snd.name == name) { ++same; found = &snd; }
        if (found == nullptr) { [missing addObject:n]; continue; }
        if (same > 1U) { SVAlert(self.window, @"Постави", [NSString stringWithFormat:@"Два звука се казват „%@“. Преименувай единия на страница ЗВУЦИ.", n], NO); return; }
        if (found->layers.empty()) { SVAlert(self.window, @"Постави", [NSString stringWithFormat:@"„%@“ още няма слоеве.", n], NO); return; }
        names.push_back(name);
    }
    if (names.empty()) { SVAlert(self.window, @"Постави", @"Копираните звуци вече ги няма в мениджъра.", NO); return; }
    std::vector<SentSound> plan;
    std::string error;
    if (!silveton::manager::planTransfer(names, [host samplerSounds], [host sentSounds], plan, error)) {
        SVAlert(self.window, @"Постави", @"В семплера няма свободно място за звук (1…500).", YES);
        return;
    }
    const BOOL asBank = [host currentBankPath] == nil;   // the sampler has no bank yet: these sounds become its bank
    NSString* path = asBank ? [host defaultBankPath] : [host nextSendFilePath];
    [[NSFileManager defaultManager] createDirectoryAtPath:path.stringByDeletingLastPathComponent withIntermediateDirectories:YES attributes:nil error:nil];
    SVProgressPanel* progress = [[SVProgressPanel alloc] initWithTitle:@"ПОСТАВЯНЕ В ЛИСТА"];
    __block BOOL ok = NO;
    __block std::string failure;
    const BankProject* from = project;
    const std::vector<SentSound>* planPtr = &plan;
    [progress runWork:^(SVProgressPanel* p) {
        [p setFraction:0.0 text:@"Подготвят се звуците …"];
        auto part = std::make_unique<BankProject>();
        if (!silveton::manager::transferProject(*from, *planPtr, *part, failure)) return;
        silveton::manager::SvBuildStats stats{};
        ok = silveton::manager::SvBankBuilder::writeAtomic(svStd(path), *part, stats, failure,
                                                           [p](double fraction, const std::string& text) -> bool {
                                                               [p setFraction:fraction text:[NSString stringWithUTF8String:text.c_str()] ?: @""];
                                                               return ![p stopRequested];
                                                           }) ? YES : NO;
        [p setFraction:1.0 text:ok ? @"Готово" : @""];
    }];
    if (!ok) {
        [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
        SVAlert(self.window, @"Постави", failure.empty() ? @"Спряно." : [NSString stringWithUTF8String:failure.c_str()], YES);
        return;
    }
    NSString* skipped = missing.count > 0U ? [NSString stringWithFormat:@" Ги няма вече в мениджъра: %@.", [missing componentsJoinedByString:@", "]] : @"";
    __weak SVSamplerPage* weakSelf = self;
    const std::vector<SentSound> planCopy = plan;
    [host takeSentFile:path asBank:asBank plan:plan done:^(NSString* problem) {
        SVSamplerPage* page = weakSelf;
        if (problem != nil) { SVAlert(page.window, @"Постави", problem, YES); return; }
        [[SVSamplerHost shared] pasteIntoList:planCopy done:^(NSString* listProblem, NSInteger first, NSInteger count) {
            if (count > 0) {
                NSString* where = count == 1 ? [NSString stringWithFormat:@"ЛИСТ %03ld", static_cast<long>(first + 1)]
                                             : [NSString stringWithFormat:@"%ld бленди от ЛИСТ %03ld", static_cast<long>(count), static_cast<long>(first + 1)];
                SVFlash(@"Постави", [NSString stringWithFormat:@"Поставени: %@.%@", where, skipped], NO);
            }
            if (listProblem != nil) SVAlert(page.window, @"Постави", listProblem, NO);
        }];
    }];
}

- (void)pageDidShow {
    NSView* picture = [[SVSamplerHost shared] pictureView];
    if (picture == nil) return;
    if (picture.superview != self) {
        picture.frame = self.bounds;
        [self addSubview:picture];
    }
    [self.window makeFirstResponder:picture];
    [(SilvetonPictureView*)picture refresh];
    [picture setNeedsDisplay:YES];
}

@end
