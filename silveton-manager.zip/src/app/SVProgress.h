#pragma once
// SILVETON_PROCESSING_V1 - progress window shared by import and processing.
#import <AppKit/AppKit.h>

@class SVManagerDocument;

// Imports file by file on a background thread with a 0-100 % window and a STOP button.
// Returns YES when at least one file was imported. details = warnings / errors.
BOOL SVImportPathsWithProgress(SVManagerDocument* document, NSArray<NSString*>* paths, NSWindow* parent, NSString** details);

// Opens the PROCESSING page (nothing runs until the user presses START).
void SVOpenProcessingPage(void);

// SILVETON_KONTAKT_V1: KONTAKT IMPORT window for one .nki (instrument list, sample rate, IMPORT) with progress.
// Returns YES when at least one instrument was imported. details = warnings / errors (nil when cancelled).
BOOL SVImportKontaktFile(SVManagerDocument* document, NSString* path, NSWindow* parent, NSString** details);

// Imports the given instruments of one .nki with progress (indexes into KontaktImporter::instrumentSets: a plain group, or
// all strings of one playing technique as ONE SOUND); sampleRate 0 = as in the files.
BOOL SVImportKontaktSets(SVManagerDocument* document, NSString* path, NSArray<NSNumber*>* setIndexes, NSUInteger sampleRate, NSInteger keyStep, NSWindow* parent, NSString** details);

// SILVETON_PITCH_V1: reads which note every sample is (progress + STOP), shows the РАЗПОЗНАТИ ТОНОВЕ window.
// Returns YES when root keys were changed (only the ticked samples, only on ПРИЕМИ ОТБЕЛЯЗАНИТЕ).
BOOL SVDetectPitchForAllSamples(SVManagerDocument* document, NSWindow* parent);
