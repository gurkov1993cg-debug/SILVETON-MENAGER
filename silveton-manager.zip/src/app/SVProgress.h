#pragma once
// SILVETON_PROCESSING_V1 - progress window shared by import and processing.
#import <AppKit/AppKit.h>

@class SVManagerDocument;

// Imports file by file on a background thread with a 0-100 % window and a STOP button.
// Returns YES when at least one file was imported. details = warnings / errors.
BOOL SVImportPathsWithProgress(SVManagerDocument* document, NSArray<NSString*>* paths, NSWindow* parent, NSString** details);

// Opens the PROCESSING page (nothing runs until the user presses START).
void SVOpenProcessingPage(void);

// SILVETON_KONTAKT_V1: KONTAKT IMPORT window for one .nki (instrument list, sample rate, IMPORT) with progress.
// Returns YES when at least one instrument was imported. details = warnings / errors (nil when cancelled).
BOOL SVImportKontaktFile(SVManagerDocument* document, NSString* path, NSWindow* parent, NSString** details);

// Imports the given Kontakt groups (instrument indexes) of one .nki with progress; sampleRate 0 = as in the files.
BOOL SVImportKontaktGroups(SVManagerDocument* document, NSString* path, NSArray<NSNumber*>* groupIndexes, NSUInteger sampleRate, NSWindow* parent, NSString** details);
