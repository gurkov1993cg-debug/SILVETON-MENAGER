#pragma once
// SILVETON_PROCESSING_V1 - progress window shared by import and processing.
#import <AppKit/AppKit.h>

@class SVManagerDocument;

// Imports file by file on a background thread with a 0-100 % window and a STOP button.
// Returns YES when at least one file was imported. details = warnings / errors.
BOOL SVImportPathsWithProgress(SVManagerDocument* document, NSArray<NSString*>* paths, NSWindow* parent, NSString** details);

// Opens the PROCESSING page (nothing runs until the user presses START).
void SVOpenProcessingPage(void);
