// SILVETON_LOOK_V1 - page 2 СЕМПЛИ: tree sound -> layers -> samples, waveform with loop, loop / trim / level / tune.
// SILVETON_PITCH_V1: which note a recording is (from the sound), for one sample or all of them.
// Nothing changes until ПРИЛОЖИ / ПРИЕМИ ТОНА is pressed.
#import "SVShell.h"
#import "SVDocument.h"
#import "SVProgress.h"
#import "SVTheme.h"
#import "SVAttackReview.h"
#import "SVAutoMapReview.h"

#include "silveton/manager/ObjectManager.h"
#include "silveton/manager/SampleEditor.h"

#include <cstddef>
#include <algorithm>
#include <cmath>
#include <map>
#include <set>
#include <string>
#include <vector>

using silveton::manager::BankProject;
using silveton::manager::DeleteImpact;
using silveton::manager::ObjectManager;
using silveton::manager::SampleEditor;

// ---------------------------------------------------------------- tree node

@interface SVTreeNode : NSObject
@property(nonatomic) NSInteger kind;          // 0 sound, 1 layer, 2 sample, 3 group of samples without a sound
@property(nonatomic) NSUInteger index;        // sound / multisample / sample index
@property(nonatomic, copy) NSString* title;
@property(nonatomic, copy) NSString* detail;
@property(nonatomic, strong) NSMutableArray<SVTreeNode*>* children;
@end
@implementation SVTreeNode
- (instancetype)init { self = [super init]; if (self) { _children = [NSMutableArray array]; _title = @""; _detail = @""; } return self; }
@end

// ---------------------------------------------------------------- waveform view

// SILVETON_ZOOM_V1: the wave can be zoomed (buttons, mouse wheel, pinch) and moved (sideways swipe, or the thin bar
// at the bottom while zoomed). viewStart / viewLength say which frames are on screen; the page fetches the picture for them.
@interface SVWaveView : NSView
@property(nonatomic, copy) NSArray<NSNumber*>* points;      // min, max, min, max ... for the frames on screen
@property(nonatomic) uint64_t totalFrames;                   // setting it shows the whole sample again
@property(nonatomic) double sampleRate;
@property(nonatomic) BOOL loopEnabled;
@property(nonatomic) uint64_t loopStart;
@property(nonatomic) uint64_t loopEnd;
@property(nonatomic) BOOL hasSelection;
@property(nonatomic) uint64_t selStart;
@property(nonatomic) uint64_t selEnd;
@property(nonatomic) int64_t playhead;                       // -1 = none
// SILVETON_PITCHCURVE_V1: semitones at evenly spaced points over the whole sample; empty = nothing drawn
@property(nonatomic, copy) NSArray<NSNumber*>* curve;
@property(nonatomic) BOOL penMode;                           // dragging draws the curve instead of selecting
@property(nonatomic) double curveLimit;                      // the top and bottom of the curve strip, in semitones
@property(nonatomic, copy) void (^onCurveChange)(void);
@property(nonatomic, readonly) uint64_t viewStart;
@property(nonatomic, readonly) uint64_t viewLength;          // == totalFrames when not zoomed
@property(nonatomic, copy) void (^onChange)(void);           // loop lines dragged or selection made
@property(nonatomic, copy) void (^onViewChange)(void);       // zoom or position changed
- (BOOL)isZoomed;
- (void)resetView;
- (void)zoomByFactor:(double)factor aroundFrame:(double)frame;   // factor > 1 = closer
- (void)panByFrames:(double)delta;
@end

@implementation SVWaveView {
    int _drag;          // 0 none, 1 loop start, 2 loop end, 3 selection, 4 position bar
    uint64_t _dragAnchor;
    CGFloat _barGrab;   // where inside the bar handle it was grabbed
    NSInteger _penLast; // last curve point the pen touched, -1 = the stroke just started
    double _penValue;
    double _panCarry;   // part of a frame left over from sideways swipes
}
- (instancetype)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) { _playhead = -1; _drag = 0; _sampleRate = 48000.0; _viewStart = 0U; _viewLength = 0U; _curveLimit = 24.0; }
    return self;
}
- (BOOL)isFlipped { return YES; }
- (void)setTotalFrames:(uint64_t)totalFrames {
    _totalFrames = totalFrames;
    _viewStart = 0U;
    _viewLength = totalFrames;
    _panCarry = 0.0;
}
- (BOOL)isZoomed { return _totalFrames > 0U && _viewLength < _totalFrames; }
- (void)notifyView {
    [self setNeedsDisplay:YES];
    if (_onViewChange != nil) _onViewChange();
}
- (void)resetView {
    if (_totalFrames == 0U) return;
    if (_viewStart == 0U && _viewLength == _totalFrames) return;
    _viewStart = 0U; _viewLength = _totalFrames;
    [self notifyView];
}
- (void)setViewFrom:(double)start length:(double)length {
    if (_totalFrames == 0U) return;
    const double total = static_cast<double>(_totalFrames);
    const double minLen = std::min(24.0, total);
    length = std::min(total, std::max(minLen, length));
    start = std::min(total - length, std::max(0.0, start));
    const uint64_t newLen = static_cast<uint64_t>(std::llround(length));
    uint64_t newStart = static_cast<uint64_t>(std::llround(start));
    if (newStart + newLen > _totalFrames) newStart = _totalFrames - newLen;
    if (newStart == _viewStart && newLen == _viewLength) return;
    _viewStart = newStart; _viewLength = newLen;
    [self notifyView];
}
- (void)zoomByFactor:(double)factor aroundFrame:(double)frame {
    if (_totalFrames == 0U || factor <= 0.0) return;
    const double total = static_cast<double>(_totalFrames);
    const double len = static_cast<double>(std::max<uint64_t>(1U, _viewLength));
    const double newLen = std::min(total, std::max(std::min(24.0, total), len / factor));
    const double t = std::min(1.0, std::max(0.0, (frame - static_cast<double>(_viewStart)) / len));
    [self setViewFrom:frame - t * newLen length:newLen];   // the frame under the cursor stays under the cursor
}
- (void)panByFrames:(double)delta {
    // small swipes at deep zoom are less than one frame: collect them until they add up to a whole frame
    _panCarry += delta;
    const double whole = std::trunc(_panCarry);
    if (whole == 0.0) return;
    _panCarry -= whole;
    [self setViewFrom:static_cast<double>(_viewStart) + whole length:static_cast<double>(_viewLength)];
}
- (CGFloat)xOfFrame:(uint64_t)frame {
    if (_totalFrames == 0U || _viewLength == 0U) return 0.0;
    const double rel = (static_cast<double>(frame) - static_cast<double>(_viewStart)) / static_cast<double>(_viewLength);
    return 1.0 + (self.bounds.size.width - 2.0) * static_cast<CGFloat>(rel);
}
- (uint64_t)frameOfX:(CGFloat)x {
    if (_totalFrames == 0U || _viewLength == 0U) return 0U;
    const double t = std::min(1.0, std::max(0.0, static_cast<double>((x - 1.0) / std::max(1.0, self.bounds.size.width - 2.0))));
    const uint64_t f = _viewStart + static_cast<uint64_t>(std::llround(t * static_cast<double>(_viewLength)));
    return std::min(f, _totalFrames);
}
// the thin position bar at the bottom (only while zoomed): x range of the handle
- (void)barHandleFrom:(CGFloat*)x0 to:(CGFloat*)x1 {
    const CGFloat w = self.bounds.size.width - 2.0;
    const double total = static_cast<double>(std::max<uint64_t>(1U, _totalFrames));
    *x0 = 1.0 + w * static_cast<CGFloat>(static_cast<double>(_viewStart) / total);
    *x1 = 1.0 + w * static_cast<CGFloat>(static_cast<double>(_viewStart + _viewLength) / total);
    if (*x1 - *x0 < 14.0) *x1 = *x0 + 14.0;
}
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    const NSRect b = self.bounds;
    [SVColField() setFill];
    NSRectFill(b);
    if (_hasSelection && _selEnd > _selStart) {
        const CGFloat x0 = [self xOfFrame:_selStart], x1 = [self xOfFrame:_selEnd];
        [[SVColAmber() colorWithAlphaComponent:0.14] setFill];
        NSRectFillUsingOperation(NSMakeRect(x0, 0.0, std::max(1.0, x1 - x0), b.size.height), NSCompositingOperationSourceOver);
    }
    if (_loopEnabled && _loopEnd > _loopStart) {
        const CGFloat x0 = [self xOfFrame:_loopStart], x1 = [self xOfFrame:_loopEnd];
        [[SVColGreen() colorWithAlphaComponent:0.10] setFill];
        NSRectFillUsingOperation(NSMakeRect(x0, 0.0, std::max(1.0, x1 - x0), b.size.height), NSCompositingOperationSourceOver);
    }
    // middle line
    [[SVColBorder() colorWithAlphaComponent:0.8] setFill];
    NSRectFill(NSMakeRect(0.0, b.size.height / 2.0, b.size.width, 1.0));
    // wave
    const NSUInteger n = _points.count / 2U;
    if (n > 0U) {
        const CGFloat mid = b.size.height / 2.0;
        const CGFloat half = (b.size.height - 8.0) / 2.0;
        const BOOL perFrame = n == _viewLength && static_cast<double>(_viewLength) <= b.size.width - 2.0;
        if (perFrame) {
            // deep zoom: every real sample is a point, joined by a line
            NSBezierPath* hiPath = [NSBezierPath bezierPath];
            NSBezierPath* loPath = [NSBezierPath bezierPath];
            BOOL differ = NO;
            for (NSUInteger i = 0U; i < n; ++i) {
                const CGFloat x = [self xOfFrame:_viewStart + i];
                const double lo = _points[i * 2U].doubleValue, hi = _points[i * 2U + 1U].doubleValue;
                if (std::fabs(hi - lo) > 1e-6) differ = YES;
                const NSPoint ph = NSMakePoint(x, mid - half * static_cast<CGFloat>(hi));
                const NSPoint pl = NSMakePoint(x, mid - half * static_cast<CGFloat>(lo));
                if (i == 0U) { [hiPath moveToPoint:ph]; [loPath moveToPoint:pl]; } else { [hiPath lineToPoint:ph]; [loPath lineToPoint:pl]; }
            }
            hiPath.lineWidth = 1.0; loPath.lineWidth = 1.0;
            [SVColAmber() setStroke];
            [hiPath stroke];
            if (differ) [loPath stroke];
            const CGFloat spacing = (b.size.width - 2.0) / static_cast<CGFloat>(std::max<uint64_t>(1U, _viewLength));
            if (spacing >= 6.0) {
                [SVColAmberLight() setFill];
                for (NSUInteger i = 0U; i < n; ++i) {
                    const CGFloat x = [self xOfFrame:_viewStart + i];
                    const CGFloat y = mid - half * static_cast<CGFloat>(_points[i * 2U + 1U].doubleValue);
                    NSRectFill(NSMakeRect(x - 1.5, y - 1.5, 3.0, 3.0));
                }
            }
        } else {
            NSBezierPath* path = [NSBezierPath bezierPath];
            for (NSUInteger i = 0U; i < n; ++i) {
                const CGFloat x = 1.0 + (b.size.width - 2.0) * static_cast<CGFloat>(i) / static_cast<CGFloat>(std::max<NSUInteger>(1U, n - 1U));
                const double lo = _points[i * 2U].doubleValue, hi = _points[i * 2U + 1U].doubleValue;
                [path moveToPoint:NSMakePoint(x, mid - half * static_cast<CGFloat>(hi))];
                [path lineToPoint:NSMakePoint(x, mid - half * static_cast<CGFloat>(lo) + 1.0)];
            }
            path.lineWidth = 1.0;
            [SVColAmber() setStroke];
            [path stroke];
        }
    }
    if (_loopEnabled && _loopEnd > _loopStart) {
        for (int k = 0; k < 2; ++k) {
            const CGFloat x = [self xOfFrame:k == 0 ? _loopStart : _loopEnd];
            [SVColGreen() setFill];
            NSRectFill(NSMakeRect(x - 1.0, 0.0, 2.0, b.size.height));
            NSString* text = k == 0 ? [NSString stringWithFormat:@"луп начало %@", SVSeconds(static_cast<double>(_loopStart) / _sampleRate)]
                                    : [NSString stringWithFormat:@"луп край %@", SVSeconds(static_cast<double>(_loopEnd) / _sampleRate)];
            NSDictionary* attrs = @{NSFontAttributeName: SVFont(11.0, NO), NSForegroundColorAttributeName: SVColGreen()};
            const NSSize size = [text sizeWithAttributes:attrs];
            [text drawAtPoint:NSMakePoint(k == 0 ? x + 4.0 : x - size.width - 4.0, 4.0) withAttributes:attrs];
        }
    }
    if (_hasSelection) {
        for (int k = 0; k < 2; ++k) {
            const CGFloat x = [self xOfFrame:k == 0 ? _selStart : _selEnd];
            [SVColAmberLight() setFill];
            NSRectFill(NSMakeRect(x - 0.5, 0.0, 1.0, b.size.height));
        }
    }
    if (_playhead >= 0) {
        const CGFloat x = [self xOfFrame:static_cast<uint64_t>(_playhead)];
        [SVColText() setFill];
        NSRectFill(NSMakeRect(x - 0.5, 0.0, 1.0, b.size.height));
    }
    if (_curve.count >= 2U && _totalFrames > 0U) {
        // SILVETON_PITCHCURVE_V1: the note movement over the sample, on the same time axis as the wave
        NSColor* line = [NSColor colorWithCalibratedRed:0.45 green:0.76 blue:1.0 alpha:1.0];
        const CGFloat mid = b.size.height / 2.0;
        const CGFloat half = (b.size.height - 8.0) / 2.0;
        [[line colorWithAlphaComponent:0.25] setFill];
        NSRectFill(NSMakeRect(0.0, mid, b.size.width, 1.0));
        NSBezierPath* path = [NSBezierPath bezierPath];
        const NSUInteger steps = static_cast<NSUInteger>(std::max(2.0, b.size.width));
        for (NSUInteger i = 0U; i < steps; ++i) {
            const CGFloat x = 1.0 + (b.size.width - 2.0) * static_cast<CGFloat>(i) / static_cast<CGFloat>(steps - 1U);
            const uint64_t frame = [self frameOfX:x];
            const double at = _totalFrames == 0U ? 0.0 : static_cast<double>(frame) / static_cast<double>(_totalFrames);
            const double place = at * static_cast<double>(_curve.count - 1U);
            const NSUInteger k = static_cast<NSUInteger>(std::min(place, static_cast<double>(_curve.count - 1U)));
            const double f = place - static_cast<double>(k);
            const double v = k + 1U < _curve.count ? _curve[k].doubleValue * (1.0 - f) + _curve[k + 1U].doubleValue * f : _curve[k].doubleValue;
            const CGFloat y = mid - half * static_cast<CGFloat>(std::min(1.0, std::max(-1.0, v / std::max(1.0, _curveLimit))));
            if (i == 0U) [path moveToPoint:NSMakePoint(x, y)]; else [path lineToPoint:NSMakePoint(x, y)];
        }
        path.lineWidth = _penMode ? 2.0 : 1.5;
        [line setStroke];
        [path stroke];
        if (_penMode) {
            NSDictionary* attrs = @{NSFontAttributeName: SVFont(10.0, NO), NSForegroundColorAttributeName: line};
            [[NSString stringWithFormat:@"+%.0f", _curveLimit] drawAtPoint:NSMakePoint(4.0, 2.0) withAttributes:attrs];
            [[NSString stringWithFormat:@"-%.0f", _curveLimit] drawAtPoint:NSMakePoint(4.0, b.size.height - 16.0) withAttributes:attrs];
        }
    }
    if ([self isZoomed]) {
        // where the shown part sits inside the whole sample
        [[SVColBorder() colorWithAlphaComponent:0.55] setFill];
        NSRectFillUsingOperation(NSMakeRect(1.0, b.size.height - 9.0, b.size.width - 2.0, 7.0), NSCompositingOperationSourceOver);
        CGFloat x0 = 0.0, x1 = 0.0;
        [self barHandleFrom:&x0 to:&x1];
        [[SVColAmber() colorWithAlphaComponent:0.75] setFill];
        NSRectFillUsingOperation(NSMakeRect(x0, b.size.height - 9.0, x1 - x0, 7.0), NSCompositingOperationSourceOver);
    }
    [SVColBorder() setStroke];
    [[NSBezierPath bezierPathWithRoundedRect:NSInsetRect(b, 0.5, 0.5) xRadius:6.0 yRadius:6.0] stroke];
}
// SILVETON_PITCHCURVE_V1: one stroke of the pen writes into the points the stroke passes over
- (void)penAtX:(CGFloat)x y:(CGFloat)y {
    if (_curve.count < 2U || _totalFrames == 0U) return;
    const CGFloat mid = self.bounds.size.height / 2.0;
    const CGFloat half = (self.bounds.size.height - 8.0) / 2.0;
    const double v = std::min(1.0, std::max(-1.0, static_cast<double>((mid - y) / std::max<CGFloat>(1.0, half)))) * _curveLimit;
    const uint64_t frame = [self frameOfX:x];
    const double at = static_cast<double>(frame) / static_cast<double>(_totalFrames);
    const NSInteger k = static_cast<NSInteger>(std::llround(at * static_cast<double>(_curve.count - 1U)));
    if (k < 0 || k >= static_cast<NSInteger>(_curve.count)) return;
    NSMutableArray<NSNumber*>* next = [_curve mutableCopy];
    const NSInteger from = _penLast < 0 ? k : std::min(_penLast, k);
    const NSInteger to = _penLast < 0 ? k : std::max(_penLast, k);
    for (NSInteger i = from; i <= to; ++i) {
        const double f = to == from ? 1.0 : static_cast<double>(i - from) / static_cast<double>(to - from);
        const double a = _penLast < 0 ? v : (k >= _penLast ? _penValue * (1.0 - f) + v * f : v * (1.0 - f) + _penValue * f);
        next[static_cast<NSUInteger>(i)] = @(a);
    }
    _penLast = k; _penValue = v;
    self.curve = next;
    [self setNeedsDisplay:YES];
    if (_onCurveChange != nil) _onCurveChange();
}
- (void)mouseDown:(NSEvent*)event {
    if (_totalFrames == 0U) return;
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    if (_penMode) { _drag = 5; _penLast = -1; [self penAtX:p.x y:p.y]; return; }
    if ([self isZoomed] && p.y >= self.bounds.size.height - 13.0) {
        CGFloat x0 = 0.0, x1 = 0.0;
        [self barHandleFrom:&x0 to:&x1];
        _drag = 4;
        if (p.x >= x0 && p.x <= x1) _barGrab = p.x - x0;
        else {
            _barGrab = (x1 - x0) / 2.0;   // click beside the handle: centre the shown part there
            [self mouseDragged:event];
        }
        return;
    }
    _drag = 3;
    if (_loopEnabled && _loopEnd > _loopStart) {
        if (std::fabs(p.x - [self xOfFrame:_loopStart]) <= 6.0) _drag = 1;
        else if (std::fabs(p.x - [self xOfFrame:_loopEnd]) <= 6.0) _drag = 2;
    }
    _dragAnchor = [self frameOfX:p.x];
    if (_drag == 3) { _hasSelection = YES; _selStart = _selEnd = _dragAnchor; [self setNeedsDisplay:YES]; }
}
- (void)mouseDragged:(NSEvent*)event {
    if (_totalFrames == 0U || _drag == 0) return;
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    if (_drag == 5) { [self penAtX:p.x y:p.y]; return; }
    if (_drag == 4) {
        const double w = std::max(1.0, static_cast<double>(self.bounds.size.width - 2.0));
        const double start = static_cast<double>(p.x - _barGrab - 1.0) / w * static_cast<double>(_totalFrames);
        [self setViewFrom:start length:static_cast<double>(_viewLength)];
        return;
    }
    const uint64_t f = [self frameOfX:p.x];
    if (_drag == 1) _loopStart = std::min(f, _loopEnd > 0U ? _loopEnd - 1U : 0U);
    else if (_drag == 2) _loopEnd = std::max(f, _loopStart + 1U);
    else { _selStart = std::min(_dragAnchor, f); _selEnd = std::max(_dragAnchor, f); }
    [self setNeedsDisplay:YES];
}
- (void)mouseUp:(NSEvent*)event {
    (void)event;
    if (_drag == 5) { _drag = 0; _penLast = -1; return; }
    if (_drag == 4) { _drag = 0; return; }
    if (_drag == 3 && _selEnd <= _selStart) _hasSelection = NO;
    _drag = 0;
    [self setNeedsDisplay:YES];
    if (_onChange != nil) _onChange();
}
// mouse wheel / two-finger up-down = zoom under the cursor, two-finger sideways = move
- (void)scrollWheel:(NSEvent*)event {
    if (_totalFrames == 0U) { [super scrollWheel:event]; return; }
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    const double dx = event.scrollingDeltaX, dy = event.scrollingDeltaY;
    const BOOL precise = event.hasPreciseScrollingDeltas;
    if (std::fabs(dx) > std::fabs(dy)) {
        const double framesPerPixel = static_cast<double>(_viewLength) / std::max(1.0, static_cast<double>(self.bounds.size.width - 2.0));
        [self panByFrames:-dx * (precise ? 1.0 : 10.0) * framesPerPixel];
    } else if (dy != 0.0) {
        const double factor = std::exp(std::min(2.0, std::max(-2.0, dy * (precise ? 0.01 : 0.25))));
        [self zoomByFactor:factor aroundFrame:static_cast<double>([self frameOfX:p.x])];
    }
}
- (void)magnifyWithEvent:(NSEvent*)event {
    if (_totalFrames == 0U) return;
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    [self zoomByFactor:std::exp(static_cast<double>(event.magnification) * 3.0) aroundFrame:static_cast<double>([self frameOfX:p.x])];
}
@end

// ---------------------------------------------------------------- tree with a right-click menu

@interface SVTreeView : NSOutlineView
@property(nonatomic, copy) NSMenu* (^menuForRow)(NSInteger row);
@end
@implementation SVTreeView
- (NSMenu*)menuForEvent:(NSEvent*)event {
    const NSInteger row = [self rowAtPoint:[self convertPoint:event.locationInWindow fromView:nil]];
    if (row < 0 || _menuForRow == nil) return nil;
    return _menuForRow(row);
}
@end

// ---------------------------------------------------------------- page

@interface SVSamplesPage : SVPageView <NSOutlineViewDataSource, NSOutlineViewDelegate>
- (void)selectSampleIndex:(NSUInteger)index;
@end

@implementation SVSamplesPage {
    SVTreeView* _tree;
    NSTextField* _zoomHint;        // SILVETON_ZOOM_V1
    NSMutableArray<SVTreeNode*>* _roots;
    NSUInteger _sample;            // NSNotFound = none
    NSTextField* _header;
    SVWaveView* _wave;
    NSTimer* _timer;
    // loop & cut
    SVToggle* _loopOn; NSTextField* _loopStartField; NSTextField* _loopEndField;
    SVToggle* _xfadeOn; NSTextField* _xfadeField;
    SVToggle* _trimOn; NSTextField* _trimStartField; NSTextField* _trimEndField;
    SVToggle* _fadeOn; NSTextField* _fadeInField; NSTextField* _fadeOutField;
    // level & tune
    SVKnob* _gain; SVKnob* _root; SVKnob* _fine; SVKnob* _normalize; SVToggle* _normalizeOn;
    NSTextField* _peakLabel;
    SVKeyButton* _undoKey;
    // SILVETON_CLEANWAVE_V1: how clean each place should be (0...1), drawn with the pen over the wave
    std::vector<float> _curveRaw;
    SVToggle* _penOn;
    SVKnob* _cleanKnob;
    SVKnob* _overtoneKnob;
    SVKnob* _edgeKnob;
    // pitch detection (SILVETON_PITCH_V1)
    NSTextField* _pitchLabel;
    SVKeyButton* _acceptKey;
    NSDictionary* _pitch;          // last result for _sample, nil = none
    double _rate;
    uint64_t _frames;
}

- (instancetype)initWithShell:(SVShellWindowController*)shell frame:(NSRect)frame {
    self = [super initWithShell:shell frame:frame];
    if (self) { _sample = NSNotFound; _roots = [NSMutableArray array]; _rate = 48000.0; _frames = 0U; [self build]; }
    return self;
}

- (void)build {
    const NSRect b = self.bounds;
    // ---- tree
    SVPanel* left = [[SVPanel alloc] initWithFrame:NSMakeRect(16.0, 16.0, 300.0, b.size.height - 32.0) title:@"КАКВО ИМА В ПРОЕКТА"];
    left.autoresizingMask = NSViewHeightSizable;
    _tree = [[SVTreeView alloc] initWithFrame:NSZeroRect];
    __weak SVSamplesPage* weakTreeSelf = self;
    _tree.menuForRow = ^NSMenu*(NSInteger row) { return [weakTreeSelf contextMenuForRow:row]; };   // SILVETON_DELETE_BLEND_V1
    SVStyleTable(_tree);
    _tree.headerView = nil;
    _tree.dataSource = self;
    _tree.delegate = self;
    _tree.indentationPerLevel = 16.0;
    NSTableColumn* name = SVTextColumn(@"name", @"", 176.0);
    [_tree addTableColumn:name];
    _tree.outlineTableColumn = name;
    NSTableColumn* detail = SVTextColumn(@"detail", @"", 94.0);
    [(NSTextFieldCell*)detail.dataCell setTextColor:SVColDim()];
    [(NSTextFieldCell*)detail.dataCell setAlignment:NSTextAlignmentRight];
    [_tree addTableColumn:detail];
    NSScrollView* scroll = SVScroll(NSMakeRect(12.0, 32.0, 276.0, left.bounds.size.height - 32.0 - 174.0), _tree);
    scroll.autoresizingMask = NSViewHeightSizable;
    [left addSubview:scroll];
    // SILVETON_AUTOMAP_V1
    const CGFloat my = left.bounds.size.height - 164.0;
    SVKeyButton* autoMap = [SVKeyButton keyWithFrame:NSMakeRect(12.0, my, 276.0, 32.0) title:@"НАПРАВИ БЛЕНДА ОТ СЕМПЛИТЕ" kind:0 target:self action:@selector(autoMapPressed:)];
    autoMap.textSize = 11.0; autoMap.autoresizingMask = NSViewMinYMargin; [left addSubview:autoMap];
    // SILVETON_ATTACK_V1
    const CGFloat ty = left.bounds.size.height - 126.0;
    SVKeyButton* trimStarts = [SVKeyButton keyWithFrame:NSMakeRect(12.0, ty, 276.0, 32.0) title:@"ОТРЕЖИ ТИШИНАТА ПРЕДИ УДАРА" kind:0 target:self action:@selector(trimLateStartsPressed:)];
    trimStarts.textSize = 11.0; trimStarts.autoresizingMask = NSViewMinYMargin; [left addSubview:trimStarts];
    const CGFloat ay = left.bounds.size.height - 88.0;
    SVKeyButton* detectAll = [SVKeyButton keyWithFrame:NSMakeRect(12.0, ay, 276.0, 34.0) title:@"РАЗПОЗНАЙ ТОНА НА ВСИЧКИ СЕМПЛИ" kind:0 target:self action:@selector(detectAllPressed:)];
    detectAll.textSize = 11.0; detectAll.autoresizingMask = NSViewMinYMargin; [left addSubview:detectAll];
    const CGFloat by = left.bounds.size.height - 46.0;
    SVKeyButton* rename = [SVKeyButton keyWithFrame:NSMakeRect(12.0, by, 112.0, 34.0) title:@"ПРЕИМЕНУВАЙ" kind:0 target:self action:@selector(renamePressed:)];
    rename.textSize = 11.0; rename.autoresizingMask = NSViewMinYMargin; [left addSubview:rename];
    SVKeyButton* copy = [SVKeyButton keyWithFrame:NSMakeRect(130.0, by, 78.0, 34.0) title:@"КОПИРАЙ" kind:0 target:self action:@selector(copyPressed:)];
    copy.textSize = 11.0; copy.autoresizingMask = NSViewMinYMargin; [left addSubview:copy];
    SVKeyButton* del = [SVKeyButton keyWithFrame:NSMakeRect(214.0, by, 74.0, 34.0) title:@"ИЗТРИЙ" kind:2 target:self action:@selector(deletePressed:)];
    del.textSize = 11.0; del.autoresizingMask = NSViewMinYMargin; [left addSubview:del];
    [self addSubview:left];

    // ---- waveform
    const CGFloat rx = 332.0;
    SVPanel* top = [[SVPanel alloc] initWithFrame:NSMakeRect(rx, 16.0, b.size.width - rx - 16.0, 262.0) title:@""];
    top.autoresizingMask = NSViewWidthSizable;
    _header = SVLabel(NSMakeRect(12.0, 10.0, top.bounds.size.width - 24.0, 18.0), @"Избери семпъл отляво.", 12.0, YES, SVColAmber());
    _header.autoresizingMask = NSViewWidthSizable;
    [top addSubview:_header];
    _wave = [[SVWaveView alloc] initWithFrame:NSMakeRect(12.0, 34.0, top.bounds.size.width - 24.0, 160.0)];
    _wave.autoresizingMask = NSViewWidthSizable;
    __weak SVSamplesPage* weakSelf = self;
    _wave.onChange = ^{ [weakSelf waveChanged]; };
    _wave.onViewChange = ^{ [weakSelf fetchWavePoints]; };
    _wave.onCurveChange = ^{ [weakSelf curveDrawn]; };
    _wave.curveLimit = 1.0;   // SILVETON_CLEANWAVE_V1: the strip means 0 ... 1 clean, not semitones
    [top addSubview:_wave];
    _zoomHint = SVLabel(NSMakeRect(12.0, 197.0, top.bounds.size.width - 24.0, 15.0), @"", 10.0, NO, SVColDim());
    _zoomHint.autoresizingMask = NSViewWidthSizable;
    _zoomHint.lineBreakMode = NSLineBreakByTruncatingTail;
    [top addSubview:_zoomHint];
    SVKeyButton* play = [SVKeyButton keyWithFrame:NSMakeRect(12.0, 216.0, 110.0, 34.0) title:@"▶ ПУСНИ" kind:1 target:self action:@selector(playPressed:)];
    [top addSubview:play];
    SVKeyButton* loop = [SVKeyButton keyWithFrame:NSMakeRect(130.0, 216.0, 130.0, 34.0) title:@"▶ САМО ЛУПА" kind:0 target:self action:@selector(playLoopPressed:)];
    [top addSubview:loop];
    SVKeyButton* stop = [SVKeyButton keyWithFrame:NSMakeRect(268.0, 216.0, 90.0, 34.0) title:@"■ СТОП" kind:0 target:self action:@selector(stopPressed:)];
    [top addSubview:stop];
    // SILVETON_ZOOM_V1: zoom buttons on the right
    const CGFloat tw = top.bounds.size.width;
    SVKeyButton* zoomAll = [SVKeyButton keyWithFrame:NSMakeRect(tw - 12.0 - 70.0, 216.0, 70.0, 34.0) title:@"ЦЯЛО" kind:0 target:self action:@selector(zoomAllPressed:)];
    zoomAll.textSize = 11.0; zoomAll.autoresizingMask = NSViewMinXMargin; [top addSubview:zoomAll];
    SVKeyButton* zoomIn = [SVKeyButton keyWithFrame:NSMakeRect(tw - 12.0 - 70.0 - 6.0 - 80.0, 216.0, 80.0, 34.0) title:@"ЗУУМ +" kind:0 target:self action:@selector(zoomInPressed:)];
    zoomIn.textSize = 11.0; zoomIn.autoresizingMask = NSViewMinXMargin; [top addSubview:zoomIn];
    SVKeyButton* zoomOut = [SVKeyButton keyWithFrame:NSMakeRect(tw - 12.0 - 70.0 - 6.0 - 80.0 - 6.0 - 80.0, 216.0, 80.0, 34.0) title:@"ЗУУМ −" kind:0 target:self action:@selector(zoomOutPressed:)];
    zoomOut.textSize = 11.0; zoomOut.autoresizingMask = NSViewMinXMargin; [top addSubview:zoomOut];
    [self updateZoomHint];
    [self addSubview:top];

    // ---- loop & cut
    const CGFloat ly = 294.0;
    SVPanel* cut = [[SVPanel alloc] initWithFrame:NSMakeRect(rx, ly, 360.0, b.size.height - ly - 16.0) title:@"ЛУП И РЯЗАНЕ"];
    cut.autoresizingMask = NSViewHeightSizable;
    CGFloat y = 36.0;
    auto row = [&](NSString* text) -> SVToggle* {
        SVToggle* t = [[SVToggle alloc] initWithFrame:NSMakeRect(12.0, y, 44.0, 22.0)];
        [cut addSubview:t];
        [cut addSubview:SVLabel(NSMakeRect(64.0, y + 3.0, 124.0, 18.0), text, 12.0, NO, SVColText())];
        return t;
    };
    auto field = [&](CGFloat x, CGFloat w) {
        NSTextField* f = SVField(NSMakeRect(x, y - 1.0, w, 24.0), @"");
        f.alignment = NSTextAlignmentRight;
        [cut addSubview:f];
        return f;
    };
    auto unit = [&](NSString* text) { [cut addSubview:SVLabel(NSMakeRect(332.0, y + 3.0, 24.0, 16.0), text, 11.0, NO, SVColDim())]; };
    auto arrow = [&](NSString* text) { [cut addSubview:SVLabel(NSMakeRect(252.0, y + 2.0, 14.0, 18.0), text, 12.0, NO, SVColDim())]; };
    _loopOn = row(@"Луп"); _loopStartField = field(188.0, 62.0); arrow(@"→"); _loopEndField = field(268.0, 62.0); unit(@"s");
    y += 34.0;
    _xfadeOn = row(@"Кросфейд на лупа"); _xfadeField = field(268.0, 62.0); unit(@"ms");
    y += 34.0;
    _trimOn = row(@"Махни от … до …"); _trimStartField = field(188.0, 62.0); arrow(@"→"); _trimEndField = field(268.0, 62.0); unit(@"s");
    y += 34.0;
    _fadeOn = row(@"Fade in / out"); _fadeInField = field(188.0, 62.0); arrow(@"/"); _fadeOutField = field(268.0, 62.0); unit(@"ms");
    y += 40.0;
    SVKeyButton* loopSel = [SVKeyButton keyWithFrame:NSMakeRect(12.0, y, 160.0, 34.0) title:@"ЛУП ОТ СЕЛЕКЦИЯТА" kind:0 target:self action:@selector(loopFromSelection:)];
    loopSel.textSize = 11.0; [cut addSubview:loopSel];
    SVKeyButton* trimSel = [SVKeyButton keyWithFrame:NSMakeRect(180.0, y, 168.0, 34.0) title:@"МАХНИ СЕЛЕКЦИЯТА" kind:0 target:self action:@selector(trimFromSelection:)];
    trimSel.textSize = 11.0; [cut addSubview:trimSel];
    y += 42.0;
    SVKeyButton* zero = [SVKeyButton keyWithFrame:NSMakeRect(12.0, y, 160.0, 34.0) title:@"НАЙ-БЛИЗКА НУЛА" kind:0 target:self action:@selector(snapZero:)];
    zero.textSize = 11.0; [cut addSubview:zero];
    [cut addSubview:[SVKeyButton keyWithFrame:NSMakeRect(180.0, y, 80.0, 34.0) title:@"ПРИЛОЖИ" kind:1 target:self action:@selector(applyCut:)]];
    _undoKey = [SVKeyButton keyWithFrame:NSMakeRect(268.0, y, 80.0, 34.0) title:@"ОТМЕНИ" kind:0 target:self action:@selector(undoPressed:)];
    [cut addSubview:_undoKey];

    // ---- SILVETON_CLEANWAVE_V1: ЧИСТА ВЪЛНА
    y += 38.0;
    [cut addSubview:SVLabel(NSMakeRect(12.0, y, 336.0, 16.0), @"ЧИСТА ВЪЛНА", 10.0, YES, SVColAmber())];
    y += 18.0;
    _penOn = [[SVToggle alloc] initWithFrame:NSMakeRect(12.0, y, 44.0, 22.0)];
    _penOn.target = self; _penOn.action = @selector(penToggled:);
    [cut addSubview:_penOn];
    [cut addSubview:SVLabel(NSMakeRect(62.0, y + 3.0, 80.0, 18.0), @"писалка", 11.0, NO, SVColText())];
    SVKeyButton* clearClean = [SVKeyButton keyWithFrame:NSMakeRect(146.0, y - 3.0, 86.0, 28.0) title:@"ИЗЧИСТИ" kind:0 target:self action:@selector(flatCurvePressed:)];
    clearClean.textSize = 10.0; [cut addSubview:clearClean];
    SVKeyButton* applyClean = [SVKeyButton keyWithFrame:NSMakeRect(240.0, y - 3.0, 108.0, 28.0) title:@"ПРИЛОЖИ" kind:1 target:self action:@selector(applyCurvePressed:)];
    applyClean.textSize = 10.0; [cut addSubview:applyClean];
    y += 30.0;
    _cleanKnob = [[SVKnob alloc] initWithFrame:NSMakeRect(12.0, y, 100.0, 84.0)];
    _cleanKnob.minimum = 0.0; _cleanKnob.maximum = 100.0; _cleanKnob.step = 1.0; _cleanKnob.label = @"ЧИСТО";
    _cleanKnob.format = ^NSString*(double v) { return [NSString stringWithFormat:@"%.0f %%", v]; };
    _cleanKnob.target = self; _cleanKnob.action = @selector(cleanAmountChanged:);
    [cut addSubview:_cleanKnob];
    _overtoneKnob = [[SVKnob alloc] initWithFrame:NSMakeRect(118.0, y, 100.0, 84.0)];
    _overtoneKnob.minimum = 1.0; _overtoneKnob.maximum = 12.0; _overtoneKnob.step = 1.0; _overtoneKnob.label = @"ТОЧНОСТ";
    _overtoneKnob.format = ^NSString*(double v) { return [NSString stringWithFormat:@"%.0f", v]; };
    _overtoneKnob.value = 1.0;
    _overtoneKnob.target = self; _overtoneKnob.action = @selector(cleanShapeChanged:);
    [cut addSubview:_overtoneKnob];
    _edgeKnob = [[SVKnob alloc] initWithFrame:NSMakeRect(224.0, y, 100.0, 84.0)];
    _edgeKnob.minimum = 0.0; _edgeKnob.maximum = 100.0; _edgeKnob.step = 1.0; _edgeKnob.label = @"РЪБОВЕ";
    _edgeKnob.format = ^NSString*(double v) { return [NSString stringWithFormat:@"%.0f %%", v]; };
    _edgeKnob.value = 100.0;
    _edgeKnob.target = self; _edgeKnob.action = @selector(cleanShapeChanged:);
    [cut addSubview:_edgeKnob];
    [self addSubview:cut];

    // ---- level & tune
    SVPanel* tone = [[SVPanel alloc] initWithFrame:NSMakeRect(rx + 376.0, ly, b.size.width - rx - 376.0 - 16.0, b.size.height - ly - 16.0) title:@"НИВО И ТОН"];
    tone.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    auto knob = [&](CGFloat x, CGFloat ky, NSString* label, double lo, double hi, double step, NSString* (^format)(double)) {
        SVKnob* k = [[SVKnob alloc] initWithFrame:NSMakeRect(x, ky, 100.0, 84.0)];
        k.minimum = lo; k.maximum = hi; k.step = step; k.label = label; k.format = format;
        [tone addSubview:k];
        return k;
    };
    _gain = knob(8.0, 40.0, @"УСИЛВАНЕ", -24.0, 24.0, 0.1, ^NSString*(double v) { return [NSString stringWithFormat:@"%+.1f dB", v]; });
    _normalize = knob(112.0, 40.0, @"НОРМАЛИЗ.", -24.0, 0.0, 0.5, ^NSString*(double v) { return [NSString stringWithFormat:@"%.1f dB", v]; });
    _normalizeOn = [[SVToggle alloc] initWithFrame:NSMakeRect(222.0, 52.0, 44.0, 22.0)];
    [tone addSubview:_normalizeOn];
    [tone addSubview:SVLabel(NSMakeRect(222.0, 78.0, 110.0, 16.0), @"нормализирай", 10.0, NO, SVColDim())];
    _root = knob(8.0, 132.0, @"ОСНОВЕН ТОН", 0.0, 127.0, 1.0, ^NSString*(double v) { return [NSString stringWithFormat:@"%@ / %.0f", SVNoteName(static_cast<NSInteger>(std::lround(v))), v]; });
    _fine = knob(112.0, 132.0, @"ФИНА", -100.0, 100.0, 1.0, ^NSString*(double v) { return [NSString stringWithFormat:@"%+.0f c", v]; });
    _gain.value = 0.0; _normalize.value = -6.0;
    [tone addSubview:[SVKeyButton keyWithFrame:NSMakeRect(222.0, 138.0, 112.0, 34.0) title:@"ОБЪРНИ" kind:0 target:self action:@selector(reversePressed:)]];
    [tone addSubview:[SVKeyButton keyWithFrame:NSMakeRect(222.0, 180.0, 112.0, 34.0) title:@"ПРИЛОЖИ" kind:1 target:self action:@selector(applyTone:)]];
    _peakLabel = SVLabel(NSMakeRect(12.0, 224.0, tone.bounds.size.width - 24.0, 32.0), @"", 11.0, NO, SVColDim());
    _peakLabel.autoresizingMask = NSViewWidthSizable;
    _peakLabel.lineBreakMode = NSLineBreakByWordWrapping;
    [_peakLabel.cell setWraps:YES];
    [tone addSubview:_peakLabel];
    // SILVETON_PITCH_V1: which note the recording is, read from the sound. Nothing changes until ПРИЕМИ ТОНА.
    [tone addSubview:SVLabel(NSMakeRect(12.0, 266.0, tone.bounds.size.width - 24.0, 16.0), @"КОЙ ТОН Е ЗАПИСЪТ (ОТ ЗВУКА)", 10.0, YES, SVColAmber())];
    _pitchLabel = SVLabel(NSMakeRect(12.0, 286.0, tone.bounds.size.width - 24.0, 34.0), @"Натисни РАЗПОЗНАЙ ТОНА.", 11.0, NO, SVColText());
    _pitchLabel.autoresizingMask = NSViewWidthSizable;
    _pitchLabel.lineBreakMode = NSLineBreakByWordWrapping;
    [_pitchLabel.cell setWraps:YES];
    [tone addSubview:_pitchLabel];
    SVKeyButton* detect = [SVKeyButton keyWithFrame:NSMakeRect(12.0, 326.0, 150.0, 34.0) title:@"РАЗПОЗНАЙ ТОНА" kind:0 target:self action:@selector(detectPressed:)];
    detect.textSize = 11.0; [tone addSubview:detect];
    _acceptKey = [SVKeyButton keyWithFrame:NSMakeRect(170.0, 326.0, 164.0, 34.0) title:@"ПРИЕМИ ТОНА" kind:1 target:self action:@selector(acceptPitchPressed:)];
    _acceptKey.textSize = 11.0; _acceptKey.enabled = NO; [tone addSubview:_acceptKey];
    [self addSubview:tone];
}

// ---------------------------------------------------------------- tree data

// a row is the same row after a rebuild when its kind and its number are the same
static NSString* SVNodeKey(SVTreeNode* node) {
    return [NSString stringWithFormat:@"%ld/%lu", static_cast<long>(node.kind), static_cast<unsigned long>(node.index)];
}

- (void)collectOpen:(NSMutableSet<NSString*>*)open from:(NSArray<SVTreeNode*>*)nodes {
    for (SVTreeNode* node in nodes) {
        if (node.children.count > 0U && [_tree isItemExpanded:node]) [open addObject:SVNodeKey(node)];
        [self collectOpen:open from:node.children];
    }
}
- (void)reopen:(NSSet<NSString*>*)open in:(NSArray<SVTreeNode*>*)nodes {
    for (SVTreeNode* node in nodes) {
        if (node.children.count > 0U && [open containsObject:SVNodeKey(node)]) [_tree expandItem:node];
        [self reopen:open in:node.children];
    }
}
- (SVTreeNode*)findNodeWithKey:(NSString*)key in:(NSArray<SVTreeNode*>*)nodes {
    for (SVTreeNode* node in nodes) {
        if ([SVNodeKey(node) isEqualToString:key]) return node;
        SVTreeNode* deeper = [self findNodeWithKey:key in:node.children];
        if (deeper != nil) return deeper;
    }
    return nil;
}

- (void)rebuildTree {
    // keep the rows that were open and the row that was picked: a rebuild must not fold the tree back up
    NSMutableSet<NSString*>* open = [NSMutableSet set];
    [self collectOpen:open from:_roots];
    const NSInteger pickedRow = _tree.selectedRow;
    NSString* pickedKey = pickedRow >= 0 ? SVNodeKey([_tree itemAtRow:pickedRow]) : nil;
    [_roots removeAllObjects];
    SVManagerDocument* doc = self.shell.documentModel;
    BankProject* project = SVProjectOf(doc);
    if (project == nullptr) { [_tree reloadData]; return; }
    std::set<std::size_t> used;
    static NSString* const layerNames[5] = {@"тих", @"среден", @"по-силен", @"силен", @"най-силен"};
    for (std::size_t si = 0U; si < project->sounds.size(); ++si) {
        const auto& sound = project->sounds[si];
        SVTreeNode* sn = [[SVTreeNode alloc] init];
        sn.kind = 0; sn.index = si;
        sn.title = SVNs(sound.name);
        std::size_t sampleCount = 0U;
        for (std::size_t li = 0U; li < sound.layers.size(); ++li) {
            const auto& layer = sound.layers[li];
            if (layer.multisampleIndex >= project->multisamples.size()) continue;
            const auto& ms = project->multisamples[layer.multisampleIndex];
            SVTreeNode* ln = [[SVTreeNode alloc] init];
            ln.kind = 1; ln.index = layer.multisampleIndex;
            NSString* nick = sound.layers.size() == 5U ? layerNames[li] : @"";
            ln.title = [NSString stringWithFormat:@"V%lu %@", static_cast<unsigned long>(li + 1U), nick];
            ln.detail = [NSString stringWithFormat:@"%lu семпла · сила %u–%u", static_cast<unsigned long>(ms.zones.size()), layer.velocityLow, layer.velocityHigh];
            std::vector<std::size_t> order;
            for (const auto& z : ms.zones) if (z.sampleIndex < project->samples.size()) order.push_back(z.sampleIndex);
            std::sort(order.begin(), order.end(), [&](std::size_t a, std::size_t c) { return project->samples[a].rootKey < project->samples[c].rootKey; });
            order.erase(std::unique(order.begin(), order.end()), order.end());
            for (std::size_t idx : order) {
                const auto& s = project->samples[idx];
                SVTreeNode* n = [[SVTreeNode alloc] init];
                n.kind = 2; n.index = idx; n.title = SVNs(s.name);
                n.detail = [NSString stringWithFormat:@"%@ · %@", SVNoteName(s.rootKey), SVSeconds(s.sampleRate ? static_cast<double>(s.totalFrames) / s.sampleRate : 0.0)];
                [ln.children addObject:n];
                used.insert(idx);
                ++sampleCount;
            }
            [sn.children addObject:ln];
        }
        sn.detail = [NSString stringWithFormat:@"%lu слоя · %lu семпла", static_cast<unsigned long>(sound.layers.size()), static_cast<unsigned long>(sampleCount)];
        [_roots addObject:sn];
    }
    SVTreeNode* loose = [[SVTreeNode alloc] init];
    loose.kind = 3; loose.title = @"Семпли без бленда";
    for (std::size_t i = 0U; i < project->samples.size(); ++i) {
        if (used.count(i) != 0U) continue;
        const auto& s = project->samples[i];
        SVTreeNode* n = [[SVTreeNode alloc] init];
        n.kind = 2; n.index = i; n.title = SVNs(s.name);
        n.detail = [NSString stringWithFormat:@"%@ · %@", SVNoteName(s.rootKey), SVSeconds(s.sampleRate ? static_cast<double>(s.totalFrames) / s.sampleRate : 0.0)];
        [loose.children addObject:n];
    }
    loose.detail = [NSString stringWithFormat:@"%lu семпла", static_cast<unsigned long>(loose.children.count)];
    if (loose.children.count > 0U) [_roots addObject:loose];
    [_tree reloadData];
    if (open.count > 0U) [self reopen:open in:_roots];
    if (pickedKey != nil) {
        SVTreeNode* again = [self findNodeWithKey:pickedKey in:_roots];
        if (again != nil) {
            const NSInteger row = [_tree rowForItem:again];
            if (row >= 0) [_tree selectRowIndexes:[NSIndexSet indexSetWithIndex:static_cast<NSUInteger>(row)] byExtendingSelection:NO];
        }
    }
}

- (NSInteger)outlineView:(NSOutlineView*)outlineView numberOfChildrenOfItem:(id)item {
    (void)outlineView;
    if (item == nil) return static_cast<NSInteger>(_roots.count);
    return static_cast<NSInteger>(((SVTreeNode*)item).children.count);
}
- (id)outlineView:(NSOutlineView*)outlineView child:(NSInteger)index ofItem:(id)item {
    (void)outlineView;
    NSArray* list = item == nil ? _roots : ((SVTreeNode*)item).children;
    return list[static_cast<NSUInteger>(index)];
}
- (BOOL)outlineView:(NSOutlineView*)outlineView isItemExpandable:(id)item {
    (void)outlineView;
    return ((SVTreeNode*)item).children.count > 0U;
}
- (id)outlineView:(NSOutlineView*)outlineView objectValueForTableColumn:(NSTableColumn*)tableColumn byItem:(id)item {
    (void)outlineView;
    SVTreeNode* node = item;
    return [tableColumn.identifier isEqualToString:@"name"] ? node.title : node.detail;
}
- (void)outlineView:(NSOutlineView*)outlineView willDisplayCell:(id)cell forTableColumn:(NSTableColumn*)tableColumn item:(id)item {
    (void)outlineView;
    SVTreeNode* node = item;
    if ([cell isKindOfClass:[NSTextFieldCell class]] && [tableColumn.identifier isEqualToString:@"name"]) {
        NSTextFieldCell* text = cell;
        text.textColor = node.kind == 2 ? SVColText() : node.kind == 1 ? SVColAmberLight() : SVColAmber();
        text.font = SVFont(13.0, node.kind != 2);
    }
}
- (void)outlineViewSelectionDidChange:(NSNotification*)notification {
    (void)notification;
    const NSInteger row = _tree.selectedRow;
    SVTreeNode* node = row >= 0 ? [_tree itemAtRow:row] : nil;
    if (node == nil || node.kind != 2) return;
    [self loadSample:node.index];
}

// ---------------------------------------------------------------- sample

- (void)loadSample:(NSUInteger)index {
    [self stopPressed:nil];
    SVManagerDocument* doc = self.shell.documentModel;
    NSDictionary* st = [doc sampleStateAtIndex:index];
    if (st == nil) {
        _sample = NSNotFound; _header.stringValue = @"Избери семпъл отляво."; _wave.points = @[]; _wave.totalFrames = 0U; [self resetCurve]; [_wave setNeedsDisplay:YES]; [self updateZoomHint];
        _pitch = nil; _pitchLabel.stringValue = @"Натисни РАЗПОЗНАЙ ТОНА."; _acceptKey.enabled = NO; [_acceptKey setNeedsDisplay:YES];
        return;
    }
    _sample = index;
    _rate = std::max(1.0, [st[@"sampleRate"] doubleValue]);
    _frames = [st[@"totalFrames"] unsignedLongLongValue];
    const BOOL stereo = [st[@"channels"] intValue] == 2;
    BankProject* project = SVProjectOf(doc);
    const unsigned bits = project != nullptr && index < project->samples.size() ? project->samples[index].bitsPerSample : 16U;
    _header.stringValue = [NSString stringWithFormat:@"%@   ·   %@ · %.0f Hz · %u бита · %@ · основен тон %@ (%d)", st[@"name"], stereo ? @"стерео" : @"моно", _rate, bits,
                           SVSeconds(static_cast<double>(_frames) / _rate), SVNoteName([st[@"rootKey"] intValue]), [st[@"rootKey"] intValue]];
    _wave.totalFrames = _frames;      // shows the whole sample again (no zoom)
    _wave.sampleRate = _rate;
    [self resetCurve];                // SILVETON_PITCHCURVE_V1: a new sample starts with a flat curve
    [self fetchWavePoints];
    _wave.loopEnabled = [st[@"loopEnabled"] boolValue];
    _wave.loopStart = [st[@"loopStart"] unsignedLongLongValue];
    _wave.loopEnd = [st[@"loopEnd"] unsignedLongLongValue];
    _wave.hasSelection = NO;
    _wave.playhead = -1;
    [_wave setNeedsDisplay:YES];
    _loopOn.on = _wave.loopEnabled;
    [self fillLoopFields];
    _xfadeOn.on = NO; _xfadeField.stringValue = [NSString stringWithFormat:@"%.0f", [st[@"crossfadeFrames"] doubleValue] / _rate * 1000.0];
    _trimOn.on = NO; _trimStartField.stringValue = @"0.000"; _trimEndField.stringValue = @"0.000";
    _fadeOn.on = NO; _fadeInField.stringValue = @"0"; _fadeOutField.stringValue = @"0";
    _gain.value = 0.0;
    _root.value = [st[@"rootKey"] doubleValue];
    _fine.value = [st[@"fineTuneCents"] doubleValue];
    _normalizeOn.on = NO;
    _peakLabel.stringValue = [NSString stringWithFormat:@"Пик: %.1f dB.  Всичко се прилага само с ПРИЛОЖИ. ОБЪРНИ обръща веднага.", [st[@"peakDb"] doubleValue]];
    _undoKey.enabled = [doc canUndoSampleEdit];
    [_undoKey setNeedsDisplay:YES];
    _pitch = nil;
    _pitchLabel.stringValue = @"Натисни РАЗПОЗНАЙ ТОНА.";
    _acceptKey.enabled = NO; [_acceptKey setNeedsDisplay:YES];
}

// ---------------------------------------------------------------- zoom (SILVETON_ZOOM_V1)

// The picture of exactly the frames that are on screen now (all of them, or the zoomed part).
- (void)fetchWavePoints {
    if (_sample == NSNotFound || _wave.totalFrames == 0U || _wave.viewLength == 0U) { _wave.points = @[]; [self updateZoomHint]; [_wave setNeedsDisplay:YES]; return; }
    NSString* error = nil;
    const NSUInteger columns = static_cast<NSUInteger>(std::max(100.0, _wave.bounds.size.width));
    NSArray<NSNumber*>* points = nil;
    if ([self cleanWanted]) {
        // SILVETON_CLEANWAVE_V1: show what it would become, before anything is applied
        points = [self.shell.documentModel cleanWavePreviewAtIndex:_sample
                                                            amount:[self cleanAmountArray]
                                                         overtones:static_cast<NSInteger>(std::lround(_overtoneKnob.value))
                                                             edges:static_cast<float>(_edgeKnob.value / 100.0)
                                                        startFrame:_wave.viewStart
                                                          endFrame:_wave.viewStart + _wave.viewLength
                                                        pointCount:columns
                                                             error:&error];
    }
    if (points == nil) points = [self.shell.documentModel waveformAtIndex:_sample startFrame:_wave.viewStart endFrame:_wave.viewStart + _wave.viewLength pointCount:columns error:&error];
    _wave.points = points ?: @[];
    [self updateZoomHint];
    [_wave setNeedsDisplay:YES];
}
- (void)updateZoomHint {
    if (_zoomHint == nil) return;
    if (_penOn.on) {
        _zoomHint.stringValue = @"ПИСАЛКА: влачи върху вълната — нагоре значи по-чисто на това място, долу значи остави го · ПРИЛОЖИ го записва";
        return;
    }
    if ([_wave isZoomed]) {
        const double t0 = static_cast<double>(_wave.viewStart) / _rate, t1 = static_cast<double>(_wave.viewStart + _wave.viewLength) / _rate;
        const double ratio = static_cast<double>(_wave.totalFrames) / static_cast<double>(std::max<uint64_t>(1U, _wave.viewLength));
        _zoomHint.stringValue = [NSString stringWithFormat:@"Показано %@ – %@ · ×%.1f · колелце = зуум · плъзгане встрани = местене · ЦЯЛО = всичко",
                                 SVSeconds(t0), SVSeconds(t1), ratio];
    } else {
        _zoomHint.stringValue = @"влачи във вълната за селекция · колелце на мишката или щипване = зуум · зелените линии са лупът";
    }
}
- (double)zoomCentre {
    if (_wave.hasSelection && _wave.selEnd > _wave.selStart) return (static_cast<double>(_wave.selStart) + static_cast<double>(_wave.selEnd)) / 2.0;
    return static_cast<double>(_wave.viewStart) + static_cast<double>(_wave.viewLength) / 2.0;
}
- (void)zoomInPressed:(id)sender { (void)sender; [_wave zoomByFactor:2.0 aroundFrame:[self zoomCentre]]; }
- (void)zoomOutPressed:(id)sender { (void)sender; [_wave zoomByFactor:0.5 aroundFrame:[self zoomCentre]]; }
- (void)zoomAllPressed:(id)sender { (void)sender; [_wave resetView]; }

// ---------------------------------------------------------------- the clean wave (SILVETON_CLEANWAVE_V1)

static const std::size_t kCurvePoints = 256U;

// how clean each place is, as the wave view shows it (0 at the middle line, 1 at the top)
- (void)showCurve {
    NSMutableArray<NSNumber*>* points = [NSMutableArray arrayWithCapacity:_curveRaw.size()];
    for (float v : _curveRaw) [points addObject:@(std::max(0.0F, std::min(1.0F, v)))];
    _wave.curve = points;
    [_wave setNeedsDisplay:YES];
}
- (void)curveDrawn {
    NSArray<NSNumber*>* drawn = _wave.curve;
    if (drawn.count != kCurvePoints) return;
    _curveRaw.resize(kCurvePoints);
    for (NSUInteger i = 0U; i < kCurvePoints; ++i) _curveRaw[i] = std::max(0.0F, std::min(1.0F, drawn[i].floatValue));
    [self fetchWavePoints];      // the wave shows what the sample would become, while the hand is still drawing
}
- (void)resetCurve {
    _curveRaw.assign(kCurvePoints, 0.0F);
    _cleanKnob.value = 0.0;
    [self showCurve];
}
- (BOOL)cleanWanted {
    for (float v : _curveRaw) if (v > 0.001F) return YES;
    return NO;
}
- (NSArray<NSNumber*>*)cleanAmountArray {
    NSMutableArray<NSNumber*>* points = [NSMutableArray arrayWithCapacity:_curveRaw.size()];
    for (float v : _curveRaw) [points addObject:@(std::max(0.0F, std::min(1.0F, v)))];
    return points;
}
- (void)penToggled:(id)sender {
    (void)sender;
    _wave.penMode = _penOn.on;
    [self updateZoomHint];
    [_wave setNeedsDisplay:YES];
}
// the big knob sets the whole sample at once; the pen then changes single places
- (void)cleanAmountChanged:(id)sender {
    (void)sender;
    _curveRaw.assign(kCurvePoints, static_cast<float>(_cleanKnob.value / 100.0));
    [self showCurve];
    [self fetchWavePoints];
}
- (void)cleanShapeChanged:(id)sender { (void)sender; [self fetchWavePoints]; }
- (void)flatCurvePressed:(id)sender { (void)sender; [self resetCurve]; [self fetchWavePoints]; }
- (void)applyCurvePressed:(id)sender {
    (void)sender;
    if (![self requireSampleForCurve]) return;
    if (![self cleanWanted]) { SVFlash(@"Чиста вълна", @"Завърти ЧИСТО или нарисувай с писалката къде да се изчисти.", YES); return; }
    [self stopPressed:nil];
    NSString* error = nil;
    if (![self.shell.documentModel cleanWaveForSampleAtIndex:_sample
                                                      amount:[self cleanAmountArray]
                                                   overtones:static_cast<NSInteger>(std::lround(_overtoneKnob.value))
                                                       edges:static_cast<float>(_edgeKnob.value / 100.0)
                                                       error:&error]) {
        SVAlert(self.window, @"Чиста вълна", error, YES);
        [self refresh];
        return;
    }
    [self resetCurve];
    [self.shell refreshAll];
    _peakLabel.stringValue = @"Вълната е изписана наново. ОТМЕНИ я връща.";
}
- (BOOL)requireSampleForCurve {
    if (_sample != NSNotFound) return YES;
    SVFlash(@"Чиста вълна", @"Първо избери семпъл отляво.", YES);
    return NO;
}

- (void)fillLoopFields {
    _loopStartField.stringValue = [NSString stringWithFormat:@"%.3f", static_cast<double>(_wave.loopStart) / _rate];
    _loopEndField.stringValue = [NSString stringWithFormat:@"%.3f", static_cast<double>(_wave.loopEnd) / _rate];
}

- (void)waveChanged {
    if (_sample == NSNotFound) return;
    [self fillLoopFields];
    if (_wave.hasSelection) {
        _trimStartField.stringValue = [NSString stringWithFormat:@"%.3f", static_cast<double>(_wave.selStart) / _rate];
        _trimEndField.stringValue = [NSString stringWithFormat:@"%.3f", static_cast<double>(_wave.selEnd) / _rate];
    }
}

- (void)selectSampleIndex:(NSUInteger)index {
    [self refresh];
    for (SVTreeNode* root in _roots) {
        for (SVTreeNode* child in root.children) {
            if (child.kind == 2 && child.index == index) { [_tree expandItem:root]; [self selectNode:child]; return; }
            for (SVTreeNode* leaf in child.children) if (leaf.kind == 2 && leaf.index == index) { [_tree expandItem:root]; [_tree expandItem:child]; [self selectNode:leaf]; return; }
        }
    }
}

- (void)selectNode:(SVTreeNode*)node {
    const NSInteger row = [_tree rowForItem:node];
    if (row >= 0) { [_tree selectRowIndexes:[NSIndexSet indexSetWithIndex:static_cast<NSUInteger>(row)] byExtendingSelection:NO]; [_tree scrollRowToVisible:row]; }
}

- (void)refresh {
    const NSUInteger keep = _sample;
    [self rebuildTree];
    if (keep != NSNotFound && keep < [self.shell.documentModel sampleCount]) [self loadSample:keep];
    else [self loadSample:NSNotFound];
}

- (void)pageWillHide { [self stopPressed:nil]; }

// ---------------------------------------------------------------- playback

- (void)playPressed:(id)sender { (void)sender; [self play:NO]; }
- (void)playLoopPressed:(id)sender { (void)sender; [self play:YES]; }
- (void)play:(BOOL)loopOnly {
    if (_sample == NSNotFound) return;
    [self stopPressed:nil];
    NSString* error = nil;
    NSDictionary* state = [self.shell.documentModel auditionStateAtIndex:_sample error:&error];
    if (state == nil) { SVAlert(self.window, @"Пускане", error, YES); return; }
    if (loopOnly && ![state[@"loopEnabled"] boolValue]) { SVFlash(@"Пускане", @"Този семпъл няма луп. Включи лупа и натисни ПРИЛОЖИ.", YES); return; }
    if (![self.shell.audition playState:state loopOnly:loopOnly error:&error]) { SVAlert(self.window, @"Пускане", error, YES); return; }
    _timer = [NSTimer scheduledTimerWithTimeInterval:1.0 / 30.0 target:self selector:@selector(tick:) userInfo:nil repeats:YES];
}
- (void)tick:(NSTimer*)timer {
    (void)timer;
    UInt64 frame = 0U;
    if ([self.shell.audition currentPlayFrame:&frame]) { _wave.playhead = static_cast<int64_t>(std::min<UInt64>(frame, _frames)); }
    else { _wave.playhead = -1; [_timer invalidate]; _timer = nil; }
    [_wave setNeedsDisplay:YES];
}
- (void)stopPressed:(id)sender {
    (void)sender;
    [self.shell.audition stop];
    [_timer invalidate]; _timer = nil;
    _wave.playhead = -1;
    [_wave setNeedsDisplay:YES];
}

// ---------------------------------------------------------------- edits

- (BOOL)requireSample {
    if (_sample != NSNotFound) return YES;
    SVFlash(@"Семпли", @"Първо избери семпъл отляво.", YES);
    return NO;
}
- (uint64_t)framesFromSeconds:(NSTextField*)field { return static_cast<uint64_t>(std::max(0.0, std::llround(field.doubleValue * _rate) * 1.0)); }
- (uint64_t)framesFromMs:(NSTextField*)field { return static_cast<uint64_t>(std::max(0.0, std::llround(field.doubleValue / 1000.0 * _rate) * 1.0)); }

// one press is enough here too: the loop is set and saved at once
- (void)loopFromSelection:(id)sender {
    (void)sender;
    if (![self requireSample]) return;
    if (!_wave.hasSelection || _wave.selEnd <= _wave.selStart) { SVFlash(@"Луп", @"Първо влачи във вълната, за да избереш част от семпъла.", YES); return; }
    _wave.loopEnabled = YES; _wave.loopStart = _wave.selStart; _wave.loopEnd = _wave.selEnd; _loopOn.on = YES;
    [self fillLoopFields];
    [_wave setNeedsDisplay:YES];
    NSString* error = nil;
    if (![self.shell.documentModel setLoopForSampleAtIndex:_sample enabled:YES startFrame:std::min(_wave.loopStart, _frames) endFrame:std::min(_wave.loopEnd, _frames) error:&error]) {
        SVAlert(self.window, @"Луп", error, YES);
        [self refresh];
        return;
    }
    [self.shell refreshAll];
    _peakLabel.stringValue = [NSString stringWithFormat:@"Лупът е сложен: %@ – %@.", SVSeconds(static_cast<double>(_wave.loopStart) / _rate), SVSeconds(static_cast<double>(_wave.loopEnd) / _rate)];
}
// SILVETON_CUT_V1: one press is enough - the marked part goes straight away, ОТМЕНИ brings it back
- (void)trimFromSelection:(id)sender {
    (void)sender;
    if (![self requireSample]) return;
    if (!_wave.hasSelection || _wave.selEnd <= _wave.selStart) { SVFlash(@"Рязане", @"Първо влачи във вълната, за да маркираш какво да се махне.", YES); return; }
    [self stopPressed:nil];
    const uint64_t from = std::min(_wave.selStart, _frames), to = std::min(_wave.selEnd, _frames);
    NSString* error = nil;
    if (![self.shell.documentModel cutOutSampleAtIndex:_sample startFrame:from endFrame:to error:&error]) {
        SVAlert(self.window, @"Рязане", error, YES);
        [self refresh];
        return;
    }
    _trimOn.on = NO;
    _trimStartField.stringValue = @"0.000";
    _trimEndField.stringValue = @"0.000";
    [self.shell refreshAll];
    _peakLabel.stringValue = [NSString stringWithFormat:@"Махнато: %@ – %@. ОТМЕНИ го връща.", SVSeconds(static_cast<double>(from) / _rate), SVSeconds(static_cast<double>(to) / _rate)];
}
- (void)snapZero:(id)sender {
    (void)sender;
    if (![self requireSample]) return;
    SVManagerDocument* doc = self.shell.documentModel;
    const uint64_t radius = static_cast<uint64_t>(_rate / 100.0);
    const uint64_t ls = [doc nearestZeroCrossingForSampleAtIndex:_sample frame:[self framesFromSeconds:_loopStartField] radius:radius];
    const uint64_t le = [doc nearestZeroCrossingForSampleAtIndex:_sample frame:[self framesFromSeconds:_loopEndField] radius:radius];
    _wave.loopStart = std::min(ls, _frames); _wave.loopEnd = std::min(std::max(le, ls + 1U), _frames);
    [self fillLoopFields];
    if (_trimOn.on) {
        const uint64_t ts = [doc nearestZeroCrossingForSampleAtIndex:_sample frame:[self framesFromSeconds:_trimStartField] radius:radius];
        const uint64_t te = [doc nearestZeroCrossingForSampleAtIndex:_sample frame:[self framesFromSeconds:_trimEndField] radius:radius];
        _trimStartField.stringValue = [NSString stringWithFormat:@"%.3f", static_cast<double>(ts) / _rate];
        _trimEndField.stringValue = [NSString stringWithFormat:@"%.3f", static_cast<double>(te) / _rate];
    }
    [_wave setNeedsDisplay:YES];
}

- (void)applyCut:(id)sender {
    (void)sender;
    if (![self requireSample]) return;
    [self stopPressed:nil];
    SVManagerDocument* doc = self.shell.documentModel;
    NSString* error = nil;
    NSMutableArray<NSString*>* done = [NSMutableArray array];
    // loop first (trim keeps a loop that lies inside the kept part)
    const uint64_t ls = [self framesFromSeconds:_loopStartField], le = [self framesFromSeconds:_loopEndField];
    if (![doc setLoopForSampleAtIndex:_sample enabled:_loopOn.on startFrame:std::min(ls, _frames) endFrame:std::min(le, _frames) error:&error]) { SVAlert(self.window, @"Луп", error, YES); [self refresh]; return; }
    [done addObject:_loopOn.on ? @"луп" : @"луп изключен"];
    if (_xfadeOn.on) {
        const uint64_t xf = [self framesFromMs:_xfadeField];
        if (xf > 0U && ![doc applyLoopCrossfadeForSampleAtIndex:_sample frames:static_cast<uint32_t>(std::min<uint64_t>(xf, 0xFFFFFFFFULL)) error:&error]) { SVAlert(self.window, @"Кросфейд", error, YES); [self refresh]; return; }
        if (xf > 0U) [done addObject:@"кросфейд"];
    }
    if (_fadeOn.on) {
        const uint64_t fi = [self framesFromMs:_fadeInField], fo = [self framesFromMs:_fadeOutField];
        if (fi > 0U && ![doc fadeInSampleAtIndex:_sample frames:fi error:&error]) { SVAlert(self.window, @"Fade in", error, YES); [self refresh]; return; }
        if (fo > 0U && ![doc fadeOutSampleAtIndex:_sample frames:fo error:&error]) { SVAlert(self.window, @"Fade out", error, YES); [self refresh]; return; }
        if (fi > 0U || fo > 0U) [done addObject:@"fade"];
    }
    if (_trimOn.on) {
        // SILVETON_CUT_V1: what is marked is thrown away, the rest is joined
        const uint64_t ts = [self framesFromSeconds:_trimStartField], te = std::min([self framesFromSeconds:_trimEndField], _frames);
        if (te > ts) {
            if (![doc cutOutSampleAtIndex:_sample startFrame:ts endFrame:te error:&error]) { SVAlert(self.window, @"Рязане", error, YES); [self refresh]; return; }
            [done addObject:@"махнато маркираното"];
        }
    }
    [self.shell refreshAll];
    _peakLabel.stringValue = [NSString stringWithFormat:@"Приложено: %@.", [done componentsJoinedByString:@", "]];
}

- (void)applyTone:(id)sender {
    (void)sender;
    if (![self requireSample]) return;
    [self stopPressed:nil];
    SVManagerDocument* doc = self.shell.documentModel;
    NSString* error = nil;
    NSMutableArray<NSString*>* done = [NSMutableArray array];
    if (std::fabs(_gain.value) >= 0.05) {
        if (![doc applyGainForSampleAtIndex:_sample gainDb:static_cast<float>(_gain.value) error:&error]) { SVAlert(self.window, @"Усилване", error, YES); [self refresh]; return; }
        [done addObject:[NSString stringWithFormat:@"усилване %+.1f dB", _gain.value]];
    }
    if (_normalizeOn.on) {
        if (![doc normalizeSampleAtIndex:_sample targetPeakDb:static_cast<float>(_normalize.value) error:&error]) { SVAlert(self.window, @"Нормализиране", error, YES); [self refresh]; return; }
        [done addObject:[NSString stringWithFormat:@"нормализирано до %.1f dB", _normalize.value]];
    }
    NSDictionary* st = [doc sampleStateAtIndex:_sample];
    const int root = static_cast<int>(std::lround(_root.value));
    const float fine = static_cast<float>(_fine.value);
    if (st != nil && (root != [st[@"rootKey"] intValue] || std::fabs(fine - [st[@"fineTuneCents"] floatValue]) > 0.01F)) {
        if (![doc setTuningForSampleAtIndex:_sample rootKey:static_cast<uint8_t>(std::clamp(root, 0, 127)) cents:fine error:&error]) { SVAlert(self.window, @"Тон", error, YES); [self refresh]; return; }
        [done addObject:@"основен тон / фина"];
    }
    [self.shell refreshAll];
    _peakLabel.stringValue = done.count == 0U ? @"Нищо за прилагане (всичко е на нула)." : [NSString stringWithFormat:@"Приложено: %@.", [done componentsJoinedByString:@", "]];
}

// ---------------------------------------------------------------- pitch (SILVETON_PITCH_V1)

- (void)detectPressed:(id)sender {
    (void)sender;
    if (![self requireSample]) return;
    SVManagerDocument* doc = self.shell.documentModel;
    NSDictionary* st = [doc sampleStateAtIndex:_sample];
    NSDictionary* r = [doc detectPitchForSampleAtIndex:_sample];
    _pitch = r;
    if (r == nil || st == nil) {
        _pitchLabel.stringValue = @"Не се разпознава ясен тон (шум, удар или много къс запис).";
        _acceptKey.enabled = NO; [_acceptKey setNeedsDisplay:YES];
        return;
    }
    const int midi = [r[@"midi"] intValue];
    const double cents = [r[@"cents"] doubleValue];
    const double conf = [r[@"confidence"] doubleValue] * 100.0;
    const int now = [st[@"rootKey"] intValue];
    NSString* same = midi == now ? @"Съвпада с основния тон." : [NSString stringWithFormat:@"Сега основният тон е %@ (%d).", SVNoteName(now), now];
    _pitchLabel.stringValue = [NSString stringWithFormat:@"Разпознат: %@ (%d), %+.0f c, %.1f Hz, сигурност %.0f %%.  %@", SVNoteName(midi), midi, cents, [r[@"hz"] doubleValue], conf, same];
    _acceptKey.enabled = YES; [_acceptKey setNeedsDisplay:YES];
}

// Sets the root key to the detected note and the fine tune against the detected offset (+4 c sharp -> fine -4 c).
- (void)acceptPitchPressed:(id)sender {
    (void)sender;
    if (![self requireSample]) return;
    if (_pitch == nil) { SVFlash(@"Тон", @"Първо натисни РАЗПОЗНАЙ ТОНА.", YES); return; }
    [self stopPressed:nil];
    const int midi = std::clamp([_pitch[@"midi"] intValue], 0, 127);
    const float fine = static_cast<float>(-std::lround([_pitch[@"cents"] doubleValue]));
    NSString* error = nil;
    if (![self.shell.documentModel setTuningForSampleAtIndex:_sample rootKey:static_cast<uint8_t>(midi) cents:fine error:&error]) { SVAlert(self.window, @"Тон", error, YES); [self refresh]; return; }
    [self.shell refreshAll];
    _pitchLabel.stringValue = [NSString stringWithFormat:@"Прието: основен тон %@ (%d), фина %+.0f c.", SVNoteName(midi), midi, static_cast<double>(fine)];
}

// SILVETON_AUTOMAP_V1: loose samples, no mapping file - hear every note and lay them over the keyboard
- (void)autoMapPressed:(id)sender {
    (void)sender;
    SVManagerDocument* doc = self.shell.documentModel;
    NSArray<NSNumber*>* loose = [doc looseSampleIndexes];
    if (loose.count == 0U) {
        SVFlash(@"Бленда от семплите", @"Всички семпли вече са в бленди по клавиши — тях не ги пипам. Тук влизат само неподредени семпли, например току-що внесени WAV файлове.", YES);
        return;
    }
    [self stopPressed:nil];
    NSArray<NSDictionary<NSString*, id>*>* rows = [doc autoMapPlanForSampleIndexes:loose];
    if (rows.count == 0U) { SVFlash(@"Бленда от семплите", @"Нищо не можа да се прочете от тези семпли.", YES); return; }
    NSString* name = nil;
    BOOL dropOld = YES;
    NSArray<NSDictionary<NSString*, id>*>* chosen = SVReviewAutoMap(self.window, doc, rows, &name, &dropOld);
    if (chosen == nil) return;                        // ОТКАЗ
    NSString* error = nil;
    NSUInteger created = 0U;
    NSUInteger removed = 0U;
    if (![doc buildAutoMapWithRows:chosen name:name removeOldSingles:dropOld createdIndex:&created removedOldCount:&removed error:&error]) {
        SVAlert(self.window, @"Бленда от семплите", error, YES);
        return;
    }
    [self.shell refreshAll];
    NSString* extra = removed > 0U
        ? [NSString stringWithFormat:@" Махнати са %lu стари бленди от по един семпъл; самите семпли си остават.", static_cast<unsigned long>(removed)]
        : @"";
    SVFlash(@"Бленда от семплите", [NSString stringWithFormat:@"Готово: бленда „%@“ от %lu семпъла.%@", name.length > 0U ? name : @"НОВА БЛЕНДА", static_cast<unsigned long>(chosen.count), extra], NO);
}

// SILVETON_ATTACK_V1: first show where it would cut on every sample that starts late, then cut the ticked ones
- (void)trimLateStartsPressed:(id)sender {
    (void)sender;
    SVManagerDocument* doc = self.shell.documentModel;
    if ([doc sampleCount] == 0U) { SVFlash(@"Начало на семплите", @"Няма семпли в проекта.", YES); return; }
    [self stopPressed:nil];
    NSArray<NSDictionary<NSString*, id>*>* rows = [doc lateStartReportWithPoints:420U];
    if (rows.count == 0U) {
        SVFlash(@"Начало на семплите", [NSString stringWithFormat:@"Проверени %lu семпъла. Всички започват веднага — няма какво да се реже.", static_cast<unsigned long>([doc sampleCount])], NO);
        return;
    }
    NSArray<NSDictionary<NSString*, id>*>* chosen = SVReviewLateStarts(self.window, rows);
    if (chosen == nil) return;                       // ОТКАЗ: nothing is touched
    if (chosen.count == 0U) { SVFlash(@"Начало на семплите", @"Нищо не е отметнато.", YES); return; }
    NSMutableArray<NSNumber*>* indexes = [NSMutableArray arrayWithCapacity:chosen.count];
    NSMutableArray<NSNumber*>* frames = [NSMutableArray arrayWithCapacity:chosen.count];
    for (NSDictionary<NSString*, id>* one in chosen) { [indexes addObject:one[@"index"]]; [frames addObject:one[@"startFrame"]]; }
    NSDictionary* report = [doc trimSampleStartsWithIndexes:indexes startFrames:frames];
    const NSUInteger trimmed = [report[@"trimmed"] unsignedIntegerValue];
    const double seconds = [report[@"secondsRemoved"] doubleValue];
    _sample = NSNotFound;
    [self.shell refreshAll];
    SVFlash(@"Начало на семплите", [NSString stringWithFormat:@"Отрязани %lu семпъла, махнати общо %@ тишина.", static_cast<unsigned long>(trimmed), SVSeconds(seconds)], NO);
}

- (void)detectAllPressed:(id)sender {
    (void)sender;
    [self stopPressed:nil];
    if ([self.shell.documentModel sampleCount] == 0U) { SVFlash(@"Тон", @"Няма семпли в проекта.", YES); return; }
    if (SVDetectPitchForAllSamples(self.shell.documentModel, self.window)) [self.shell refreshAll];
}

- (void)reversePressed:(id)sender {
    (void)sender;
    if (![self requireSample]) return;
    [self stopPressed:nil];
    NSString* error = nil;
    if (![self.shell.documentModel reverseSampleAtIndex:_sample error:&error]) { SVAlert(self.window, @"Обръщане", error, YES); return; }
    [self.shell refreshAll];
}

- (void)undoPressed:(id)sender {
    (void)sender;
    [self stopPressed:nil];
    NSString* error = nil;
    if (![self.shell.documentModel undoSampleEdit:&error]) { SVFlash(@"Отмяна", error ?: @"Няма какво да се отмени.", YES); return; }
    [self.shell refreshAll];
}

// ---------------------------------------------------------------- objects

// ПРЕИМЕНУВАЙ and КОПИРАЙ work on the row that is picked: a blend or a sample, the same as ИЗТРИЙ
- (void)renamePressed:(id)sender {
    (void)sender;
    SVTreeNode* node = [self selectedNode];
    if (node == nil || (node.kind != 0 && node.kind != 2)) { SVFlash(@"Преименуване", @"Избери бленда или семпъл отляво.", YES); return; }
    [self renameNode:node];
}
- (void)renameNode:(SVTreeNode*)node {
    const BOOL blend = node.kind == 0;
    NSString* now = blend ? node.title : [self.shell.documentModel sampleStateAtIndex:node.index][@"name"];
    NSString* name = SVAskText(self.window, blend ? @"Ново име на блендата" : @"Ново име на семпъла", @"", now);
    if (name.length == 0U) return;
    NSString* error = nil;
    if (![self.shell.documentModel renameObjectKind:(blend ? 2 : 0) index:node.index name:name error:&error]) { SVAlert(self.window, @"Преименуване", error, YES); return; }
    [self.shell refreshAll];
}
- (void)copyPressed:(id)sender {
    (void)sender;
    SVTreeNode* node = [self selectedNode];
    if (node == nil || (node.kind != 0 && node.kind != 2)) { SVFlash(@"Копиране", @"Избери бленда или семпъл отляво.", YES); return; }
    [self copyNode:node];
}
- (void)copyNode:(SVTreeNode*)node {
    const BOOL blend = node.kind == 0;
    NSString* error = nil;
    NSUInteger created = 0U;
    if (![self.shell.documentModel duplicateObjectKind:(blend ? 2 : 0) index:node.index createdIndex:&created error:&error]) { SVAlert(self.window, @"Копиране", error, YES); return; }
    [self.shell refreshAll];
    if (!blend) [self selectSampleIndex:created];
}
// ---------------------------------------------------------------- delete (SILVETON_DELETE_BLEND_V1)

- (SVTreeNode*)selectedNode {
    const NSInteger row = _tree.selectedRow;
    return row >= 0 ? [_tree itemAtRow:row] : nil;
}

// ИЗТРИЙ works on the row that is selected in the tree: a blend (top row) or a sample.
- (void)deletePressed:(id)sender {
    (void)sender;
    SVTreeNode* node = [self selectedNode];
    if (node == nil) { SVFlash(@"Изтриване", @"Първо избери бленда или семпъл отляво.", YES); return; }
    if (node.kind == 0) { [self deleteBlendNode:node]; return; }
    if (node.kind == 2) { [self deleteSampleAtIndex:node.index]; return; }
    SVFlash(@"Изтриване", @"Избери цялата бленда (най-горния ред) или един семпъл. Слой не се трие отделно.", YES);
}

// Right click on a row: the menu belongs to the row under the mouse, which is selected first.
- (NSMenu*)contextMenuForRow:(NSInteger)row {
    SVTreeNode* node = [_tree itemAtRow:row];
    if (node == nil || (node.kind != 0 && node.kind != 2)) return nil;
    [_tree selectRowIndexes:[NSIndexSet indexSetWithIndex:static_cast<NSUInteger>(row)] byExtendingSelection:NO];
    NSMenu* menu = [[NSMenu alloc] initWithTitle:@""];
    const BOOL blend = node.kind == 0;
    NSMenuItem* rename = [menu addItemWithTitle:blend ? @"Преименувай блендата…" : @"Преименувай семпъла…" action:@selector(renameFromMenu:) keyEquivalent:@""];
    rename.target = self; rename.representedObject = node;
    NSMenuItem* copy = [menu addItemWithTitle:blend ? @"Копирай блендата" : @"Копирай семпъла" action:@selector(copyFromMenu:) keyEquivalent:@""];
    copy.target = self; copy.representedObject = node;
    [menu addItem:[NSMenuItem separatorItem]];
    NSMenuItem* item = [menu addItemWithTitle:blend ? @"Изтрий блендата…" : @"Изтрий семпъла…" action:@selector(deleteFromMenu:) keyEquivalent:@""];
    item.target = self;
    item.representedObject = node;
    return menu;
}
- (void)renameFromMenu:(NSMenuItem*)item {
    SVTreeNode* node = item.representedObject;
    if (node != nil) [self renameNode:node];
}
- (void)copyFromMenu:(NSMenuItem*)item {
    SVTreeNode* node = item.representedObject;
    if (node != nil) [self copyNode:node];
}
- (void)deleteFromMenu:(NSMenuItem*)item {
    SVTreeNode* node = item.representedObject;
    if (node == nil) return;
    if (node.kind == 0) [self deleteBlendNode:node];
    else if (node.kind == 2) [self deleteSampleAtIndex:node.index];
}

- (void)deleteSampleAtIndex:(NSUInteger)index {
    NSDictionary* st = [self.shell.documentModel sampleStateAtIndex:index];
    if (st == nil) { SVFlash(@"Изтриване", @"Този семпъл вече го няма.", YES); return; }
    if (!SVConfirm(self.window, @"Изтриване на семпъл", [NSString stringWithFormat:@"„%@“ ще бъде махнат от проекта заедно със зоните, които го ползват. Сигурен ли си?", st[@"name"]], @"Изтрий")) return;
    [self stopPressed:nil];
    NSString* error = nil; NSString* summary = nil;
    if (![self.shell.documentModel deleteObjectKind:0 index:index summary:&summary error:&error]) { SVAlert(self.window, @"Изтриване", error, YES); return; }
    _sample = NSNotFound;
    [self.shell refreshAll];
}

// A whole blend: its layers and the samples only it uses go too. What another blend also uses stays.
- (void)deleteBlendNode:(SVTreeNode*)node {
    SVManagerDocument* doc = self.shell.documentModel;
    BankProject* project = SVProjectOf(doc);
    if (project == nullptr || node.index >= project->sounds.size()) { SVFlash(@"Изтриване", @"Тази бленда вече я няма.", YES); return; }
    DeleteImpact impact{};
    std::string why;
    if (!ObjectManager::soundContent(*project, node.index, impact, why)) { SVAlert(self.window, @"Изтриване", SVNs(why), YES); return; }
    NSString* text = [NSString stringWithFormat:@"Блендата „%@“ ще бъде махната от проекта заедно със своите %lu слоя и %lu семпла. Каквото ползва и друг звук, остава. Това не може да се върне. Сигурен ли си?",
                      node.title, static_cast<unsigned long>(impact.layersRemoved), static_cast<unsigned long>(impact.samplesRemoved)];
    if (!SVConfirm(self.window, @"Изтриване на бленда", text, @"Изтрий")) return;
    [self stopPressed:nil];
    NSString* error = nil; NSString* summary = nil;
    if (![doc deleteObjectKind:3 index:node.index summary:&summary error:&error]) { SVAlert(self.window, @"Изтриване", error, YES); return; }
    _sample = NSNotFound;     // sample numbers have moved
    [self.shell refreshAll];
}
@end
