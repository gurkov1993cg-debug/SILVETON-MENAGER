// SILVETON_LOOK_V1 - page 2 СЕМПЛИ: tree sound -> layers -> samples, waveform with loop, loop / trim / level / tune.
// Nothing changes until ПРИЛОЖИ is pressed.
#import "SVShell.h"
#import "SVDocument.h"
#import "SVTheme.h"

#include <algorithm>
#include <cmath>
#include <map>
#include <set>
#include <string>
#include <vector>

using silveton::manager::BankProject;

// ---------------------------------------------------------------- tree node

@interface SVTreeNode : NSObject
@property(nonatomic) NSInteger kind;          // 0 sound, 1 layer, 2 sample, 3 group of samples without a sound
@property(nonatomic) NSUInteger index;        // sound / multisample / sample index
@property(nonatomic, copy) NSString* title;
@property(nonatomic, copy) NSString* detail;
@property(nonatomic, strong) NSMutableArray<SVTreeNode*>* children;
@end
@implementation SVTreeNode
- (instancetype)init { self = [super init]; if (self) { _children = [NSMutableArray array]; _title = @""; _detail = @""; } return self; }
@end

// ---------------------------------------------------------------- waveform view

@interface SVWaveView : NSView
@property(nonatomic, copy) NSArray<NSNumber*>* points;      // min, max, min, max ...
@property(nonatomic) uint64_t totalFrames;
@property(nonatomic) double sampleRate;
@property(nonatomic) BOOL loopEnabled;
@property(nonatomic) uint64_t loopStart;
@property(nonatomic) uint64_t loopEnd;
@property(nonatomic) BOOL hasSelection;
@property(nonatomic) uint64_t selStart;
@property(nonatomic) uint64_t selEnd;
@property(nonatomic) int64_t playhead;                       // -1 = none
@property(nonatomic, copy) void (^onChange)(void);           // loop lines dragged or selection made
@end

@implementation SVWaveView {
    int _drag;          // 0 none, 1 loop start, 2 loop end, 3 selection
    uint64_t _dragAnchor;
}
- (instancetype)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) { _playhead = -1; _drag = 0; _sampleRate = 48000.0; }
    return self;
}
- (BOOL)isFlipped { return YES; }
- (CGFloat)xOfFrame:(uint64_t)frame {
    if (_totalFrames == 0U) return 0.0;
    return 1.0 + (self.bounds.size.width - 2.0) * static_cast<CGFloat>(static_cast<double>(frame) / static_cast<double>(_totalFrames));
}
- (uint64_t)frameOfX:(CGFloat)x {
    if (_totalFrames == 0U) return 0U;
    const double t = std::min(1.0, std::max(0.0, static_cast<double>((x - 1.0) / std::max(1.0, self.bounds.size.width - 2.0))));
    return static_cast<uint64_t>(std::llround(t * static_cast<double>(_totalFrames)));
}
- (void)drawRect:(NSRect)dirty {
    (void)dirty;
    const NSRect b = self.bounds;
    [SVColField() setFill];
    NSRectFill(b);
    if (_hasSelection && _selEnd > _selStart) {
        const CGFloat x0 = [self xOfFrame:_selStart], x1 = [self xOfFrame:_selEnd];
        [[SVColAmber() colorWithAlphaComponent:0.14] setFill];
        NSRectFillUsingOperation(NSMakeRect(x0, 0.0, std::max(1.0, x1 - x0), b.size.height), NSCompositingOperationSourceOver);
    }
    if (_loopEnabled && _loopEnd > _loopStart) {
        const CGFloat x0 = [self xOfFrame:_loopStart], x1 = [self xOfFrame:_loopEnd];
        [[SVColGreen() colorWithAlphaComponent:0.10] setFill];
        NSRectFillUsingOperation(NSMakeRect(x0, 0.0, std::max(1.0, x1 - x0), b.size.height), NSCompositingOperationSourceOver);
    }
    // middle line
    [[SVColBorder() colorWithAlphaComponent:0.8] setFill];
    NSRectFill(NSMakeRect(0.0, b.size.height / 2.0, b.size.width, 1.0));
    // wave
    const NSUInteger n = _points.count / 2U;
    if (n > 0U) {
        NSBezierPath* path = [NSBezierPath bezierPath];
        const CGFloat mid = b.size.height / 2.0;
        const CGFloat half = (b.size.height - 8.0) / 2.0;
        for (NSUInteger i = 0U; i < n; ++i) {
            const CGFloat x = 1.0 + (b.size.width - 2.0) * static_cast<CGFloat>(i) / static_cast<CGFloat>(std::max<NSUInteger>(1U, n - 1U));
            const double lo = _points[i * 2U].doubleValue, hi = _points[i * 2U + 1U].doubleValue;
            [path moveToPoint:NSMakePoint(x, mid - half * static_cast<CGFloat>(hi))];
            [path lineToPoint:NSMakePoint(x, mid - half * static_cast<CGFloat>(lo) + 1.0)];
        }
        path.lineWidth = 1.0;
        [SVColAmber() setStroke];
        [path stroke];
    }
    if (_loopEnabled && _loopEnd > _loopStart) {
        for (int k = 0; k < 2; ++k) {
            const CGFloat x = [self xOfFrame:k == 0 ? _loopStart : _loopEnd];
            [SVColGreen() setFill];
            NSRectFill(NSMakeRect(x - 1.0, 0.0, 2.0, b.size.height));
            NSString* text = k == 0 ? [NSString stringWithFormat:@"луп начало %@", SVSeconds(static_cast<double>(_loopStart) / _sampleRate)]
                                    : [NSString stringWithFormat:@"луп край %@", SVSeconds(static_cast<double>(_loopEnd) / _sampleRate)];
            NSDictionary* attrs = @{NSFontAttributeName: SVFont(11.0, NO), NSForegroundColorAttributeName: SVColGreen()};
            const NSSize size = [text sizeWithAttributes:attrs];
            [text drawAtPoint:NSMakePoint(k == 0 ? x + 4.0 : x - size.width - 4.0, 4.0) withAttributes:attrs];
        }
    }
    if (_hasSelection) {
        for (int k = 0; k < 2; ++k) {
            const CGFloat x = [self xOfFrame:k == 0 ? _selStart : _selEnd];
            [SVColAmberLight() setFill];
            NSRectFill(NSMakeRect(x - 0.5, 0.0, 1.0, b.size.height));
        }
    }
    if (_playhead >= 0) {
        const CGFloat x = [self xOfFrame:static_cast<uint64_t>(_playhead)];
        [SVColText() setFill];
        NSRectFill(NSMakeRect(x - 0.5, 0.0, 1.0, b.size.height));
    }
    [SVColBorder() setStroke];
    [[NSBezierPath bezierPathWithRoundedRect:NSInsetRect(b, 0.5, 0.5) xRadius:6.0 yRadius:6.0] stroke];
}
- (void)mouseDown:(NSEvent*)event {
    if (_totalFrames == 0U) return;
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    _drag = 3;
    if (_loopEnabled && _loopEnd > _loopStart) {
        if (std::fabs(p.x - [self xOfFrame:_loopStart]) <= 6.0) _drag = 1;
        else if (std::fabs(p.x - [self xOfFrame:_loopEnd]) <= 6.0) _drag = 2;
    }
    _dragAnchor = [self frameOfX:p.x];
    if (_drag == 3) { _hasSelection = YES; _selStart = _selEnd = _dragAnchor; [self setNeedsDisplay:YES]; }
}
- (void)mouseDragged:(NSEvent*)event {
    if (_totalFrames == 0U || _drag == 0) return;
    const NSPoint p = [self convertPoint:event.locationInWindow fromView:nil];
    const uint64_t f = [self frameOfX:p.x];
    if (_drag == 1) _loopStart = std::min(f, _loopEnd > 0U ? _loopEnd - 1U : 0U);
    else if (_drag == 2) _loopEnd = std::max(f, _loopStart + 1U);
    else { _selStart = std::min(_dragAnchor, f); _selEnd = std::max(_dragAnchor, f); }
    [self setNeedsDisplay:YES];
}
- (void)mouseUp:(NSEvent*)event {
    (void)event;
    if (_drag == 3 && _selEnd <= _selStart) _hasSelection = NO;
    _drag = 0;
    [self setNeedsDisplay:YES];
    if (_onChange != nil) _onChange();
}
@end

// ---------------------------------------------------------------- page

@interface SVSamplesPage : SVPageView <NSOutlineViewDataSource, NSOutlineViewDelegate>
- (void)selectSampleIndex:(NSUInteger)index;
@end

@implementation SVSamplesPage {
    NSOutlineView* _tree;
    NSMutableArray<SVTreeNode*>* _roots;
    NSUInteger _sample;            // NSNotFound = none
    NSTextField* _header;
    SVWaveView* _wave;
    NSTimer* _timer;
    // loop & cut
    SVToggle* _loopOn; NSTextField* _loopStartField; NSTextField* _loopEndField;
    SVToggle* _xfadeOn; NSTextField* _xfadeField;
    SVToggle* _trimOn; NSTextField* _trimStartField; NSTextField* _trimEndField;
    SVToggle* _fadeOn; NSTextField* _fadeInField; NSTextField* _fadeOutField;
    // level & tune
    SVKnob* _gain; SVKnob* _root; SVKnob* _fine; SVKnob* _normalize; SVToggle* _normalizeOn;
    NSTextField* _peakLabel;
    SVKeyButton* _undoKey;
    double _rate;
    uint64_t _frames;
}

- (instancetype)initWithShell:(SVShellWindowController*)shell frame:(NSRect)frame {
    self = [super initWithShell:shell frame:frame];
    if (self) { _sample = NSNotFound; _roots = [NSMutableArray array]; _rate = 48000.0; _frames = 0U; [self build]; }
    return self;
}

- (void)build {
    const NSRect b = self.bounds;
    // ---- tree
    SVPanel* left = [[SVPanel alloc] initWithFrame:NSMakeRect(16.0, 16.0, 360.0, b.size.height - 32.0) title:@"КАКВО ИМА В ПРОЕКТА"];
    left.autoresizingMask = NSViewHeightSizable;
    _tree = [[NSOutlineView alloc] initWithFrame:NSZeroRect];
    SVStyleTable(_tree);
    _tree.headerView = nil;
    _tree.dataSource = self;
    _tree.delegate = self;
    _tree.indentationPerLevel = 18.0;
    NSTableColumn* name = SVTextColumn(@"name", @"", 220.0);
    [_tree addTableColumn:name];
    _tree.outlineTableColumn = name;
    NSTableColumn* detail = SVTextColumn(@"detail", @"", 110.0);
    [(NSTextFieldCell*)detail.dataCell setTextColor:SVColDim()];
    [(NSTextFieldCell*)detail.dataCell setAlignment:NSTextAlignmentRight];
    [_tree addTableColumn:detail];
    NSScrollView* scroll = SVScroll(NSMakeRect(12.0, 32.0, 336.0, left.bounds.size.height - 32.0 - 56.0), _tree);
    scroll.autoresizingMask = NSViewHeightSizable;
    [left addSubview:scroll];
    const CGFloat by = left.bounds.size.height - 46.0;
    SVKeyButton* rename = [SVKeyButton keyWithFrame:NSMakeRect(12.0, by, 118.0, 34.0) title:@"ПРЕИМЕНУВАЙ" kind:0 target:self action:@selector(renamePressed:)];
    rename.textSize = 11.0; rename.autoresizingMask = NSViewMinYMargin; [left addSubview:rename];
    SVKeyButton* copy = [SVKeyButton keyWithFrame:NSMakeRect(136.0, by, 100.0, 34.0) title:@"КОПИРАЙ" kind:0 target:self action:@selector(copyPressed:)];
    copy.textSize = 11.0; copy.autoresizingMask = NSViewMinYMargin; [left addSubview:copy];
    SVKeyButton* del = [SVKeyButton keyWithFrame:NSMakeRect(242.0, by, 106.0, 34.0) title:@"ИЗТРИЙ" kind:2 target:self action:@selector(deletePressed:)];
    del.textSize = 11.0; del.autoresizingMask = NSViewMinYMargin; [left addSubview:del];
    [self addSubview:left];

    // ---- waveform
    const CGFloat rx = 392.0;
    SVPanel* top = [[SVPanel alloc] initWithFrame:NSMakeRect(rx, 16.0, b.size.width - rx - 16.0, 300.0) title:@""];
    top.autoresizingMask = NSViewWidthSizable;
    _header = SVLabel(NSMakeRect(12.0, 10.0, top.bounds.size.width - 24.0, 18.0), @"Избери семпъл отляво.", 12.0, YES, SVColAmber());
    _header.autoresizingMask = NSViewWidthSizable;
    [top addSubview:_header];
    _wave = [[SVWaveView alloc] initWithFrame:NSMakeRect(12.0, 34.0, top.bounds.size.width - 24.0, 212.0)];
    _wave.autoresizingMask = NSViewWidthSizable;
    __weak SVSamplesPage* weakSelf = self;
    _wave.onChange = ^{ [weakSelf waveChanged]; };
    [top addSubview:_wave];
    SVKeyButton* play = [SVKeyButton keyWithFrame:NSMakeRect(12.0, 254.0, 110.0, 34.0) title:@"▶ ПУСНИ" kind:1 target:self action:@selector(playPressed:)];
    [top addSubview:play];
    SVKeyButton* loop = [SVKeyButton keyWithFrame:NSMakeRect(130.0, 254.0, 130.0, 34.0) title:@"▶ САМО ЛУПА" kind:0 target:self action:@selector(playLoopPressed:)];
    [top addSubview:loop];
    SVKeyButton* stop = [SVKeyButton keyWithFrame:NSMakeRect(268.0, 254.0, 90.0, 34.0) title:@"■ СТОП" kind:0 target:self action:@selector(stopPressed:)];
    [top addSubview:stop];
    [top addSubview:SVLabel(NSMakeRect(370.0, 262.0, 420.0, 18.0), @"влачи във вълната за селекция, зелените линии са лупът", 11.0, NO, SVColDim())];
    [self addSubview:top];

    // ---- loop & cut
    const CGFloat ly = 332.0;
    SVPanel* cut = [[SVPanel alloc] initWithFrame:NSMakeRect(rx, ly, 420.0, b.size.height - ly - 16.0) title:@"ЛУП И РЯЗАНЕ"];
    cut.autoresizingMask = NSViewHeightSizable;
    CGFloat y = 36.0;
    auto row = [&](NSString* text) -> SVToggle* {
        SVToggle* t = [[SVToggle alloc] initWithFrame:NSMakeRect(12.0, y, 44.0, 22.0)];
        [cut addSubview:t];
        [cut addSubview:SVLabel(NSMakeRect(64.0, y + 2.0, 150.0, 18.0), text, 13.0, NO, SVColText())];
        return t;
    };
    auto field = [&](CGFloat x, CGFloat w) {
        NSTextField* f = SVField(NSMakeRect(x, y - 1.0, w, 24.0), @"");
        f.alignment = NSTextAlignmentRight;
        [cut addSubview:f];
        return f;
    };
    _loopOn = row(@"Луп"); _loopStartField = field(214.0, 80.0); [cut addSubview:SVLabel(NSMakeRect(298.0, y + 2.0, 14.0, 18.0), @"→", 12.0, NO, SVColDim())]; _loopEndField = field(314.0, 80.0);
    [cut addSubview:SVLabel(NSMakeRect(400.0, y + 3.0, 16.0, 16.0), @"s", 11.0, NO, SVColDim())];
    y += 34.0;
    _xfadeOn = row(@"Кросфейд на лупа"); _xfadeField = field(314.0, 80.0); [cut addSubview:SVLabel(NSMakeRect(400.0, y + 3.0, 18.0, 16.0), @"ms", 11.0, NO, SVColDim())];
    y += 34.0;
    _trimOn = row(@"Отрежи начало / край"); _trimStartField = field(214.0, 80.0); [cut addSubview:SVLabel(NSMakeRect(298.0, y + 2.0, 14.0, 18.0), @"→", 12.0, NO, SVColDim())]; _trimEndField = field(314.0, 80.0);
    [cut addSubview:SVLabel(NSMakeRect(400.0, y + 3.0, 16.0, 16.0), @"s", 11.0, NO, SVColDim())];
    y += 34.0;
    _fadeOn = row(@"Fade in / Fade out"); _fadeInField = field(214.0, 80.0); [cut addSubview:SVLabel(NSMakeRect(298.0, y + 2.0, 14.0, 18.0), @"/", 12.0, NO, SVColDim())]; _fadeOutField = field(314.0, 80.0);
    [cut addSubview:SVLabel(NSMakeRect(400.0, y + 3.0, 18.0, 16.0), @"ms", 11.0, NO, SVColDim())];
    y += 40.0;
    [cut addSubview:[SVKeyButton keyWithFrame:NSMakeRect(12.0, y, 150.0, 34.0) title:@"ЛУП ОТ СЕЛЕКЦИЯТА" kind:0 target:self action:@selector(loopFromSelection:)]];
    [cut addSubview:[SVKeyButton keyWithFrame:NSMakeRect(170.0, y, 160.0, 34.0) title:@"РЯЗАНЕ ОТ СЕЛЕКЦИЯТА" kind:0 target:self action:@selector(trimFromSelection:)]];
    y += 42.0;
    [cut addSubview:[SVKeyButton keyWithFrame:NSMakeRect(12.0, y, 150.0, 34.0) title:@"НАЙ-БЛИЗКА НУЛА" kind:0 target:self action:@selector(snapZero:)]];
    [cut addSubview:[SVKeyButton keyWithFrame:NSMakeRect(170.0, y, 110.0, 34.0) title:@"ПРИЛОЖИ" kind:1 target:self action:@selector(applyCut:)]];
    _undoKey = [SVKeyButton keyWithFrame:NSMakeRect(288.0, y, 110.0, 34.0) title:@"ОТМЕНИ" kind:0 target:self action:@selector(undoPressed:)];
    [cut addSubview:_undoKey];
    [self addSubview:cut];

    // ---- level & tune
    SVPanel* tone = [[SVPanel alloc] initWithFrame:NSMakeRect(rx + 436.0, ly, b.size.width - rx - 436.0 - 16.0, b.size.height - ly - 16.0) title:@"НИВО И ТОН"];
    tone.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    auto knob = [&](CGFloat x, NSString* label, double lo, double hi, double step, NSString* (^format)(double)) {
        SVKnob* k = [[SVKnob alloc] initWithFrame:NSMakeRect(x, 40.0, 96.0, 84.0)];
        k.minimum = lo; k.maximum = hi; k.step = step; k.label = label; k.format = format;
        [tone addSubview:k];
        return k;
    };
    _gain = knob(12.0, @"УСИЛВАНЕ", -24.0, 24.0, 0.1, ^NSString*(double v) { return [NSString stringWithFormat:@"%+.1f dB", v]; });
    _root = knob(110.0, @"ОСНОВЕН ТОН", 0.0, 127.0, 1.0, ^NSString*(double v) { return [NSString stringWithFormat:@"%@ / %.0f", SVNoteName(static_cast<NSInteger>(std::lround(v))), v]; });
    _fine = knob(208.0, @"ФИНА", -100.0, 100.0, 1.0, ^NSString*(double v) { return [NSString stringWithFormat:@"%+.0f c", v]; });
    _normalize = knob(306.0, @"НОРМАЛИЗ.", -24.0, 0.0, 0.5, ^NSString*(double v) { return [NSString stringWithFormat:@"%.1f dB", v]; });
    _normalizeOn = [[SVToggle alloc] initWithFrame:NSMakeRect(326.0, 128.0, 44.0, 22.0)];
    [tone addSubview:_normalizeOn];
    _gain.value = 0.0; _normalize.value = -6.0;
    [tone addSubview:[SVKeyButton keyWithFrame:NSMakeRect(12.0, 166.0, 100.0, 34.0) title:@"ОБЪРНИ" kind:0 target:self action:@selector(reversePressed:)]];
    [tone addSubview:[SVKeyButton keyWithFrame:NSMakeRect(120.0, 166.0, 110.0, 34.0) title:@"ПРИЛОЖИ" kind:1 target:self action:@selector(applyTone:)]];
    _peakLabel = SVLabel(NSMakeRect(12.0, 210.0, tone.bounds.size.width - 24.0, 36.0), @"", 11.0, NO, SVColDim());
    _peakLabel.autoresizingMask = NSViewWidthSizable;
    _peakLabel.lineBreakMode = NSLineBreakByWordWrapping;
    [_peakLabel.cell setWraps:YES];
    [tone addSubview:_peakLabel];
    [self addSubview:tone];
}

// ---------------------------------------------------------------- tree data

- (void)rebuildTree {
    [_roots removeAllObjects];
    SVManagerDocument* doc = self.shell.documentModel;
    BankProject* project = SVProjectOf(doc);
    if (project == nullptr) { [_tree reloadData]; return; }
    std::set<std::size_t> used;
    static NSString* const layerNames[5] = {@"тих", @"среден", @"по-силен", @"силен", @"най-силен"};
    for (std::size_t si = 0U; si < project->sounds.size(); ++si) {
        const auto& sound = project->sounds[si];
        SVTreeNode* sn = [[SVTreeNode alloc] init];
        sn.kind = 0; sn.index = si;
        sn.title = SVNs(sound.name);
        std::size_t sampleCount = 0U;
        for (std::size_t li = 0U; li < sound.layers.size(); ++li) {
            const auto& layer = sound.layers[li];
            if (layer.multisampleIndex >= project->multisamples.size()) continue;
            const auto& ms = project->multisamples[layer.multisampleIndex];
            SVTreeNode* ln = [[SVTreeNode alloc] init];
            ln.kind = 1; ln.index = layer.multisampleIndex;
            NSString* nick = sound.layers.size() == 5U ? layerNames[li] : @"";
            ln.title = [NSString stringWithFormat:@"V%lu %@", static_cast<unsigned long>(li + 1U), nick];
            ln.detail = [NSString stringWithFormat:@"%lu семпла · сила %u–%u", static_cast<unsigned long>(ms.zones.size()), layer.velocityLow, layer.velocityHigh];
            std::vector<std::size_t> order;
            for (const auto& z : ms.zones) if (z.sampleIndex < project->samples.size()) order.push_back(z.sampleIndex);
            std::sort(order.begin(), order.end(), [&](std::size_t a, std::size_t c) { return project->samples[a].rootKey < project->samples[c].rootKey; });
            order.erase(std::unique(order.begin(), order.end()), order.end());
            for (std::size_t idx : order) {
                const auto& s = project->samples[idx];
                SVTreeNode* n = [[SVTreeNode alloc] init];
                n.kind = 2; n.index = idx; n.title = SVNs(s.name);
                n.detail = [NSString stringWithFormat:@"%@ · %@", SVNoteName(s.rootKey), SVSeconds(s.sampleRate ? static_cast<double>(s.totalFrames) / s.sampleRate : 0.0)];
                [ln.children addObject:n];
                used.insert(idx);
                ++sampleCount;
            }
            [sn.children addObject:ln];
        }
        sn.detail = [NSString stringWithFormat:@"%lu слоя · %lu семпла", static_cast<unsigned long>(sound.layers.size()), static_cast<unsigned long>(sampleCount)];
        [_roots addObject:sn];
    }
    SVTreeNode* loose = [[SVTreeNode alloc] init];
    loose.kind = 3; loose.title = @"Семпли без бленда";
    for (std::size_t i = 0U; i < project->samples.size(); ++i) {
        if (used.count(i) != 0U) continue;
        const auto& s = project->samples[i];
        SVTreeNode* n = [[SVTreeNode alloc] init];
        n.kind = 2; n.index = i; n.title = SVNs(s.name);
        n.detail = [NSString stringWithFormat:@"%@ · %@", SVNoteName(s.rootKey), SVSeconds(s.sampleRate ? static_cast<double>(s.totalFrames) / s.sampleRate : 0.0)];
        [loose.children addObject:n];
    }
    loose.detail = [NSString stringWithFormat:@"%lu семпла", static_cast<unsigned long>(loose.children.count)];
    if (loose.children.count > 0U) [_roots addObject:loose];
    [_tree reloadData];
}

- (NSInteger)outlineView:(NSOutlineView*)outlineView numberOfChildrenOfItem:(id)item {
    (void)outlineView;
    if (item == nil) return static_cast<NSInteger>(_roots.count);
    return static_cast<NSInteger>(((SVTreeNode*)item).children.count);
}
- (id)outlineView:(NSOutlineView*)outlineView child:(NSInteger)index ofItem:(id)item {
    (void)outlineView;
    NSArray* list = item == nil ? _roots : ((SVTreeNode*)item).children;
    return list[static_cast<NSUInteger>(index)];
}
- (BOOL)outlineView:(NSOutlineView*)outlineView isItemExpandable:(id)item {
    (void)outlineView;
    return ((SVTreeNode*)item).children.count > 0U;
}
- (id)outlineView:(NSOutlineView*)outlineView objectValueForTableColumn:(NSTableColumn*)tableColumn byItem:(id)item {
    (void)outlineView;
    SVTreeNode* node = item;
    return [tableColumn.identifier isEqualToString:@"name"] ? node.title : node.detail;
}
- (void)outlineView:(NSOutlineView*)outlineView willDisplayCell:(id)cell forTableColumn:(NSTableColumn*)tableColumn item:(id)item {
    (void)outlineView;
    SVTreeNode* node = item;
    if ([cell isKindOfClass:[NSTextFieldCell class]] && [tableColumn.identifier isEqualToString:@"name"]) {
        NSTextFieldCell* text = cell;
        text.textColor = node.kind == 2 ? SVColText() : node.kind == 1 ? SVColAmberLight() : SVColAmber();
        text.font = SVFont(13.0, node.kind != 2);
    }
}
- (void)outlineViewSelectionDidChange:(NSNotification*)notification {
    (void)notification;
    const NSInteger row = _tree.selectedRow;
    SVTreeNode* node = row >= 0 ? [_tree itemAtRow:row] : nil;
    if (node == nil || node.kind != 2) return;
    [self loadSample:node.index];
}

// ---------------------------------------------------------------- sample

- (void)loadSample:(NSUInteger)index {
    [self stopPressed:nil];
    SVManagerDocument* doc = self.shell.documentModel;
    NSDictionary* st = [doc sampleStateAtIndex:index];
    if (st == nil) { _sample = NSNotFound; _header.stringValue = @"Избери семпъл отляво."; _wave.points = @[]; _wave.totalFrames = 0U; [_wave setNeedsDisplay:YES]; return; }
    _sample = index;
    _rate = std::max(1.0, [st[@"sampleRate"] doubleValue]);
    _frames = [st[@"totalFrames"] unsignedLongLongValue];
    const BOOL stereo = [st[@"channels"] intValue] == 2;
    BankProject* project = SVProjectOf(doc);
    const unsigned bits = project != nullptr && index < project->samples.size() ? project->samples[index].bitsPerSample : 16U;
    _header.stringValue = [NSString stringWithFormat:@"%@   ·   %@ · %.0f Hz · %u бита · %@ · основен тон %@ (%d)", st[@"name"], stereo ? @"стерео" : @"моно", _rate, bits,
                           SVSeconds(static_cast<double>(_frames) / _rate), SVNoteName([st[@"rootKey"] intValue]), [st[@"rootKey"] intValue]];
    NSString* error = nil;
    NSArray<NSNumber*>* points = [doc waveformAtIndex:index pointCount:static_cast<NSUInteger>(std::max(100.0, _wave.bounds.size.width)) error:&error];
    _wave.points = points ?: @[];
    _wave.totalFrames = _frames;
    _wave.sampleRate = _rate;
    _wave.loopEnabled = [st[@"loopEnabled"] boolValue];
    _wave.loopStart = [st[@"loopStart"] unsignedLongLongValue];
    _wave.loopEnd = [st[@"loopEnd"] unsignedLongLongValue];
    _wave.hasSelection = NO;
    _wave.playhead = -1;
    [_wave setNeedsDisplay:YES];
    _loopOn.on = _wave.loopEnabled;
    [self fillLoopFields];
    _xfadeOn.on = NO; _xfadeField.stringValue = [NSString stringWithFormat:@"%.0f", [st[@"crossfadeFrames"] doubleValue] / _rate * 1000.0];
    _trimOn.on = NO; _trimStartField.stringValue = @"0.000"; _trimEndField.stringValue = [NSString stringWithFormat:@"%.3f", static_cast<double>(_frames) / _rate];
    _fadeOn.on = NO; _fadeInField.stringValue = @"0"; _fadeOutField.stringValue = @"0";
    _gain.value = 0.0;
    _root.value = [st[@"rootKey"] doubleValue];
    _fine.value = [st[@"fineTuneCents"] doubleValue];
    _normalizeOn.on = NO;
    _peakLabel.stringValue = [NSString stringWithFormat:@"Пик: %.1f dB.  Всичко се прилага само с ПРИЛОЖИ. ОБЪРНИ обръща веднага.", [st[@"peakDb"] doubleValue]];
    _undoKey.enabled = [doc canUndoSampleEdit];
    [_undoKey setNeedsDisplay:YES];
}

- (void)fillLoopFields {
    _loopStartField.stringValue = [NSString stringWithFormat:@"%.3f", static_cast<double>(_wave.loopStart) / _rate];
    _loopEndField.stringValue = [NSString stringWithFormat:@"%.3f", static_cast<double>(_wave.loopEnd) / _rate];
}

- (void)waveChanged {
    if (_sample == NSNotFound) return;
    [self fillLoopFields];
    if (_wave.hasSelection) {
        _trimStartField.stringValue = [NSString stringWithFormat:@"%.3f", static_cast<double>(_wave.selStart) / _rate];
        _trimEndField.stringValue = [NSString stringWithFormat:@"%.3f", static_cast<double>(_wave.selEnd) / _rate];
    }
}

- (void)selectSampleIndex:(NSUInteger)index {
    [self refresh];
    for (SVTreeNode* root in _roots) {
        for (SVTreeNode* child in root.children) {
            if (child.kind == 2 && child.index == index) { [_tree expandItem:root]; [self selectNode:child]; return; }
            for (SVTreeNode* leaf in child.children) if (leaf.kind == 2 && leaf.index == index) { [_tree expandItem:root]; [_tree expandItem:child]; [self selectNode:leaf]; return; }
        }
    }
}

- (void)selectNode:(SVTreeNode*)node {
    const NSInteger row = [_tree rowForItem:node];
    if (row >= 0) { [_tree selectRowIndexes:[NSIndexSet indexSetWithIndex:static_cast<NSUInteger>(row)] byExtendingSelection:NO]; [_tree scrollRowToVisible:row]; }
}

- (void)refresh {
    const NSUInteger keep = _sample;
    [self rebuildTree];
    if (keep != NSNotFound && keep < [self.shell.documentModel sampleCount]) [self loadSample:keep];
    else [self loadSample:NSNotFound];
}

- (void)pageWillHide { [self stopPressed:nil]; }

// ---------------------------------------------------------------- playback

- (void)playPressed:(id)sender { (void)sender; [self play:NO]; }
- (void)playLoopPressed:(id)sender { (void)sender; [self play:YES]; }
- (void)play:(BOOL)loopOnly {
    if (_sample == NSNotFound) return;
    [self stopPressed:nil];
    NSString* error = nil;
    NSDictionary* state = [self.shell.documentModel auditionStateAtIndex:_sample error:&error];
    if (state == nil) { SVAlert(self.window, @"Пускане", error, YES); return; }
    if (loopOnly && ![state[@"loopEnabled"] boolValue]) { SVAlert(self.window, @"Пускане", @"Този семпъл няма луп. Включи лупа и натисни ПРИЛОЖИ.", NO); return; }
    if (![self.shell.audition playState:state loopOnly:loopOnly error:&error]) { SVAlert(self.window, @"Пускане", error, YES); return; }
    _timer = [NSTimer scheduledTimerWithTimeInterval:1.0 / 30.0 target:self selector:@selector(tick:) userInfo:nil repeats:YES];
}
- (void)tick:(NSTimer*)timer {
    (void)timer;
    UInt64 frame = 0U;
    if ([self.shell.audition currentPlayFrame:&frame]) { _wave.playhead = static_cast<int64_t>(std::min<UInt64>(frame, _frames)); }
    else { _wave.playhead = -1; [_timer invalidate]; _timer = nil; }
    [_wave setNeedsDisplay:YES];
}
- (void)stopPressed:(id)sender {
    (void)sender;
    [self.shell.audition stop];
    [_timer invalidate]; _timer = nil;
    _wave.playhead = -1;
    [_wave setNeedsDisplay:YES];
}

// ---------------------------------------------------------------- edits

- (BOOL)requireSample {
    if (_sample != NSNotFound) return YES;
    SVAlert(self.window, @"Семпли", @"Първо избери семпъл отляво.", NO);
    return NO;
}
- (uint64_t)framesFromSeconds:(NSTextField*)field { return static_cast<uint64_t>(std::max(0.0, std::llround(field.doubleValue * _rate) * 1.0)); }
- (uint64_t)framesFromMs:(NSTextField*)field { return static_cast<uint64_t>(std::max(0.0, std::llround(field.doubleValue / 1000.0 * _rate) * 1.0)); }

- (void)loopFromSelection:(id)sender {
    (void)sender;
    if (![self requireSample]) return;
    if (!_wave.hasSelection || _wave.selEnd <= _wave.selStart) { SVAlert(self.window, @"Луп", @"Първо влачи във вълната, за да избереш част от семпъла.", NO); return; }
    _wave.loopEnabled = YES; _wave.loopStart = _wave.selStart; _wave.loopEnd = _wave.selEnd; _loopOn.on = YES;
    [self fillLoopFields];
    [_wave setNeedsDisplay:YES];
}
- (void)trimFromSelection:(id)sender {
    (void)sender;
    if (![self requireSample]) return;
    if (!_wave.hasSelection || _wave.selEnd <= _wave.selStart) { SVAlert(self.window, @"Рязане", @"Първо влачи във вълната, за да избереш какво да остане.", NO); return; }
    _trimOn.on = YES;
    _trimStartField.stringValue = [NSString stringWithFormat:@"%.3f", static_cast<double>(_wave.selStart) / _rate];
    _trimEndField.stringValue = [NSString stringWithFormat:@"%.3f", static_cast<double>(_wave.selEnd) / _rate];
}
- (void)snapZero:(id)sender {
    (void)sender;
    if (![self requireSample]) return;
    SVManagerDocument* doc = self.shell.documentModel;
    const uint64_t radius = static_cast<uint64_t>(_rate / 100.0);
    const uint64_t ls = [doc nearestZeroCrossingForSampleAtIndex:_sample frame:[self framesFromSeconds:_loopStartField] radius:radius];
    const uint64_t le = [doc nearestZeroCrossingForSampleAtIndex:_sample frame:[self framesFromSeconds:_loopEndField] radius:radius];
    _wave.loopStart = std::min(ls, _frames); _wave.loopEnd = std::min(std::max(le, ls + 1U), _frames);
    [self fillLoopFields];
    if (_trimOn.on) {
        const uint64_t ts = [doc nearestZeroCrossingForSampleAtIndex:_sample frame:[self framesFromSeconds:_trimStartField] radius:radius];
        const uint64_t te = [doc nearestZeroCrossingForSampleAtIndex:_sample frame:[self framesFromSeconds:_trimEndField] radius:radius];
        _trimStartField.stringValue = [NSString stringWithFormat:@"%.3f", static_cast<double>(ts) / _rate];
        _trimEndField.stringValue = [NSString stringWithFormat:@"%.3f", static_cast<double>(te) / _rate];
    }
    [_wave setNeedsDisplay:YES];
}

- (void)applyCut:(id)sender {
    (void)sender;
    if (![self requireSample]) return;
    [self stopPressed:nil];
    SVManagerDocument* doc = self.shell.documentModel;
    NSString* error = nil;
    NSMutableArray<NSString*>* done = [NSMutableArray array];
    // loop first (trim keeps a loop that lies inside the kept part)
    const uint64_t ls = [self framesFromSeconds:_loopStartField], le = [self framesFromSeconds:_loopEndField];
    if (![doc setLoopForSampleAtIndex:_sample enabled:_loopOn.on startFrame:std::min(ls, _frames) endFrame:std::min(le, _frames) error:&error]) { SVAlert(self.window, @"Луп", error, YES); [self refresh]; return; }
    [done addObject:_loopOn.on ? @"луп" : @"луп изключен"];
    if (_xfadeOn.on) {
        const uint64_t xf = [self framesFromMs:_xfadeField];
        if (xf > 0U && ![doc applyLoopCrossfadeForSampleAtIndex:_sample frames:static_cast<uint32_t>(std::min<uint64_t>(xf, 0xFFFFFFFFULL)) error:&error]) { SVAlert(self.window, @"Кросфейд", error, YES); [self refresh]; return; }
        if (xf > 0U) [done addObject:@"кросфейд"];
    }
    if (_fadeOn.on) {
        const uint64_t fi = [self framesFromMs:_fadeInField], fo = [self framesFromMs:_fadeOutField];
        if (fi > 0U && ![doc fadeInSampleAtIndex:_sample frames:fi error:&error]) { SVAlert(self.window, @"Fade in", error, YES); [self refresh]; return; }
        if (fo > 0U && ![doc fadeOutSampleAtIndex:_sample frames:fo error:&error]) { SVAlert(self.window, @"Fade out", error, YES); [self refresh]; return; }
        if (fi > 0U || fo > 0U) [done addObject:@"fade"];
    }
    if (_trimOn.on) {
        const uint64_t ts = [self framesFromSeconds:_trimStartField], te = std::min([self framesFromSeconds:_trimEndField], _frames);
        if (ts > 0U || te < _frames) {
            if (![doc trimSampleAtIndex:_sample startFrame:ts endFrame:te error:&error]) { SVAlert(self.window, @"Рязане", error, YES); [self refresh]; return; }
            [done addObject:@"рязане"];
        }
    }
    [self.shell refreshAll];
    _peakLabel.stringValue = [NSString stringWithFormat:@"Приложено: %@.", [done componentsJoinedByString:@", "]];
}

- (void)applyTone:(id)sender {
    (void)sender;
    if (![self requireSample]) return;
    [self stopPressed:nil];
    SVManagerDocument* doc = self.shell.documentModel;
    NSString* error = nil;
    NSMutableArray<NSString*>* done = [NSMutableArray array];
    if (std::fabs(_gain.value) >= 0.05) {
        if (![doc applyGainForSampleAtIndex:_sample gainDb:static_cast<float>(_gain.value) error:&error]) { SVAlert(self.window, @"Усилване", error, YES); [self refresh]; return; }
        [done addObject:[NSString stringWithFormat:@"усилване %+.1f dB", _gain.value]];
    }
    if (_normalizeOn.on) {
        if (![doc normalizeSampleAtIndex:_sample targetPeakDb:static_cast<float>(_normalize.value) error:&error]) { SVAlert(self.window, @"Нормализиране", error, YES); [self refresh]; return; }
        [done addObject:[NSString stringWithFormat:@"нормализирано до %.1f dB", _normalize.value]];
    }
    NSDictionary* st = [doc sampleStateAtIndex:_sample];
    const int root = static_cast<int>(std::lround(_root.value));
    const float fine = static_cast<float>(_fine.value);
    if (st != nil && (root != [st[@"rootKey"] intValue] || std::fabs(fine - [st[@"fineTuneCents"] floatValue]) > 0.01F)) {
        if (![doc setTuningForSampleAtIndex:_sample rootKey:static_cast<uint8_t>(std::clamp(root, 0, 127)) cents:fine error:&error]) { SVAlert(self.window, @"Тон", error, YES); [self refresh]; return; }
        [done addObject:@"основен тон / фина"];
    }
    [self.shell refreshAll];
    _peakLabel.stringValue = done.count == 0U ? @"Нищо за прилагане (всичко е на нула)." : [NSString stringWithFormat:@"Приложено: %@.", [done componentsJoinedByString:@", "]];
}

- (void)reversePressed:(id)sender {
    (void)sender;
    if (![self requireSample]) return;
    [self stopPressed:nil];
    NSString* error = nil;
    if (![self.shell.documentModel reverseSampleAtIndex:_sample error:&error]) { SVAlert(self.window, @"Обръщане", error, YES); return; }
    [self.shell refreshAll];
}

- (void)undoPressed:(id)sender {
    (void)sender;
    [self stopPressed:nil];
    NSString* error = nil;
    if (![self.shell.documentModel undoSampleEdit:&error]) { SVAlert(self.window, @"Отмяна", error ?: @"Няма какво да се отмени.", NO); return; }
    [self.shell refreshAll];
}

// ---------------------------------------------------------------- objects

- (void)renamePressed:(id)sender {
    (void)sender;
    if (![self requireSample]) return;
    NSDictionary* st = [self.shell.documentModel sampleStateAtIndex:_sample];
    NSString* name = SVAskText(self.window, @"Ново име на семпъла", @"", st[@"name"]);
    if (name.length == 0U) return;
    NSString* error = nil;
    if (![self.shell.documentModel renameObjectKind:0 index:_sample name:name error:&error]) { SVAlert(self.window, @"Преименуване", error, YES); return; }
    [self.shell refreshAll];
}
- (void)copyPressed:(id)sender {
    (void)sender;
    if (![self requireSample]) return;
    NSString* error = nil;
    NSUInteger created = 0U;
    if (![self.shell.documentModel duplicateObjectKind:0 index:_sample createdIndex:&created error:&error]) { SVAlert(self.window, @"Копиране", error, YES); return; }
    [self.shell refreshAll];
    [self selectSampleIndex:created];
}
- (void)deletePressed:(id)sender {
    (void)sender;
    if (![self requireSample]) return;
    NSDictionary* st = [self.shell.documentModel sampleStateAtIndex:_sample];
    if (!SVConfirm(self.window, @"Изтриване на семпъл", [NSString stringWithFormat:@"„%@“ ще бъде махнат от проекта заедно със зоните, които го ползват. Сигурен ли си?", st[@"name"]], @"Изтрий")) return;
    [self stopPressed:nil];
    NSString* error = nil; NSString* summary = nil;
    if (![self.shell.documentModel deleteObjectKind:0 index:_sample summary:&summary error:&error]) { SVAlert(self.window, @"Изтриване", error, YES); return; }
    _sample = NSNotFound;
    [self.shell refreshAll];
}
@end
