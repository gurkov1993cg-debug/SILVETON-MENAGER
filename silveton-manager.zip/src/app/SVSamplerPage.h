// SILVETON_MERGE_V1 - page 5 СЕМПЛЕР: the SILVETON SAMPLER (the same program as on the tablet and the Mac sampler) inside the Manager.
// The sampler runs from the start of the program to its end (sound, MIDI keyboard); the page only shows its screens.
#pragma once
#import "SVShell.h"

#ifdef __cplusplus
#include <set>
#include <string>
#include <utility>
#include <vector>
#endif

@interface SVSamplerPage : SVPageView
@end

@interface SVSamplerHost : NSObject
+ (SVSamplerHost*)shared;                  // one for the whole program
- (void)start;                              // sound, MIDI and screens start (when the program starts)
- (void)stop;                               // the end of the program
- (NSView*)pictureView;                     // the screens of the sampler
// The Manager has written a bank: the sampler plays it from now on (the blends find their sounds by name).
- (void)useBankFile:(NSString*)path;
// Menu Семплер > Избери банка… (another SILVETON_BANK.sv for the sampler)
- (void)chooseBank:(id)sender;
#ifdef __cplusplus
// SILVETON_UNUSED_SOUNDS_V1: which of `sounds` (position 1..500, name) a blend uses - the blends of the LIST next to the sampler's bank,
// every saved set, the COMBI that is open now and the TRANSWAVE frames. NO = something could not be read or there are no blends at all:
// then nothing may be deleted (`why` says what).
- (BOOL)usedSoundPositions:(const std::vector<std::pair<int, std::string>>&)sounds used:(std::set<int>&)used why:(std::string&)why;
#endif
@end
