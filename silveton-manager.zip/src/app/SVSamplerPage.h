// SILVETON_MERGE_V1 - page 5 СЕМПЛЕР: the SILVETON SAMPLER (the same program as on the tablet and the Mac sampler) inside the Manager.
// The sampler runs from the start of the program to its end (sound, MIDI keyboard); the page only shows its screens.
#pragma once
#import "SVShell.h"

#ifdef __cplusplus
#include "silveton/manager/SoundTransfer.h"

#include <set>
#include <string>
#include <utility>
#include <vector>
#endif

@interface SVSamplerPage : SVPageView
@end

@interface SVSamplerHost : NSObject
+ (SVSamplerHost*)shared;                  // one for the whole program
- (void)start;                              // sound, MIDI and screens start (when the program starts)
- (void)stop;                               // the end of the program
- (NSView*)pictureView;                     // the screens of the sampler
// The Manager has written a bank: the sampler plays it from now on (the blends find their sounds by name).
- (void)useBankFile:(NSString*)path;
// Menu Семплер > Избери банка… (another SILVETON_BANK.sv for the sampler)
- (void)chooseBank:(id)sender;
#ifdef __cplusplus
// SILVETON_UNUSED_SOUNDS_V1: which of `sounds` (position 1..500, name) a blend uses - the blends of the LIST next to the sampler's bank,
// every saved set, the COMBI that is open now and the TRANSWAVE frames. NO = something could not be read or there are no blends at all:
// then nothing may be deleted (`why` says what).
- (BOOL)usedSoundPositions:(const std::vector<std::pair<int, std::string>>&)sounds used:(std::set<int>&)used why:(std::string&)why;
#endif

// ---- SILVETON_SEND_V1: SOUNDs of the Manager go straight into the sampler's list; the bank on the disk is written only at the end.
// The sent SOUNDs are small bank files in sendFolder; the sampler takes them in every time it loads its bank (also after a restart).
// SILVETON_PASTE_V1: ЗВУЦИ > right button > Копирай keeps the names here; on СЕМПЛЕР > ЛИСТ the right button on a position offers
// ПОСТАВИ (pasteHandler is called with that position; the page does the work). Cleared after a paste.
@property(nonatomic, copy) NSArray<NSString*>* copiedSounds;
@property(nonatomic, copy) void (^pasteHandler)(NSInteger position);
- (void)runPasteAt:(NSNumber*)position;     // calls pasteHandler (from a run loop timer, never from inside a main-queue block)
- (NSString*)sendFolder;                    // Application Support/SILVETON SAMPLER/ПРАТЕНИ
- (NSString*)currentBankPath;               // the bank the sampler plays (nil = none yet)
- (NSString*)defaultBankPath;               // Documents/SILVETON/SILVETON_BANK.sv
- (NSString*)nextSendFilePath;
- (NSUInteger)sentFileCount;
#ifdef __cplusplus
- (std::vector<std::pair<int, std::string>>)samplerSounds;            // place 1..500 + name of every SOUND in the sampler now
- (std::vector<silveton::manager::SentSound>)sentSounds;               // which Manager SOUND is at which place of the sampler
- (std::vector<std::string>)sentFilePaths;
- (std::set<int>)droppedPlaces;                                        // sent SOUNDs deleted in the Manager: they stay out of the bank
- (std::set<int>)removedPlaces;   // SILVETON_LIST_DELETE_SOUNDS_V1: SOUNDs that left the sampler with a blend deleted from the LIST
// The file is written: the sampler takes it in. asBank = the sampler had no bank: the file is its bank from now on.
- (void)takeSentFile:(NSString*)path asBank:(BOOL)asBank plan:(const std::vector<silveton::manager::SentSound>&)plan done:(void (^)(NSString* error))done;
- (void)dropSentManagerNames:(const std::set<std::string>&)names;      // ИЗТРИЙ НЕИЗПОЛЗВАНИТЕ ЗВУЦИ deleted them in the Manager
// SILVETON_PASTE_V1: the sounds of `plan` (already in the sampler) become new blends in the empty LIST positions from the clicked one on.
// start = the LIST position (0..199); -1 = the one clicked last.
- (void)pasteIntoList:(const std::vector<silveton::manager::SentSound>&)plan start:(NSInteger)start
                 done:(void (^)(NSString* problem, NSInteger first, NSInteger count))done;
// SILVETON_PROJECT_V1: a project opened: its bank + its sent SOUNDs (one file) + the LIST and settings saved with it.
- (void)openProjectBank:(NSString*)bank sentFile:(NSString*)sentFile sounds:(const std::vector<silveton::manager::SentSound>&)sounds
                dropped:(const std::set<int>&)dropped removed:(const std::set<int>&)removed stateDir:(NSString*)dir done:(void (^)(NSString* error))done;
#endif
- (NSString*)saveSamplerStateTo:(NSString*)dir;   // LIST, blends, effects, settings, the open COMBI; nil = saved, else why not
// The bank for the tablet was written at `bank` (the sampler's bank + the sent files): the sampler plays it, the sent files go away,
// the LIST and settings saved in `dir` just before come back exactly as they were.
- (void)tabletBankWritten:(NSString*)bank stateDir:(NSString*)dir done:(void (^)(NSString* error))done;
@end
