// SILVETON_ATTACK_V1 - a window that shows where the quiet in front of every sample would be cut.
// Returns one entry per ticked row: @{"index": sample number, "startFrame": where to cut}, or nil on cancel.
#pragma once
#import <AppKit/AppKit.h>

// SILVETON_ATTACK_V3: play the first `frames` frames of that sample (the part in front of the green line, the part that
// would be cut away). frames == 0 means: stop the sound.
typedef void (^SVReviewPlayBlock)(NSUInteger sampleIndex, unsigned long long frames);

#ifdef __cplusplus
extern "C" {
#endif
NSArray<NSDictionary<NSString*, id>*>* SVReviewLateStarts(NSWindow* parent, NSString* blendName, NSArray<NSDictionary<NSString*, id>*>* rows, SVReviewPlayBlock play);
#ifdef __cplusplus
}
#endif
