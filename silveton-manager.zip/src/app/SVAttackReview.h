// SILVETON_ATTACK_V1 - a window that shows where the quiet in front of every sample would be cut.
// Returns one entry per ticked row: @{"index": sample number, "startFrame": where to cut}, or nil on cancel.
#pragma once
#import <AppKit/AppKit.h>

#ifdef __cplusplus
extern "C" {
#endif
NSArray<NSDictionary<NSString*, id>*>* SVReviewLateStarts(NSWindow* parent, NSArray<NSDictionary<NSString*, id>*>* rows);
#ifdef __cplusplus
}
#endif
