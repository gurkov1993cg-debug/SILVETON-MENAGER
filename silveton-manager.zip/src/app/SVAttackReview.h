// SILVETON_ATTACK_V1 - a window that shows where the quiet in front of every sample would be cut.
// Returns the sample numbers that were ticked, or nil when nothing is to be done.
#pragma once
#import <AppKit/AppKit.h>

#ifdef __cplusplus
extern "C" {
#endif
NSArray<NSNumber*>* SVReviewLateStarts(NSWindow* parent, NSArray<NSDictionary<NSString*, id>*>* rows);
#ifdef __cplusplus
}
#endif
