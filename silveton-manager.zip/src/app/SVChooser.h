// SILVETON_LOOK_V1 - a small modal list with a search box. Returns the chosen row or -1.
#pragma once
#import <AppKit/AppKit.h>

#ifdef __cplusplus
extern "C" {
#endif
NSInteger SVChooseFromList(NSWindow* parent, NSString* title, NSString* hint, NSArray<NSString*>* items, NSInteger initial);
#ifdef __cplusplus
}
#endif
