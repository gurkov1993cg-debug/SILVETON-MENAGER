// SILVETON_LOOK_V1 - application: one window (SVShell), a short menu, a question before losing changes.
#import <AppKit/AppKit.h>

#import "SVShell.h"
#import "SVDocument.h"
#import "SVTheme.h"

@interface SVAppDelegate : NSObject <NSApplicationDelegate>
@property(nonatomic, readonly) SVShellWindowController* mainWindowController;
- (void)showPageCommand:(NSMenuItem*)sender;
- (void)undoSampleEdit:(id)sender;
- (void)redoSampleEdit:(id)sender;
@end

@implementation SVAppDelegate {
    SVShellWindowController* _mainWindowController;
}

- (SVShellWindowController*)mainWindowController { return _mainWindowController; }

// reachable through KVC by helpers that look for the document on the main window controller
- (SVManagerDocument*)documentModel { return _mainWindowController.documentModel; }

- (void)applicationDidFinishLaunching:(NSNotification*)notification {
    (void)notification;
    _mainWindowController = [[SVShellWindowController alloc] init];
    [_mainWindowController showWindow:self];
    [_mainWindowController.window center];
    [_mainWindowController.window makeKeyAndOrderFront:self];
    [NSApp activateIgnoringOtherApps:YES];
}

- (void)showPageCommand:(NSMenuItem*)sender { [_mainWindowController showPage:sender.tag]; }

- (void)undoSampleEdit:(id)sender {
    (void)sender;
    [_mainWindowController.audition stop];
    NSString* error = nil;
    if (![_mainWindowController.documentModel undoSampleEdit:&error]) { SVAlert(_mainWindowController.window, @"Отмяна", error ?: @"Няма какво да се отмени.", NO); return; }
    [_mainWindowController refreshAll];
}

- (void)redoSampleEdit:(id)sender {
    (void)sender;
    [_mainWindowController.audition stop];
    NSString* error = nil;
    if (![_mainWindowController.documentModel redoSampleEdit:&error]) { SVAlert(_mainWindowController.window, @"Повтори", error ?: @"Няма какво да се повтори.", NO); return; }
    [_mainWindowController refreshAll];
}

- (BOOL)validateMenuItem:(NSMenuItem*)item {
    if (item.action == @selector(undoSampleEdit:)) return [_mainWindowController.documentModel canUndoSampleEdit];
    if (item.action == @selector(redoSampleEdit:)) return [_mainWindowController.documentModel canRedoSampleEdit];
    return YES;
}

- (NSApplicationTerminateReply)applicationShouldTerminate:(NSApplication*)sender {
    (void)sender;
    if (_mainWindowController == nil || ![_mainWindowController.documentModel hasUnsavedChanges]) return NSTerminateNow;
    NSAlert* alert = [[NSAlert alloc] init];
    alert.messageText = @"Има незаписани промени";
    alert.informativeText = @"Банката не е записана (ЗАПИШИ е на страница БАНКА). Да се излезе ли без запис?";
    [alert addButtonWithTitle:@"Излез без запис"];
    [alert addButtonWithTitle:@"Остани"];
    return [alert runModal] == NSAlertFirstButtonReturn ? NSTerminateNow : NSTerminateCancel;
}

- (void)applicationWillTerminate:(NSNotification*)notification {
    (void)notification;
    [_mainWindowController.audition stop];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication*)sender {
    (void)sender;
    return YES;
}
@end
