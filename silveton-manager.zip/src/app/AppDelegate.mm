#import <AppKit/AppKit.h>

#include <cmath>
#include <cstdint>

@interface SVMainWindowController : NSWindowController
- (NSUInteger)selectedSampleIndex;
- (void)refreshProjectView;
- (void)showEmbeddedWorkspaceView:(NSView*)view identifier:(NSString*)identifier;
- (void)showSampleWorkspace;
@end

@interface SVManagerDocument : NSObject
- (NSDictionary<NSString*, id>*)auditionStateAtIndex:(NSUInteger)index error:(NSString**)error;
- (BOOL)canUndoSampleEdit;
- (BOOL)canRedoSampleEdit;
- (BOOL)undoSampleEdit:(NSString**)error;
- (BOOL)redoSampleEdit:(NSString**)error;
- (BOOL)copySampleRangeAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error;
- (BOOL)cutSampleRangeAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error;
- (BOOL)deleteSampleRangeAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error;
- (BOOL)silenceSampleRangeAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error;
- (BOOL)pasteSampleRangeAtIndex:(NSUInteger)index atFrame:(uint64_t)atFrame error:(NSString**)error;
- (BOOL)reverseSampleRangeAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error;
- (BOOL)applyGainForSampleRangeAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame gainDb:(float)gainDb error:(NSString**)error;
- (BOOL)normalizeSampleRangeAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame targetPeakDb:(float)targetPeakDb error:(NSString**)error;
- (BOOL)fadeInSampleRangeAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error;
- (BOOL)fadeOutSampleRangeAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error;
- (NSString*)sampleClipboardSummary;
@end

@interface SVSampleAuditionPlayer : NSObject
- (BOOL)playState:(NSDictionary<NSString*, id>*)state loopOnly:(BOOL)loopOnly error:(NSString**)error;
- (void)stop;
@end

@interface SVMultisampleWindowController : NSWindowController
- (instancetype)initWithDocumentModel:(SVManagerDocument*)documentModel;
- (void)refreshFromDocument;
@end

@interface SVBankOrganizerWindowController : NSWindowController
- (instancetype)initWithDocumentModel:(SVManagerDocument*)documentModel;
- (void)refreshFromDocument;
@end

@interface SVSoundEditorWindowController : NSWindowController
- (instancetype)initWithDocumentModel:(SVManagerDocument*)documentModel;
- (void)refreshFromDocument;
@end

@interface SVAppDelegate : NSObject <NSApplicationDelegate>
@end

@implementation SVAppDelegate {
    SVMainWindowController* _mainWindowController;
    SVMultisampleWindowController* _multisampleWindowController;
    SVBankOrganizerWindowController* _bankOrganizerWindowController;
    SVSoundEditorWindowController* _soundEditorWindowController;
    NSView* _multisamplePageView;
    NSView* _bankPageView;
    NSView* _soundPageView;
    SVSampleAuditionPlayer* _auditionPlayer;
}

- (NSButton*)toolbarButtonWithFrame:(NSRect)frame title:(NSString*)title action:(SEL)action {
    NSButton* button = [[NSButton alloc] initWithFrame:frame];
    button.title = title;
    button.bezelStyle = NSBezelStyleRounded;
    button.font = [NSFont systemFontOfSize:12.0 weight:NSFontWeightMedium];
    button.target = self;
    button.action = action;
    button.autoresizingMask = NSViewMinYMargin;
    return button;
}

- (NSTextField*)smallLabelWithFrame:(NSRect)frame text:(NSString*)text {
    NSTextField* label = [[NSTextField alloc] initWithFrame:frame];
    label.stringValue = text ?: @"";
    label.editable = NO;
    label.selectable = NO;
    label.bezeled = NO;
    label.drawsBackground = NO;
    label.font = [NSFont systemFontOfSize:10.5 weight:NSFontWeightRegular];
    label.textColor = [NSColor colorWithCalibratedWhite:0.58 alpha:1.0];
    return label;
}

- (SVManagerDocument*)documentModel {
    return [_mainWindowController valueForKey:@"documentModel"];
}

- (void)showMessage:(NSString*)title text:(NSString*)text style:(NSAlertStyle)style {
    NSAlert* alert = [[NSAlert alloc] init];
    alert.messageText = title ?: @"SILVETON Manager";
    alert.informativeText = text ?: @"";
    alert.alertStyle = style;
    if (_mainWindowController.window != nil) [alert beginSheetModalForWindow:_mainWindowController.window completionHandler:nil];
    else [alert runModal];
}

- (void)refreshAllEditors {
    [_mainWindowController refreshProjectView];
    [_multisampleWindowController refreshFromDocument];
    [_bankOrganizerWindowController refreshFromDocument];
    [_soundEditorWindowController refreshFromDocument];
}

- (BOOL)parseUnsignedField:(NSTextField*)field label:(NSString*)label value:(uint64_t*)valueOut {
    if (field == nil) return NO;
    NSString* text = [field.stringValue stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (text.length == 0U || [text hasPrefix:@"-"]) {
        [self showMessage:@"Invalid edit range" text:[NSString stringWithFormat:@"%@ must be a non-negative whole number.", label] style:NSAlertStyleWarning];
        return NO;
    }
    NSScanner* scanner = [NSScanner scannerWithString:text];
    unsigned long long parsed = 0ULL;
    if (![scanner scanUnsignedLongLong:&parsed] || !scanner.isAtEnd) {
        [self showMessage:@"Invalid edit range" text:[NSString stringWithFormat:@"%@ must be a non-negative whole number.", label] style:NSAlertStyleWarning];
        return NO;
    }
    if (valueOut != nullptr) *valueOut = static_cast<uint64_t>(parsed);
    return YES;
}

- (BOOL)readEditRangeStart:(uint64_t*)startOut end:(uint64_t*)endOut {
    NSTextField* startField = [_mainWindowController valueForKey:@"trimStartField"];
    NSTextField* endField = [_mainWindowController valueForKey:@"trimEndField"];
    uint64_t startFrame = 0U;
    uint64_t endFrame = 0U;
    if (![self parseUnsignedField:startField label:@"Range Start" value:&startFrame] ||
        ![self parseUnsignedField:endField label:@"Range End" value:&endFrame]) return NO;
    if (startFrame >= endFrame) {
        [self showMessage:@"Invalid edit range" text:@"Range Start must be before Range End." style:NSAlertStyleWarning];
        return NO;
    }
    if (startOut != nullptr) *startOut = startFrame;
    if (endOut != nullptr) *endOut = endFrame;
    return YES;
}

- (BOOL)readFloatFieldKey:(NSString*)key label:(NSString*)label value:(float*)valueOut {
    NSTextField* field = [_mainWindowController valueForKey:key];
    if (field == nil) return NO;
    NSString* text = [field.stringValue stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSScanner* scanner = [NSScanner scannerWithString:text];
    double parsed = 0.0;
    if (text.length == 0U || ![scanner scanDouble:&parsed] || !scanner.isAtEnd || !std::isfinite(parsed)) {
        [self showMessage:@"Invalid value" text:[NSString stringWithFormat:@"%@ must be a valid number.", label] style:NSAlertStyleWarning];
        return NO;
    }
    if (valueOut != nullptr) *valueOut = static_cast<float>(parsed);
    return YES;
}

- (BOOL)selectedSampleIndex:(NSUInteger*)indexOut {
    const NSUInteger index = [_mainWindowController selectedSampleIndex];
    if (index == NSNotFound) {
        [self showMessage:@"No sample selected" text:@"Select a sample first." style:NSAlertStyleWarning];
        return NO;
    }
    if (indexOut != nullptr) *indexOut = index;
    return YES;
}

- (void)finishRangeMutation:(BOOL)ok error:(NSString*)error title:(NSString*)title {
    if (ok != YES) {
        [self showMessage:title text:error ?: @"Sample edit failed." style:NSAlertStyleWarning];
        return;
    }
    [_auditionPlayer stop];
    [self refreshAllEditors];
}

- (void)applicationDidFinishLaunching:(NSNotification*)notification {
    (void)notification;
    _mainWindowController = [[SVMainWindowController alloc] init];
    _auditionPlayer = [[SVSampleAuditionPlayer alloc] init];
    [_mainWindowController showWindow:self];
    [_mainWindowController.window center];
    [_mainWindowController.window makeKeyAndOrderFront:self];

    // The main window owns the complete SILVETON layout.
    // Do not overlay legacy macOS-style transport/range controls here.

    [NSApp activateIgnoringOtherApps:YES];
}

- (BOOL)selectedSampleState:(NSDictionary<NSString*, id>**)stateOut {
    NSUInteger index = 0U;
    if (![self selectedSampleIndex:&index]) return NO;
    NSString* error = nil;
    NSDictionary<NSString*, id>* state = [[self documentModel] auditionStateAtIndex:index error:&error];
    if (state == nil) {
        [self showMessage:@"Audition unavailable" text:error style:NSAlertStyleCritical];
        return NO;
    }
    if (stateOut != nullptr) *stateOut = state;
    return YES;
}

- (void)playSample:(id)sender {
    (void)sender;
    NSDictionary<NSString*, id>* state = nil;
    if (![self selectedSampleState:&state]) return;
    NSString* error = nil;
    if (![_auditionPlayer playState:state loopOnly:NO error:&error]) [self showMessage:@"Playback failed" text:error style:NSAlertStyleCritical];
}

- (void)playLoop:(id)sender {
    (void)sender;
    NSDictionary<NSString*, id>* state = nil;
    if (![self selectedSampleState:&state]) return;
    NSString* error = nil;
    if (![_auditionPlayer playState:state loopOnly:YES error:&error]) [self showMessage:@"Loop playback failed" text:error style:NSAlertStyleWarning];
}

- (void)playRange:(id)sender {
    (void)sender;
    uint64_t startFrame = 0U, endFrame = 0U;
    if (![self readEditRangeStart:&startFrame end:&endFrame]) return;
    NSDictionary<NSString*, id>* state = nil;
    if (![self selectedSampleState:&state]) return;
    const uint64_t totalFrames = [state[@"totalFrames"] unsignedLongLongValue];
    if (endFrame > totalFrames) {
        [self showMessage:@"Play Range" text:@"Range End is beyond the sample length." style:NSAlertStyleWarning];
        return;
    }
    const unsigned int channels = [state[@"channels"] unsignedIntValue];
    const unsigned int encoding = [state[@"encoding"] unsignedIntValue];
    const NSUInteger bytesPerSample = encoding == 1U ? 2U : (encoding == 2U ? 3U : (encoding == 3U ? 4U : 0U));
    NSData* audio = state[@"audioData"];
    if (bytesPerSample == 0U || audio == nil) {
        [self showMessage:@"Play Range" text:@"Unsupported sample encoding." style:NSAlertStyleWarning];
        return;
    }
    const NSUInteger bytesPerFrame = bytesPerSample * static_cast<NSUInteger>(channels);
    const uint64_t frameCount = endFrame - startFrame;
    const uint64_t byteStart64 = startFrame * static_cast<uint64_t>(bytesPerFrame);
    const uint64_t byteCount64 = frameCount * static_cast<uint64_t>(bytesPerFrame);
    if (byteStart64 + byteCount64 > static_cast<uint64_t>(audio.length)) {
        [self showMessage:@"Play Range" text:@"Selected audio range is invalid." style:NSAlertStyleWarning];
        return;
    }
    NSData* sliced = [audio subdataWithRange:NSMakeRange(static_cast<NSUInteger>(byteStart64), static_cast<NSUInteger>(byteCount64))];
    NSMutableDictionary<NSString*, id>* ranged = [state mutableCopy];
    ranged[@"audioData"] = sliced;
    ranged[@"totalFrames"] = @(frameCount);
    ranged[@"loopEnabled"] = @NO;
    ranged[@"loopStart"] = @0ULL;
    ranged[@"loopEnd"] = @0ULL;
    NSString* error = nil;
    if (![_auditionPlayer playState:ranged loopOnly:NO error:&error]) [self showMessage:@"Play Range failed" text:error style:NSAlertStyleWarning];
}

- (void)stopAudition:(id)sender { (void)sender; [_auditionPlayer stop]; }

- (void)copyRange:(id)sender {
    (void)sender;
    NSUInteger index = 0U;
    uint64_t startFrame = 0U, endFrame = 0U;
    if (![self selectedSampleIndex:&index] || ![self readEditRangeStart:&startFrame end:&endFrame]) return;
    NSString* error = nil;
    if (![[self documentModel] copySampleRangeAtIndex:index startFrame:startFrame endFrame:endFrame error:&error]) {
        [self showMessage:@"Copy Range" text:error style:NSAlertStyleWarning];
        return;
    }
    NSTextField* status = [_mainWindowController valueForKey:@"statusLabel"];
    if (status != nil) status.stringValue = [[self documentModel] sampleClipboardSummary];
}

- (void)cutRange:(id)sender {
    (void)sender;
    NSUInteger index = 0U;
    uint64_t startFrame = 0U, endFrame = 0U;
    if (![self selectedSampleIndex:&index] || ![self readEditRangeStart:&startFrame end:&endFrame]) return;
    NSString* error = nil;
    BOOL ok = [[self documentModel] cutSampleRangeAtIndex:index startFrame:startFrame endFrame:endFrame error:&error];
    [self finishRangeMutation:ok error:error title:@"Cut Range"];
}

- (void)pasteRange:(id)sender {
    (void)sender;
    NSUInteger index = 0U;
    uint64_t startFrame = 0U, endFrame = 0U;
    if (![self selectedSampleIndex:&index] || ![self readEditRangeStart:&startFrame end:&endFrame]) return;
    (void)endFrame;
    NSString* error = nil;
    BOOL ok = [[self documentModel] pasteSampleRangeAtIndex:index atFrame:startFrame error:&error];
    [self finishRangeMutation:ok error:error title:@"Paste Range"];
}

- (void)deleteRange:(id)sender {
    (void)sender;
    NSUInteger index = 0U;
    uint64_t startFrame = 0U, endFrame = 0U;
    if (![self selectedSampleIndex:&index] || ![self readEditRangeStart:&startFrame end:&endFrame]) return;
    NSString* error = nil;
    BOOL ok = [[self documentModel] deleteSampleRangeAtIndex:index startFrame:startFrame endFrame:endFrame error:&error];
    [self finishRangeMutation:ok error:error title:@"Delete Range"];
}

- (void)silenceRange:(id)sender {
    (void)sender;
    NSUInteger index = 0U;
    uint64_t startFrame = 0U, endFrame = 0U;
    if (![self selectedSampleIndex:&index] || ![self readEditRangeStart:&startFrame end:&endFrame]) return;
    NSString* error = nil;
    BOOL ok = [[self documentModel] silenceSampleRangeAtIndex:index startFrame:startFrame endFrame:endFrame error:&error];
    [self finishRangeMutation:ok error:error title:@"Silence Range"];
}

- (void)reverseRange:(id)sender {
    (void)sender;
    NSUInteger index = 0U;
    uint64_t startFrame = 0U, endFrame = 0U;
    if (![self selectedSampleIndex:&index] || ![self readEditRangeStart:&startFrame end:&endFrame]) return;
    NSString* error = nil;
    BOOL ok = [[self documentModel] reverseSampleRangeAtIndex:index startFrame:startFrame endFrame:endFrame error:&error];
    [self finishRangeMutation:ok error:error title:@"Reverse Range"];
}

- (void)fadeInRange:(id)sender {
    (void)sender;
    NSUInteger index = 0U;
    uint64_t startFrame = 0U, endFrame = 0U;
    if (![self selectedSampleIndex:&index] || ![self readEditRangeStart:&startFrame end:&endFrame]) return;
    NSString* error = nil;
    BOOL ok = [[self documentModel] fadeInSampleRangeAtIndex:index startFrame:startFrame endFrame:endFrame error:&error];
    [self finishRangeMutation:ok error:error title:@"Fade In Range"];
}

- (void)fadeOutRange:(id)sender {
    (void)sender;
    NSUInteger index = 0U;
    uint64_t startFrame = 0U, endFrame = 0U;
    if (![self selectedSampleIndex:&index] || ![self readEditRangeStart:&startFrame end:&endFrame]) return;
    NSString* error = nil;
    BOOL ok = [[self documentModel] fadeOutSampleRangeAtIndex:index startFrame:startFrame endFrame:endFrame error:&error];
    [self finishRangeMutation:ok error:error title:@"Fade Out Range"];
}

- (void)gainRange:(id)sender {
    (void)sender;
    NSUInteger index = 0U;
    uint64_t startFrame = 0U, endFrame = 0U;
    float gainDb = 0.0F;
    if (![self selectedSampleIndex:&index] || ![self readEditRangeStart:&startFrame end:&endFrame] ||
        ![self readFloatFieldKey:@"gainField" label:@"Gain dB" value:&gainDb]) return;
    NSString* error = nil;
    BOOL ok = [[self documentModel] applyGainForSampleRangeAtIndex:index startFrame:startFrame endFrame:endFrame gainDb:gainDb error:&error];
    [self finishRangeMutation:ok error:error title:@"Gain Range"];
}

- (void)normalizeRange:(id)sender {
    (void)sender;
    NSUInteger index = 0U;
    uint64_t startFrame = 0U, endFrame = 0U;
    float targetDb = 0.0F;
    if (![self selectedSampleIndex:&index] || ![self readEditRangeStart:&startFrame end:&endFrame] ||
        ![self readFloatFieldKey:@"normalizeField" label:@"Normalize dBFS" value:&targetDb]) return;
    NSString* error = nil;
    BOOL ok = [[self documentModel] normalizeSampleRangeAtIndex:index startFrame:startFrame endFrame:endFrame targetPeakDb:targetDb error:&error];
    [self finishRangeMutation:ok error:error title:@"Normalize Range"];
}

- (void)undoSampleEdit:(id)sender {
    (void)sender;
    [_auditionPlayer stop];
    SVManagerDocument* model = [self documentModel];
    NSString* error = nil;
    if (![model undoSampleEdit:&error]) {
        [self showMessage:@"Undo" text:error style:NSAlertStyleInformational];
        return;
    }
    [self refreshAllEditors];
}

- (void)redoSampleEdit:(id)sender {
    (void)sender;
    [_auditionPlayer stop];
    SVManagerDocument* model = [self documentModel];
    NSString* error = nil;
    if (![model redoSampleEdit:&error]) {
        [self showMessage:@"Redo" text:error style:NSAlertStyleInformational];
        return;
    }
    [self refreshAllEditors];
}

- (void)showBankOrganizer:(id)sender {
    (void)sender;
    if (_bankOrganizerWindowController == nil) {
        SVManagerDocument* model = [self documentModel];
        if (model == nil) {
            [self showMessage:@"Bank Organizer unavailable" text:@"The shared Manager document could not be accessed." style:NSAlertStyleCritical];
            return;
        }
        _bankOrganizerWindowController = [[SVBankOrganizerWindowController alloc] initWithDocumentModel:model];
        _bankPageView = _bankOrganizerWindowController.window.contentView;
        _bankOrganizerWindowController.window.contentView = [[NSView alloc] initWithFrame:NSMakeRect(0.0, 0.0, 10.0, 10.0)];
    }
    [_bankOrganizerWindowController refreshFromDocument];
    [_mainWindowController showEmbeddedWorkspaceView:_bankPageView identifier:@"BANK"];
}

- (void)showSoundEditor:(id)sender {
    (void)sender;
    if (_soundEditorWindowController == nil) {
        SVManagerDocument* model = [self documentModel];
        if (model == nil) {
            [self showMessage:@"SOUND Editor unavailable" text:@"The shared Manager document could not be accessed." style:NSAlertStyleCritical];
            return;
        }
        _soundEditorWindowController = [[SVSoundEditorWindowController alloc] initWithDocumentModel:model];
        _soundPageView = _soundEditorWindowController.window.contentView;
        _soundEditorWindowController.window.contentView = [[NSView alloc] initWithFrame:NSMakeRect(0.0, 0.0, 10.0, 10.0)];
    }
    [_soundEditorWindowController refreshFromDocument];
    [_mainWindowController showEmbeddedWorkspaceView:_soundPageView identifier:@"SOUND"];
}

- (void)showMultisampleEditor:(id)sender {
    (void)sender;
    if (_multisampleWindowController == nil) {
        SVManagerDocument* model = [self documentModel];
        if (model == nil) {
            [self showMessage:@"Multisample Editor unavailable" text:@"The shared Manager document could not be accessed." style:NSAlertStyleCritical];
            return;
        }
        _multisampleWindowController = [[SVMultisampleWindowController alloc] initWithDocumentModel:model];
        _multisamplePageView = _multisampleWindowController.window.contentView;
        _multisampleWindowController.window.contentView = [[NSView alloc] initWithFrame:NSMakeRect(0.0, 0.0, 10.0, 10.0)];
    }
    [_multisampleWindowController refreshFromDocument];
    [_mainWindowController showEmbeddedWorkspaceView:_multisamplePageView identifier:@"MULTISAMPLE"];
}

- (void)applicationWillTerminate:(NSNotification*)notification {
    (void)notification;
    [_auditionPlayer stop];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication*)sender {
    (void)sender;
    return YES;
}

@end
