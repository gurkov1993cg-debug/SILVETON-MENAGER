// SILVETON_LOOK_V1 - application: one window (SVShell), a short menu, a question before losing changes.
#import <AppKit/AppKit.h>

#import "SVShell.h"
#import "SVDocument.h"
#import "SVTheme.h"
#import "SVSamplerPage.h"
#import "SVBankPage.h"

@interface SVAppDelegate : NSObject <NSApplicationDelegate>
@property(nonatomic, readonly) SVShellWindowController* mainWindowController;
- (void)showPageCommand:(NSMenuItem*)sender;
- (void)undoSampleEdit:(id)sender;
- (void)redoSampleEdit:(id)sender;
// SILVETON_WORKFLOW_V1: menu Файл
- (void)newProject:(id)sender;
- (void)openProject:(id)sender;
- (void)saveProject:(id)sender;
- (void)saveProjectAs:(id)sender;
- (void)writeTabletBank:(id)sender;
@end

@implementation SVAppDelegate {
    SVShellWindowController* _mainWindowController;
}

- (SVShellWindowController*)mainWindowController { return _mainWindowController; }

// reachable through KVC by helpers that look for the document on the main window controller
- (SVManagerDocument*)documentModel { return _mainWindowController.documentModel; }

- (void)applicationDidFinishLaunching:(NSNotification*)notification {
    (void)notification;
    [[SVSamplerHost shared] start];   // SILVETON_MERGE_V1: the sampler plays from the start (sound + MIDI keyboard)
    _mainWindowController = [[SVShellWindowController alloc] init];
    [_mainWindowController showWindow:self];
    [_mainWindowController.window center];
    [_mainWindowController.window makeKeyAndOrderFront:self];
    [NSApp activateIgnoringOtherApps:YES];
}

- (void)showPageCommand:(NSMenuItem*)sender { [_mainWindowController showPage:sender.tag]; }

- (void)undoSampleEdit:(id)sender {
    (void)sender;
    [_mainWindowController.audition stop];
    NSString* error = nil;
    if (![_mainWindowController.documentModel undoSampleEdit:&error]) { SVAlert(_mainWindowController.window, @"Отмяна", error ?: @"Няма какво да се отмени.", NO); return; }
    [_mainWindowController refreshAll];
}

- (void)redoSampleEdit:(id)sender {
    (void)sender;
    [_mainWindowController.audition stop];
    NSString* error = nil;
    if (![_mainWindowController.documentModel redoSampleEdit:&error]) { SVAlert(_mainWindowController.window, @"Повтори", error ?: @"Няма какво да се повтори.", NO); return; }
    [_mainWindowController refreshAll];
}

// ---- SILVETON_WORKFLOW_V1: menu Файл = the project keys of the БАНКА page, from every page
- (SVBankPage*)bankPage { return (SVBankPage*)[_mainWindowController pageAt:SVPageBank]; }
- (void)newProject:(id)sender { (void)sender; [[self bankPage] newProjectPressed:nil]; }
- (void)openProject:(id)sender { (void)sender; [[self bankPage] openProjectPressed:nil]; }
- (void)saveProject:(id)sender { (void)sender; [[self bankPage] saveProjectPressed:nil]; }
- (void)saveProjectAs:(id)sender { (void)sender; [[self bankPage] saveProjectAsPressed:nil]; }
- (void)writeTabletBank:(id)sender { (void)sender; [[self bankPage] tabletBankPressed:nil]; }

- (BOOL)validateMenuItem:(NSMenuItem*)item {
    if (item.action == @selector(undoSampleEdit:)) return [_mainWindowController.documentModel canUndoSampleEdit];
    if (item.action == @selector(redoSampleEdit:)) return [_mainWindowController.documentModel canRedoSampleEdit];
    return YES;
}

- (NSApplicationTerminateReply)applicationShouldTerminate:(NSApplication*)sender {
    (void)sender;
    if (_mainWindowController == nil || ![_mainWindowController.documentModel hasUnsavedChanges]) return NSTerminateNow;
    NSAlert* alert = [[NSAlert alloc] init];
    alert.messageText = @"Има незаписани промени";
    alert.informativeText = @"Проектът не е запазен (Файл → Запази проекта, Cmd+S). Да се излезе ли без запис?";
    [alert addButtonWithTitle:@"Излез без запис"];
    [alert addButtonWithTitle:@"Остани"];
    return [alert runModal] == NSAlertFirstButtonReturn ? NSTerminateNow : NSTerminateCancel;
}

- (void)applicationWillTerminate:(NSNotification*)notification {
    (void)notification;
    [_mainWindowController.audition stop];
    [[SVSamplerHost shared] stop];
}

- (BOOL)applicationShouldTerminateAfterLastWindowClosed:(NSApplication*)sender {
    (void)sender;
    return YES;
}
@end
