# SILVETON MANAGER — STRUCTURE

Updated: 2026-10-03

## Repository
- `gurkov1993cg-debug/SILVETON-MENAGER`
- Active development branch: `silveton-manager-development`
- `main` is preserved.

## Target
- Native Intel iMac 2011 application.
- x86_64 only, C++17 core, Objective-C++/AppKit GUI.
- macOS deployment target 10.13.
- No JUCE, Electron, or browser GUI runtime.

## Product role
`import -> sample edit -> multisample building -> bank/library organization -> deduplication -> SILVETON_BANK.sv`

SOUND editing is intentionally not duplicated in Manager. SOUND editing stays in SILVETON Sampler on the tablet. Manager owns sample editing, multisample editing and bank/library preparation.

Tablet runtime must only open the prepared bank/index and stream audio; it must not rebuild KMP/KSC structures on startup.

## Implemented files
- `CMakeLists.txt`: portable core + Apple-only Objective-C++ AppKit target, x86_64/macOS 10.13, strict warnings as errors. `src/core/SampleEditor.cpp` is part of the real core target. ARC (`-fobjc-arc`) is enabled only for the AppKit Manager target so Objective-C object ivars follow the ownership model used by the GUI code; the C++ core is unchanged.
- `include/silveton/manager/ManagerTypes.h`: canonical Manager sample/multisample/SOUND model and preserved raw Korg metadata.
- `include/silveton/manager/KorgImporter.h`, `src/core/KorgImporter.cpp`: KSF/KMP/KSC import, exact zones/dependencies, canonical PCM16LE. Path handling no longer depends on `std::filesystem`; it uses macOS-10.13-compatible string/POSIX path operations while preserving direct and nested KSF resolution and stable source identities.
- `include/silveton/manager/KontaktImporter.h`, `src/core/KontaktImporter.cpp`, `src/app/KontaktImportController.mm` (SILVETON_KONTAKT_V1): Kontakt 5+ `.nki` import (NI container + FastLZ, groups/zones/file table, `.nkx` monoliths, NCW decoding). One Kontakt group = one SOUND with up to 5 velocity layers (soft, medium, stronger, strong, top hit). The KONTAKT IMPORT window lists the instruments inside the file, shows the sample rate the files claim and the one their pitch fits, and imports only the ticked ones with progress. `tests/KontaktImporterTests.cpp` covers FastLZ, NCW blocks and the layer choice.
- `include/silveton/manager/PitchDetector.h`, `src/core/PitchDetector.cpp` (SILVETON_PITCH_V1): which note (and octave) a recording is, read from the audio: YIN difference function on a 0.3 s window after the attack, threshold 0.15, an octave check that accepts the doubled period only when its dip is clearly deeper (piano bass notes with a weak fundamental), parabolic interpolation, 25–4500 Hz. `PitchResult` = hz, MIDI note, cents, confidence. 40/40 exact on real piano samples with known roots. `src/app/PitchDetectController.mm` runs it over every sample with progress and shows the РАЗПОЗНАТИ ТОНОВЕ window (tick → ПРИЕМИ ОТБЕЛЯЗАНИТЕ sets root key and fine tune against the detected offset). The СЕМПЛИ page has РАЗПОЗНАЙ ТОНА / ПРИЕМИ ТОНА for one sample. Nothing is changed without the accept key. Tests live in `tests/KontaktImporterTests.cpp`.
- Instrument sets (`KontaktImporter::instrumentSets` / `importSet` / `importGroups`): groups named `<A-G>_<technique>` that exist for at least 3 strings are merged per technique into ONE SOUND (a string-split bass); on a key reached by several strings the string with the highest lowest key wins (first position), so every key plays exactly one sample per velocity layer. Plain groups stay one set each. The import page lists sets, `SVImportKontaktSets` imports them. `probeSampleRate` now reads the pitch with `PitchDetector` (octave-safe) and overrules the rate in the files only when the pitch clearly contradicts it. Test on a hand-built string library in `tests/KontaktImporterTests.cpp`.
- `include/silveton/manager/SampleEditor.h`, `src/core/SampleEditor.cpp`: real offline sample-edit core for PCM16LE/PCM24LE/Float32LE project copies. Implements destructive trim, validated loop metadata/crossfade bounds, explicit user-triggered destructive loop-crossfade baking, frame-correct reverse with loop remap, gain, peak normalize, fade in/out, root key, fine tune, peak readback, nearest zero crossing and waveform min/max envelope generation. Source files on disk are not modified by these operations.
- `include/silveton/manager/SampleHash.h`, `src/core/SampleHash.cpp`: deterministic sample-audio hashing plus exact-byte dedup policy.
- `include/silveton/manager/SvBankFormat.h`, `src/core/SvBankFormat.cpp`: `.sv` v1 explicit little-endian fixed records + SHA-256. The SHA-256 round constant at index 53 is corrected to standard `0x4ed8aa4aU`.
- `include/silveton/manager/SvBankBuilder.h`, `src/core/SvBankBuilder.cpp`: reference validation, string/audio dedup, 4096-byte audio alignment, integrity and atomic writing without `std::filesystem`.
- `include/silveton/manager/SvBankReader.h`, `src/core/SvBankReader.cpp`: bounds/integrity/reference validation and complete project reconstruction.
- `include/silveton/manager/AudioFileLoader.h`, `src/core/AudioFileLoader.cpp`: WAV PCM16/24/Float32, AIFF PCM16/24, AIFC NONE/sowt with supported root/loop metadata. Path identity, extension and stem handling use macOS-10.13-compatible string/POSIX operations instead of `std::filesystem`.
- `tests/ManagerCoreTests.cpp`: always-active Release regression suite for KSF/KMP/WAV/AIFF, SampleEditor PCM mutation/no-auto-apply behavior, SHA-256, `.sv` round-trip/dedup/corruption/atomic write. Sample-editor coverage checks setLoop metadata without PCM mutation, explicit real loop-crossfade PCM mutation, fade in/out, trim, reverse, gain, normalize, root key, fine tune, zero crossing and waveform generation.

### Native AppKit application (SILVETON_LOOK_V1, 2026-10-13)
One window (`src/app/SVShell.mm`): top bar, five page keys on the left in the order of the work, the page in the middle, one status line. Look shared through `src/app/SVTheme.mm` (dark board, amber = on, matte dark = off; panels, keys, toggles, knobs, bars, tables). Pages, each a flipped `SVPageView`:
- `src/app/SVImportPage.mm` – ВНАСЯНЕ: files of a chosen folder on the left (KMP/KSC/KSF/NKI/WAV/AIFF, ticks), on the right what will come in (for a .nki the instruments with keys / layers / samples / MB and the sample-rate check), the import log at the bottom.
- `src/app/SVSamplesPage.mm` – СЕМПЛИ: tree SOUND → layers → samples, waveform with loop and selection, audition, loop / cut and level / tone edits that run only on ПРИЛОЖИ.
- `src/app/SVSoundsPage.mm` – БЛЕНДИ: SOUND list (positions 1..500), layers of the chosen SOUND with velocity ranges, keyboard that shows which sample plays on a key, zone edits.
- `src/app/SVProcessingPage.mm` – ОБРАБОТКА: which SOUNDs, four switches (48 kHz, –6 dB per instrument, even tone, soft limiter), START / STOP, analyzer before / after (SVSpectrumView from `ProcessingController.mm`).
- `src/app/SVBankPage.mm` – БАНКА: content and size, save / load / new project, update a client's bank (adds SOUNDs, keeps the client's data, old bank kept as a copy).
`src/app/SVDocument.h` is the one declaration of `SVManagerDocument` (implemented in `ManagerDocument*.mm`). `src/app/ProcessingController.mm` keeps the progress panel, the import-with-progress call and the analyzer view. `src/app/KontaktImportController.mm` does the Kontakt import with progress. The earlier page controllers (Workflow, Media, Converter, Objects, Organizer, Multisample, Sound, MainWindow, GUIIntegration, FinalGUITheme) are gone.

### `.github/workflows/SILVETON MENAGER.yml`
- Runner `macos-15-intel`, Xcode 16.4, Release x86_64, deployment target 10.13.
- Tests before AppKit build; architecture/deployment/Info.plist/signing/package checks afterward.

## Real Korg regression fixture
User-provided `SALEAS-GRK SH.kmp` + 13 KSF files.
Verified: 14 RLP1 regions; first is `SKIPPEDSAMPL` keys 0..1; 13 playable zones; 48 kHz/16-bit/mono; first playable zone C4/root 60 keys 2..61; raw pan 64 preserved and maps to centre; no fake loop.

## SILVETON_BANK.sv v1 layout
1. Fixed 256-byte header: magic/version/counts/section offsets/SHA-256.
2. SOUND records.
3. SOUND layer records.
4. Multisample records.
5. Sample records.
6. Zone records.
7. Deduplicated string table.
8. 4096-byte-aligned deduplicated audio payload.

## Sample editor scope
Manager sample editing is the authoritative desktop editing layer for:
- waveform visualization;
- trim start/end;
- loop start/end/crossfade;
- normalize and gain;
- fade in/out;
- reverse;
- nearest-zero-crossing assistance;
- root key and fine tune.

All destructive sample-edit operations are explicit user actions. Import and `.sv` build do not auto-normalize, auto-trim, auto-fade, auto-crossfade, auto-reverse, auto-snap loop/start/end points or alter root/tune values without the user's command.

Loop crossfade behavior is real: `applyLoopCrossfade()` linearly blends the selected loop tail with the selected loop head per channel and per sample, writes the overlap into the project-copy audio, advances loop start by the overlap length so the fade-in material is not replayed twice, and clears the pending crossfade metadata after the bake. This function is never called automatically.

## Multisample editor scope
The project model and ManagerDocument bridge now support real multisample zone editing:
- actual sample assignment per zone;
- Key Low / Key High;
- Velocity Low / Velocity High;
- Root Key;
- Transpose;
- Tune cents;
- Gain dB;
- Pan;
- zone add/remove;
- multisample rename;
- automatic contiguous key mapping from selected samples using their actual Root Keys.

The visible piano keyboard/key-zone GUI is not yet implemented in `MainWindowController.mm` at this revision. It must read/write these real zone records and must not be a decorative keyboard.

Manager will not duplicate tablet SOUND parameters such as amp/filter/LFO/portamento/TONE/FX.

## Verification status
- Local Linux Release core/tests: PASS, `ctest` 1/1 for the pre-sample-editor core baseline.
- Intel run `37092662586`: Xcode 16.4 configure PASS; core compile FAILED in `SvBankBuilder.cpp` because libc++ `std::filesystem` is unavailable for deployment target macOS 10.13. `SvBankBuilder.cpp` was corrected without raising the target.
- Intel run `37092813628`: configuration PASS and `SvBankBuilder.cpp` progressed past the prior failure; next failure was `KorgImporter.cpp` for the same macOS 10.13 `std::filesystem` availability rule. `KorgImporter.cpp` was corrected without raising the target.
- Intel run `37108737366` / run 48: `KorgImporter.cpp`, `SvBankBuilder.cpp`, `SvBankReader.cpp`, `SvBankFormat.cpp` progressed through compile. The next real failure was isolated to `tests/ManagerCoreTests.cpp`, where the test fixture still used `std::filesystem` APIs unavailable for a macOS 10.13 deployment target.
- `tests/ManagerCoreTests.cpp` commit `73ff5b5999240b724483556ae185adb397284f45` removes only that test-side incompatibility: string/POSIX temp path creation, file names and cleanup replace `std::filesystem`; the actual regression assertions and Manager behavior are preserved.
- Intel run `37109218356` / run 49: configuration PASS and `ManagerCoreTests.cpp` progressed past the prior failure. The next real compile failure was `src/core/AudioFileLoader.cpp`, where source identity, extension and stem helpers still used `std::filesystem` unavailable at macOS 10.13.
- `src/core/AudioFileLoader.cpp` commit `52947cf4a95ab9784a9f643cb6bea12234173c84` removes only that path-library incompatibility. WAV/AIFF parsing, root/loop metadata, PCM conversion and public API remain unchanged.
- Sample-editor implementation commit `f79a7e33bf1112585cd91a479b975050eda05801` is present.
- Real user-applied loop-crossfade implementation commit `eafe4a8776603103883e31a7f8fdfa482c91340f` is present.
- `SampleEditor.cpp` was added to the core build target in commit `2819851c494639ad3429e1761ec566caeb4b4a0e`.
- Sample-editor regression coverage commit `099babef24741c2b34971eaaa698e4640a4745c5` is present and explicitly checks that editing is user-triggered and PCM changes are real.
- Intel run `37110792932` / run 63: strict x86_64/macOS 10.13 core build including `SampleEditor.cpp` and the expanded regression test executable SUCCEEDED. CTest then failed at the independent SHA-256 standard-vector assertion before the later bank/app stages. The exact source cause was the incorrect SHA-256 K constant `0x4ed8aa4U` in `SvBankFormat.cpp`; it must be `0x4ed8aa4aU`.
- `SvBankFormat.cpp` commit `ae378ab9f1fd5673db7949db25582e6b73eb11bf` corrects only that SHA-256 round constant; the `.sv` API/layout and sample editor are unchanged.
- Intel run `37111451698` / run 69: strict x86_64/macOS 10.13 configuration PASS, core build PASS, expanded sample-editor regression tests PASS (`ctest` 1/1). The AppKit app build then failed only in `MainWindowController.mm` because `NSTextField` does not provide `unsignedLongLongValue`; 12 occurrences affected Trim/Loop/Crossfade/Fade/Zero-Crossing GUI parsing. Core/DSP code was not the cause.
- `MainWindowController.mm` commit `fa1d3537dbea13c001d2793769f5272701a88614` replaces only those unsupported field conversions with explicit validated non-negative uint64 parsing and keeps every edit user-triggered. DSP/editor algorithms, public ManagerDocument bridge and other GUI controls are unchanged.
- Intel run `37111941671` / run 71: complete CI SUCCESS — configure, core build, regression tests, AppKit app build, x86_64/macOS 10.13 verification, ad-hoc signing, packaging and artifact upload all passed. This proves build/package correctness only, not GUI runtime compatibility.
- Physical iMac 2011 / macOS 10.13.6 launch test then FAILED before the GUI became usable. Crash report: `EXC_BAD_ACCESS` on main thread, `objc_msgSend` selector `count`, frame `-[SVMainWindowController tableView:viewForTableColumn:row:]`. The application is confirmed x86-64 native on macOS 10.13.6.
- Root cause: Objective-C++ AppKit code uses ARC-style object ivars, while the Manager target had no ARC compile flag. `sampleDisplayRows` returns an autoreleased `NSMutableArray`; `_sampleRows` stored it in a raw ivar and AppKit later sent `count` after the object lifetime had ended.
- `CMakeLists.txt` commit `ab16701d4a9c6bbfdace99d1bf32d89a4fe45a43` enables `-fobjc-arc` only for `SILVETON_MANAGER`. No C++ core, sample-editor DSP/API, bank format or GUI control logic is changed. A new Intel CI run and another physical High Sierra open test are required before calling the GUI runtime proven.
- `ManagerDocument.mm` sample-edit bridge commit `9c1be226146a8ac2125e822f728e93cf74c4d549` is present.
- `MainWindowController.mm` real waveform/editor GUI wiring commit `5eecd85c88899a6c4463098369d315c5040fdc4a` is present.
- `ManagerDocument.mm` commit `3c6418df8038055e8973e536280e76474a3ecf74` adds the real multisample/zone editing bridge described above. This commit is not yet a proven GUI feature and still requires Intel CI plus visible keyboard/zone wiring in `MainWindowController.mm`.

## Next
1. Wire `MainWindowController.mm` to the real multisample/zone bridge: multisample list, zone list, 128-note key map/piano keyboard and editable zone parameters.
2. Run the exact branch through Intel x86_64/macOS 10.13 CI and fix only real compile/test failures.
3. Install/open the exact successful artifact on the physical iMac 2011/macOS 10.13.6 and verify the window, sample editor and multisample keyboard/zone editor remain usable without crash.
4. Import the real KMP fixture and prove that the visible key map represents its real zones; edit a zone and verify the built `.sv` contains the changed zone values.


## SILVETON INFO / SOUND position contract

- One SILVETON bank supports exactly the address space `SOUND 001` through `SOUND 500`.
- `SoundDefinition::position` is the permanent INFO position used by SILVETON SAMPLER lookup; `0` is only an in-memory/unassigned compatibility value and is never written by a new bank build.
- Positions are unique. A new/duplicated SOUND receives the first free position; a 501st SOUND is rejected.
- `.sv` format v1.1 stores the SOUND position in every SOUND record while keeping v1.0 field offsets intact. The reader maps legacy v1.0 zero padding to sequential positions when possible.
- Samples and multisamples carry stable `uint32_t SampleID` / `MultisampleID`. Zones and SOUND layers write both the legacy array index and the stable ID, allowing the Sampler to build direct ID lookups while preserving v1.0 compatibility.
- KSC import is transactional at collection level: an explicitly referenced missing KMP/KSF fails the import rather than silently dropping zones.
- KSC collection import deduplicates truly identical KSF audio with metadata checks so reused samples share one SampleID.
- KSF 8-bit PCM is expanded to PCM16; KSF 16-bit stays PCM16. Original sample rate is retained unless a separate explicit conversion is requested.

## Kontakt guitars (SILVETON_GUITAR_V1)
- `instrumentSets`: a string group is `<token>_<technique>` with token A..H plus an optional digit (E6, E1, H ...);
  the first group of every string is used (libraries keep each group twice); `strings` is "E6 A D G H E1" (space separated).
- `importGroups` (several strings): per-key ownership - the first group in preference order with a zone on a key owns it;
  zones are cut to the owned keys (a private copy of the library holds the cut zones), no key doubled, none left empty.
- `readNkxBlock` (monolith): a tree of blocks. Block = 22-byte header (u32 entry count at +14) + entries
  (u16 len, u32 value, u16 type 1 = folder / else file, name); a folder's value = offset of its block; the data of
  a block's files follows its entries in order (31-byte header with u64 size at +19). Piano monoliths = one flat
  block, guitars = Resources/ + Samples/ folders. Test: tests/KontaktImporterTests.cpp (both layouts).
