# SILVETON MANAGER — STRUCTURE

Updated: 2026-10-22

## Repository
- `gurkov1993cg-debug/SILVETON-MENAGER`
- Active development branch: `silveton-manager-development`
- `main` is preserved.

## Target
- Native Intel iMac 2011 application.
- x86_64 only, C++17 core, Objective-C++/AppKit GUI.
- macOS deployment target 10.13.
- No JUCE, Electron, or browser GUI runtime.

## Product role
`import -> sample edit -> multisample building -> bank/library organization -> deduplication -> SILVETON_BANK.sv`

SOUND editing is intentionally not duplicated in Manager. SOUND editing stays in SILVETON Sampler on the tablet. Manager owns sample editing, multisample editing and bank/library preparation.

Tablet runtime must only open the prepared bank/index and stream audio; it must not rebuild KMP/KSC structures on startup.

## Implemented files
- `CMakeLists.txt`: portable core + Apple-only Objective-C++ AppKit target, x86_64/macOS 10.13, strict warnings as errors. `src/core/SampleEditor.cpp` is part of the real core target. ARC (`-fobjc-arc`) is enabled only for the AppKit Manager target so Objective-C object ivars follow the ownership model used by the GUI code; the C++ core is unchanged.
- `include/silveton/manager/ManagerTypes.h`: canonical Manager sample/multisample/SOUND model and preserved raw Korg metadata.
- `include/silveton/manager/KorgImporter.h`, `src/core/KorgImporter.cpp`: KSF/KMP/KSC import, exact zones/dependencies, canonical PCM16LE. Path handling no longer depends on `std::filesystem`; it uses macOS-10.13-compatible string/POSIX path operations while preserving direct and nested KSF resolution and stable source identities.
- SILVETON_KONTAKT_OLD_V1: Kontakt 2-4 `.nki` (starts with bytes 12 90 A8 7F = 0x7FA89012) is read too: after a short header there is ONE FastLZ stream
  (found by trying the first offsets, `decompressOldNki`) that holds the chunk list directly - program chunk 0x28 first, file name table 0x3D
  (`parseOldFileTable`: u32 version, resource list, then the sample files). Groups 0x33 / zones 0x34 are the same as in Kontakt 5. Checked on
  Ilya Efimov Classic Bass (160 groups, 6312 zones, 34 instruments). tests/KontaktImporterTests.cpp has a small synthetic old file.
- SILVETON_KONTAKT_LISTEN_V1: `KontaktImporter::listenItems` (the samples of one instrument, nothing decoded) and `loadListenAudio` (one sample, the opened
  files are kept between calls). In the import view (СЕМПЛИ → ВНАСЯНЕ ОТ ДИСКА) a click on an instrument row (not on its tick box) opens SVKontaktListenPanel (SVImportPage.mm):
  a small window with that instrument's samples; a click on a sample plays it at once at the rate chosen under the list. Listening only.
- `include/silveton/manager/KontaktImporter.h`, `src/core/KontaktImporter.cpp`, `src/app/KontaktImportController.mm` (SILVETON_KONTAKT_V1): Kontakt 5+ `.nki` import (NI container + FastLZ, groups/zones/file table, `.nkx` monoliths, NCW decoding). One Kontakt group = one SOUND with up to 5 velocity layers (soft, medium, stronger, strong, top hit). The KONTAKT IMPORT window lists the instruments inside the file, shows the sample rate the files claim and the one their pitch fits, and imports only the ticked ones with progress. `tests/KontaktImporterTests.cpp` covers FastLZ, NCW blocks and the layer choice.
- `include/silveton/manager/KeyThinner.h`, `src/core/KeyThinner.cpp` (SILVETON_THIN_V1): decides which notes of loose samples a neighbour can play for (see the section below).
- `include/silveton/manager/PitchDetector.h`, `src/core/PitchDetector.cpp` (SILVETON_PITCH_V1): which note (and octave) a recording is, read from the audio: YIN difference function on a 0.3 s window after the attack, threshold 0.15, an octave check that accepts the doubled period only when its dip is clearly deeper (piano bass notes with a weak fundamental), parabolic interpolation, 25–4500 Hz. `PitchResult` = hz, MIDI note, cents, confidence. 40/40 exact on real piano samples with known roots. `src/app/PitchDetectController.mm` runs it over every sample with progress and shows the РАЗПОЗНАТИ ТОНОВЕ window (tick → ПРИЕМИ ОТБЕЛЯЗАНИТЕ sets root key and fine tune against the detected offset). The СЕМПЛИ page has РАЗПОЗНАЙ ТОНА / ПРИЕМИ ТОНА for one sample. Nothing is changed without the accept key. Tests live in `tests/KontaktImporterTests.cpp`.
- Instrument sets (`KontaktImporter::instrumentSets` / `importSet` / `importGroups`): groups named `<A-G>_<technique>` that exist for at least 3 strings are merged per technique into ONE SOUND (a string-split bass); on a key reached by several strings the string with the highest lowest key wins (first position), so every key plays exactly one sample per velocity layer. Plain groups stay one set each. The import page lists sets, `SVImportKontaktSets` imports them. `probeSampleRate` now reads the pitch with `PitchDetector` (octave-safe) and overrules the rate in the files only when the pitch clearly contradicts it. Test on a hand-built string library in `tests/KontaktImporterTests.cpp`.
- `include/silveton/manager/SampleEditor.h`, `src/core/SampleEditor.cpp`: real offline sample-edit core for PCM16LE/PCM24LE/Float32LE project copies. Implements destructive trim, validated loop metadata/crossfade bounds, explicit user-triggered destructive loop-crossfade baking, frame-correct reverse with loop remap, gain, peak normalize, fade in/out, root key, fine tune, peak readback, nearest zero crossing and waveform min/max envelope generation. Source files on disk are not modified by these operations.
- `include/silveton/manager/SampleHash.h`, `src/core/SampleHash.cpp`: deterministic sample-audio hashing plus exact-byte dedup policy.
- `include/silveton/manager/SvBankFormat.h`, `src/core/SvBankFormat.cpp`: `.sv` v1 explicit little-endian fixed records + SHA-256. The SHA-256 round constant at index 53 is corrected to standard `0x4ed8aa4aU`.
- `include/silveton/manager/SvBankBuilder.h`, `src/core/SvBankBuilder.cpp`: reference validation, string/audio dedup, 4096-byte audio alignment, integrity and atomic writing without `std::filesystem`.
- `include/silveton/manager/SvBankReader.h`, `src/core/SvBankReader.cpp`: bounds/integrity/reference validation and complete project reconstruction.
- `include/silveton/manager/AudioFileLoader.h`, `src/core/AudioFileLoader.cpp`: WAV PCM16/24/Float32, AIFF PCM16/24, AIFC NONE/sowt with supported root/loop metadata, and (SILVETON_NCW_V1) loose Kontakt .ncw files. Path identity, extension and stem handling use macOS-10.13-compatible string/POSIX operations instead of `std::filesystem`.
- `tests/ManagerCoreTests.cpp`: always-active Release regression suite for KSF/KMP/WAV/AIFF, SampleEditor PCM mutation/no-auto-apply behavior, SHA-256, `.sv` round-trip/dedup/corruption/atomic write. Sample-editor coverage checks setLoop metadata without PCM mutation, explicit real loop-crossfade PCM mutation, fade in/out, trim, reverse, gain, normalize, root key, fine tune, zero crossing and waveform generation.

### Native AppKit application (SILVETON_LOOK_V1, 2026-10-13)
One window (`src/app/SVShell.mm`): top bar, four page keys on the left in the order of the work (SILVETON_FIND_V1: the old page ВНАСЯНЕ is part of СЕМПЛИ now), the page in the middle, one status line. Look shared through `src/app/SVTheme.mm` (dark board, amber = on, matte dark = off; panels, keys, toggles, knobs, bars, tables). Pages, each a flipped `SVPageView`:
- `src/app/SVImportPage.mm` – ВНАСЯНЕ (a view, no longer a page; SVSamplesPage holds it, see SILVETON_FIND_V1 below): files of a chosen folder on top (KMP/KSC/KSF/NKI/WAV/AIFF, ticks), in the middle what will come in (for a .nki the instruments with keys / layers / samples / MB and the sample-rate check), the import log at the bottom.
- `src/app/SVSamplesPage.mm` – СЕМПЛИ: tree SOUND → layers → samples, waveform with loop and selection, audition, loop / cut and level / tone edits that run only on ПРИЛОЖИ. Right of the tree it also holds the import (SILVETON_FIND_V1).
- `src/app/SVSoundsPage.mm` – БЛЕНДИ: SOUND list (positions 1..500), layers of the chosen SOUND with velocity ranges, keyboard that shows which sample plays on a key, zone edits.
- `src/app/SVProcessingPage.mm` – ОБРАБОТКА: which SOUNDs, four switches (48 kHz, –6 dB per instrument, even tone, soft limiter), START / STOP, analyzer before / after (SVSpectrumView from `ProcessingController.mm`).
- `src/app/SVBankPage.mm` – БАНКА: content and size, save / load / new project, update a client's bank (adds SOUNDs, keeps the client's data, old bank kept as a copy).
`src/app/SVDocument.h` is the one declaration of `SVManagerDocument` (implemented in `ManagerDocument*.mm`). `src/app/ProcessingController.mm` keeps the progress panel, the import-with-progress call and the analyzer view. `src/app/KontaktImportController.mm` does the Kontakt import with progress. The earlier page controllers (Workflow, Media, Converter, Objects, Organizer, Multisample, Sound, MainWindow, GUIIntegration, FinalGUITheme) are gone.

### SILVETON_MERGE_V1 (2026-10-22): the Manager and the Mac sampler are one program
- `sampler/` is the SILVETON SAMPLER: the sound core (`sampler/core`), the host with CoreAudio / CoreMIDI (`sampler/host`), the screens
  (`sampler/ui`, the same screens as the tablet), the fonts (`sampler/resources/fonts`, copied into the app's Resources/fonts) and stb.
  The same code as the Mac sampler (repo IMAK2011OO) and the tablet; only its libraries are built (`sampler/CMakeLists.txt`:
  imak_ui, imak_gfx, imak_host, silveton_live_core; no tests, no own app). Its own notes: `sampler/STRUCTURE-SAMPLER.md`.
- Page 5 СЕМПЛЕР (`src/app/SVSamplerPage.mm`): `SVSamplerHost` starts the sampler when the program starts (`AppDelegate`) and stops it at
  the end - the window part of the Mac sampler's main.mm (picture view, mouse, keyboard, wheel, 60 Hz clock, bank candidates
  Documents/SILVETON, ~/SILVETON, Documents, Downloads, Desktop). The sound and the MIDI keyboard work on every page; the screens are drawn
  only while page 5 is shown. Menu Семплер > Избери банка за семплера… (Cmd+O) = the Mac sampler's File > Choose bank.
- БАНКА > ЗАПИШИ: after the bank is written (atomically, temp + rename) `SVSamplerHost useBankFile:` makes the sampler load it; its blends
  find their sounds by name (SILVETON_SOUND_BY_NAME_V1).
- Page 2 is ЗВУЦИ now (was БЛЕНДИ) and every Manager text says „звук“ for a SOUND - „бленда“ is only the sampler's blend (7 Uppers).
- Colours of the sampler (SVTheme): green = on / chosen (SVColAmber* keep their names but are green now), white titles, yellow = look here
  (SVColWarn), blue = marked / folder (SVColMark), waveforms and ranges neutral (SVColWave). An action key (kind 1) is a lighter grey key.
- SILVETON_UNUSED_SOUNDS_V1: ЗВУЦИ > ИЗТРИЙ НЕИЗПОЛЗВАНИТЕ ЗВУЦИ. Which sounds are used is worked out by `SVUsedSoundPositions`
  (`src/app/SVUsedSounds.h`, plain C++): every blend of SILVETON_BLENDS.SVSET next to the sampler's bank and of every saved set
  (SILVETON_SETS) - basic sound, layers, TRANSWAVE frames - found by the sampler's own rule (`resolveSoundByName`), plus the COMBI that is
  open now. No blend at all or a file that cannot be read = nothing is deleted. One question (count + names), then
  `deleteObjectKind:3` for each (layers + the samples only they use) from the last to the first; the bank file changes on ЗАПИШИ.
- SILVETON_MULTI_DELETE_V1: see the СЕМПЛИ notes (several marked sounds deleted with one right click).

### `.github/workflows/SILVETON MENAGER.yml`
- Runner `macos-15-intel`, Xcode 16.4, Release x86_64, deployment target 10.13.
- Tests before AppKit build; architecture/deployment/Info.plist/signing/package checks afterward.

## Real Korg regression fixture
User-provided `SALEAS-GRK SH.kmp` + 13 KSF files.
Verified: 14 RLP1 regions; first is `SKIPPEDSAMPL` keys 0..1; 13 playable zones; 48 kHz/16-bit/mono; first playable zone C4/root 60 keys 2..61; raw pan 64 preserved and maps to centre; no fake loop.

## SILVETON_BANK.sv v1 layout
1. Fixed 256-byte header: magic/version/counts/section offsets/SHA-256.
2. SOUND records.
3. SOUND layer records.
4. Multisample records.
5. Sample records.
6. Zone records.
7. Deduplicated string table.
8. 4096-byte-aligned deduplicated audio payload.

## Sample editor scope
Manager sample editing is the authoritative desktop editing layer for:
- waveform visualization;
- trim start/end;
- loop start/end/crossfade;
- normalize and gain;
- fade in/out;
- reverse;
- nearest-zero-crossing assistance;
- root key and fine tune.

All destructive sample-edit operations are explicit user actions. Import and `.sv` build do not auto-normalize, auto-trim, auto-fade, auto-crossfade, auto-reverse, auto-snap loop/start/end points or alter root/tune values without the user's command.

Loop crossfade behavior is real: `applyLoopCrossfade()` linearly blends the selected loop tail with the selected loop head per channel and per sample, writes the overlap into the project-copy audio, advances loop start by the overlap length so the fade-in material is not replayed twice, and clears the pending crossfade metadata after the bake. This function is never called automatically.

## Multisample editor scope
The project model and ManagerDocument bridge now support real multisample zone editing:
- actual sample assignment per zone;
- Key Low / Key High;
- Velocity Low / Velocity High;
- Root Key;
- Transpose;
- Tune cents;
- Gain dB;
- Pan;
- zone add/remove;
- multisample rename;
- automatic contiguous key mapping from selected samples using their actual Root Keys.

The visible piano keyboard/key-zone GUI is not yet implemented in `MainWindowController.mm` at this revision. It must read/write these real zone records and must not be a decorative keyboard.

Manager will not duplicate tablet SOUND parameters such as amp/filter/LFO/portamento/TONE/FX.

## Verification status
- Local Linux Release core/tests: PASS, `ctest` 1/1 for the pre-sample-editor core baseline.
- Intel run `37092662586`: Xcode 16.4 configure PASS; core compile FAILED in `SvBankBuilder.cpp` because libc++ `std::filesystem` is unavailable for deployment target macOS 10.13. `SvBankBuilder.cpp` was corrected without raising the target.
- Intel run `37092813628`: configuration PASS and `SvBankBuilder.cpp` progressed past the prior failure; next failure was `KorgImporter.cpp` for the same macOS 10.13 `std::filesystem` availability rule. `KorgImporter.cpp` was corrected without raising the target.
- Intel run `37108737366` / run 48: `KorgImporter.cpp`, `SvBankBuilder.cpp`, `SvBankReader.cpp`, `SvBankFormat.cpp` progressed through compile. The next real failure was isolated to `tests/ManagerCoreTests.cpp`, where the test fixture still used `std::filesystem` APIs unavailable for a macOS 10.13 deployment target.
- `tests/ManagerCoreTests.cpp` commit `73ff5b5999240b724483556ae185adb397284f45` removes only that test-side incompatibility: string/POSIX temp path creation, file names and cleanup replace `std::filesystem`; the actual regression assertions and Manager behavior are preserved.
- Intel run `37109218356` / run 49: configuration PASS and `ManagerCoreTests.cpp` progressed past the prior failure. The next real compile failure was `src/core/AudioFileLoader.cpp`, where source identity, extension and stem helpers still used `std::filesystem` unavailable at macOS 10.13.
- `src/core/AudioFileLoader.cpp` commit `52947cf4a95ab9784a9f643cb6bea12234173c84` removes only that path-library incompatibility. WAV/AIFF parsing, root/loop metadata, PCM conversion and public API remain unchanged.
- Sample-editor implementation commit `f79a7e33bf1112585cd91a479b975050eda05801` is present.
- Real user-applied loop-crossfade implementation commit `eafe4a8776603103883e31a7f8fdfa482c91340f` is present.
- `SampleEditor.cpp` was added to the core build target in commit `2819851c494639ad3429e1761ec566caeb4b4a0e`.
- Sample-editor regression coverage commit `099babef24741c2b34971eaaa698e4640a4745c5` is present and explicitly checks that editing is user-triggered and PCM changes are real.
- Intel run `37110792932` / run 63: strict x86_64/macOS 10.13 core build including `SampleEditor.cpp` and the expanded regression test executable SUCCEEDED. CTest then failed at the independent SHA-256 standard-vector assertion before the later bank/app stages. The exact source cause was the incorrect SHA-256 K constant `0x4ed8aa4U` in `SvBankFormat.cpp`; it must be `0x4ed8aa4aU`.
- `SvBankFormat.cpp` commit `ae378ab9f1fd5673db7949db25582e6b73eb11bf` corrects only that SHA-256 round constant; the `.sv` API/layout and sample editor are unchanged.
- Intel run `37111451698` / run 69: strict x86_64/macOS 10.13 configuration PASS, core build PASS, expanded sample-editor regression tests PASS (`ctest` 1/1). The AppKit app build then failed only in `MainWindowController.mm` because `NSTextField` does not provide `unsignedLongLongValue`; 12 occurrences affected Trim/Loop/Crossfade/Fade/Zero-Crossing GUI parsing. Core/DSP code was not the cause.
- `MainWindowController.mm` commit `fa1d3537dbea13c001d2793769f5272701a88614` replaces only those unsupported field conversions with explicit validated non-negative uint64 parsing and keeps every edit user-triggered. DSP/editor algorithms, public ManagerDocument bridge and other GUI controls are unchanged.
- Intel run `37111941671` / run 71: complete CI SUCCESS — configure, core build, regression tests, AppKit app build, x86_64/macOS 10.13 verification, ad-hoc signing, packaging and artifact upload all passed. This proves build/package correctness only, not GUI runtime compatibility.
- Physical iMac 2011 / macOS 10.13.6 launch test then FAILED before the GUI became usable. Crash report: `EXC_BAD_ACCESS` on main thread, `objc_msgSend` selector `count`, frame `-[SVMainWindowController tableView:viewForTableColumn:row:]`. The application is confirmed x86-64 native on macOS 10.13.6.
- Root cause: Objective-C++ AppKit code uses ARC-style object ivars, while the Manager target had no ARC compile flag. `sampleDisplayRows` returns an autoreleased `NSMutableArray`; `_sampleRows` stored it in a raw ivar and AppKit later sent `count` after the object lifetime had ended.
- `CMakeLists.txt` commit `ab16701d4a9c6bbfdace99d1bf32d89a4fe45a43` enables `-fobjc-arc` only for `SILVETON_MANAGER`. No C++ core, sample-editor DSP/API, bank format or GUI control logic is changed. A new Intel CI run and another physical High Sierra open test are required before calling the GUI runtime proven.
- `ManagerDocument.mm` sample-edit bridge commit `9c1be226146a8ac2125e822f728e93cf74c4d549` is present.
- `MainWindowController.mm` real waveform/editor GUI wiring commit `5eecd85c88899a6c4463098369d315c5040fdc4a` is present.
- `ManagerDocument.mm` commit `3c6418df8038055e8973e536280e76474a3ecf74` adds the real multisample/zone editing bridge described above. This commit is not yet a proven GUI feature and still requires Intel CI plus visible keyboard/zone wiring in `MainWindowController.mm`.

## Next
1. Wire `MainWindowController.mm` to the real multisample/zone bridge: multisample list, zone list, 128-note key map/piano keyboard and editable zone parameters.
2. Run the exact branch through Intel x86_64/macOS 10.13 CI and fix only real compile/test failures.
3. Install/open the exact successful artifact on the physical iMac 2011/macOS 10.13.6 and verify the window, sample editor and multisample keyboard/zone editor remain usable without crash.
4. Import the real KMP fixture and prove that the visible key map represents its real zones; edit a zone and verify the built `.sv` contains the changed zone values.


## SILVETON INFO / SOUND position contract

- One SILVETON bank supports exactly the address space `SOUND 001` through `SOUND 500`.
- `SoundDefinition::position` is the permanent INFO position used by SILVETON SAMPLER lookup; `0` is only an in-memory/unassigned compatibility value and is never written by a new bank build.
- Positions are unique. A new/duplicated SOUND receives the first free position; a 501st SOUND is rejected.
- `.sv` format v1.1 stores the SOUND position in every SOUND record while keeping v1.0 field offsets intact. The reader maps legacy v1.0 zero padding to sequential positions when possible.
- Samples and multisamples carry stable `uint32_t SampleID` / `MultisampleID`. Zones and SOUND layers write both the legacy array index and the stable ID, allowing the Sampler to build direct ID lookups while preserving v1.0 compatibility.
- KSC import is transactional at collection level: an explicitly referenced missing KMP/KSF fails the import rather than silently dropping zones.
- KSC collection import deduplicates truly identical KSF audio with metadata checks so reused samples share one SampleID.
- KSF 8-bit PCM is expanded to PCM16; KSF 16-bit stays PCM16. Original sample rate is retained unless a separate explicit conversion is requested.

## Kontakt guitars (SILVETON_GUITAR_V1)
- `instrumentSets`: a string group is `<token>_<technique>` with token A..H plus an optional digit (E6, E1, H ...);
  the first group of every string is used (libraries keep each group twice); `strings` is "E6 A D G H E1" (space separated).
- `importGroups` (several strings): per-key ownership - the first group in preference order with a zone on a key owns it;
  zones are cut to the owned keys (a private copy of the library holds the cut zones), no key doubled, none left empty.
- `readNkxBlock` (monolith): a tree of blocks. Block = 22-byte header (u32 entry count at +14) + entries
  (u16 len, u32 value, u16 type 1 = folder / else file, name); then the data of the block in entry order: a file =
  31-byte header (u64 size at +19) + bytes, a folder = its block right there (value = its offset). Checked against
  the .nkc index of AG Samples 1 (all blocks and file offsets) and the head of AG Samples 2. Piano monoliths = one
  flat block, guitars = Resources/ + Samples/ folders. The reader is tolerant: a folder that leads nowhere / back,
  a missing file chain or a bad entry is only noted (`Monolith::note`) and the rest is still read; only a first
  block that is not a block is "damaged", and the message says why (offset, found/expected values). File names are
  also found when only the letter case differs.
- The real break (Ilya Efimov AG/NG/LP/TC Samples 1, bass): the "pictures" folder holds type-4 entries whose data
  carries header magic 0x2AE905FA (kNkxResourceMagic), not 0x16CCF80A, and its length is not stated anywhere, so
  that block cannot be walked through. It holds no audio: the block is left and the folders beside it are read by
  the offset their own entry gives (verified against AG Samples 1.nkc: ir_samples 152, pictures 30080175,
  Samples 32665917 - all exact). Samples 2/3 monoliths have no pictures folder, which is why some instruments
  imported and others stopped. Tests: tests/KontaktImporterTests.cpp (Flat, Folders, Inline, Bogus, Mixed, Pictures).

## Waveform zoom (SILVETON_ZOOM_V1)
- `SampleEditor::buildWaveformRange(sample, start, end, columns, points)` = the picture of frames [start, end) only;
  with fewer frames than columns it returns one point per frame (deep zoom shows the real samples as a line with dots).
  `buildWaveform` is the same call for the whole sample. Document: `waveformAtIndex:startFrame:endFrame:pointCount:error:`.
- `SVWaveView` (SVSamplesPage.mm) holds `viewStart` / `viewLength`; min 24 frames on screen. ЗУУМ +/−, ЦЯЛО, mouse wheel
  (zoom under the cursor), pinch, sideways swipe (move) and the thin bar at the bottom of the wave while zoomed.
  Selection, loop lines and playhead all use the zoomed scale. Loading another sample shows it whole again.

## Delete a blend (SILVETON_DELETE_BLEND_V1)
- `ObjectManager::deleteSoundWithContent` / `soundContent` (preview, same rule): a SOUND goes together with the
  multisamples only it uses and the samples inside them that no other multisample uses; everything else is kept
  and all indexes are remapped. `deleteObjectKind:3` in the document (kinds 0/1/2 unchanged; the ЗВУЦИ page still
  deletes a SOUND alone with kind 2).
- СЕМПЛИ page: ИЗТРИЙ acts on the selected row (blend or sample); right-click on a blend row or a sample row shows
  "Изтрий блендата…" / "Изтрий семпъла…" (both ask first). Tests: tests/ObjectManagerTests.cpp.

## Cut out the marked part (SILVETON_CUT_V1)
- `SampleEditor::cutOut(sample, start, end)` removes [start, end) and joins what is left (the opposite of `trim`,
  which keeps that range and is still used by nothing in the UI). A loop the cut goes through is switched off, a
  loop after the cut moves back, a loop before it stays. The whole sample, an empty mark and a mark past the end
  are refused. Document: `cutOutSampleAtIndex:startFrame:endFrame:error:` (same undo path as the other edits).
- СЕМПЛИ page: the row is "Махни маркираното", the button "МАХНИ СЕЛЕКЦИЯТА"; ПРИЛОЖИ throws the marked part away.
  Tests: tests/ManagerCoreTests.cpp.

## Pitch curve (SILVETON_PITCHCURVE_V1)
- `SampleEditor::applyPitchCurve(sample, curve)`: `curve` holds semitones at evenly spaced points over the whole
  sample (linear between points, +-24 limit). The reading head moves by 2^(semitones/12) per written frame, so the
  length changes with the curve; Catmull-Rom interpolation between frames. A loop is mapped through the same walk
  (start/end recorded while writing) and switched off when it cannot follow. A flat curve touches nothing.
- `SampleEditor::shapeCurve(curve, amount)`: the knob. amount 0 keeps the drawing exactly; 1 replaces it with the
  least-squares fit of `c + a * e^(-t/T)` (T searched over 41 log-spaced values 0.01..2.0, a and c solved exactly),
  in between is a linear mix. Deterministic, no corners at 1.
- `SVWaveView` draws the curve over the wave on the same time axis and, with `penMode`, a drag writes into the
  points the stroke passes (`penAtX:y:`, interpolating along the stroke). СЕМПЛИ page keeps the raw drawing in
  `_curveRaw`, shows `shapeCurve(raw, knob)`, and ПРИЛОЖИ of the КРИВА НА ТОНА section writes it into the audio
  (`applyPitchCurveForSampleAtIndex:curve:`, normal undo). A new sample starts flat.
- Tests: tests/ManagerCoreTests.cpp (octave up/down length and wave count, falling curve, loop mapping, flat =
  untouched, knob at 0/50/100 against a known exact curve).

## Clean wave (SILVETON_CLEANWAVE_V1)
- `WaveSmoother::clean` / `preview` / `noteTrack` (src/core/WaveSmoother.cpp): write a rough sample out again as a
  clean, rounded wave. Nothing is invented - the note, the overtones and the loudness are measured from the sample.
  1. the note at every sample: FFT of a 4x decimated mix -> keep the band the note lives in -> analytic signal ->
     phase slope, then two phase-locked refinement passes (spin back, blur, read the leftover turn).
  2. average every cycle with its neighbours through a cycle->index table (cancels what does not repeat).
  3. measure each overtone against that phase (hop 256, Hann 768) and write the wave back from those overtones.
  4. `edges` pulls both the note and the loudness towards `c + a * e^(-t/T)` (least squares over 41 values of T).
  5. `amount` (0...1 per point along the sample) mixes the result with the original; the peak is matched back.
- Document: `cleanWaveForSampleAtIndex:amount:overtones:edges:` (normal undo) and `cleanWavePreviewAtIndex:...`,
  which returns waveform points for the same work without changing anything.
- СЕМПЛИ page, section ЧИСТА ВЪЛНА: knobs ЧИСТО (sets the whole sample), ТОЧНОСТ (1-12 overtones), РЪБОВЕ
  (how straight the note and the loudness become), the pen over the wave for single places, ИЗЧИСТИ and ПРИЛОЖИ.
  The wave shows the result live while the knobs move; nothing is written until ПРИЛОЖИ.
- Tests: tests/WaveSmootherTests.cpp (rough -> 50x smoother at the same peak, amount 0 changes nothing, the pen
  cleans only the marked part, stereo stays stereo, more overtones keep more detail, too short is refused).

## Editor quality pass (2026-10-14)
- СЕМПЛИ tree: `rebuildTree` keeps which rows were open and which row was picked (key = kind/index), so an edit
  never folds the tree back up.
- One press, one action: МАХНИ СЕЛЕКЦИЯТА cuts at once and ЛУП ОТ СЕЛЕКЦИЯТА sets and saves the loop at once
  (ОТМЕНИ still undoes). ПРИЛОЖИ stays for the typed times, the crossfade and the fades.
- ПРЕИМЕНУВАЙ and КОПИРАЙ act on the picked row, blend or sample, like ИЗТРИЙ; the right-click menu offers all
  three.
- ВНАСЯНЕ bottom row at the smallest window (1280): the rate chooser 12-190, the step chooser 196-406 and
  ВНЕСИ ИЗБРАНИТЕ 414-590 no longer overlap (the note moved up beside the rate line; it used to be given a
  negative width).

## Late start (SILVETON_ATTACK_V1)
- `SampleEditor::findAttack`: 1 ms loudness envelope; the hit is the first point at 25 % of the loudest point -
  where the sound is really there, not the first whisper in front of it (a pick before the note, a breath, a
  hum). From the hit it walks back to where the rise crosses 10 % of the loudest point (the real onset, at most 25 ms
  back), then leaves a 3 ms breath in front of that and moves to the nearest zero crossing - so the line always
  stands a little before the sound, never on it. `hasLateStart` is true over 2 ms of lead-in AND only when the cut cannot land inside the
  sound: what lies in front of it must average under 8 % of the loudest point (a slow swell has already
  started, so nothing is offered) and the cut must sit inside the first third of the sample.
- Document: `lateStartReportForSampleIndexes:points:` (SILVETON_ATTACK_V2) lists the samples that start late - only among
  the indexes handed to it, i.e. the samples of the blend marked in the СЕМПЛИ tree (`markedBlendSamples:` in SVSamplesPage.mm;
  nothing marked = nothing happens) - with the picture of their first
  moments (0 ... just after the first hit) and where the cut would be; `trimLateStartsForSampleIndexes:` cuts
  only the ones handed to it. No per-sample undo entry is kept.
- СЕМПЛИ page, SILVETON_AUTOPLAY_V1: a sample picked BY HAND in the tree starts playing by itself (`autoPlayCurrent`, no ▶ ПУСНИ needed).
  `_quietSelect` is YES while the program moves the selection (refresh/rebuild, `selectNode:`, right-click menu), so those stay silent.
- SILVETON_MULTI_V1: the СЕМПЛИ tree allows several marked rows (Cmd + click / Shift + click). `markedBlendSamples:` gives the samples of all marked blends
  (each once) and a label (БЛЕНДА „X“ / N БЛЕНДИ); ОТРЕЖИ ТИШИНАТА works on them. ИЗТРИЙ / ПРЕИМЕНУВАЙ / КОПИРАЙ refuse when several rows are marked;
  nothing is loaded or played while several rows are marked; a right click on a marked row keeps the marks.
- SILVETON_MULTI_DELETE_V1: a right click on one of several marked rows opens „Изтрий маркираните бленди (N)…“ (only the marked top rows = blends count).
  One question for all of them, then they are deleted from the last to the first (`deleteObjectKind:3` each: layers + the samples only they use; what another blend uses stays).
- SILVETON_ATTACK_V3: the review window has an ON/OFF switch СВИРИ ПРИ МЕСТЕНЕ (off at start). ON = while a green line is dragged the part in
  front of it (sample start ... line = what would be cut away) sounds; a new piece starts when the last one is over (0.35 s at most),
  and the final piece sounds when the mouse goes up. The window gets a play block from the page (`playFirstFrames:ofSample:` in SVSamplesPage.mm,
  frames 0 = stop); it stops when the window closes.
- СЕМПЛИ page: ОТРЕЖИ ТИШИНАТА ПРЕДИ УДАРА opens SVAttackReview (src/app/SVAttackReview.mm) - one row per
  sample, with the first moments drawn: dim before the green cut line (goes), amber after it (stays), the
  lead-in in ms and a tick per row. The green line can be dragged with the mouse: the hand wins over the found
  point, and the lead-in column follows. ОТРЕЖИ cuts each ticked row exactly where its line stands
  (`trimSampleStartsWithIndexes:startFrames:`, moved to the nearest zero crossing first), ОТКАЗ changes nothing.
- Tests: tests/ManagerCoreTests.cpp (quarter-second lead-in found and cut, cutting twice is a no-op, a sample
  that already starts at once is left alone, hiss in front still counts, a silent sample finds nothing).

## Blend from loose samples (SILVETON_AUTOMAP_V1)
- `AutoMapper::listen` (src/core/AutoMapper.cpp) runs PitchDetector over every given sample: which note it is and
  in which octave, plus its peak. `arrange` lays them out: notes sorted, each one holding the keys up to halfway
  towards its neighbours (lowest reaches key 0, highest key 127, no gaps and no key taken twice); samples that
  land on the same note become velocity layers, quietest first. `noteFromText` accepts "C4", "a#3", "Bb2" or "60"
  so a wrong note can be typed over. `build` writes one multisample per velocity layer plus the SOUND whose
  layers carry the velocity bands.
- One-file blends: importing a plain WAV/AIFF/KSF makes a multisample of its own with a single zone over the
  whole keyboard (`sourceIdentity` "single:..."). That is not a real mapping, so `AutoMapper::isSingleBlend`
  recognises it and `looseSampleIndexes` still counts such a sample as free to map. After the real blend is
  written, `AutoMapper::dropSingleBlendsFor` removes the one-file blends of the samples that were mapped
  (through `ObjectManager::deleteMultisampleCascade`, so layers and now-empty SOUNDs go with them and the new
  SOUND's layer indexes stay right); samples are never touched. The review window carries the switch
  "махни старите бленди от по един семпъл" (on by default) and the document keeps the created SOUND by its
  position number, because removing earlier SOUNDs shifts the indexes.
- Document: `looseSampleIndexes` (samples that no real multisample uses), `autoMapPlanForSampleIndexes:`,
  `autoMapArrangeRows:` (after a hand edit), `buildAutoMapWithRows:name:createdIndex:error:` and
  `buildAutoMapWithRows:name:removeOldSingles:createdIndex:removedOldCount:error:`.
- СЕМПЛИ page: НАПРАВИ БЛЕНДА ОТ СЕМПЛИТЕ opens SVAutoMapReview (src/app/SVAutoMapReview.mm): one row per
  sample with its heard note (amber when it is only a guess), the keys it holds, which layer it is, and a strip
  showing where it sits on the keyboard. The note is editable; typing one re-arranges the keyboard at once.
  A name for the blend, ticks per row, ВСИЧКИ / НИЩО, НАПРАВИ БЛЕНДАТА or ОТКАЗ.
- Tests: tests/AutoMapperTests.cpp (three octaves laid out with no gaps and no doubles, one note alone holds the
  whole keyboard, three loudnesses become three layers quietest first, a hand-corrected note moves the keyboard,
  an empty plan is refused, the typed-note parser).

## One press per action (SILVETON_LOOK_V1)
- Every result and every guard used to be an `SVAlert` with an OK button, which made each function two or three
  presses. `SVFlash(title, text, beep)` (src/app/SVShell.mm, declared in SVShell.h) puts the same one-line
  message into the status line at the bottom through `-[SVShellWindowController flashStatus:text:]`; the title
  turns amber and the text stays until the next message or until another page is opened (`showPage:` restores
  the page hint, `refreshBars` leaves the message alone). Guards also beep.
- Windows are kept only where they are needed: errors (`SVAlert(..., YES)`) and the confirmations before
  something is deleted or changes are lost (`SVConfirm`).
- Layout fixes of the same pass: СЛОЕВЕ labels "сила от" / "ниво dB" / "пан −1…1" no longer reach into the
  fields beside them; the ВНЕСИ ИЗБРАНИТЕ key sits on the popup row instead of poking into the text above it;
  ПРЕИМЕНУВАЙ got a wider key; the ОБРАБОТКА note was shortened to the two lines it has room for.
- The two little checkers used for this live in the scratchpad: one computes every control's real frame from the
  source and reports overlaps, the other estimates text width against the frame it has to fit in.

## Blends found by name, same blends (SILVETON_UNIQUE_SOUND_NAME_V1, SILVETON_SAME_BLENDS_V1)
- The sampler finds a SOUND again by its NAME (SILVETON_SOUND_BY_NAME_V1 in the tablet app), so no two SOUNDs of a project should share a name.
  `ObjectManager::uniqueSoundName` gives "Piano" -> "Piano 2" -> "Piano 3" (the SOUND being renamed is skipped). It is used by
  `renameSound`, `createSoundFromMultisample`, the library-entry edit and every import (`ManagerDocument settleImportedSounds` for
  .kmp/.ksc/.ksf/.wav and the new-blend-from-samples path; `KontaktImportController` after `appendKontakt`).
  `ObjectManager::settleNewSounds(project, firstNewSound)` numbers only the newly appended SOUNDs (ascending; a name counts as taken only
  when an EARLIER index has it). Nothing is left out or deleted by an import. Names already in a loaded project/bank are never changed.
- Scan, never automatic: `ObjectManager::soundsSameContent` (same layers - ranges, tuning, level, pan - over multisamples with the same zones,
  over samples with the same audio; names/IDs/positions ignored) and `findSameSounds` (groups of at least two). Nothing is changed by them.
- СЕМПЛИ page: ТЪРСИ ЕДНАКВИ БЛЕНДИ opens SVSameBlendsPanel (SVSamplesPage.mm): one row per blend of each group with a tick box, layers, MB;
  МАРКИРАЙ ЛИШНИТЕ ticks all but the first of every group, the user can tick/untick any row by hand, ИЗТРИЙ МАРКИРАНИТЕ deletes the ticked
  ones through `deleteObjectKind:3` (= `deleteSoundWithContent`, content used by another blend stays). A warning appears when every blend
  of a group is ticked. After deleting the list is rebuilt from a new scan.
- Tests: tests/ObjectManagerTests.cpp (numbering, rename to a taken name, settleNewSounds order, findSameSounds groups).

## Import beside the tree, search below a folder (SILVETON_FIND_V1)
- Pages are four now: СЕМПЛИ (0), БЛЕНДИ (1), ОБРАБОТКА (2), БАНКА (3) (`SVPageIndex` in SVShell.h; menu "Страници" Cmd+1..4; `SVOpenProcessingPage` shows page 2).
- СЕМПЛИ has one more key in the left panel, ВНАСЯНЕ ОТ ДИСКА (amber = the import is shown). The import view (`SVImportPage`, created inside `SVSamplesPage -build`)
  and the three editor panels (wave, ЛУП И РЯЗАНЕ, НИВО И ТОН) occupy the same area on the right of the tree; `setImportShown:` shows one and hides the other.
  The Manager starts with the import shown. Picking a sample BY HAND in the tree (not `_quietSelect`), `selectSampleIndex:` from another page, or pressing the key again
  goes back to the editor (`showEditor`, which also closes the Kontakt listening window). `refresh` and `pageWillHide` of the page are passed on to the import view.
- Import view, top to bottom (722 x 680 at the smallest window): ФАЙЛОВЕ НА ДИСКА (270 high: path line, list, ИЗБЕРИ ПАПКА, ТЪРСИ В ПАПКАТА И ПОД-ПАПКИТЕ, ВСИЧКИ, НИЩО),
  КАКВО ЩЕ ВЛЕЗЕ (grows), ВЛЯЗЛО ДОСЕГА (108 high).
- Search: `InstrumentFinder::search` (include/silveton/manager/InstrumentFinder.h, src/core/InstrumentFinder.cpp, POSIX opendir/lstat because std::filesystem is
  not there for macOS 10.13) walks the folder and all sub-folders and returns ONLY `.nki` and `.kmp` (the samples of a .nki and the .ksf of a .kmp are read from beside
  the instrument file by the importers; .ksc, .ksf, WAV and the rest are not listed). Hidden entries (also macOS "._" copies) and links are skipped; limits 20000 results /
  300000 folders / depth 40 (`cutOff`); a cancel flag stops it (`cancelled`, what was found is kept). It runs on a background queue (`scanPressed:`); the key turns red
  ("■ СПРИ ТЪРСЕНЕТО") and the path line counts folders / finds; a result of an older search is dropped (`_scanGeneration`). The result replaces the left list (folder
  column shown, first row "⬅ обратно към папките" = double click returns to the normal folder view); looking into any folder by hand ends the search list.
  Nothing is ticked or imported by the search. Nothing found: the normal list stays and the status line says so.
- Several .nki ticked: one is open on the right (the first ticked); the others wait ("още N .nki чакат"). After ВНЕСИ the imported files and the open .nki are unticked and
  the next ticked .nki opens (before this change the other ticked .nki were silently dropped).
- Tests: tests/InstrumentFinderTests.cpp (only .nki / .kmp, hidden folder and "._" file and a link back to the top skipped, sorted by folder then name, result limit, depth
  limit, cancel, missing folder, a file given as folder). The app code cannot be compiled on Linux; the search methods of SVImportPage were syntax-checked with clang
  (ARC, blocks, lambdas) against stub AppKit types; the real check is the Mac build.

## Loose .ncw files (SILVETON_NCW_V1)
- A single Kontakt `.ncw` file (compressed wave, magic 0xD69EA801) is read like a WAV: `AudioFileLoader::loadNcw` (include/silveton/manager/AudioFileLoader.h,
  src/core/AudioFileLoader.cpp) calls the same `KontaktImporter::decodeNcw` that reads the samples of a .nki. 16 and 24 bit (a stereo file goes through the same decoder; only mono was tried with a real file). A .ncw holds only the sound
  (rate, bits, length, blocks - nothing after the blocks): no root key, no key range, no loop. Those are in the .nki, so a loose .ncw comes in like a WAV without a
  "smpl" chunk (root key 60, no loop; note recognition / the blend-from-samples path can find the note).
- Wired in at three places that decide "which files are read": `AudioFileLoader::load` (by extension), `MediaPathPolicy::classify` (so the file list of the import view
  shows .ncw files of the chosen folder, name "Kontakt NCW (семпъл)") and `ManagerDocument importPaths` (ManagerDocument.mm). The recursive search
  (`InstrumentFinder`) still lists ONLY .nki and .kmp, on purpose (see above): a loose .ncw is found with ИЗБЕРИ ПАПКА, not with the search.
- Tests: tests/KontaktImporterTests.cpp (16 and 24 bit file on disk, upper case extension, name from the file name, cut file / not-NCW file / missing file are errors),
  tests/MediaPathPolicyTests.cpp (.NCW is importable), tests/InstrumentFinderTests.cpp (.ncw is not listed by the search). Also run once with a real 12 second 48 kHz
  mono .ncw (574720 frames, no jumps, pitch 124.5 Hz).

## Samples without a place are always put on the keyboard (SILVETON_PLACE_V1)
- A sample that comes in on its own (WAV, AIFF, loose .ncw, .ksf) says nothing about which key it belongs to. After every import from the disk
  (`SVImportPage -importPressed:`) the NEW free samples (`looseSampleIndexes` after the import minus the ones that were free before it) go through the same
  steps as the key НАПРАВИ БЛЕНДА ОТ СЕМПЛИТЕ (SILVETON_AUTOMAP_V1): `autoMapPlanForSampleIndexes:` listens to the note and octave of each, `SVReviewAutoMap` shows
  the notes (wrong ones are typed over by hand, rows can be unticked), `buildAutoMapWithRows:...` writes one blend over the keyboard
  (`-placeNewLooseSamplesNotIn:` in src/app/SVImportPage.mm). It runs without any key being pressed.
- Not touched: .kmp / .ksc / .nki bring their own mapping, their samples already sit in real blends (they are not "free"). Samples that were already free BEFORE the
  import (for example after an ОТКАЗ earlier) are not asked about again - the key on СЕМПЛИ still does that.
- ОТКАЗ (or nothing ticked) leaves the samples as before: a blend of one file each, root key from the file or 60. The import log says so. If the sound has no clear
  note, the window shows it amber (a guess) with the note the file carried (default 60).
- The app code cannot be compiled on Linux: `-placeNewLooseSamplesNotIn:` was syntax-checked with clang (ARC, fast enumeration, generics) against stub AppKit
  types; the real check is the Mac build.

## Fewer samples for the same keys, by choice (SILVETON_THIN_V1)
- Where: the window that lays loose samples over the keyboard (`SVReviewAutoMap`, src/app/SVAutoMapReview.mm) - it opens after every import
  (SILVETON_PLACE_V1) and from the key НАПРАВИ БЛЕНДА ОТ СЕМПЛИТЕ. NOT used for .nki (that keeps its own "1 семпъл на 2/3 клавиша" menu in the import view).
- Nothing is thrown away unless the user chooses it. The menu РАЗРЕДИ ТОНОВЕТЕ starts on "на всеки клавиш (нищо не се маха)". Next to it the window ALWAYS
  shows the manager's advice (`_advice`): how many samples (and MB) could go because the neighbour sounds the same, or "няма нужда" because the tones are
  already 3 keys apart / the neighbours sound different. Menu items: every key, 1 sample for 2 keys, 1 sample for 3 keys, "Мениджърът решава сам".
- Core `KeyThinner::decide` (include/silveton/manager/KeyThinner.h, src/core/KeyThinner.cpp) gives one `ThinDecision` per plan entry (drop yes/no, a reason, the
  note that plays for it). Rules: the lowest and the highest note stay; a note with no clear pitch (not heard, or confidence < 0.5) stays and nothing is moved
  across it; a note beside a note with another number of velocity layers (or beside an unclear one) stays; the velocity layers of one note go or stay together;
  two kept notes are never further apart than the step (2 or 3 keys), so a notes set that is already spread (3 keys apart) loses nothing and the notes say
  "KeepSpread". A dropped note is always covered by the nearest kept note (ties to the lower), so the shift is at most one semitone. The kept notes are found
  per run of clear notes with a small dynamic programme: fewest samples first, then the most even spacing.
- `ThinMode::Decide` also listens: for every dropped note the covering sample, shifted, must match it in level (<= 3 dB, loudest 25-100 ms), tuning
  (<= 15 cents, `AutoMapEntry::cents` from the pitch finder), fade-out (time to fall 12 dB within a ratio of 1.6, after the shift) and brightness (spectral centre
  divided by the note, ratio <= 1.35). The limits (kLevelDb, kTuningCents, kDecayRatio, kBrightnessRatio in KeyThinner.cpp) are ESTIMATES, to be tuned on real
  banks. A sample that cannot be measured (too short, silent) is never dropped ("Unknown").
- `ThinMemory` keeps the measured features between looks (the window asks again after each tick / menu change), keyed by sample index and note.
- Document (src/app/ManagerDocument.mm): `autoMapThinMemory`, `autoMapThinRows:ticked:mode:memory:summary:` (rows come back with drop / why / coverNote and the keys laid
  out again over the samples that stay; the summary holds what the chosen way throws away and the advice numbers), and
  `buildAutoMapWithRows:...removeSamples:...removedSampleCount:freedBytes:` - the blend is made from the kept rows, then `AutoMapper::dropSamples` takes the dropped
  samples OUT OF THE PROJECT (`deleteSampleCascade`, from the highest number down; any one-file blend that played only them goes with them). Only samples that are
  still free and not in the new blend can go. Undo history and the sample clipboard are cleared (the numbers moved). The new blend is found again by its position.
- Review window columns: РЕШЕНИЕ says why every note stays or goes ("МАХА СЕ · звучи същото като C4", "стои · вече е разредено" ...); a dropped row is dim, its
  strip shows only a red mark of the note.
- Tests: tests/KeyThinnerTests.cpp (12 notes in a row -> 5 samples for 3 keys, 7 for 2 keys; notes already 3 keys apart lose nothing; notes 2 keys apart lose nothing;
  a louder / differently fading / brighter / detuned note stays and plays for nobody; an unclear note and a note with another layer count are walls; layers go
  together; the memory gives the same answer; `dropSamples` leaves the blend pointing at the right samples) and a cents check in tests/AutoMapperTests.cpp.
  Also run clean under -fsanitize=address,undefined.
- The app code cannot be compiled on Linux. It was syntax-checked with clang against the real GNUstep Foundation/AppKit headers (manual reference counting,
  `-fobjc-runtime=macosx-10.13`), old tree against new tree: no new errors or warnings except two GNUstep-only gaps (`NSTextField lineBreakMode` and `maximumNumberOfLines`,
  which exist on macOS). ARC itself is not checked there; the real check is the Mac build.
