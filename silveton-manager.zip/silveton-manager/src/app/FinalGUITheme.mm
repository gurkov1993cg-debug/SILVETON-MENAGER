#import <AppKit/AppKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>

namespace {

static const void* kSVThemeAppliedKey = &kSVThemeAppliedKey;

NSColor* SVBackgroundColor() { return [NSColor colorWithCalibratedRed:0.035 green:0.047 blue:0.061 alpha:1.0]; }
NSColor* SVPanelColor()      { return [NSColor colorWithCalibratedRed:0.105 green:0.129 blue:0.157 alpha:1.0]; }
NSColor* SVFieldColor()      { return [NSColor colorWithCalibratedRed:0.125 green:0.153 blue:0.184 alpha:1.0]; }
NSColor* SVSelectedColor()   { return [NSColor colorWithCalibratedRed:0.155 green:0.220 blue:0.274 alpha:1.0]; }
NSColor* SVPrimaryTextColor(){ return [NSColor colorWithCalibratedRed:0.850 green:0.875 blue:0.910 alpha:1.0]; }
NSColor* SVMutedTextColor()  { return [NSColor colorWithCalibratedRed:0.450 green:0.500 blue:0.565 alpha:1.0]; }
NSColor* SVAccentColor()     { return [NSColor colorWithCalibratedRed:0.310 green:0.740 blue:1.000 alpha:1.0]; }
NSColor* SVDangerColor()     { return [NSColor colorWithCalibratedRed:0.960 green:0.350 blue:0.370 alpha:1.0]; }
NSColor* SVBorderColor()     { return [NSColor colorWithCalibratedRed:0.190 green:0.225 blue:0.270 alpha:1.0]; }

BOOL SVTitleContains(NSString* title, NSArray<NSString*>* needles) {
    if (title.length == 0U) return NO;
    NSString* lower = title.lowercaseString;
    for (NSString* needle in needles) if ([lower containsString:needle.lowercaseString]) return YES;
    return NO;
}

void SVStyleButton(NSButton* button) {
    if (button == nil) return;
    const BOOL pushButton = button.bezelStyle == NSBezelStyleRounded ||
                            button.bezelStyle == NSBezelStyleTexturedRounded ||
                            button.bezelStyle == NSBezelStyleRecessed;
    if (!pushButton) return;

    NSColor* titleColor = SVPrimaryTextColor();
    NSColor* fillColor = SVFieldColor();
    NSFontWeight weight = NSFontWeightMedium;

    if (SVTitleContains(button.title, @[@"save", @"apply", @"import", @"build", @"create", @"load"])) {
        titleColor = [NSColor colorWithCalibratedWhite:0.96 alpha:1.0];
        fillColor = SVSelectedColor();
        weight = NSFontWeightSemibold;
    } else if (SVTitleContains(button.title, @[@"delete", @"clear", @"remove"])) {
        titleColor = SVDangerColor();
    }

    button.bordered = NO;
    button.wantsLayer = YES;
    button.layer.backgroundColor = fillColor.CGColor;
    button.layer.borderColor = SVBorderColor().CGColor;
    button.layer.borderWidth = 1.0;
    button.layer.cornerRadius = 9.0;
    button.layer.shadowColor = [NSColor blackColor].CGColor;
    button.layer.shadowOpacity = 0.34;
    button.layer.shadowRadius = 3.0;
    button.layer.shadowOffset = CGSizeMake(0.0, -1.0);

    NSMutableParagraphStyle* paragraph = [[NSMutableParagraphStyle alloc] init];
    paragraph.alignment = NSTextAlignmentCenter;
    button.attributedTitle = [[NSAttributedString alloc] initWithString:button.title ?: @""
                                                            attributes:@{
        NSForegroundColorAttributeName: titleColor,
        NSFontAttributeName: [NSFont systemFontOfSize:11.5 weight:weight],
        NSKernAttributeName: @0.35,
        NSParagraphStyleAttributeName: paragraph
    }];
}

void SVStyleTextField(NSTextField* field) {
    if (field == nil) return;
    if (field.editable || field.bezeled) {
        field.drawsBackground = YES;
        field.backgroundColor = SVFieldColor();
        field.textColor = SVPrimaryTextColor();
        field.wantsLayer = YES;
        field.layer.cornerRadius = 7.0;
        field.layer.borderWidth = 1.0;
        field.layer.borderColor = SVBorderColor().CGColor;
        field.font = [NSFont systemFontOfSize:11.5 weight:NSFontWeightRegular];
    } else {
        field.textColor = field.textColor ?: SVPrimaryTextColor();
    }
}

void SVStyleTable(NSTableView* table) {
    if (table == nil) return;
    table.backgroundColor = SVPanelColor();
    table.gridColor = [NSColor colorWithCalibratedWhite:0.09 alpha:1.0];
    table.usesAlternatingRowBackgroundColors = NO;
    table.selectionHighlightStyle = NSTableViewSelectionHighlightStyleRegular;
    if (table.rowHeight < 34.0) table.rowHeight = 34.0;
    if (table.headerView != nil) {
        table.headerView.wantsLayer = YES;
        table.headerView.layer.backgroundColor = SVFieldColor().CGColor;
    }
}

void SVStyleScrollView(NSScrollView* scroll) {
    if (scroll == nil) return;
    scroll.drawsBackground = YES;
    scroll.backgroundColor = SVPanelColor();
    scroll.borderType = NSNoBorder;
    scroll.wantsLayer = YES;
    scroll.layer.cornerRadius = 12.0;
    scroll.layer.borderWidth = 1.0;
    scroll.layer.borderColor = SVBorderColor().CGColor;
}

void SVStyleViewTree(NSView* view) {
    if (view == nil) return;
    if ([view isKindOfClass:[NSTextField class]]) SVStyleTextField((NSTextField*)view);
    else if ([view isKindOfClass:[NSButton class]]) SVStyleButton((NSButton*)view);
    else if ([view isKindOfClass:[NSTableView class]]) SVStyleTable((NSTableView*)view);
    else if ([view isKindOfClass:[NSScrollView class]]) SVStyleScrollView((NSScrollView*)view);
    else if ([view isKindOfClass:[NSPopUpButton class]]) ((NSPopUpButton*)view).font = [NSFont systemFontOfSize:11.5 weight:NSFontWeightMedium];
    else if ([view isKindOfClass:[NSSegmentedControl class]]) ((NSSegmentedControl*)view).font = [NSFont systemFontOfSize:11.5 weight:NSFontWeightMedium];
    for (NSView* child in view.subviews) SVStyleViewTree(child);
}

void SVApplyWindowTheme(NSWindow* window) {
    if (window == nil) return;
    NSNumber* applied = objc_getAssociatedObject(window, kSVThemeAppliedKey);
    if (applied.boolValue) { SVStyleViewTree(window.contentView); return; }

    objc_setAssociatedObject(window, kSVThemeAppliedKey, @YES, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    window.backgroundColor = SVBackgroundColor();
    window.opaque = YES;
    window.hasShadow = YES;
    window.titlebarAppearsTransparent = YES;
    window.movableByWindowBackground = NO;
    window.releasedWhenClosed = NO;
    window.titleVisibility = NSWindowTitleHidden;

    if (window.contentView != nil) {
        window.contentView.wantsLayer = YES;
        window.contentView.layer.backgroundColor = SVBackgroundColor().CGColor;
    }
    SVStyleViewTree(window.contentView);
}

void SVThemeAllWindows(void) { for (NSWindow* window in NSApp.windows) SVApplyWindowTheme(window); }

} // namespace

@interface SVFinalGUITheme : NSObject
@end

@implementation SVFinalGUITheme
+ (void)load {
    [[NSNotificationCenter defaultCenter] addObserverForName:NSApplicationDidFinishLaunchingNotification object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification* note) {
        (void)note; SVThemeAllWindows();
    }];
    [[NSNotificationCenter defaultCenter] addObserverForName:NSWindowDidBecomeKeyNotification object:nil queue:[NSOperationQueue mainQueue] usingBlock:^(NSNotification* note) {
        NSWindow* window = [note.object isKindOfClass:[NSWindow class]] ? (NSWindow*)note.object : nil;
        SVApplyWindowTheme(window);
    }];
}
@end
