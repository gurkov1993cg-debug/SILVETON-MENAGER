#import <AppKit/AppKit.h>

#include <cerrno>
#include <cstdint>
#include <cstdlib>

@interface SVManagerDocument : NSObject
- (BOOL)importPaths:(NSArray<NSString*>*)paths error:(NSString**)error;
- (BOOL)buildBankAtPath:(NSString*)path error:(NSString**)error summary:(NSString**)summary;
- (NSString*)statusSummary;
- (void)clearProject;
- (NSUInteger)sampleCount;
- (NSArray<NSString*>*)sampleDisplayRows;
- (NSDictionary<NSString*, id>*)sampleStateAtIndex:(NSUInteger)index;
- (NSArray<NSNumber*>*)waveformAtIndex:(NSUInteger)index pointCount:(NSUInteger)pointCount error:(NSString**)error;
- (BOOL)trimSampleAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error;
- (BOOL)setLoopForSampleAtIndex:(NSUInteger)index enabled:(BOOL)enabled startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error;
- (BOOL)applyLoopCrossfadeForSampleAtIndex:(NSUInteger)index frames:(uint32_t)frames error:(NSString**)error;
- (BOOL)reverseSampleAtIndex:(NSUInteger)index error:(NSString**)error;
- (BOOL)applyGainForSampleAtIndex:(NSUInteger)index gainDb:(float)gainDb error:(NSString**)error;
- (BOOL)normalizeSampleAtIndex:(NSUInteger)index targetPeakDb:(float)targetPeakDb error:(NSString**)error;
- (BOOL)fadeInSampleAtIndex:(NSUInteger)index frames:(uint64_t)frames error:(NSString**)error;
- (BOOL)fadeOutSampleAtIndex:(NSUInteger)index frames:(uint64_t)frames error:(NSString**)error;
- (BOOL)setRootKeyForSampleAtIndex:(NSUInteger)index rootKey:(uint8_t)rootKey error:(NSString**)error;
- (BOOL)setFineTuneForSampleAtIndex:(NSUInteger)index cents:(float)cents error:(NSString**)error;
- (uint64_t)nearestZeroCrossingForSampleAtIndex:(NSUInteger)index frame:(uint64_t)frame radius:(uint64_t)radius;
@end

@interface SVWaveformView : NSView
@property(nonatomic, copy) NSArray<NSNumber*>* points;
@property(nonatomic) uint64_t totalFrames;
@property(nonatomic) BOOL loopEnabled;
@property(nonatomic) uint64_t loopStart;
@property(nonatomic) uint64_t loopEnd;
@end

@implementation SVWaveformView

- (BOOL)isFlipped { return YES; }

- (void)drawRect:(NSRect)dirtyRect {
    (void)dirtyRect;
    [[NSColor colorWithCalibratedRed:0.030 green:0.070 blue:0.052 alpha:1.0] setFill];
    NSRectFill(self.bounds);

    const CGFloat width = NSWidth(self.bounds);
    const CGFloat height = NSHeight(self.bounds);
    const CGFloat middle = height * 0.5;

    [[NSColor colorWithCalibratedRed:0.250 green:0.320 blue:0.245 alpha:1.0] setStroke];
    NSBezierPath* centre = [NSBezierPath bezierPath];
    [centre moveToPoint:NSMakePoint(0.0, middle)];
    [centre lineToPoint:NSMakePoint(width, middle)];
    centre.lineWidth = 1.0;
    [centre stroke];

    const NSUInteger pairCount = self.points.count / 2U;
    if (pairCount > 0U) {
        NSBezierPath* waveform = [NSBezierPath bezierPath];
        waveform.lineWidth = 1.0;
        for (NSUInteger i = 0U; i < pairCount; ++i) {
            const float minimum = self.points[i * 2U].floatValue;
            const float maximum = self.points[i * 2U + 1U].floatValue;
            const CGFloat x = pairCount <= 1U ? 0.0 : (static_cast<CGFloat>(i) / static_cast<CGFloat>(pairCount - 1U)) * width;
            const CGFloat yMin = middle - static_cast<CGFloat>(maximum) * middle;
            const CGFloat yMax = middle - static_cast<CGFloat>(minimum) * middle;
            [waveform moveToPoint:NSMakePoint(x, yMin)];
            [waveform lineToPoint:NSMakePoint(x, yMax)];
        }
        [[NSColor colorWithCalibratedRed:0.830 green:0.755 blue:0.500 alpha:1.0] setStroke];
        [waveform stroke];
    }

    if (self.loopEnabled && self.totalFrames > 0U && self.loopStart < self.loopEnd) {
        const CGFloat xStart = static_cast<CGFloat>(static_cast<long double>(self.loopStart) / static_cast<long double>(self.totalFrames)) * width;
        const CGFloat xEnd = static_cast<CGFloat>(static_cast<long double>(self.loopEnd) / static_cast<long double>(self.totalFrames)) * width;
        [[NSColor colorWithCalibratedRed:0.560 green:0.740 blue:0.480 alpha:0.95] setStroke];
        NSBezierPath* markers = [NSBezierPath bezierPath];
        markers.lineWidth = 1.5;
        [markers moveToPoint:NSMakePoint(xStart, 0.0)];
        [markers lineToPoint:NSMakePoint(xStart, height)];
        [markers moveToPoint:NSMakePoint(xEnd, 0.0)];
        [markers lineToPoint:NSMakePoint(xEnd, height)];
        [markers stroke];
    }

    [[NSColor colorWithCalibratedRed:0.380 green:0.410 blue:0.300 alpha:1.0] setStroke];
    NSFrameRect(self.bounds);
}

@end

@interface SVBoutiqueButton : NSButton
@end

@implementation SVBoutiqueButton
- (instancetype)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.bordered = NO;
        self.focusRingType = NSFocusRingTypeNone;
        self.wantsLayer = YES;
    }
    return self;
}
- (void)drawRect:(NSRect)dirtyRect {
    (void)dirtyRect;
    NSRect rect = NSInsetRect(self.bounds, 1.0, 1.0);
    NSBezierPath* p = [NSBezierPath bezierPathWithRoundedRect:rect xRadius:4.0 yRadius:4.0];
    const BOOL down = [(NSButtonCell*)self.cell isHighlighted];
    NSColor* fill = down
        ? [NSColor colorWithCalibratedRed:0.555 green:0.505 blue:0.315 alpha:1.0]
        : [NSColor colorWithCalibratedRed:0.655 green:0.600 blue:0.390 alpha:1.0];
    [fill setFill]; [p fill];
    [[NSColor colorWithCalibratedRed:0.285 green:0.300 blue:0.215 alpha:1.0] setStroke];
    p.lineWidth = 1.0; [p stroke];
    NSMutableParagraphStyle* para = [[NSMutableParagraphStyle alloc] init];
    para.alignment = NSTextAlignmentCenter;
    NSAttributedString* t = [[NSAttributedString alloc] initWithString:self.title ?: @"" attributes:@{
        NSForegroundColorAttributeName:[NSColor colorWithCalibratedRed:0.095 green:0.125 blue:0.105 alpha:1.0],
        NSFontAttributeName:[NSFont systemFontOfSize:11.0 weight:NSFontWeightSemibold],
        NSParagraphStyleAttributeName:para
    }];
    NSSize ts = t.size;
    [t drawAtPoint:NSMakePoint(floor((NSWidth(self.bounds)-ts.width)*0.5), floor((NSHeight(self.bounds)-ts.height)*0.5)+1.0)];
}
@end

@interface SVMainWindowController : NSWindowController <NSTableViewDataSource, NSTableViewDelegate>
@end

namespace {

NSTextField* makeLabel(NSRect frame, NSString* text, CGFloat size, NSFontWeight weight, NSColor* color) {
    NSTextField* label = [[NSTextField alloc] initWithFrame:frame];
    label.stringValue = text;
    label.editable = NO;
    label.selectable = NO;
    label.bezeled = NO;
    label.drawsBackground = NO;
    label.font = [NSFont systemFontOfSize:size weight:weight];
    label.textColor = color;
    return label;
}

NSTextField* makeNumericField(NSRect frame, NSString* text) {
    NSTextField* field = [[NSTextField alloc] initWithFrame:frame];
    field.stringValue = text;
    field.bezeled = YES;
    field.editable = YES;
    field.selectable = YES;
    field.drawsBackground = YES;
    field.backgroundColor = [NSColor colorWithCalibratedRed:0.890 green:0.850 blue:0.735 alpha:1.0];
    field.textColor = [NSColor colorWithCalibratedRed:0.100 green:0.140 blue:0.115 alpha:1.0];
    field.font = [NSFont monospacedDigitSystemFontOfSize:12.0 weight:NSFontWeightRegular];
    field.alignment = NSTextAlignmentRight;
    return field;
}

NSButton* makeButton(NSRect frame, NSString* title, id target, SEL action) {
    NSButton* button = [[SVBoutiqueButton alloc] initWithFrame:frame];
    button.title = title;
    button.target = target;
    button.action = action;
        button.font = [NSFont systemFontOfSize:11.5 weight:NSFontWeightMedium];
    button.focusRingType = NSFocusRingTypeNone;
    return button;
}

NSBox* makePanel(NSRect frame, NSString* title) {
    NSBox* panel = [[NSBox alloc] initWithFrame:frame];
    panel.boxType = NSBoxCustom;
    panel.borderType = NSLineBorder;
    panel.borderWidth = 1.0;
    panel.cornerRadius = 5.0;
    panel.borderColor = [NSColor colorWithCalibratedRed:0.315 green:0.335 blue:0.235 alpha:1.0];
    panel.fillColor = [NSColor colorWithCalibratedRed:0.785 green:0.745 blue:0.625 alpha:1.0];
    panel.title = title ?: @"";
    panel.titlePosition = NSAtTop;
    panel.titleFont = [NSFont systemFontOfSize:11.0 weight:NSFontWeightSemibold];
    panel.contentViewMargins = NSMakeSize(14.0, 12.0);
    return panel;
}

void showMessage(NSWindow* window, NSString* title, NSString* message, NSAlertStyle style) {
    NSAlert* alert = [[NSAlert alloc] init];
    alert.messageText = title ?: @"SILVETON Manager";
    alert.informativeText = message ?: @"";
    alert.alertStyle = style;
    [alert beginSheetModalForWindow:window completionHandler:nil];
}

bool parseUnsignedField(NSTextField* field, std::uint64_t& value) noexcept {
    if (field == nil) return false;
    NSString* trimmed = [field.stringValue stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (trimmed.length == 0U || [trimmed hasPrefix:@"-"]) return false;
    const char* text = trimmed.UTF8String;
    if (text == nullptr || *text == '\0') return false;

    errno = 0;
    char* end = nullptr;
    const unsigned long long parsed = std::strtoull(text, &end, 10);
    if (errno == ERANGE || end == text || end == nullptr || *end != '\0') return false;
    value = static_cast<std::uint64_t>(parsed);
    return true;
}

} // namespace

@implementation SVMainWindowController {
    SVManagerDocument* _documentModel;
    NSTableView* _sampleTable;
    SVWaveformView* _waveformView;
    NSTextField* _sampleTitleLabel;
    NSTextField* _sampleInfoLabel;
    NSTextField* _statusLabel;
    NSTextField* _pathLabel;
    NSArray<NSString*>* _sampleRows;

    NSTextField* _trimStartField;
    NSTextField* _trimEndField;
    NSTextField* _loopStartField;
    NSTextField* _loopEndField;
    NSTextField* _crossfadeField;
    NSTextField* _fadeInField;
    NSTextField* _fadeOutField;
    NSTextField* _gainField;
    NSTextField* _normalizeField;
    NSTextField* _rootKeyField;
    NSTextField* _fineTuneField;
    NSTextField* _zeroRadiusField;
}

- (instancetype)init {
    const NSRect rect = NSMakeRect(0.0, 0.0, 1280.0, 820.0);
    NSWindow* window = [[NSWindow alloc] initWithContentRect:rect
                                                  styleMask:(NSWindowStyleMaskTitled |
                                                             NSWindowStyleMaskClosable |
                                                             NSWindowStyleMaskMiniaturizable |
                                                             NSWindowStyleMaskResizable)
                                                    backing:NSBackingStoreBuffered
                                                      defer:NO];
    window.title = @"SILVETON Manager";
    window.minSize = NSMakeSize(1180.0, 760.0);
    window.backgroundColor = [NSColor colorWithCalibratedRed:0.075 green:0.135 blue:0.108 alpha:1.0];

    self = [super initWithWindow:window];
    if (self) {
        _documentModel = [[SVManagerDocument alloc] init];
        _sampleRows = @[];
        [self buildInterface];
        [self refreshProjectView];
    }
    return self;
}

- (void)buildInterface {
    NSView* content = self.window.contentView;
    content.autoresizesSubviews = YES;

    NSColor* primary = [NSColor colorWithCalibratedRed:0.925 green:0.875 blue:0.730 alpha:1.0];
    NSColor* secondary = [NSColor colorWithCalibratedRed:0.770 green:0.735 blue:0.620 alpha:1.0];
    NSColor* accent = [NSColor colorWithCalibratedRed:0.455 green:0.390 blue:0.205 alpha:1.0];
    NSColor* labelColor = [NSColor colorWithCalibratedRed:0.155 green:0.190 blue:0.150 alpha:1.0];

    // Header
    NSTextField* title = makeLabel(NSMakeRect(28.0, 770.0, 420.0, 30.0), @"SILVETON MANAGER", 22.0, NSFontWeightBold, primary);
    title.autoresizingMask = NSViewMinYMargin;
    [content addSubview:title];

    NSTextField* subtitle = makeLabel(NSMakeRect(30.0, 746.0, 760.0, 20.0),
                                      @"KMP / KSC LIBRARY  •  MULTISAMPLE MAPPING  •  SAMPLE EDITING",
                                      11.5, NSFontWeightRegular, secondary);
    subtitle.autoresizingMask = NSViewMinYMargin;
    [content addSubview:subtitle];

    NSButton* importButton = makeButton(NSMakeRect(812.0, 758.0, 150.0, 30.0), @"Import KMP / KSC…", self, @selector(importPressed:));
    importButton.autoresizingMask = NSViewMinXMargin | NSViewMinYMargin;
    [content addSubview:importButton];

    NSButton* clearButton = makeButton(NSMakeRect(970.0, 758.0, 82.0, 30.0), @"Clear", self, @selector(clearPressed:));
    clearButton.autoresizingMask = NSViewMinXMargin | NSViewMinYMargin;
    [content addSubview:clearButton];

    NSButton* buildButton = makeButton(NSMakeRect(1060.0, 758.0, 188.0, 30.0), @"Build SILVETON Bank…", self, @selector(buildPressed:));
    buildButton.autoresizingMask = NSViewMinXMargin | NSViewMinYMargin;
    [content addSubview:buildButton];

    // Left browser panel
    NSBox* browserPanel = makePanel(NSMakeRect(24.0, 104.0, 318.0, 624.0), @"SAMPLES");
    browserPanel.autoresizingMask = NSViewHeightSizable;
    [content addSubview:browserPanel];

    NSScrollView* sampleScroll = [[NSScrollView alloc] initWithFrame:NSMakeRect(12.0, 14.0, 292.0, 572.0)];
    sampleScroll.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    sampleScroll.hasVerticalScroller = YES;
    sampleScroll.hasHorizontalScroller = NO;
    sampleScroll.borderType = NSNoBorder;
    sampleScroll.drawsBackground = YES;
    sampleScroll.backgroundColor = [NSColor colorWithCalibratedRed:0.070 green:0.125 blue:0.100 alpha:1.0];

    _sampleTable = [[NSTableView alloc] initWithFrame:sampleScroll.bounds];
    _sampleTable.headerView = nil;
    _sampleTable.rowHeight = 31.0;
    _sampleTable.intercellSpacing = NSMakeSize(0.0, 1.0);
    _sampleTable.backgroundColor = sampleScroll.backgroundColor;
    _sampleTable.gridStyleMask = NSTableViewGridNone;
    _sampleTable.dataSource = self;
    _sampleTable.delegate = self;
    _sampleTable.allowsMultipleSelection = NO;
    NSTableColumn* sampleColumn = [[NSTableColumn alloc] initWithIdentifier:@"sample"];
    sampleColumn.width = 280.0;
    sampleColumn.resizingMask = NSTableColumnAutoresizingMask;
    [_sampleTable addTableColumn:sampleColumn];
    sampleScroll.documentView = _sampleTable;
    [browserPanel.contentView addSubview:sampleScroll];

    // Main sample editor panel
    NSBox* editorPanel = makePanel(NSMakeRect(356.0, 104.0, 900.0, 624.0), @"SAMPLE EDITOR");
    editorPanel.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    [content addSubview:editorPanel];
    NSView* e = editorPanel.contentView;

    _sampleTitleLabel = makeLabel(NSMakeRect(16.0, 566.0, 620.0, 24.0), @"No sample selected", 15.0, NSFontWeightSemibold, [NSColor colorWithCalibratedRed:0.105 green:0.145 blue:0.120 alpha:1.0]);
    _sampleTitleLabel.autoresizingMask = NSViewWidthSizable | NSViewMinYMargin;
    [e addSubview:_sampleTitleLabel];

    _sampleInfoLabel = makeLabel(NSMakeRect(16.0, 544.0, 840.0, 18.0), @"", 10.5, NSFontWeightRegular, [NSColor colorWithCalibratedRed:0.240 green:0.260 blue:0.205 alpha:1.0]);
    _sampleInfoLabel.autoresizingMask = NSViewWidthSizable | NSViewMinYMargin;
    [e addSubview:_sampleInfoLabel];

    _waveformView = [[SVWaveformView alloc] initWithFrame:NSMakeRect(16.0, 332.0, 840.0, 202.0)];
    _waveformView.autoresizingMask = NSViewWidthSizable | NSViewMinYMargin;
    _waveformView.wantsLayer = YES;
    _waveformView.layer.cornerRadius = 6.0;
    _waveformView.layer.masksToBounds = YES;
    [e addSubview:_waveformView];

    // Editing cards
    NSBox* rangePanel = makePanel(NSMakeRect(16.0, 168.0, 410.0, 150.0), @"RANGE & LOOP");
    rangePanel.autoresizingMask = NSViewMinYMargin;
    [e addSubview:rangePanel];
    NSView* r = rangePanel.contentView;

    [r addSubview:makeLabel(NSMakeRect(8.0, 92.0, 34.0, 18.0), @"Trim", 10.5, NSFontWeightSemibold, accent)];
    [r addSubview:makeLabel(NSMakeRect(50.0, 92.0, 34.0, 18.0), @"Start", 10.0, NSFontWeightRegular, labelColor)];
    _trimStartField = makeNumericField(NSMakeRect(86.0, 88.0, 76.0, 24.0), @"0"); [r addSubview:_trimStartField];
    [r addSubview:makeLabel(NSMakeRect(170.0, 92.0, 26.0, 18.0), @"End", 10.0, NSFontWeightRegular, labelColor)];
    _trimEndField = makeNumericField(NSMakeRect(198.0, 88.0, 76.0, 24.0), @"0"); [r addSubview:_trimEndField];
    [r addSubview:makeButton(NSMakeRect(282.0, 86.0, 102.0, 27.0), @"Apply Trim", self, @selector(trimPressed:))];

    [r addSubview:makeLabel(NSMakeRect(8.0, 56.0, 34.0, 18.0), @"Loop", 10.5, NSFontWeightSemibold, accent)];
    [r addSubview:makeLabel(NSMakeRect(50.0, 56.0, 34.0, 18.0), @"Start", 10.0, NSFontWeightRegular, labelColor)];
    _loopStartField = makeNumericField(NSMakeRect(86.0, 52.0, 76.0, 24.0), @"0"); [r addSubview:_loopStartField];
    [r addSubview:makeLabel(NSMakeRect(170.0, 56.0, 26.0, 18.0), @"End", 10.0, NSFontWeightRegular, labelColor)];
    _loopEndField = makeNumericField(NSMakeRect(198.0, 52.0, 76.0, 24.0), @"0"); [r addSubview:_loopEndField];
    [r addSubview:makeButton(NSMakeRect(282.0, 50.0, 48.0, 27.0), @"Set", self, @selector(setLoopPressed:))];
    [r addSubview:makeButton(NSMakeRect(334.0, 50.0, 50.0, 27.0), @"Off", self, @selector(loopOffPressed:))];

    _crossfadeField = makeNumericField(NSMakeRect(86.0, 16.0, 76.0, 24.0), @"0"); [r addSubview:_crossfadeField];
    [r addSubview:makeLabel(NSMakeRect(8.0, 20.0, 70.0, 18.0), @"Crossfade", 10.0, NSFontWeightRegular, labelColor)];
    [r addSubview:makeButton(NSMakeRect(170.0, 14.0, 112.0, 27.0), @"Apply X-Fade", self, @selector(crossfadePressed:))];
    [r addSubview:makeButton(NSMakeRect(288.0, 14.0, 46.0, 27.0), @"S◀", self, @selector(snapLoopStartPressed:))];
    [r addSubview:makeButton(NSMakeRect(338.0, 14.0, 46.0, 27.0), @"E▶", self, @selector(snapLoopEndPressed:))];

    NSBox* processPanel = makePanel(NSMakeRect(438.0, 168.0, 418.0, 150.0), @"PROCESS & TUNING");
    processPanel.autoresizingMask = NSViewMinXMargin | NSViewMinYMargin;
    [e addSubview:processPanel];
    NSView* q = processPanel.contentView;

    [q addSubview:makeLabel(NSMakeRect(8.0, 92.0, 48.0, 18.0), @"Fade In", 10.0, NSFontWeightRegular, labelColor)];
    _fadeInField = makeNumericField(NSMakeRect(58.0, 88.0, 72.0, 24.0), @"0"); [q addSubview:_fadeInField];
    [q addSubview:makeButton(NSMakeRect(136.0, 86.0, 58.0, 27.0), @"Apply", self, @selector(fadeInPressed:))];
    [q addSubview:makeLabel(NSMakeRect(208.0, 92.0, 54.0, 18.0), @"Fade Out", 10.0, NSFontWeightRegular, labelColor)];
    _fadeOutField = makeNumericField(NSMakeRect(264.0, 88.0, 72.0, 24.0), @"0"); [q addSubview:_fadeOutField];
    [q addSubview:makeButton(NSMakeRect(342.0, 86.0, 58.0, 27.0), @"Apply", self, @selector(fadeOutPressed:))];

    [q addSubview:makeLabel(NSMakeRect(8.0, 56.0, 46.0, 18.0), @"Gain dB", 10.0, NSFontWeightRegular, labelColor)];
    _gainField = makeNumericField(NSMakeRect(58.0, 52.0, 72.0, 24.0), @"0.0"); [q addSubview:_gainField];
    [q addSubview:makeButton(NSMakeRect(136.0, 50.0, 58.0, 27.0), @"Apply", self, @selector(gainPressed:))];
    [q addSubview:makeLabel(NSMakeRect(208.0, 56.0, 52.0, 18.0), @"Peak dB", 10.0, NSFontWeightRegular, labelColor)];
    _normalizeField = makeNumericField(NSMakeRect(264.0, 52.0, 72.0, 24.0), @"-1.0"); [q addSubview:_normalizeField];
    [q addSubview:makeButton(NSMakeRect(342.0, 50.0, 58.0, 27.0), @"Norm", self, @selector(normalizePressed:))];

    [q addSubview:makeLabel(NSMakeRect(8.0, 20.0, 46.0, 18.0), @"Root", 10.0, NSFontWeightRegular, labelColor)];
    _rootKeyField = makeNumericField(NSMakeRect(58.0, 16.0, 56.0, 24.0), @"60"); [q addSubview:_rootKeyField];
    [q addSubview:makeLabel(NSMakeRect(124.0, 20.0, 40.0, 18.0), @"Cents", 10.0, NSFontWeightRegular, labelColor)];
    _fineTuneField = makeNumericField(NSMakeRect(166.0, 16.0, 62.0, 24.0), @"0.0"); [q addSubview:_fineTuneField];
    [q addSubview:makeButton(NSMakeRect(236.0, 14.0, 76.0, 27.0), @"Tuning", self, @selector(tuningPressed:))];
    [q addSubview:makeButton(NSMakeRect(318.0, 14.0, 82.0, 27.0), @"Reverse", self, @selector(reversePressed:))];

    // Keep the zero-cross radius user-controlled but out of the primary flow.
    _zeroRadiusField = makeNumericField(NSMakeRect(770.0, 126.0, 64.0, 22.0), @"256");
    [e addSubview:makeLabel(NSMakeRect(690.0, 129.0, 76.0, 18.0), @"Zero radius", 9.5, NSFontWeightRegular, secondary)];
    [e addSubview:_zeroRadiusField];
    [e addSubview:makeButton(NSMakeRect(16.0, 124.0, 94.0, 27.0), @"Snap Trim S", self, @selector(snapTrimStartPressed:))];
    [e addSubview:makeButton(NSMakeRect(116.0, 124.0, 94.0, 27.0), @"Snap Trim E", self, @selector(snapTrimEndPressed:))];

    _statusLabel = makeLabel(NSMakeRect(28.0, 70.0, 1220.0, 20.0), @"", 11.5, NSFontWeightMedium, accent);
    _statusLabel.autoresizingMask = NSViewWidthSizable | NSViewMaxYMargin;
    [content addSubview:_statusLabel];

    _pathLabel = makeLabel(NSMakeRect(28.0, 46.0, 1220.0, 18.0), @"Bank not built yet", 10.5, NSFontWeightRegular, secondary);
    _pathLabel.lineBreakMode = NSLineBreakByTruncatingMiddle;
    _pathLabel.autoresizingMask = NSViewWidthSizable | NSViewMaxYMargin;
    [content addSubview:_pathLabel];
}

- (NSUInteger)selectedSampleIndex {
    const NSInteger row = _sampleTable.selectedRow;
    return row < 0 ? NSNotFound : static_cast<NSUInteger>(row);
}

- (void)refreshProjectView {
    const NSInteger oldSelection = _sampleTable.selectedRow;
    _sampleRows = [_documentModel sampleDisplayRows];
    [_sampleTable reloadData];
    _statusLabel.stringValue = [_documentModel statusSummary];

    if (_sampleRows.count == 0U) {
        [_sampleTable deselectAll:nil];
        [self refreshSelectedSample];
        return;
    }

    NSInteger selection = oldSelection;
    if (selection < 0 || static_cast<NSUInteger>(selection) >= _sampleRows.count) selection = 0;
    [_sampleTable selectRowIndexes:[NSIndexSet indexSetWithIndex:static_cast<NSUInteger>(selection)] byExtendingSelection:NO];
    [self refreshSelectedSample];
}

- (void)refreshSelectedSample {
    const NSUInteger index = [self selectedSampleIndex];
    if (index == NSNotFound) {
        _sampleTitleLabel.stringValue = @"No sample selected";
        _sampleInfoLabel.stringValue = @"";
        _waveformView.points = @[];
        _waveformView.totalFrames = 0U;
        _waveformView.loopEnabled = NO;
        [_waveformView setNeedsDisplay:YES];
        return;
    }

    NSDictionary<NSString*, id>* state = [_documentModel sampleStateAtIndex:index];
    if (state == nil) return;
    _sampleTitleLabel.stringValue = state[@"name"] ?: @"Sample";

    const unsigned int sampleRate = [state[@"sampleRate"] unsignedIntValue];
    const unsigned int channels = [state[@"channels"] unsignedIntValue];
    const unsigned long long totalFrames = [state[@"totalFrames"] unsignedLongLongValue];
    const float peakDb = [state[@"peakDb"] floatValue];
    _sampleInfoLabel.stringValue = [NSString stringWithFormat:@"%u Hz · %u channel%@ · %llu frames · peak %.2f dBFS",
                                    sampleRate, channels, channels == 1U ? @"" : @"s", totalFrames, peakDb];

    NSString* waveformError = nil;
    NSArray<NSNumber*>* waveform = [_documentModel waveformAtIndex:index pointCount:1200U error:&waveformError];
    if (waveform == nil) {
        _waveformView.points = @[];
        if (waveformError.length != 0U) _sampleInfoLabel.stringValue = waveformError;
    } else {
        _waveformView.points = waveform;
    }
    _waveformView.totalFrames = static_cast<uint64_t>(totalFrames);
    _waveformView.loopEnabled = [state[@"loopEnabled"] boolValue];
    _waveformView.loopStart = [state[@"loopStart"] unsignedLongLongValue];
    _waveformView.loopEnd = [state[@"loopEnd"] unsignedLongLongValue];
    [_waveformView setNeedsDisplay:YES];

    _trimStartField.stringValue = @"0";
    _trimEndField.stringValue = [NSString stringWithFormat:@"%llu", totalFrames];
    _loopStartField.stringValue = [NSString stringWithFormat:@"%llu", [state[@"loopStart"] unsignedLongLongValue]];
    _loopEndField.stringValue = [NSString stringWithFormat:@"%llu", [state[@"loopEnd"] unsignedLongLongValue]];
    _crossfadeField.stringValue = [NSString stringWithFormat:@"%u", [state[@"crossfadeFrames"] unsignedIntValue]];
    _rootKeyField.stringValue = [NSString stringWithFormat:@"%u", [state[@"rootKey"] unsignedIntValue]];
    _fineTuneField.stringValue = [NSString stringWithFormat:@"%.2f", [state[@"fineTuneCents"] floatValue]];
}

- (NSInteger)numberOfRowsInTableView:(NSTableView*)tableView {
    (void)tableView;
    return static_cast<NSInteger>(_sampleRows.count);
}

- (NSView*)tableView:(NSTableView*)tableView viewForTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView;
    (void)tableColumn;
    if (row < 0 || static_cast<NSUInteger>(row) >= _sampleRows.count) return nil;
    NSTextField* cell = makeLabel(NSMakeRect(8.0, 4.0, 300.0, 22.0), _sampleRows[static_cast<NSUInteger>(row)], 11.0,
                                  NSFontWeightRegular, [NSColor colorWithCalibratedWhite:0.88 alpha:1.0]);
    cell.autoresizingMask = NSViewWidthSizable;
    return cell;
}

- (void)tableViewSelectionDidChange:(NSNotification*)notification {
    (void)notification;
    [self refreshSelectedSample];
}

- (BOOL)requireSelectedSample:(NSUInteger*)indexOut {
    const NSUInteger index = [self selectedSampleIndex];
    if (index == NSNotFound) {
        showMessage(self.window, @"No sample selected", @"Select a sample first.", NSAlertStyleWarning);
        return NO;
    }
    if (indexOut != nullptr) *indexOut = index;
    return YES;
}

- (BOOL)readUnsignedField:(NSTextField*)field label:(NSString*)label value:(uint64_t*)valueOut {
    std::uint64_t value = 0U;
    if (!parseUnsignedField(field, value)) {
        showMessage(self.window, @"Invalid numeric value",
                    [NSString stringWithFormat:@"%@ must be a non-negative whole number.", label], NSAlertStyleWarning);
        return NO;
    }
    if (valueOut != nullptr) *valueOut = value;
    return YES;
}

- (void)finishEditWithError:(NSString*)error title:(NSString*)title {
    if (error.length != 0U) {
        showMessage(self.window, title, error, NSAlertStyleCritical);
        return;
    }
    [self refreshProjectView];
}

- (void)importPressed:(id)sender {
    (void)sender;
    NSOpenPanel* panel = [NSOpenPanel openPanel];
    panel.title = @"Import KMP/KSC collection or sampler material";
    panel.prompt = @"Import";
    panel.canChooseFiles = YES;
    panel.canChooseDirectories = NO;
    panel.allowsMultipleSelection = YES;
    panel.resolvesAliases = YES;
    panel.allowedFileTypes = @[@"kmp", @"KMP", @"ksc", @"KSC", @"ksf", @"KSF",
                               @"wav", @"WAV", @"wave", @"WAVE", @"aif", @"AIF", @"aiff", @"AIFF", @"aifc", @"AIFC"];

    if ([panel runModal] != NSModalResponseOK) return;
    NSMutableArray<NSString*>* paths = [NSMutableArray arrayWithCapacity:panel.URLs.count];
    for (NSURL* url in panel.URLs) {
        if (url.fileURL && url.path != nil) [paths addObject:url.path];
    }

    NSString* details = nil;
    if (![_documentModel importPaths:paths error:&details]) {
        showMessage(self.window, @"Import failed", details ?: @"No sampler material was imported.", NSAlertStyleCritical);
        return;
    }
    [self refreshProjectView];
    if (details.length != 0U) showMessage(self.window, @"Imported with warnings", details, NSAlertStyleWarning);
}

- (void)clearPressed:(id)sender {
    (void)sender;
    if (_sampleRows.count == 0U) return;
    NSAlert* alert = [[NSAlert alloc] init];
    alert.messageText = @"Clear the current Manager project?";
    alert.informativeText = @"Imported and edited project-copy data will be cleared. Original source files and already built .sv banks are not deleted.";
    [alert addButtonWithTitle:@"Clear"];
    [alert addButtonWithTitle:@"Cancel"];
    alert.alertStyle = NSAlertStyleWarning;
    if ([alert runModal] != NSAlertFirstButtonReturn) return;
    [_documentModel clearProject];
    _pathLabel.stringValue = @"Bank not built yet";
    [self refreshProjectView];
}

- (void)buildPressed:(id)sender {
    (void)sender;
    if (_sampleRows.count == 0U) {
        showMessage(self.window, @"Nothing to build", @"Import at least one KMP/KSC/KSF/WAV/AIFF resource first.", NSAlertStyleWarning);
        return;
    }

    NSSavePanel* panel = [NSSavePanel savePanel];
    panel.title = @"Build SILVETON bank";
    panel.prompt = @"Build Bank";
    panel.nameFieldStringValue = @"SILVETON_BANK.sv";
    panel.allowedFileTypes = @[@"sv"];
    panel.allowsOtherFileTypes = NO;
    panel.canCreateDirectories = YES;
    if ([panel runModal] != NSModalResponseOK || panel.URL.path == nil) return;

    NSString* error = nil;
    NSString* summary = nil;
    if (![_documentModel buildBankAtPath:panel.URL.path error:&error summary:&summary]) {
        showMessage(self.window, @"Bank build failed", error ?: @"Unknown bank build error.", NSAlertStyleCritical);
        return;
    }

    _pathLabel.stringValue = [NSString stringWithFormat:@"Built: %@", panel.URL.path];
    showMessage(self.window, @"SILVETON bank built", summary ?: @"Bank build completed.", NSAlertStyleInformational);
}

- (void)trimPressed:(id)sender {
    (void)sender;
    NSUInteger index = 0U; if (![self requireSelectedSample:&index]) return;
    uint64_t startFrame = 0U;
    uint64_t endFrame = 0U;
    if (![self readUnsignedField:_trimStartField label:@"Trim Start" value:&startFrame] ||
        ![self readUnsignedField:_trimEndField label:@"Trim End" value:&endFrame]) return;
    NSString* error = nil;
    [_documentModel trimSampleAtIndex:index startFrame:startFrame endFrame:endFrame error:&error];
    [self finishEditWithError:error title:@"Trim failed"];
}

- (void)setLoopPressed:(id)sender {
    (void)sender;
    NSUInteger index = 0U; if (![self requireSelectedSample:&index]) return;
    uint64_t startFrame = 0U;
    uint64_t endFrame = 0U;
    if (![self readUnsignedField:_loopStartField label:@"Loop Start" value:&startFrame] ||
        ![self readUnsignedField:_loopEndField label:@"Loop End" value:&endFrame]) return;
    NSString* error = nil;
    [_documentModel setLoopForSampleAtIndex:index enabled:YES startFrame:startFrame endFrame:endFrame error:&error];
    [self finishEditWithError:error title:@"Set Loop failed"];
}

- (void)loopOffPressed:(id)sender {
    (void)sender;
    NSUInteger index = 0U; if (![self requireSelectedSample:&index]) return;
    NSString* error = nil;
    [_documentModel setLoopForSampleAtIndex:index enabled:NO startFrame:0U endFrame:0U error:&error];
    [self finishEditWithError:error title:@"Loop Off failed"];
}

- (void)crossfadePressed:(id)sender {
    (void)sender;
    NSUInteger index = 0U; if (![self requireSelectedSample:&index]) return;
    uint64_t requested = 0U;
    if (![self readUnsignedField:_crossfadeField label:@"Loop Crossfade" value:&requested]) return;
    if (requested > UINT32_MAX) {
        showMessage(self.window, @"Crossfade failed", @"Crossfade frame count is too large.", NSAlertStyleWarning);
        return;
    }
    NSString* error = nil;
    [_documentModel applyLoopCrossfadeForSampleAtIndex:index frames:static_cast<uint32_t>(requested) error:&error];
    [self finishEditWithError:error title:@"Crossfade failed"];
}

- (void)fadeInPressed:(id)sender {
    (void)sender;
    NSUInteger index = 0U; if (![self requireSelectedSample:&index]) return;
    uint64_t frames = 0U;
    if (![self readUnsignedField:_fadeInField label:@"Fade In" value:&frames]) return;
    NSString* error = nil;
    [_documentModel fadeInSampleAtIndex:index frames:frames error:&error];
    [self finishEditWithError:error title:@"Fade In failed"];
}

- (void)fadeOutPressed:(id)sender {
    (void)sender;
    NSUInteger index = 0U; if (![self requireSelectedSample:&index]) return;
    uint64_t frames = 0U;
    if (![self readUnsignedField:_fadeOutField label:@"Fade Out" value:&frames]) return;
    NSString* error = nil;
    [_documentModel fadeOutSampleAtIndex:index frames:frames error:&error];
    [self finishEditWithError:error title:@"Fade Out failed"];
}

- (void)gainPressed:(id)sender {
    (void)sender;
    NSUInteger index = 0U; if (![self requireSelectedSample:&index]) return;
    NSString* error = nil;
    [_documentModel applyGainForSampleAtIndex:index gainDb:_gainField.floatValue error:&error];
    [self finishEditWithError:error title:@"Gain failed"];
}

- (void)normalizePressed:(id)sender {
    (void)sender;
    NSUInteger index = 0U; if (![self requireSelectedSample:&index]) return;
    NSString* error = nil;
    [_documentModel normalizeSampleAtIndex:index targetPeakDb:_normalizeField.floatValue error:&error];
    [self finishEditWithError:error title:@"Normalize failed"];
}

- (void)reversePressed:(id)sender {
    (void)sender;
    NSUInteger index = 0U; if (![self requireSelectedSample:&index]) return;
    NSString* error = nil;
    [_documentModel reverseSampleAtIndex:index error:&error];
    [self finishEditWithError:error title:@"Reverse failed"];
}

- (void)tuningPressed:(id)sender {
    (void)sender;
    NSUInteger index = 0U; if (![self requireSelectedSample:&index]) return;
    const NSInteger root = _rootKeyField.integerValue;
    const float cents = _fineTuneField.floatValue;
    if (root < 0 || root > 127) {
        showMessage(self.window, @"Tuning failed", @"Root Key must be between 0 and 127.", NSAlertStyleWarning);
        return;
    }
    if (cents < -100.0F || cents > 100.0F) {
        showMessage(self.window, @"Tuning failed", @"Fine Tune must be between -100 and +100 cents.", NSAlertStyleWarning);
        return;
    }

    NSString* error = nil;
    if (![_documentModel setRootKeyForSampleAtIndex:index rootKey:static_cast<uint8_t>(root) error:&error]) {
        [self finishEditWithError:error title:@"Tuning failed"];
        return;
    }
    if (![_documentModel setFineTuneForSampleAtIndex:index cents:cents error:&error]) {
        [self finishEditWithError:error title:@"Tuning failed"];
        return;
    }
    [self finishEditWithError:nil title:@"Tuning failed"];
}

- (BOOL)readZeroRadius:(uint64_t*)radiusOut {
    return [self readUnsignedField:_zeroRadiusField label:@"Zero radius" value:radiusOut];
}

- (void)snapTrimStartPressed:(id)sender {
    (void)sender;
    NSUInteger index = 0U; if (![self requireSelectedSample:&index]) return;
    uint64_t frame = 0U;
    uint64_t radius = 0U;
    if (![self readUnsignedField:_trimStartField label:@"Trim Start" value:&frame] || ![self readZeroRadius:&radius]) return;
    const uint64_t snapped = [_documentModel nearestZeroCrossingForSampleAtIndex:index frame:frame radius:radius];
    _trimStartField.stringValue = [NSString stringWithFormat:@"%llu", static_cast<unsigned long long>(snapped)];
}

- (void)snapTrimEndPressed:(id)sender {
    (void)sender;
    NSUInteger index = 0U; if (![self requireSelectedSample:&index]) return;
    uint64_t frame = 0U;
    uint64_t radius = 0U;
    if (![self readUnsignedField:_trimEndField label:@"Trim End" value:&frame] || ![self readZeroRadius:&radius]) return;
    const uint64_t snapped = [_documentModel nearestZeroCrossingForSampleAtIndex:index frame:frame radius:radius];
    _trimEndField.stringValue = [NSString stringWithFormat:@"%llu", static_cast<unsigned long long>(snapped)];
}

- (void)snapLoopStartPressed:(id)sender {
    (void)sender;
    NSUInteger index = 0U; if (![self requireSelectedSample:&index]) return;
    uint64_t frame = 0U;
    uint64_t radius = 0U;
    if (![self readUnsignedField:_loopStartField label:@"Loop Start" value:&frame] || ![self readZeroRadius:&radius]) return;
    const uint64_t snapped = [_documentModel nearestZeroCrossingForSampleAtIndex:index frame:frame radius:radius];
    _loopStartField.stringValue = [NSString stringWithFormat:@"%llu", static_cast<unsigned long long>(snapped)];
}

- (void)snapLoopEndPressed:(id)sender {
    (void)sender;
    NSUInteger index = 0U; if (![self requireSelectedSample:&index]) return;
    uint64_t frame = 0U;
    uint64_t radius = 0U;
    if (![self readUnsignedField:_loopEndField label:@"Loop End" value:&frame] || ![self readZeroRadius:&radius]) return;
    const uint64_t snapped = [_documentModel nearestZeroCrossingForSampleAtIndex:index frame:frame radius:radius];
    _loopEndField.stringValue = [NSString stringWithFormat:@"%llu", static_cast<unsigned long long>(snapped)];
}

@end
