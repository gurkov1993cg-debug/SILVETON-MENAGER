#import <AppKit/AppKit.h>

#include <cerrno>
#include <cstdint>
#include <cstdlib>

@interface SVManagerDocument : NSObject
- (BOOL)importPaths:(NSArray<NSString*>*)paths error:(NSString**)error;
- (BOOL)buildBankAtPath:(NSString*)path error:(NSString**)error summary:(NSString**)summary;
- (NSString*)statusSummary;
- (void)clearProject;
- (NSUInteger)sampleCount;
- (NSArray<NSString*>*)sampleDisplayRows;
- (NSDictionary<NSString*, id>*)sampleStateAtIndex:(NSUInteger)index;
- (NSArray<NSNumber*>*)waveformAtIndex:(NSUInteger)index pointCount:(NSUInteger)pointCount error:(NSString**)error;
- (BOOL)trimSampleAtIndex:(NSUInteger)index startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error;
- (BOOL)setLoopForSampleAtIndex:(NSUInteger)index enabled:(BOOL)enabled startFrame:(uint64_t)startFrame endFrame:(uint64_t)endFrame error:(NSString**)error;
- (BOOL)applyLoopCrossfadeForSampleAtIndex:(NSUInteger)index frames:(uint32_t)frames error:(NSString**)error;
- (BOOL)reverseSampleAtIndex:(NSUInteger)index error:(NSString**)error;
- (BOOL)applyGainForSampleAtIndex:(NSUInteger)index gainDb:(float)gainDb error:(NSString**)error;
- (BOOL)normalizeSampleAtIndex:(NSUInteger)index targetPeakDb:(float)targetPeakDb error:(NSString**)error;
- (BOOL)fadeInSampleAtIndex:(NSUInteger)index frames:(uint64_t)frames error:(NSString**)error;
- (BOOL)fadeOutSampleAtIndex:(NSUInteger)index frames:(uint64_t)frames error:(NSString**)error;
- (BOOL)setRootKeyForSampleAtIndex:(NSUInteger)index rootKey:(uint8_t)rootKey error:(NSString**)error;
- (BOOL)setFineTuneForSampleAtIndex:(NSUInteger)index cents:(float)cents error:(NSString**)error;
- (uint64_t)nearestZeroCrossingForSampleAtIndex:(NSUInteger)index frame:(uint64_t)frame radius:(uint64_t)radius;
@end

@interface SVWaveformView : NSView
@property(nonatomic, copy) NSArray<NSNumber*>* points;
@property(nonatomic) uint64_t totalFrames;
@property(nonatomic) BOOL loopEnabled;
@property(nonatomic) uint64_t loopStart;
@property(nonatomic) uint64_t loopEnd;
@end

@implementation SVWaveformView

- (BOOL)isFlipped { return YES; }

- (void)drawRect:(NSRect)dirtyRect {
    (void)dirtyRect;
    [[NSColor colorWithCalibratedRed:0.042 green:0.050 blue:0.060 alpha:1.0] setFill];
    NSRectFill(self.bounds);

    const CGFloat width = NSWidth(self.bounds);
    const CGFloat height = NSHeight(self.bounds);
    const CGFloat middle = height * 0.5;

    [[NSColor colorWithCalibratedWhite:0.20 alpha:1.0] setStroke];
    NSBezierPath* centre = [NSBezierPath bezierPath];
    [centre moveToPoint:NSMakePoint(0.0, middle)];
    [centre lineToPoint:NSMakePoint(width, middle)];
    centre.lineWidth = 1.0;
    [centre stroke];

    const NSUInteger pairCount = self.points.count / 2U;
    if (pairCount > 0U) {
        NSBezierPath* waveform = [NSBezierPath bezierPath];
        waveform.lineWidth = 1.0;
        for (NSUInteger i = 0U; i < pairCount; ++i) {
            const float minimum = self.points[i * 2U].floatValue;
            const float maximum = self.points[i * 2U + 1U].floatValue;
            const CGFloat x = pairCount <= 1U ? 0.0 : (static_cast<CGFloat>(i) / static_cast<CGFloat>(pairCount - 1U)) * width;
            const CGFloat yMin = middle - static_cast<CGFloat>(maximum) * middle;
            const CGFloat yMax = middle - static_cast<CGFloat>(minimum) * middle;
            [waveform moveToPoint:NSMakePoint(x, yMin)];
            [waveform lineToPoint:NSMakePoint(x, yMax)];
        }
        [[NSColor colorWithCalibratedRed:0.38 green:0.72 blue:0.98 alpha:1.0] setStroke];
        [waveform stroke];
    }

    if (self.loopEnabled && self.totalFrames > 0U && self.loopStart < self.loopEnd) {
        const CGFloat xStart = static_cast<CGFloat>(static_cast<long double>(self.loopStart) / static_cast<long double>(self.totalFrames)) * width;
        const CGFloat xEnd = static_cast<CGFloat>(static_cast<long double>(self.loopEnd) / static_cast<long double>(self.totalFrames)) * width;
        [[NSColor colorWithCalibratedRed:0.34 green:0.88 blue:0.64 alpha:0.95] setStroke];
        NSBezierPath* markers = [NSBezierPath bezierPath];
        markers.lineWidth = 1.5;
        [markers moveToPoint:NSMakePoint(xStart, 0.0)];
        [markers lineToPoint:NSMakePoint(xStart, height)];
        [markers moveToPoint:NSMakePoint(xEnd, 0.0)];
        [markers lineToPoint:NSMakePoint(xEnd, height)];
        [markers stroke];
    }

    [[NSColor colorWithCalibratedWhite:0.22 alpha:1.0] setStroke];
    NSFrameRect(self.bounds);
}

@end

@interface SVAppDelegate : NSObject
- (void)playSample:(id)sender;
- (void)playLoop:(id)sender;
- (void)stopAudition:(id)sender;
- (void)undoSampleEdit:(id)sender;
- (void)redoSampleEdit:(id)sender;
- (void)playRange:(id)sender;
- (void)copyRange:(id)sender;
- (void)cutRange:(id)sender;
- (void)pasteRange:(id)sender;
- (void)deleteRange:(id)sender;
- (void)silenceRange:(id)sender;
- (void)reverseRange:(id)sender;
- (void)fadeInRange:(id)sender;
- (void)fadeOutRange:(id)sender;
- (void)gainRange:(id)sender;
- (void)normalizeRange:(id)sender;
- (void)showSampleEditorCommand:(id)sender;
- (void)showMediaCommand:(id)sender;
- (void)showMultisampleEditor:(id)sender;
- (void)showSoundEditor:(id)sender;
- (void)showBankOrganizer:(id)sender;
- (void)showObjectManagerCommand:(id)sender;
- (void)showConverterCommand:(id)sender;
- (void)showWorkflowCommand:(id)sender;
- (void)saveBankCommand:(id)sender;
@end

@interface SVPanelView : NSView
@property(nonatomic, strong) NSColor* panelFill;
@property(nonatomic, strong) NSColor* panelStroke;
@property(nonatomic) CGFloat panelRadius;
@end

@implementation SVPanelView
- (instancetype)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _panelFill = [NSColor colorWithCalibratedRed:0.078 green:0.092 blue:0.108 alpha:1.0];
        _panelStroke = [NSColor colorWithCalibratedWhite:0.19 alpha:1.0];
        _panelRadius = 12.0;
    }
    return self;
}
- (void)drawRect:(NSRect)dirtyRect {
    (void)dirtyRect;
    NSRect r = NSInsetRect(self.bounds, 0.5, 0.5);
    NSBezierPath* p = [NSBezierPath bezierPathWithRoundedRect:r xRadius:self.panelRadius yRadius:self.panelRadius];
    [self.panelFill setFill];
    [p fill];
    [self.panelStroke setStroke];
    p.lineWidth = 1.0;
    [p stroke];
}
@end

@interface SVHardwareButton : NSButton
@property(nonatomic) BOOL silvetonAccent;
@property(nonatomic) BOOL silvetonNavigation;
@property(nonatomic) BOOL silvetonSelected;
@end

@implementation SVHardwareButton
- (instancetype)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.bordered = NO;
        self.buttonType = NSButtonTypeMomentaryChange;
        self.focusRingType = NSFocusRingTypeNone;
        self.font = [NSFont systemFontOfSize:11.0 weight:NSFontWeightMedium];
    }
    return self;
}
- (void)drawRect:(NSRect)dirtyRect {
    (void)dirtyRect;
    const BOOL pressed = [(NSButtonCell*)self.cell isHighlighted];
    NSRect r = NSInsetRect(self.bounds, 1.0, 1.0);
    const CGFloat radius = self.silvetonNavigation ? 11.0 : 7.0;
    NSBezierPath* p = [NSBezierPath bezierPathWithRoundedRect:r xRadius:radius yRadius:radius];

    NSColor* top = nil;
    NSColor* bottom = nil;
    NSColor* stroke = nil;
    if (self.silvetonAccent) {
        top = [NSColor colorWithCalibratedRed:0.16 green:0.34 blue:0.50 alpha:1.0];
        bottom = [NSColor colorWithCalibratedRed:0.085 green:0.18 blue:0.28 alpha:1.0];
        stroke = [NSColor colorWithCalibratedRed:0.34 green:0.69 blue:0.98 alpha:0.95];
    } else if (self.silvetonSelected) {
        top = [NSColor colorWithCalibratedRed:0.19 green:0.25 blue:0.31 alpha:1.0];
        bottom = [NSColor colorWithCalibratedRed:0.10 green:0.15 blue:0.20 alpha:1.0];
        stroke = [NSColor colorWithCalibratedRed:0.30 green:0.60 blue:0.86 alpha:0.85];
    } else {
        top = [NSColor colorWithCalibratedRed:0.16 green:0.18 blue:0.21 alpha:1.0];
        bottom = [NSColor colorWithCalibratedRed:0.075 green:0.086 blue:0.10 alpha:1.0];
        stroke = [NSColor colorWithCalibratedWhite:0.24 alpha:1.0];
    }
    if (pressed) {
        NSColor* swap = top; top = bottom; bottom = swap;
    }
    NSGradient* gradient = [[NSGradient alloc] initWithStartingColor:top endingColor:bottom];
    [gradient drawInBezierPath:p angle:90.0];
    [stroke setStroke];
    p.lineWidth = 1.0;
    [p stroke];

    CGFloat textX = 0.0;
    if (self.silvetonNavigation) {
        const NSRect ledRect = NSMakeRect(16.0, floor(NSMidY(self.bounds) - 4.0), 8.0, 8.0);
        NSBezierPath* led = [NSBezierPath bezierPathWithOvalInRect:ledRect];
        NSColor* ledColor = self.silvetonSelected
            ? [NSColor colorWithCalibratedRed:0.40 green:0.82 blue:1.0 alpha:1.0]
            : [NSColor colorWithCalibratedWhite:0.14 alpha:1.0];
        [ledColor setFill];
        [led fill];
        [[NSColor colorWithCalibratedWhite:0.05 alpha:1.0] setStroke];
        [led stroke];
        textX = 12.0;
    }

    NSMutableParagraphStyle* paragraph = [[NSMutableParagraphStyle alloc] init];
    paragraph.alignment = NSTextAlignmentCenter;
    NSColor* textColor = self.enabled
        ? [NSColor colorWithCalibratedWhite:(self.silvetonSelected ? 0.95 : 0.78) alpha:1.0]
        : [NSColor colorWithCalibratedWhite:0.36 alpha:1.0];
    NSDictionary* attrs = @{
        NSForegroundColorAttributeName: textColor,
        NSFontAttributeName: self.font ?: [NSFont systemFontOfSize:11.0 weight:NSFontWeightMedium],
        NSParagraphStyleAttributeName: paragraph,
        NSKernAttributeName: @(self.silvetonNavigation ? 1.8 : 0.2)
    };
    NSAttributedString* t = [[NSAttributedString alloc] initWithString:self.title ?: @"" attributes:attrs];
    NSRect textRect = self.bounds;
    textRect.origin.x += textX;
    textRect.size.width -= textX;
    NSSize size = t.size;
    [t drawAtPoint:NSMakePoint(NSMinX(textRect) + floor((NSWidth(textRect) - size.width) * 0.5),
                               floor((NSHeight(self.bounds) - size.height) * 0.5) + 1.0)];
}
@end

@interface SVSampleRowView : NSTableRowView
@end

@implementation SVSampleRowView
- (void)drawBackgroundInRect:(NSRect)dirtyRect {
    (void)dirtyRect;
    NSRect r = NSInsetRect(self.bounds, 3.0, 3.0);
    NSBezierPath* p = [NSBezierPath bezierPathWithRoundedRect:r xRadius:8.0 yRadius:8.0];
    [[NSColor colorWithCalibratedRed:0.105 green:0.122 blue:0.145 alpha:1.0] setFill];
    [p fill];
}
- (void)drawSelectionInRect:(NSRect)dirtyRect {
    (void)dirtyRect;
    if (!self.selected) return;
    NSRect r = NSInsetRect(self.bounds, 3.0, 3.0);
    NSBezierPath* p = [NSBezierPath bezierPathWithRoundedRect:r xRadius:8.0 yRadius:8.0];
    [[NSColor colorWithCalibratedRed:0.12 green:0.22 blue:0.30 alpha:1.0] setFill];
    [p fill];
    [[NSColor colorWithCalibratedRed:0.28 green:0.64 blue:0.92 alpha:0.75] setStroke];
    [p stroke];
}
@end

@interface SVMainWindowController : NSWindowController <NSTableViewDataSource, NSTableViewDelegate>
- (NSUInteger)selectedSampleIndex;
@end

namespace {

NSTextField* makeLabel(NSRect frame, NSString* text, CGFloat size, NSFontWeight weight, NSColor* color) {
    NSTextField* label = [[NSTextField alloc] initWithFrame:frame];
    label.stringValue = text;
    label.editable = NO;
    label.selectable = NO;
    label.bezeled = NO;
    label.drawsBackground = NO;
    label.font = [NSFont systemFontOfSize:size weight:weight];
    label.textColor = color;
    return label;
}

NSTextField* makeNumericField(NSRect frame, NSString* text) {
    NSTextField* field = [[NSTextField alloc] initWithFrame:frame];
    field.stringValue = text;
    field.bezeled = YES;
    field.editable = YES;
    field.selectable = YES;
    field.drawsBackground = YES;
    field.backgroundColor = [NSColor colorWithCalibratedRed:0.085 green:0.098 blue:0.112 alpha:1.0];
    field.textColor = [NSColor colorWithCalibratedWhite:0.92 alpha:1.0];
    field.font = [NSFont monospacedDigitSystemFontOfSize:12.0 weight:NSFontWeightRegular];
    field.alignment = NSTextAlignmentRight;
    return field;
}

NSButton* makeButton(NSRect frame, NSString* title, id target, SEL action) {
    SVHardwareButton* button = [[SVHardwareButton alloc] initWithFrame:frame];
    button.title = title ?: @"";
    button.target = target;
    button.action = action;
    button.font = [NSFont systemFontOfSize:11.0 weight:NSFontWeightMedium];
    return button;
}

SVHardwareButton* makeNavigationButton(NSRect frame, NSString* title, id target, SEL action, BOOL selected, BOOL accent) {
    SVHardwareButton* button = [[SVHardwareButton alloc] initWithFrame:frame];
    button.title = title ?: @"";
    button.target = target;
    button.action = action;
    button.silvetonNavigation = YES;
    button.silvetonSelected = selected;
    button.silvetonAccent = accent;
    button.font = [NSFont systemFontOfSize:10.5 weight:NSFontWeightMedium];
    return button;
}

SVPanelView* makePanel(NSRect frame, NSColor* fill, CGFloat radius) {
    SVPanelView* panel = [[SVPanelView alloc] initWithFrame:frame];
    if (fill != nil) panel.panelFill = fill;
    panel.panelRadius = radius;
    return panel;
}

void showMessage(NSWindow* window, NSString* title, NSString* message, NSAlertStyle style) {
    NSAlert* alert = [[NSAlert alloc] init];
    alert.messageText = title ?: @"SILVETON Manager";
    alert.informativeText = message ?: @"";
    alert.alertStyle = style;
    [alert beginSheetModalForWindow:window completionHandler:nil];
}

bool parseUnsignedField(NSTextField* field, std::uint64_t& value) noexcept {
    if (field == nil) return false;
    NSString* trimmed = [field.stringValue stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (trimmed.length == 0U || [trimmed hasPrefix:@"-"]) return false;
    const char* text = trimmed.UTF8String;
    if (text == nullptr || *text == '\0') return false;

    errno = 0;
    char* end = nullptr;
    const unsigned long long parsed = std::strtoull(text, &end, 10);
    if (errno == ERANGE || end == text || end == nullptr || *end != '\0') return false;
    value = static_cast<std::uint64_t>(parsed);
    return true;
}

} // namespace

@implementation SVMainWindowController {
    SVManagerDocument* _documentModel;
    NSTableView* _sampleTable;
    SVWaveformView* _waveformView;
    NSTextField* _sampleTitleLabel;
    NSTextField* _sampleInfoLabel;
    NSTextField* _statusLabel;
    NSTextField* _pathLabel;
    NSArray<NSString*>* _sampleRows;

    NSTextField* _trimStartField;
    NSTextField* _trimEndField;
    NSTextField* _loopStartField;
    NSTextField* _loopEndField;
    NSTextField* _crossfadeField;
    NSTextField* _fadeInField;
    NSTextField* _fadeOutField;
    NSTextField* _gainField;
    NSTextField* _normalizeField;
    NSTextField* _rootKeyField;
    NSTextField* _fineTuneField;
    NSTextField* _zeroRadiusField;
}

- (instancetype)init {
    const NSRect rect = NSMakeRect(0.0, 0.0, 1344.0, 800.0);
    NSWindow* window = [[NSWindow alloc] initWithContentRect:rect
                                                  styleMask:(NSWindowStyleMaskTitled |
                                                             NSWindowStyleMaskClosable |
                                                             NSWindowStyleMaskMiniaturizable |
                                                             NSWindowStyleMaskResizable)
                                                    backing:NSBackingStoreBuffered
                                                      defer:NO];
    window.title = @"SILVETON Manager";
    window.minSize = NSMakeSize(1180.0, 700.0);
    window.backgroundColor = [NSColor colorWithCalibratedRed:0.028 green:0.034 blue:0.041 alpha:1.0];
    window.titlebarAppearsTransparent = NO;

    self = [super initWithWindow:window];
    if (self) {
        _documentModel = [[SVManagerDocument alloc] init];
        _sampleRows = @[];
        [self buildInterface];
        [self refreshProjectView];
    }
    return self;
}

- (void)buildInterface {
    NSView* content = self.window.contentView;
    content.autoresizesSubviews = YES;
    content.wantsLayer = YES;
    content.layer.backgroundColor = [NSColor colorWithCalibratedRed:0.028 green:0.034 blue:0.041 alpha:1.0].CGColor;

    NSColor* primary = [NSColor colorWithCalibratedWhite:0.91 alpha:1.0];
    NSColor* secondary = [NSColor colorWithCalibratedWhite:0.55 alpha:1.0];
    NSColor* blue = [NSColor colorWithCalibratedRed:0.31 green:0.70 blue:0.98 alpha:1.0];
    NSColor* panelFill = [NSColor colorWithCalibratedRed:0.071 green:0.083 blue:0.098 alpha:1.0];
    NSColor* innerFill = [NSColor colorWithCalibratedRed:0.090 green:0.103 blue:0.121 alpha:1.0];

    // Top hardware header, matching the sampler visual language.
    SVPanelView* header = makePanel(NSMakeRect(16.0, 726.0, 1312.0, 58.0),
                                    [NSColor colorWithCalibratedRed:0.045 green:0.052 blue:0.061 alpha:1.0], 10.0);
    header.autoresizingMask = NSViewWidthSizable | NSViewMinYMargin;
    [content addSubview:header];

    NSTextField* brand = makeLabel(NSMakeRect(390.0, 739.0, 550.0, 34.0), @"S I L V E T O N   manager", 23.0,
                                   NSFontWeightSemibold, primary);
    brand.alignment = NSTextAlignmentCenter;
    brand.autoresizingMask = NSViewMinXMargin | NSViewMaxXMargin | NSViewMinYMargin;
    [content addSubview:brand];

    SVHardwareButton* importButton = (SVHardwareButton*)makeButton(NSMakeRect(32.0, 738.0, 148.0, 34.0), @"IMPORT KMP / KSC…", self, @selector(importPressed:));
    importButton.silvetonAccent = YES;
    importButton.autoresizingMask = NSViewMinYMargin;
    [content addSubview:importButton];

    NSButton* clearButton = makeButton(NSMakeRect(190.0, 738.0, 90.0, 34.0), @"CLEAR", self, @selector(clearPressed:));
    clearButton.autoresizingMask = NSViewMinYMargin;
    [content addSubview:clearButton];

    SVHardwareButton* buildButton = (SVHardwareButton*)makeButton(NSMakeRect(1082.0, 738.0, 226.0, 34.0), @"BUILD SILVETON BANK…", self, @selector(buildPressed:));
    buildButton.silvetonAccent = YES;
    buildButton.autoresizingMask = NSViewMinXMargin | NSViewMinYMargin;
    [content addSubview:buildButton];

    // Main editor body and separate navigation rail.
    SVPanelView* mainPanel = makePanel(NSMakeRect(16.0, 18.0, 1114.0, 694.0), panelFill, 12.0);
    mainPanel.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    [content addSubview:mainPanel positioned:NSWindowBelow relativeTo:nil];

    SVPanelView* railPanel = makePanel(NSMakeRect(1144.0, 18.0, 184.0, 694.0),
                                       [NSColor colorWithCalibratedRed:0.060 green:0.071 blue:0.084 alpha:1.0], 12.0);
    railPanel.autoresizingMask = NSViewMinXMargin | NSViewHeightSizable;
    [content addSubview:railPanel positioned:NSWindowBelow relativeTo:nil];

    NSTextField* sectionLed = makeLabel(NSMakeRect(36.0, 675.0, 360.0, 24.0), @"●  SAMPLE EDITOR", 12.0,
                                        NSFontWeightMedium, blue);
    sectionLed.autoresizingMask = NSViewMinYMargin;
    [content addSubview:sectionLed];

    _statusLabel = makeLabel(NSMakeRect(680.0, 676.0, 426.0, 22.0), @"", 11.0, NSFontWeightMedium, secondary);
    _statusLabel.alignment = NSTextAlignmentRight;
    _statusLabel.autoresizingMask = NSViewMinXMargin | NSViewMinYMargin;
    [content addSubview:_statusLabel];

    // Sample browser panel.
    SVPanelView* browserPanel = makePanel(NSMakeRect(34.0, 92.0, 344.0, 566.0), innerFill, 10.0);
    browserPanel.autoresizingMask = NSViewHeightSizable;
    [content addSubview:browserPanel positioned:NSWindowAbove relativeTo:mainPanel];

    NSTextField* sampleSection = makeLabel(NSMakeRect(50.0, 626.0, 220.0, 22.0), @"MULTISAMPLES / SAMPLES", 11.0,
                                           NSFontWeightSemibold, secondary);
    sampleSection.autoresizingMask = NSViewMinYMargin;
    [content addSubview:sampleSection];

    NSScrollView* sampleScroll = [[NSScrollView alloc] initWithFrame:NSMakeRect(46.0, 116.0, 320.0, 500.0)];
    sampleScroll.autoresizingMask = NSViewHeightSizable;
    sampleScroll.hasVerticalScroller = YES;
    sampleScroll.hasHorizontalScroller = NO;
    sampleScroll.borderType = NSNoBorder;
    sampleScroll.drawsBackground = YES;
    sampleScroll.backgroundColor = [NSColor colorWithCalibratedRed:0.070 green:0.082 blue:0.098 alpha:1.0];

    _sampleTable = [[NSTableView alloc] initWithFrame:sampleScroll.bounds];
    _sampleTable.headerView = nil;
    _sampleTable.rowHeight = 48.0;
    _sampleTable.backgroundColor = sampleScroll.backgroundColor;
    _sampleTable.gridStyleMask = NSTableViewGridNone;
    _sampleTable.intercellSpacing = NSMakeSize(0.0, 2.0);
    _sampleTable.dataSource = self;
    _sampleTable.delegate = self;
    _sampleTable.allowsMultipleSelection = NO;
    _sampleTable.selectionHighlightStyle = NSTableViewSelectionHighlightStyleNone;
    NSTableColumn* sampleColumn = [[NSTableColumn alloc] initWithIdentifier:@"sample"];
    sampleColumn.width = 302.0;
    sampleColumn.resizingMask = NSTableColumnAutoresizingMask;
    [_sampleTable addTableColumn:sampleColumn];
    sampleScroll.documentView = _sampleTable;
    [content addSubview:sampleScroll];

    // Editor panel.
    SVPanelView* editorPanel = makePanel(NSMakeRect(392.0, 92.0, 720.0, 566.0), innerFill, 10.0);
    editorPanel.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    [content addSubview:editorPanel positioned:NSWindowAbove relativeTo:mainPanel];

    _sampleTitleLabel = makeLabel(NSMakeRect(414.0, 620.0, 470.0, 28.0), @"No sample selected", 18.0,
                                  NSFontWeightMedium, primary);
    _sampleTitleLabel.autoresizingMask = NSViewWidthSizable | NSViewMinYMargin;
    [content addSubview:_sampleTitleLabel];

    _sampleInfoLabel = makeLabel(NSMakeRect(414.0, 597.0, 670.0, 20.0), @"", 10.5, NSFontWeightRegular, secondary);
    _sampleInfoLabel.autoresizingMask = NSViewWidthSizable | NSViewMinYMargin;
    [content addSubview:_sampleInfoLabel];

    _waveformView = [[SVWaveformView alloc] initWithFrame:NSMakeRect(414.0, 452.0, 676.0, 134.0)];
    _waveformView.autoresizingMask = NSViewWidthSizable | NSViewMinYMargin;
    [content addSubview:_waveformView];

    id delegate = NSApp.delegate;
    NSButton* play = makeButton(NSMakeRect(414.0, 408.0, 84.0, 30.0), @"PLAY", delegate, @selector(playSample:));
    NSButton* loopPlay = makeButton(NSMakeRect(504.0, 408.0, 92.0, 30.0), @"PLAY LOOP", delegate, @selector(playLoop:));
    NSButton* stop = makeButton(NSMakeRect(602.0, 408.0, 72.0, 30.0), @"STOP", delegate, @selector(stopAudition:));
    NSButton* undo = makeButton(NSMakeRect(954.0, 408.0, 62.0, 30.0), @"UNDO", delegate, @selector(undoSampleEdit:));
    NSButton* redo = makeButton(NSMakeRect(1022.0, 408.0, 68.0, 30.0), @"REDO", delegate, @selector(redoSampleEdit:));
    [content addSubview:play]; [content addSubview:loopPlay]; [content addSubview:stop]; [content addSubview:undo]; [content addSubview:redo];

    NSColor* labelColor = [NSColor colorWithCalibratedWhite:0.68 alpha:1.0];

    [content addSubview:makeLabel(NSMakeRect(414.0, 367.0, 58.0, 20.0), @"TRIM", 10.5, NSFontWeightSemibold, blue)];
    [content addSubview:makeLabel(NSMakeRect(476.0, 367.0, 38.0, 20.0), @"START", 9.5, NSFontWeightRegular, (NSColor*)labelColor)];
    _trimStartField = makeNumericField(NSMakeRect(516.0, 364.0, 92.0, 24.0), @"0"); [content addSubview:_trimStartField];
    [content addSubview:makeLabel(NSMakeRect(618.0, 367.0, 30.0, 20.0), @"END", 9.5, NSFontWeightRegular, (NSColor*)labelColor)];
    _trimEndField = makeNumericField(NSMakeRect(650.0, 364.0, 92.0, 24.0), @"0"); [content addSubview:_trimEndField];
    [content addSubview:makeButton(NSMakeRect(752.0, 362.0, 82.0, 28.0), @"SNAP A", self, @selector(snapTrimStartPressed:))];
    [content addSubview:makeButton(NSMakeRect(840.0, 362.0, 82.0, 28.0), @"SNAP B", self, @selector(snapTrimEndPressed:))];
    [content addSubview:makeButton(NSMakeRect(986.0, 362.0, 104.0, 28.0), @"APPLY TRIM", self, @selector(trimPressed:))];

    [content addSubview:makeLabel(NSMakeRect(414.0, 329.0, 58.0, 20.0), @"LOOP", 10.5, NSFontWeightSemibold, blue)];
    [content addSubview:makeLabel(NSMakeRect(476.0, 329.0, 38.0, 20.0), @"START", 9.5, NSFontWeightRegular, (NSColor*)labelColor)];
    _loopStartField = makeNumericField(NSMakeRect(516.0, 326.0, 92.0, 24.0), @"0"); [content addSubview:_loopStartField];
    [content addSubview:makeLabel(NSMakeRect(618.0, 329.0, 30.0, 20.0), @"END", 9.5, NSFontWeightRegular, (NSColor*)labelColor)];
    _loopEndField = makeNumericField(NSMakeRect(650.0, 326.0, 92.0, 24.0), @"0"); [content addSubview:_loopEndField];
    [content addSubview:makeButton(NSMakeRect(752.0, 324.0, 80.0, 28.0), @"SET LOOP", self, @selector(setLoopPressed:))];
    [content addSubview:makeButton(NSMakeRect(838.0, 324.0, 76.0, 28.0), @"LOOP OFF", self, @selector(loopOffPressed:))];
    [content addSubview:makeButton(NSMakeRect(920.0, 324.0, 80.0, 28.0), @"SNAP A", self, @selector(snapLoopStartPressed:))];
    [content addSubview:makeButton(NSMakeRect(1006.0, 324.0, 84.0, 28.0), @"SNAP B", self, @selector(snapLoopEndPressed:))];

    [content addSubview:makeLabel(NSMakeRect(414.0, 291.0, 88.0, 20.0), @"CROSSFADE", 10.5, NSFontWeightSemibold, blue)];
    _crossfadeField = makeNumericField(NSMakeRect(516.0, 288.0, 92.0, 24.0), @"0"); [content addSubview:_crossfadeField];
    [content addSubview:makeButton(NSMakeRect(618.0, 286.0, 150.0, 28.0), @"APPLY CROSSFADE", self, @selector(crossfadePressed:))];
    [content addSubview:makeLabel(NSMakeRect(786.0, 291.0, 82.0, 20.0), @"ZERO RADIUS", 9.5, NSFontWeightRegular, (NSColor*)labelColor)];
    _zeroRadiusField = makeNumericField(NSMakeRect(870.0, 288.0, 82.0, 24.0), @"256"); [content addSubview:_zeroRadiusField];

    [content addSubview:makeLabel(NSMakeRect(414.0, 253.0, 58.0, 20.0), @"FADES", 10.5, NSFontWeightSemibold, blue)];
    [content addSubview:makeLabel(NSMakeRect(476.0, 253.0, 46.0, 20.0), @"IN", 9.5, NSFontWeightRegular, (NSColor*)labelColor)];
    _fadeInField = makeNumericField(NSMakeRect(516.0, 250.0, 84.0, 24.0), @"0"); [content addSubview:_fadeInField];
    [content addSubview:makeButton(NSMakeRect(606.0, 248.0, 70.0, 28.0), @"APPLY", self, @selector(fadeInPressed:))];
    [content addSubview:makeLabel(NSMakeRect(692.0, 253.0, 46.0, 20.0), @"OUT", 9.5, NSFontWeightRegular, (NSColor*)labelColor)];
    _fadeOutField = makeNumericField(NSMakeRect(730.0, 250.0, 84.0, 24.0), @"0"); [content addSubview:_fadeOutField];
    [content addSubview:makeButton(NSMakeRect(820.0, 248.0, 70.0, 28.0), @"APPLY", self, @selector(fadeOutPressed:))];

    [content addSubview:makeLabel(NSMakeRect(414.0, 215.0, 58.0, 20.0), @"LEVEL", 10.5, NSFontWeightSemibold, blue)];
    [content addSubview:makeLabel(NSMakeRect(476.0, 215.0, 44.0, 20.0), @"GAIN", 9.5, NSFontWeightRegular, (NSColor*)labelColor)];
    _gainField = makeNumericField(NSMakeRect(516.0, 212.0, 74.0, 24.0), @"0.0"); [content addSubview:_gainField];
    [content addSubview:makeButton(NSMakeRect(596.0, 210.0, 86.0, 28.0), @"APPLY", self, @selector(gainPressed:))];
    [content addSubview:makeLabel(NSMakeRect(696.0, 215.0, 76.0, 20.0), @"NORMALIZE", 9.5, NSFontWeightRegular, (NSColor*)labelColor)];
    _normalizeField = makeNumericField(NSMakeRect(774.0, 212.0, 74.0, 24.0), @"-1.0"); [content addSubview:_normalizeField];
    [content addSubview:makeButton(NSMakeRect(854.0, 210.0, 92.0, 28.0), @"NORMALIZE", self, @selector(normalizePressed:))];
    [content addSubview:makeButton(NSMakeRect(986.0, 210.0, 104.0, 28.0), @"REVERSE", self, @selector(reversePressed:))];

    [content addSubview:makeLabel(NSMakeRect(414.0, 177.0, 58.0, 20.0), @"TUNING", 10.5, NSFontWeightSemibold, blue)];
    [content addSubview:makeLabel(NSMakeRect(476.0, 177.0, 38.0, 20.0), @"ROOT", 9.5, NSFontWeightRegular, (NSColor*)labelColor)];
    _rootKeyField = makeNumericField(NSMakeRect(516.0, 174.0, 64.0, 24.0), @"60"); [content addSubview:_rootKeyField];
    [content addSubview:makeLabel(NSMakeRect(592.0, 177.0, 48.0, 20.0), @"CENTS", 9.5, NSFontWeightRegular, (NSColor*)labelColor)];
    _fineTuneField = makeNumericField(NSMakeRect(642.0, 174.0, 72.0, 24.0), @"0.0"); [content addSubview:_fineTuneField];
    [content addSubview:makeButton(NSMakeRect(722.0, 172.0, 112.0, 28.0), @"APPLY TUNING", self, @selector(tuningPressed:))];

    // Selection/range operations live inside the editor instead of being overlaid by AppDelegate.
    [content addSubview:makeButton(NSMakeRect(414.0, 130.0, 82.0, 28.0), @"PLAY RNG", delegate, @selector(playRange:))];
    [content addSubview:makeButton(NSMakeRect(502.0, 130.0, 58.0, 28.0), @"COPY", delegate, @selector(copyRange:))];
    [content addSubview:makeButton(NSMakeRect(566.0, 130.0, 54.0, 28.0), @"CUT", delegate, @selector(cutRange:))];
    [content addSubview:makeButton(NSMakeRect(626.0, 130.0, 76.0, 28.0), @"PASTE", delegate, @selector(pasteRange:))];
    [content addSubview:makeButton(NSMakeRect(708.0, 130.0, 64.0, 28.0), @"DELETE", delegate, @selector(deleteRange:))];
    [content addSubview:makeButton(NSMakeRect(778.0, 130.0, 68.0, 28.0), @"SILENCE", delegate, @selector(silenceRange:))];
    [content addSubview:makeButton(NSMakeRect(852.0, 130.0, 72.0, 28.0), @"REVERSE", delegate, @selector(reverseRange:))];
    [content addSubview:makeButton(NSMakeRect(930.0, 130.0, 72.0, 28.0), @"FADE IN", delegate, @selector(fadeInRange:))];
    [content addSubview:makeButton(NSMakeRect(1008.0, 130.0, 82.0, 28.0), @"FADE OUT", delegate, @selector(fadeOutRange:))];

    _pathLabel = makeLabel(NSMakeRect(36.0, 48.0, 1058.0, 20.0), @"Bank not built yet", 10.5,
                           NSFontWeightRegular, secondary);
    _pathLabel.autoresizingMask = NSViewWidthSizable | NSViewMaxYMargin;
    [content addSubview:_pathLabel];

    // Right-side module rail, same hierarchy as the sampler reference.
    const CGFloat rx = 1158.0;
    const CGFloat rw = 156.0;
    const CGFloat rh = 61.0;
    const CGFloat gap = 8.0;
    CGFloat ry = 635.0;
    NSArray<NSDictionary*>* nav = @[
        @{@"t": @"SAMPLES", @"s": NSStringFromSelector(@selector(showSampleEditorCommand:)), @"sel": @YES},
        @{@"t": @"MEDIA", @"s": NSStringFromSelector(@selector(showMediaCommand:)), @"sel": @NO},
        @{@"t": @"MULTISAMPLE", @"s": NSStringFromSelector(@selector(showMultisampleEditor:)), @"sel": @NO},
        @{@"t": @"SOUND", @"s": NSStringFromSelector(@selector(showSoundEditor:)), @"sel": @NO},
        @{@"t": @"BANK", @"s": NSStringFromSelector(@selector(showBankOrganizer:)), @"sel": @NO},
        @{@"t": @"OBJECTS", @"s": NSStringFromSelector(@selector(showObjectManagerCommand:)), @"sel": @NO},
        @{@"t": @"CONVERTER", @"s": NSStringFromSelector(@selector(showConverterCommand:)), @"sel": @NO},
        @{@"t": @"WORKFLOW", @"s": NSStringFromSelector(@selector(showWorkflowCommand:)), @"sel": @NO}
    ];
    for (NSDictionary* item in nav) {
        SEL action = NSSelectorFromString(item[@"s"]);
        SVHardwareButton* b = makeNavigationButton(NSMakeRect(rx, ry, rw, rh), item[@"t"], delegate, action,
                                                    [item[@"sel"] boolValue], NO);
        b.autoresizingMask = NSViewMinXMargin | NSViewMinYMargin;
        [content addSubview:b];
        ry -= (rh + gap);
    }
    SVHardwareButton* save = makeNavigationButton(NSMakeRect(rx, 42.0, rw, 60.0), @"SAVE BANK", delegate,
                                                  @selector(saveBankCommand:), NO, YES);
    save.autoresizingMask = NSViewMinXMargin | NSViewMaxYMargin;
    [content addSubview:save];
}

- (NSUInteger)selectedSampleIndex {
    const NSInteger row = _sampleTable.selectedRow;
    return row < 0 ? NSNotFound : static_cast<NSUInteger>(row);
}

- (void)refreshProjectView {
    const NSInteger oldSelection = _sampleTable.selectedRow;
    _sampleRows = [_documentModel sampleDisplayRows];
    [_sampleTable reloadData];
    _statusLabel.stringValue = [_documentModel statusSummary];

    if (_sampleRows.count == 0U) {
        [_sampleTable deselectAll:nil];
        [self refreshSelectedSample];
        return;
    }

    NSInteger selection = oldSelection;
    if (selection < 0 || static_cast<NSUInteger>(selection) >= _sampleRows.count) selection = 0;
    [_sampleTable selectRowIndexes:[NSIndexSet indexSetWithIndex:static_cast<NSUInteger>(selection)] byExtendingSelection:NO];
    [self refreshSelectedSample];
}

- (void)refreshSelectedSample {
    const NSUInteger index = [self selectedSampleIndex];
    if (index == NSNotFound) {
        _sampleTitleLabel.stringValue = @"No sample selected";
        _sampleInfoLabel.stringValue = @"";
        _waveformView.points = @[];
        _waveformView.totalFrames = 0U;
        _waveformView.loopEnabled = NO;
        [_waveformView setNeedsDisplay:YES];
        return;
    }

    NSDictionary<NSString*, id>* state = [_documentModel sampleStateAtIndex:index];
    if (state == nil) return;
    _sampleTitleLabel.stringValue = state[@"name"] ?: @"Sample";

    const unsigned int sampleRate = [state[@"sampleRate"] unsignedIntValue];
    const unsigned int channels = [state[@"channels"] unsignedIntValue];
    const unsigned long long totalFrames = [state[@"totalFrames"] unsignedLongLongValue];
    const float peakDb = [state[@"peakDb"] floatValue];
    _sampleInfoLabel.stringValue = [NSString stringWithFormat:@"%u Hz · %u channel%@ · %llu frames · peak %.2f dBFS",
                                    sampleRate, channels, channels == 1U ? @"" : @"s", totalFrames, peakDb];

    NSString* waveformError = nil;
    NSArray<NSNumber*>* waveform = [_documentModel waveformAtIndex:index pointCount:1200U error:&waveformError];
    if (waveform == nil) {
        _waveformView.points = @[];
        if (waveformError.length != 0U) _sampleInfoLabel.stringValue = waveformError;
    } else {
        _waveformView.points = waveform;
    }
    _waveformView.totalFrames = static_cast<uint64_t>(totalFrames);
    _waveformView.loopEnabled = [state[@"loopEnabled"] boolValue];
    _waveformView.loopStart = [state[@"loopStart"] unsignedLongLongValue];
    _waveformView.loopEnd = [state[@"loopEnd"] unsignedLongLongValue];
    [_waveformView setNeedsDisplay:YES];

    _trimStartField.stringValue = @"0";
    _trimEndField.stringValue = [NSString stringWithFormat:@"%llu", totalFrames];
    _loopStartField.stringValue = [NSString stringWithFormat:@"%llu", [state[@"loopStart"] unsignedLongLongValue]];
    _loopEndField.stringValue = [NSString stringWithFormat:@"%llu", [state[@"loopEnd"] unsignedLongLongValue]];
    _crossfadeField.stringValue = [NSString stringWithFormat:@"%u", [state[@"crossfadeFrames"] unsignedIntValue]];
    _rootKeyField.stringValue = [NSString stringWithFormat:@"%u", [state[@"rootKey"] unsignedIntValue]];
    _fineTuneField.stringValue = [NSString stringWithFormat:@"%.2f", [state[@"fineTuneCents"] floatValue]];
}

- (NSInteger)numberOfRowsInTableView:(NSTableView*)tableView {
    (void)tableView;
    return static_cast<NSInteger>(_sampleRows.count);
}

- (NSTableRowView*)tableView:(NSTableView*)tableView rowViewForRow:(NSInteger)row {
    (void)tableView;
    (void)row;
    return [[SVSampleRowView alloc] initWithFrame:NSZeroRect];
}

- (NSView*)tableView:(NSTableView*)tableView viewForTableColumn:(NSTableColumn*)tableColumn row:(NSInteger)row {
    (void)tableView;
    (void)tableColumn;
    if (row < 0 || static_cast<NSUInteger>(row) >= _sampleRows.count) return nil;
    NSTextField* cell = makeLabel(NSMakeRect(16.0, 12.0, 276.0, 24.0), _sampleRows[static_cast<NSUInteger>(row)], 12.0,
                                  NSFontWeightMedium, [NSColor colorWithCalibratedWhite:0.86 alpha:1.0]);
    cell.autoresizingMask = NSViewWidthSizable;
    return cell;
}

- (void)tableViewSelectionDidChange:(NSNotification*)notification {
    (void)notification;
    [self refreshSelectedSample];
}

- (BOOL)requireSelectedSample:(NSUInteger*)indexOut {
    const NSUInteger index = [self selectedSampleIndex];
    if (index == NSNotFound) {
        showMessage(self.window, @"No sample selected", @"Select a sample first.", NSAlertStyleWarning);
        return NO;
    }
    if (indexOut != nullptr) *indexOut = index;
    return YES;
}

- (BOOL)readUnsignedField:(NSTextField*)field label:(NSString*)label value:(uint64_t*)valueOut {
    std::uint64_t value = 0U;
    if (!parseUnsignedField(field, value)) {
        showMessage(self.window, @"Invalid numeric value",
                    [NSString stringWithFormat:@"%@ must be a non-negative whole number.", label], NSAlertStyleWarning);
        return NO;
    }
    if (valueOut != nullptr) *valueOut = value;
    return YES;
}

- (void)finishEditWithError:(NSString*)error title:(NSString*)title {
    if (error.length != 0U) {
        showMessage(self.window, title, error, NSAlertStyleCritical);
        return;
    }
    [self refreshProjectView];
}

- (void)importPressed:(id)sender {
    (void)sender;
    NSOpenPanel* panel = [NSOpenPanel openPanel];
    panel.title = @"Import sampler material";
    panel.prompt = @"Import";
    panel.canChooseFiles = YES;
    panel.canChooseDirectories = NO;
    panel.allowsMultipleSelection = YES;
    panel.resolvesAliases = YES;
    panel.allowedFileTypes = @[@"kmp", @"KMP", @"ksc", @"KSC", @"ksf", @"KSF",
                               @"wav", @"WAV", @"wave", @"WAVE", @"aif", @"AIF", @"aiff", @"AIFF", @"aifc", @"AIFC"];

    if ([panel runModal] != NSModalResponseOK) return;
    NSMutableArray<NSString*>* paths = [NSMutableArray arrayWithCapacity:panel.URLs.count];
    for (NSURL* url in panel.URLs) {
        if (url.fileURL && url.path != nil) [paths addObject:url.path];
    }

    NSString* details = nil;
    if (![_documentModel importPaths:paths error:&details]) {
        showMessage(self.window, @"Import failed", details ?: @"No sampler material was imported.", NSAlertStyleCritical);
        return;
    }
    [self refreshProjectView];
    if (details.length != 0U) showMessage(self.window, @"Imported with warnings", details, NSAlertStyleWarning);
}

- (void)clearPressed:(id)sender {
    (void)sender;
    if (_sampleRows.count == 0U) return;
    NSAlert* alert = [[NSAlert alloc] init];
    alert.messageText = @"Clear the current Manager project?";
    alert.informativeText = @"Imported and edited project-copy data will be cleared. Original source files and already built .sv banks are not deleted.";
    [alert addButtonWithTitle:@"Clear"];
    [alert addButtonWithTitle:@"Cancel"];
    alert.alertStyle = NSAlertStyleWarning;
    if ([alert runModal] != NSAlertFirstButtonReturn) return;
    [_documentModel clearProject];
    _pathLabel.stringValue = @"Bank not built yet";
    [self refreshProjectView];
}

- (void)buildPressed:(id)sender {
    (void)sender;
    if (_sampleRows.count == 0U) {
        showMessage(self.window, @"Nothing to build", @"Import at least one KMP/KSC/KSF/WAV/AIFF resource first.", NSAlertStyleWarning);
        return;
    }

    NSSavePanel* panel = [NSSavePanel savePanel];
    panel.title = @"Build SILVETON bank";
    panel.prompt = @"Build Bank";
    panel.nameFieldStringValue = @"SILVETON_BANK.sv";
    panel.allowedFileTypes = @[@"sv"];
    panel.allowsOtherFileTypes = NO;
    panel.canCreateDirectories = YES;
    if ([panel runModal] != NSModalResponseOK || panel.URL.path == nil) return;

    NSString* error = nil;
    NSString* summary = nil;
    if (![_documentModel buildBankAtPath:panel.URL.path error:&error summary:&summary]) {
        showMessage(self.window, @"Bank build failed", error ?: @"Unknown bank build error.", NSAlertStyleCritical);
        return;
    }

    _pathLabel.stringValue = [NSString stringWithFormat:@"Built: %@", panel.URL.path];
    showMessage(self.window, @"SILVETON bank built", summary ?: @"Bank build completed.", NSAlertStyleInformational);
}

- (void)trimPressed:(id)sender {
    (void)sender;
    NSUInteger index = 0U; if (![self requireSelectedSample:&index]) return;
    uint64_t startFrame = 0U;
    uint64_t endFrame = 0U;
    if (![self readUnsignedField:_trimStartField label:@"Trim Start" value:&startFrame] ||
        ![self readUnsignedField:_trimEndField label:@"Trim End" value:&endFrame]) return;
    NSString* error = nil;
    [_documentModel trimSampleAtIndex:index startFrame:startFrame endFrame:endFrame error:&error];
    [self finishEditWithError:error title:@"Trim failed"];
}

- (void)setLoopPressed:(id)sender {
    (void)sender;
    NSUInteger index = 0U; if (![self requireSelectedSample:&index]) return;
    uint64_t startFrame = 0U;
    uint64_t endFrame = 0U;
    if (![self readUnsignedField:_loopStartField label:@"Loop Start" value:&startFrame] ||
        ![self readUnsignedField:_loopEndField label:@"Loop End" value:&endFrame]) return;
    NSString* error = nil;
    [_documentModel setLoopForSampleAtIndex:index enabled:YES startFrame:startFrame endFrame:endFrame error:&error];
    [self finishEditWithError:error title:@"Set Loop failed"];
}

- (void)loopOffPressed:(id)sender {
    (void)sender;
    NSUInteger index = 0U; if (![self requireSelectedSample:&index]) return;
    NSString* error = nil;
    [_documentModel setLoopForSampleAtIndex:index enabled:NO startFrame:0U endFrame:0U error:&error];
    [self finishEditWithError:error title:@"Loop Off failed"];
}

- (void)crossfadePressed:(id)sender {
    (void)sender;
    NSUInteger index = 0U; if (![self requireSelectedSample:&index]) return;
    uint64_t requested = 0U;
    if (![self readUnsignedField:_crossfadeField label:@"Loop Crossfade" value:&requested]) return;
    if (requested > UINT32_MAX) {
        showMessage(self.window, @"Crossfade failed", @"Crossfade frame count is too large.", NSAlertStyleWarning);
        return;
    }
    NSString* error = nil;
    [_documentModel applyLoopCrossfadeForSampleAtIndex:index frames:static_cast<uint32_t>(requested) error:&error];
    [self finishEditWithError:error title:@"Crossfade failed"];
}

- (void)fadeInPressed:(id)sender {
    (void)sender;
    NSUInteger index = 0U; if (![self requireSelectedSample:&index]) return;
    uint64_t frames = 0U;
    if (![self readUnsignedField:_fadeInField label:@"Fade In" value:&frames]) return;
    NSString* error = nil;
    [_documentModel fadeInSampleAtIndex:index frames:frames error:&error];
    [self finishEditWithError:error title:@"Fade In failed"];
}

- (void)fadeOutPressed:(id)sender {
    (void)sender;
    NSUInteger index = 0U; if (![self requireSelectedSample:&index]) return;
    uint64_t frames = 0U;
    if (![self readUnsignedField:_fadeOutField label:@"Fade Out" value:&frames]) return;
    NSString* error = nil;
    [_documentModel fadeOutSampleAtIndex:index frames:frames error:&error];
    [self finishEditWithError:error title:@"Fade Out failed"];
}

- (void)gainPressed:(id)sender {
    (void)sender;
    NSUInteger index = 0U; if (![self requireSelectedSample:&index]) return;
    NSString* error = nil;
    [_documentModel applyGainForSampleAtIndex:index gainDb:_gainField.floatValue error:&error];
    [self finishEditWithError:error title:@"Gain failed"];
}

- (void)normalizePressed:(id)sender {
    (void)sender;
    NSUInteger index = 0U; if (![self requireSelectedSample:&index]) return;
    NSString* error = nil;
    [_documentModel normalizeSampleAtIndex:index targetPeakDb:_normalizeField.floatValue error:&error];
    [self finishEditWithError:error title:@"Normalize failed"];
}

- (void)reversePressed:(id)sender {
    (void)sender;
    NSUInteger index = 0U; if (![self requireSelectedSample:&index]) return;
    NSString* error = nil;
    [_documentModel reverseSampleAtIndex:index error:&error];
    [self finishEditWithError:error title:@"Reverse failed"];
}

- (void)tuningPressed:(id)sender {
    (void)sender;
    NSUInteger index = 0U; if (![self requireSelectedSample:&index]) return;
    const NSInteger root = _rootKeyField.integerValue;
    const float cents = _fineTuneField.floatValue;
    if (root < 0 || root > 127) {
        showMessage(self.window, @"Tuning failed", @"Root Key must be between 0 and 127.", NSAlertStyleWarning);
        return;
    }
    if (cents < -100.0F || cents > 100.0F) {
        showMessage(self.window, @"Tuning failed", @"Fine Tune must be between -100 and +100 cents.", NSAlertStyleWarning);
        return;
    }

    NSString* error = nil;
    if (![_documentModel setRootKeyForSampleAtIndex:index rootKey:static_cast<uint8_t>(root) error:&error]) {
        [self finishEditWithError:error title:@"Tuning failed"];
        return;
    }
    if (![_documentModel setFineTuneForSampleAtIndex:index cents:cents error:&error]) {
        [self finishEditWithError:error title:@"Tuning failed"];
        return;
    }
    [self finishEditWithError:nil title:@"Tuning failed"];
}

- (BOOL)readZeroRadius:(uint64_t*)radiusOut {
    return [self readUnsignedField:_zeroRadiusField label:@"Zero radius" value:radiusOut];
}

- (void)snapTrimStartPressed:(id)sender {
    (void)sender;
    NSUInteger index = 0U; if (![self requireSelectedSample:&index]) return;
    uint64_t frame = 0U;
    uint64_t radius = 0U;
    if (![self readUnsignedField:_trimStartField label:@"Trim Start" value:&frame] || ![self readZeroRadius:&radius]) return;
    const uint64_t snapped = [_documentModel nearestZeroCrossingForSampleAtIndex:index frame:frame radius:radius];
    _trimStartField.stringValue = [NSString stringWithFormat:@"%llu", static_cast<unsigned long long>(snapped)];
}

- (void)snapTrimEndPressed:(id)sender {
    (void)sender;
    NSUInteger index = 0U; if (![self requireSelectedSample:&index]) return;
    uint64_t frame = 0U;
    uint64_t radius = 0U;
    if (![self readUnsignedField:_trimEndField label:@"Trim End" value:&frame] || ![self readZeroRadius:&radius]) return;
    const uint64_t snapped = [_documentModel nearestZeroCrossingForSampleAtIndex:index frame:frame radius:radius];
    _trimEndField.stringValue = [NSString stringWithFormat:@"%llu", static_cast<unsigned long long>(snapped)];
}

- (void)snapLoopStartPressed:(id)sender {
    (void)sender;
    NSUInteger index = 0U; if (![self requireSelectedSample:&index]) return;
    uint64_t frame = 0U;
    uint64_t radius = 0U;
    if (![self readUnsignedField:_loopStartField label:@"Loop Start" value:&frame] || ![self readZeroRadius:&radius]) return;
    const uint64_t snapped = [_documentModel nearestZeroCrossingForSampleAtIndex:index frame:frame radius:radius];
    _loopStartField.stringValue = [NSString stringWithFormat:@"%llu", static_cast<unsigned long long>(snapped)];
}

- (void)snapLoopEndPressed:(id)sender {
    (void)sender;
    NSUInteger index = 0U; if (![self requireSelectedSample:&index]) return;
    uint64_t frame = 0U;
    uint64_t radius = 0U;
    if (![self readUnsignedField:_loopEndField label:@"Loop End" value:&frame] || ![self readZeroRadius:&radius]) return;
    const uint64_t snapped = [_documentModel nearestZeroCrossingForSampleAtIndex:index frame:frame radius:radius];
    _loopEndField.stringValue = [NSString stringWithFormat:@"%llu", static_cast<unsigned long long>(snapped)];
}

@end
