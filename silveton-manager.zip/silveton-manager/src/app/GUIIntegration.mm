#import <AppKit/AppKit.h>
#import <objc/runtime.h>
#import "SilvetonControls.h"

@interface SVAppDelegate : NSObject <NSApplicationDelegate>
- (void)showMediaCommand:(id)sender;
- (void)showObjectManagerCommand:(id)sender;
- (void)showConverterCommand:(id)sender;
- (void)showMultisampleEditor:(id)sender;
- (void)showSoundEditor:(id)sender;
- (void)showBankOrganizer:(id)sender;
- (void)showWorkflowCommand:(id)sender;
- (void)saveBankCommand:(id)sender;
- (void)showSampleEditorCommand:(id)sender;
@end

@interface SVGUIBridge : NSObject
- (instancetype)initWithDelegate:(SVAppDelegate*)delegate;
- (void)installOnMainWindow;
@end

namespace {
static const void* kSVGUIBridgeKey = &kSVGUIBridgeKey;

NSString* const kSamplesItem = @"samples";
NSString* const kMediaItem = @"media";
NSString* const kMultisampleItem = @"multisample";
NSString* const kSoundItem = @"sound";
NSString* const kBankItem = @"bank";
NSString* const kObjectsItem = @"objects";
NSString* const kConverterItem = @"converter";
NSString* const kWorkflowItem = @"workflow";

id SVMainController(SVAppDelegate* delegate) {
    return [delegate valueForKey:@"mainWindowController"];
}

NSTextField* SVSidebarLabel(NSRect frame, NSString* text) {
    NSTextField* label = [[NSTextField alloc] initWithFrame:frame];
    label.stringValue = text ?: @"";
    label.editable = NO;
    label.selectable = NO;
    label.bezeled = NO;
    label.drawsBackground = NO;
    label.font = [NSFont systemFontOfSize:10.0 weight:NSFontWeightSemibold];
    label.textColor = [NSColor colorWithCalibratedRed:0.42 green:0.47 blue:0.53 alpha:1.0];
    label.alignment = NSTextAlignmentCenter;
    return label;
}

void SVInstallGUIWhenReady(void) {
    [[NSNotificationCenter defaultCenter] addObserverForName:NSApplicationDidFinishLaunchingNotification
                                                      object:nil
                                                       queue:[NSOperationQueue mainQueue]
                                                  usingBlock:^(NSNotification* note) {
        (void)note;
        dispatch_async(dispatch_get_main_queue(), ^{
            id delegateObject = NSApp.delegate;
            if (delegateObject == nil || ![delegateObject isKindOfClass:NSClassFromString(@"SVAppDelegate")]) return;
            SVAppDelegate* delegate = (SVAppDelegate*)delegateObject;
            SVGUIBridge* bridge = [[SVGUIBridge alloc] initWithDelegate:delegate];
            objc_setAssociatedObject(delegate, kSVGUIBridgeKey, bridge, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
            [bridge installOnMainWindow];
        });
    }];
}
}

@implementation SVGUIBridge {
    __weak SVAppDelegate* _delegate;
    NSMutableDictionary<NSString*, SVBoutiqueButton*>* _buttons;
}

- (instancetype)initWithDelegate:(SVAppDelegate*)delegate {
    self = [super init];
    if (self) {
        _delegate = delegate;
        _buttons = [NSMutableDictionary dictionary];
    }
    return self;
}

- (SVBoutiqueButton*)sidebarButton:(NSString*)title
                         identifier:(NSString*)identifier
                                  y:(CGFloat)y
                             action:(SEL)action {
    SVBoutiqueButton* button = [[SVBoutiqueButton alloc] initWithFrame:NSMakeRect(1260.0, y, 152.0, 56.0)];
    button.title = title;
    button.target = self;
    button.action = action;
    button.showLED = YES;
    button.font = [NSFont systemFontOfSize:10.5 weight:NSFontWeightMedium];
    button.autoresizingMask = NSViewMinXMargin | NSViewMinYMargin;
    _buttons[identifier] = button;
    return button;
}

- (void)installOnMainWindow {
    id main = SVMainController(_delegate);
    if (main == nil || ![main respondsToSelector:@selector(window)]) return;
    NSWindow* window = [main window];
    if (window == nil || window.contentView == nil) return;

    // The sampler-style sidebar replaces the old NSToolbar completely.
    window.toolbar = nil;

    NSView* content = window.contentView;
    SVPanelView* sidebar = [[SVPanelView alloc] initWithFrame:NSMakeRect(1248.0, 16.0, 176.0, 750.0)];
    sidebar.cornerRadius = 14.0;
    sidebar.autoresizingMask = NSViewMinXMargin | NSViewHeightSizable;
    [content addSubview:sidebar];

    NSTextField* label = SVSidebarLabel(NSMakeRect(1260.0, 734.0, 152.0, 18.0), @"WORKSPACES");
    label.autoresizingMask = NSViewMinXMargin | NSViewMinYMargin;
    [content addSubview:label];

    [content addSubview:[self sidebarButton:@"SAMPLES" identifier:kSamplesItem y:668.0 action:@selector(samples:)]];
    [content addSubview:[self sidebarButton:@"MEDIA" identifier:kMediaItem y:602.0 action:@selector(media:)]];
    [content addSubview:[self sidebarButton:@"MULTISAMPLE" identifier:kMultisampleItem y:536.0 action:@selector(multisample:)]];
    [content addSubview:[self sidebarButton:@"SOUND" identifier:kSoundItem y:470.0 action:@selector(sound:)]];
    [content addSubview:[self sidebarButton:@"BANK" identifier:kBankItem y:404.0 action:@selector(bank:)]];
    [content addSubview:[self sidebarButton:@"OBJECTS" identifier:kObjectsItem y:338.0 action:@selector(objects:)]];
    [content addSubview:[self sidebarButton:@"CONVERTER" identifier:kConverterItem y:272.0 action:@selector(converter:)]];
    [content addSubview:[self sidebarButton:@"WORKFLOW" identifier:kWorkflowItem y:206.0 action:@selector(workflow:)]];

    SVBoutiqueButton* save = [[SVBoutiqueButton alloc] initWithFrame:NSMakeRect(1260.0, 76.0, 152.0, 62.0)];
    save.title = @"SAVE BANK";
    save.target = self;
    save.action = @selector(save:);
    save.accentAction = YES;
    save.showLED = YES;
    save.font = [NSFont systemFontOfSize:10.5 weight:NSFontWeightSemibold];
    save.autoresizingMask = NSViewMinXMargin | NSViewMaxYMargin;
    [content addSubview:save];

    [self selectWorkspace:kSamplesItem];
}

- (void)selectWorkspace:(NSString*)identifier {
    for (NSString* key in _buttons) _buttons[key].selectedState = [key isEqualToString:identifier];
}

- (void)samples:(id)sender { [self selectWorkspace:kSamplesItem]; [_delegate showSampleEditorCommand:sender]; }
- (void)media:(id)sender { [self selectWorkspace:kMediaItem]; [_delegate showMediaCommand:sender]; }
- (void)multisample:(id)sender { [self selectWorkspace:kMultisampleItem]; [_delegate showMultisampleEditor:sender]; }
- (void)sound:(id)sender { [self selectWorkspace:kSoundItem]; [_delegate showSoundEditor:sender]; }
- (void)bank:(id)sender { [self selectWorkspace:kBankItem]; [_delegate showBankOrganizer:sender]; }
- (void)objects:(id)sender { [self selectWorkspace:kObjectsItem]; [_delegate showObjectManagerCommand:sender]; }
- (void)converter:(id)sender { [self selectWorkspace:kConverterItem]; [_delegate showConverterCommand:sender]; }
- (void)workflow:(id)sender { [self selectWorkspace:kWorkflowItem]; [_delegate showWorkflowCommand:sender]; }
- (void)save:(id)sender { [_delegate saveBankCommand:sender]; }

@end

@implementation SVAppDelegate (GUIIntegration)

+ (void)load {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ SVInstallGUIWhenReady(); });
}

- (void)showSampleEditorCommand:(id)sender {
    (void)sender;
    id main = SVMainController(self);
    if (main == nil || ![main respondsToSelector:@selector(showWindow:)]) return;
    [main showWindow:self];
    NSWindow* window = [main window];
    [window makeKeyAndOrderFront:self];
}

@end
