#import <AppKit/AppKit.h>

@interface SVPanelView : NSView
@property(nonatomic) CGFloat cornerRadius;
@property(nonatomic) BOOL emphasized;
@end

@interface SVHeaderView : NSView
@end

@interface SVBoutiqueButton : NSButton
@property(nonatomic) BOOL accentAction;
@property(nonatomic) BOOL dangerAction;
@property(nonatomic) BOOL selectedState;
@property(nonatomic) BOOL showLED;
@end

@interface SVTableRowView : NSTableRowView
@end
