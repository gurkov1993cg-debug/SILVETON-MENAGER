#import "SilvetonControls.h"
#import <QuartzCore/QuartzCore.h>

namespace {
NSColor* SVColor(CGFloat r, CGFloat g, CGFloat b, CGFloat a = 1.0) {
    return [NSColor colorWithCalibratedRed:r green:g blue:b alpha:a];
}

void SVDrawRoundedPanel(NSRect bounds, CGFloat radius, BOOL emphasized) {
    NSRect outer = NSInsetRect(bounds, 0.5, 0.5);
    NSBezierPath* shape = [NSBezierPath bezierPathWithRoundedRect:outer xRadius:radius yRadius:radius];

    NSGradient* fill = [[NSGradient alloc] initWithStartingColor:(emphasized ? SVColor(0.115, 0.145, 0.178) : SVColor(0.092, 0.108, 0.128))
                                                  endingColor:(emphasized ? SVColor(0.078, 0.098, 0.122) : SVColor(0.064, 0.076, 0.091))];
    [fill drawInBezierPath:shape angle:-90.0];

    [SVColor(0.175, 0.205, 0.238, 0.72) setStroke];
    shape.lineWidth = 1.0;
    [shape stroke];

    NSBezierPath* inner = [NSBezierPath bezierPathWithRoundedRect:NSInsetRect(outer, 1.0, 1.0)
                                                          xRadius:MAX(1.0, radius - 1.0)
                                                          yRadius:MAX(1.0, radius - 1.0)];
    [SVColor(0.020, 0.025, 0.031, 0.72) setStroke];
    inner.lineWidth = 1.0;
    [inner stroke];
}

void SVDrawLED(NSPoint center, BOOL on) {
    const CGFloat glowRadius = 10.0;
    if (on) {
        for (NSInteger i = 5; i >= 1; --i) {
            const CGFloat t = static_cast<CGFloat>(i) / 5.0;
            NSRect glowRect = NSMakeRect(center.x - glowRadius * t,
                                         center.y - glowRadius * t,
                                         glowRadius * 2.0 * t,
                                         glowRadius * 2.0 * t);
            [SVColor(0.20, 0.72, 1.0, 0.035 + (1.0 - t) * 0.045) setFill];
            [[NSBezierPath bezierPathWithOvalInRect:glowRect] fill];
        }
    }

    NSRect rim = NSMakeRect(center.x - 5.2, center.y - 5.2, 10.4, 10.4);
    [SVColor(0.018, 0.024, 0.030) setFill];
    [[NSBezierPath bezierPathWithOvalInRect:rim] fill];
    [SVColor(0.13, 0.16, 0.19) setStroke];
    [[NSBezierPath bezierPathWithOvalInRect:rim] stroke];

    NSRect core = NSMakeRect(center.x - 3.2, center.y - 3.2, 6.4, 6.4);
    [(on ? SVColor(0.39, 0.82, 1.0) : SVColor(0.10, 0.12, 0.14)) setFill];
    [[NSBezierPath bezierPathWithOvalInRect:core] fill];
    if (on) {
        NSRect shine = NSMakeRect(center.x - 1.6, center.y + 0.2, 2.3, 2.3);
        [SVColor(0.86, 0.96, 1.0, 0.95) setFill];
        [[NSBezierPath bezierPathWithOvalInRect:shine] fill];
    }
}
}

@implementation SVPanelView

- (instancetype)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _cornerRadius = 14.0;
        _emphasized = NO;
        self.wantsLayer = YES;
    }
    return self;
}

- (void)setCornerRadius:(CGFloat)cornerRadius {
    _cornerRadius = cornerRadius;
    [self setNeedsDisplay:YES];
}

- (void)setEmphasized:(BOOL)emphasized {
    _emphasized = emphasized;
    [self setNeedsDisplay:YES];
}

- (void)drawRect:(NSRect)dirtyRect {
    (void)dirtyRect;
    SVDrawRoundedPanel(self.bounds, self.cornerRadius, self.emphasized);
}

@end

@implementation SVHeaderView

- (void)drawRect:(NSRect)dirtyRect {
    (void)dirtyRect;
    NSGradient* background = [[NSGradient alloc] initWithStartingColor:SVColor(0.045, 0.052, 0.061)
                                                         endingColor:SVColor(0.026, 0.031, 0.038)];
    [background drawInRect:self.bounds angle:-90.0];

    [SVColor(0.15, 0.17, 0.20, 0.85) setStroke];
    NSBezierPath* bottom = [NSBezierPath bezierPath];
    [bottom moveToPoint:NSMakePoint(0.0, 0.5)];
    [bottom lineToPoint:NSMakePoint(NSWidth(self.bounds), 0.5)];
    [bottom stroke];

    const CGFloat cx = NSMidX(self.bounds) - 105.0;
    const CGFloat cy = NSMidY(self.bounds) + 1.0;
    NSBezierPath* wave = [NSBezierPath bezierPath];
    wave.lineWidth = 2.6;
    [wave moveToPoint:NSMakePoint(cx - 20.0, cy)];
    [wave curveToPoint:NSMakePoint(cx - 10.0, cy - 12.0)
          controlPoint1:NSMakePoint(cx - 16.0, cy)
          controlPoint2:NSMakePoint(cx - 15.0, cy - 12.0)];
    [wave curveToPoint:NSMakePoint(cx, cy + 12.0)
          controlPoint1:NSMakePoint(cx - 5.0, cy - 12.0)
          controlPoint2:NSMakePoint(cx - 5.0, cy + 12.0)];
    [wave curveToPoint:NSMakePoint(cx + 10.0, cy - 12.0)
          controlPoint1:NSMakePoint(cx + 5.0, cy + 12.0)
          controlPoint2:NSMakePoint(cx + 5.0, cy - 12.0)];
    [wave curveToPoint:NSMakePoint(cx + 20.0, cy)
          controlPoint1:NSMakePoint(cx + 15.0, cy - 12.0)
          controlPoint2:NSMakePoint(cx + 16.0, cy)];
    [SVColor(0.76, 0.81, 0.87) setStroke];
    [wave stroke];

    NSDictionary* brandAttrs = @{
        NSForegroundColorAttributeName: SVColor(0.80, 0.84, 0.89),
        NSFontAttributeName: [NSFont systemFontOfSize:25.0 weight:NSFontWeightBold],
        NSKernAttributeName: @5.0
    };
    [@"SILVETON" drawAtPoint:NSMakePoint(cx + 39.0, cy - 15.0) withAttributes:brandAttrs];

    NSDictionary* subAttrs = @{
        NSForegroundColorAttributeName: SVColor(0.65, 0.68, 0.73),
        NSFontAttributeName: [NSFont systemFontOfSize:15.0 weight:NSFontWeightRegular],
        NSKernAttributeName: @2.0
    };
    [@"manager" drawAtPoint:NSMakePoint(cx + 217.0, cy - 11.0) withAttributes:subAttrs];
}

@end

@implementation SVBoutiqueButton

- (instancetype)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.bordered = NO;
        self.buttonType = NSButtonTypeMomentaryChange;
        self.focusRingType = NSFocusRingTypeNone;
        self.font = [NSFont systemFontOfSize:11.5 weight:NSFontWeightMedium];
        self.wantsLayer = YES;
        _accentAction = NO;
        _dangerAction = NO;
        _selectedState = NO;
        _showLED = NO;
    }
    return self;
}

- (void)setAccentAction:(BOOL)value { _accentAction = value; [self setNeedsDisplay:YES]; }
- (void)setDangerAction:(BOOL)value { _dangerAction = value; [self setNeedsDisplay:YES]; }
- (void)setSelectedState:(BOOL)value { _selectedState = value; [self setNeedsDisplay:YES]; }
- (void)setShowLED:(BOOL)value { _showLED = value; [self setNeedsDisplay:YES]; }

- (void)drawRect:(NSRect)dirtyRect {
    (void)dirtyRect;
    const BOOL highlighted = [(NSButtonCell*)self.cell isHighlighted];
    NSRect outer = NSInsetRect(self.bounds, 1.0, 1.5);
    const CGFloat radius = MIN(10.0, NSHeight(outer) * 0.22);
    NSBezierPath* shape = [NSBezierPath bezierPathWithRoundedRect:outer xRadius:radius yRadius:radius];

    NSColor* top = nil;
    NSColor* bottom = nil;
    NSColor* stroke = nil;
    NSColor* text = nil;

    if (self.dangerAction) {
        top = highlighted ? SVColor(0.32, 0.105, 0.11) : SVColor(0.25, 0.075, 0.08);
        bottom = SVColor(0.12, 0.035, 0.04);
        stroke = SVColor(0.55, 0.18, 0.19, 0.95);
        text = SVColor(0.98, 0.75, 0.75);
    } else if (self.accentAction || self.selectedState) {
        top = highlighted ? SVColor(0.18, 0.30, 0.40) : SVColor(0.14, 0.23, 0.31);
        bottom = SVColor(0.08, 0.14, 0.19);
        stroke = SVColor(0.30, 0.46, 0.58, 0.95);
        text = SVColor(0.86, 0.91, 0.96);
    } else {
        top = highlighted ? SVColor(0.16, 0.18, 0.21) : SVColor(0.13, 0.15, 0.18);
        bottom = SVColor(0.075, 0.086, 0.10);
        stroke = SVColor(0.24, 0.27, 0.31, 0.95);
        text = SVColor(0.72, 0.76, 0.81);
    }

    NSGradient* gradient = [[NSGradient alloc] initWithStartingColor:top endingColor:bottom];
    [gradient drawInBezierPath:shape angle:-90.0];
    [stroke setStroke];
    shape.lineWidth = 1.0;
    [shape stroke];

    NSBezierPath* highlight = [NSBezierPath bezierPathWithRoundedRect:NSInsetRect(outer, 1.1, 1.1)
                                                              xRadius:MAX(1.0, radius - 1.0)
                                                              yRadius:MAX(1.0, radius - 1.0)];
    [SVColor(1.0, 1.0, 1.0, 0.055) setStroke];
    highlight.lineWidth = 1.0;
    [highlight stroke];

    const CGFloat leftPad = self.showLED ? 31.0 : 0.0;
    if (self.showLED) SVDrawLED(NSMakePoint(20.0, NSMidY(self.bounds)), self.selectedState || self.accentAction);

    NSMutableParagraphStyle* paragraph = [[NSMutableParagraphStyle alloc] init];
    paragraph.alignment = NSTextAlignmentCenter;
    NSDictionary* attributes = @{
        NSForegroundColorAttributeName: text,
        NSFontAttributeName: self.font ?: [NSFont systemFontOfSize:11.5 weight:NSFontWeightMedium],
        NSParagraphStyleAttributeName: paragraph,
        NSKernAttributeName: @1.1
    };
    NSAttributedString* title = [[NSAttributedString alloc] initWithString:self.title ?: @"" attributes:attributes];
    NSSize titleSize = title.size;
    const CGFloat contentWidth = NSWidth(self.bounds) - leftPad;
    const CGFloat x = leftPad + floor((contentWidth - titleSize.width) * 0.5);
    const CGFloat y = floor((NSHeight(self.bounds) - titleSize.height) * 0.5) + 1.0;
    [title drawAtPoint:NSMakePoint(x, y)];
}

@end

@implementation SVTableRowView

- (void)drawSelectionInRect:(NSRect)dirtyRect {
    (void)dirtyRect;
    if (!self.selected) return;
    NSRect rect = NSInsetRect(self.bounds, 1.0, 1.0);
    NSBezierPath* shape = [NSBezierPath bezierPathWithRoundedRect:rect xRadius:7.0 yRadius:7.0];
    NSGradient* gradient = [[NSGradient alloc] initWithStartingColor:SVColor(0.16, 0.22, 0.28)
                                                         endingColor:SVColor(0.105, 0.16, 0.21)];
    [gradient drawInBezierPath:shape angle:-90.0];
    [SVColor(0.23, 0.38, 0.49, 0.88) setStroke];
    [shape stroke];
}

@end
