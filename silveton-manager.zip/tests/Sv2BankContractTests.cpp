#include "silveton/manager/ManagerTypes.h"
#include "silveton/manager/SvBankBuilder.h"
#include "silveton/manager/SvBankFormat.h"
#include "silveton/manager/SvBankReader.h"

#include <algorithm>
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <set>
#include <string>
#include <unistd.h>
#include <vector>

namespace {

using namespace silveton::manager;
using Bytes = std::vector<std::uint8_t>;

[[noreturn]] void fail(const std::string& message) {
    std::cerr << "FAIL: " << message << '\n';
    std::exit(1);
}

void require(bool condition, const std::string& message) {
    if (!condition) fail(message);
}

ImportedSample makeSample(std::uint32_t id,
                          const std::string& name,
                          std::uint32_t sampleRate,
                          std::uint16_t channels,
                          const Bytes& audio,
                          std::uint64_t frames) {
    ImportedSample sample{};
    sample.sampleId = id;
    sample.name = name;
    sample.sourceIdentity = "sv2-test:" + name;
    sample.sampleRate = sampleRate;
    sample.channels = channels;
    sample.encoding = AudioEncoding::Pcm16LE;
    sample.bitsPerSample = 16U;
    sample.rootKey = 60U;
    sample.fineTuneCents = 3.25F;
    sample.totalFrames = frames;
    sample.loop.enabled = true;
    sample.loop.startFrame = 1U;
    sample.loop.endFrame = frames;
    sample.loop.crossfadeFrames = frames > 2U ? 1U : 0U;
    sample.audioData = audio;
    return sample;
}

ImportedZone makeZone(std::uint32_t sampleIndex, std::uint8_t low, std::uint8_t high) {
    ImportedZone zone{};
    zone.sampleIndex = sampleIndex;
    zone.keyLow = low;
    zone.keyHigh = high;
    zone.velocityLow = 1U;
    zone.velocityHigh = 127U;
    zone.rootKey = static_cast<std::uint8_t>((static_cast<unsigned>(low) + static_cast<unsigned>(high)) / 2U);
    zone.tuneCents = 1.5F;
    zone.gainDb = -0.5F;
    zone.pan = 0.1F;
    return zone;
}

SoundDefinition makeSound(const std::string& name,
                          std::uint16_t slot,
                          std::uint16_t category,
                          std::uint32_t multisampleIndex) {
    SoundDefinition sound{};
    sound.name = name;
    sound.position = slot;
    sound.category = category;
    SoundLayer layer{};
    layer.multisampleIndex = multisampleIndex;
    sound.layers.push_back(layer);
    return sound;
}

BankProject makeProject() {
    BankProject project{};
    project.name = "SV2 REGRESSION BANK";

    const Bytes audioA{0x00U,0x00U, 0x10U,0x00U, 0xF0U,0xFFU, 0x00U,0x00U};
    const Bytes audioB{0x01U,0x00U, 0x20U,0x00U, 0xE0U,0xFFU, 0x02U,0x00U};
    const Bytes audioC{0x00U,0x00U,0x00U,0x00U, 0x20U,0x00U,0xE0U,0xFFU};

    project.samples.push_back(makeSample(1001U, "44K_A", 44100U, 1U, audioA, 4U));
    project.samples.push_back(makeSample(1002U, "48K_B", 48000U, 1U, audioB, 4U));
    project.samples.push_back(makeSample(1003U, "44K_ST", 44100U, 2U, audioC, 2U));
    project.samples.push_back(makeSample(1004U, "44K_A_DUP", 44100U, 1U, audioA, 4U));

    ImportedMultisample ms1{};
    ms1.multisampleId = 2001U;
    ms1.name = "MS-ONE";
    ms1.sourceIdentity = "sv2-test:ms1";
    ms1.zones.push_back(makeZone(0U, 0U, 63U));
    ms1.zones.push_back(makeZone(1U, 64U, 127U));
    project.multisamples.push_back(ms1);

    ImportedMultisample ms2{};
    ms2.multisampleId = 2002U;
    ms2.name = "MS-TWO";
    ms2.sourceIdentity = "sv2-test:ms2";
    ms2.zones.push_back(makeZone(2U, 0U, 79U));
    ms2.zones.push_back(makeZone(3U, 80U, 127U));
    project.multisamples.push_back(ms2);

    project.sounds.push_back(makeSound("SOUND-001", 1U, 1U, 0U));
    project.sounds.push_back(makeSound("SOUND-007", 7U, 2U, 1U));
    project.sounds.push_back(makeSound("SOUND-250", 250U, 3U, 0U));
    project.sounds.push_back(makeSound("SOUND-500", 500U, 4U, 1U));
    return project;
}

Bytes readFile(const std::string& path) {
    std::ifstream in(path, std::ios::binary | std::ios::ate);
    require(static_cast<bool>(in), "open written SV2 bank");
    const auto size = in.tellg();
    require(size >= 0, "measure written SV2 bank");
    in.seekg(0, std::ios::beg);
    Bytes bytes(static_cast<std::size_t>(size));
    if (!bytes.empty()) {
        in.read(reinterpret_cast<char*>(bytes.data()), static_cast<std::streamsize>(bytes.size()));
        require(in.good(), "read written SV2 bank");
    }
    return bytes;
}

void putLe32(Bytes& bytes, std::size_t offset, std::uint32_t value) {
    require(offset + 4U <= bytes.size(), "putLe32 bounds");
    bytes[offset] = static_cast<std::uint8_t>(value & 0xFFU);
    bytes[offset + 1U] = static_cast<std::uint8_t>((value >> 8U) & 0xFFU);
    bytes[offset + 2U] = static_cast<std::uint8_t>((value >> 16U) & 0xFFU);
    bytes[offset + 3U] = static_cast<std::uint8_t>((value >> 24U) & 0xFFU);
}

} // namespace

int main() {
    using namespace silveton::manager;

    const BankProject project = makeProject();
    const std::string path = std::string("/tmp/SILVETON_BANK_sv2_") + std::to_string(static_cast<long long>(::getpid())) + ".sv";

    SvBuildStats stats{};
    std::string error;
    require(SvBankBuilder::writeAtomic(path, project, stats, error), "write SV2 SILVETON_BANK.sv: " + error);
    require(error.empty(), "SV2 writer returned error");
    require(stats.soundCount == 4U && stats.multisampleCount == 2U && stats.sampleCount == 4U, "SV2 writer counts");
    require(stats.uniqueAudioPayloadCount == 3U, "SV2 audio deduplication");

    const Bytes bytes = readFile(path);
    require(bytes.size() >= kSvBankHeaderSize, "SV2 bank header size");
    require(std::equal(kSvBankMagic.begin(), kSvBankMagic.end(), bytes.begin()), "magic must be SILVSV2\\0");

    SvBankHeader header{};
    std::string headerError;
    require(deserializeHeader(bytes.data(), bytes.size(), header, headerError), "decode SV2 header: " + headerError);
    require(header.versionMajor == 2U, "SV2 major version must be 2");
    require(header.soundCount == 4U && header.multisampleCount == 2U && header.sampleCount == 4U && header.zoneCount == 4U,
            "SV2 header object counts");

    const auto& sampleSec = header.sections[static_cast<std::size_t>(SvSection::Samples)];
    const auto& audioSec = header.sections[static_cast<std::size_t>(SvSection::Audio)];
    std::set<std::uint32_t> sampleIds;
    std::set<std::uint32_t> sampleRates;
    std::array<SvSampleRecord,4> sampleRecords{};
    for (std::size_t i = 0U; i < sampleRecords.size(); ++i) {
        const std::size_t offset = static_cast<std::size_t>(sampleSec.offset) + i * kSvSampleRecordSize;
        require(readSampleRecord(bytes.data() + offset, bytes.size() - offset, sampleRecords[i]), "decode raw SV2 sample record");
        require(sampleRecords[i].sampleId != 0U && sampleIds.insert(sampleRecords[i].sampleId).second, "nonzero unique SampleID");
        sampleRates.insert(sampleRecords[i].sampleRate);
        require(sampleRecords[i].audioOffset <= audioSec.size && sampleRecords[i].audioSize <= audioSec.size - sampleRecords[i].audioOffset,
                "SV2 sample audio offsets in AUDIO section");
    }
    require(sampleRates.count(44100U) == 1U && sampleRates.count(48000U) == 1U, "SV2 preserves mixed 44.1/48 kHz sample rates");
    require(sampleRecords[0].audioOffset == sampleRecords[3].audioOffset && sampleRecords[0].audioSize == sampleRecords[3].audioSize,
            "SV2 deduplicated samples share AUDIO offset");

    const auto& zoneSec = header.sections[static_cast<std::size_t>(SvSection::Zones)];
    const std::array<std::uint32_t,4> expectedZoneIds{{1001U,1002U,1003U,1004U}};
    for (std::size_t i = 0U; i < expectedZoneIds.size(); ++i) {
        SvZoneRecord zone{};
        const std::size_t offset = static_cast<std::size_t>(zoneSec.offset) + i * kSvZoneRecordSize;
        require(readZoneRecord(bytes.data() + offset, bytes.size() - offset, zone), "decode raw SV2 zone record");
        require(zone.sampleId == expectedZoneIds[i], "Zone must persist SampleID, not sampleIndex");
    }

    const auto& msSec = header.sections[static_cast<std::size_t>(SvSection::Multisamples)];
    const std::array<std::uint32_t,2> expectedMsIds{{2001U,2002U}};
    for (std::size_t i = 0U; i < expectedMsIds.size(); ++i) {
        SvMultisampleRecord ms{};
        const std::size_t offset = static_cast<std::size_t>(msSec.offset) + i * kSvMultisampleRecordSize;
        require(readMultisampleRecord(bytes.data() + offset, bytes.size() - offset, ms), "decode raw SV2 multisample record");
        require(ms.multisampleId == expectedMsIds[i], "Multisample record must persist multisampleId");
    }

    const auto& layerSec = header.sections[static_cast<std::size_t>(SvSection::SoundLayers)];
    const std::array<std::uint32_t,4> expectedLayerIds{{2001U,2002U,2001U,2002U}};
    for (std::size_t i = 0U; i < expectedLayerIds.size(); ++i) {
        SvSoundLayerRecord layer{};
        const std::size_t offset = static_cast<std::size_t>(layerSec.offset) + i * kSvSoundLayerRecordSize;
        require(readSoundLayerRecord(bytes.data() + offset, bytes.size() - offset, layer), "decode raw SV2 SOUND layer record");
        require(layer.multisampleId == expectedLayerIds[i], "SoundLayer must persist MultisampleID, not multisampleIndex");
    }

    const auto& soundSec = header.sections[static_cast<std::size_t>(SvSection::Sounds)];
    const std::array<std::uint16_t,4> expectedSlots{{1U,7U,250U,500U}};
    for (std::size_t i = 0U; i < expectedSlots.size(); ++i) {
        SvSoundRecord sound{};
        const std::size_t offset = static_cast<std::size_t>(soundSec.offset) + i * kSvSoundRecordSize;
        require(readSoundRecord(bytes.data() + offset, bytes.size() - offset, sound), "decode raw SV2 SOUND record");
        require(sound.soundSlotId == expectedSlots[i], "SV2 SOUND position 1..500");
    }

    const auto round = SvBankReader::readFile(path, true);
    require(round.ok(), "SV2 readback with SHA/integrity");
    require(round.header.versionMajor == 2U, "SV2 readback major");
    require(round.project.sounds.size() == 4U && round.project.multisamples.size() == 2U && round.project.samples.size() == 4U,
            "SV2 readback counts");
    require(round.project.samples[0].sampleRate == 44100U && round.project.samples[1].sampleRate == 48000U,
            "SV2 readback preserves native sample rates");
    require(round.project.multisamples[0].zones[0].sampleIndex == 0U && round.project.multisamples[1].zones[1].sampleIndex == 3U,
            "SV2 reader resolves SampleID to internal sample index");
    require(round.project.sounds[0].layers[0].multisampleIndex == 0U && round.project.sounds[1].layers[0].multisampleIndex == 1U,
            "SV2 reader resolves MultisampleID to internal multisample index");
    require(round.project.sounds[0].position == 1U && round.project.sounds[3].position == 500U,
            "SV2 readback SOUND slots 1..500");

    BankProject invalid = project;
    invalid.samples[0].sampleId = 0U;
    require(!SvBankBuilder::build(invalid).ok(), "reject zero SampleID");
    invalid = project;
    invalid.samples[1].sampleId = invalid.samples[0].sampleId;
    require(!SvBankBuilder::build(invalid).ok(), "reject duplicate SampleID");
    invalid = project;
    invalid.multisamples[0].multisampleId = 0U;
    require(!SvBankBuilder::build(invalid).ok(), "reject zero MultisampleID");
    invalid = project;
    invalid.sounds[1].position = invalid.sounds[0].position;
    require(!SvBankBuilder::build(invalid).ok(), "reject duplicate SOUND slot");
    invalid = project;
    invalid.multisamples[0].zones[0].sampleIndex = 999U;
    require(!SvBankBuilder::build(invalid).ok(), "reject Zone with missing sample reference");
    invalid = project;
    invalid.sounds[0].layers[0].multisampleIndex = 999U;
    require(!SvBankBuilder::build(invalid).ok(), "reject SoundLayer with missing multisample reference");

    Bytes brokenZone = bytes;
    putLe32(brokenZone, static_cast<std::size_t>(zoneSec.offset), 0xDEADBEEFU);
    require(!SvBankReader::read(brokenZone, false).ok(), "reader rejects Zone missing SampleID");

    Bytes brokenLayer = bytes;
    putLe32(brokenLayer, static_cast<std::size_t>(layerSec.offset), 0xCAFEBABEU);
    require(!SvBankReader::read(brokenLayer, false).ok(), "reader rejects SoundLayer missing MultisampleID");

    Bytes sv1Magic = bytes;
    const std::array<std::uint8_t, 8> oldMagic{{'S','I','L','V','S','V','1',0}};
    std::copy(oldMagic.begin(), oldMagic.end(), sv1Magic.begin());
    require(!SvBankReader::read(sv1Magic, false).ok(), "reader rejects legacy SILVSV1 banks");

    Bytes wrongMajor = bytes;
    wrongMajor[8] = 1U;
    wrongMajor[9] = 0U;
    require(!SvBankReader::read(wrongMajor, false).ok(), "reader rejects SV major version 1");

    std::remove(path.c_str());
    std::cout << "SILVETON Manager SV2 bank contract tests PASS\n";
    return 0;
}
