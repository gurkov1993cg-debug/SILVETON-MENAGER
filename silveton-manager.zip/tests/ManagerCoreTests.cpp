#include "silveton/manager/AudioFileLoader.h"
#include "silveton/manager/KorgImporter.h"
#include "silveton/manager/SampleEditor.h"
#include "silveton/manager/SvBankBuilder.h"
#include "silveton/manager/SvBankFormat.h"
#include "silveton/manager/SvBankReader.h"

#include <array>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <sstream>
#include <string>
#include <sys/stat.h>
#include <unistd.h>
#include <vector>

namespace {

using Bytes = std::vector<std::uint8_t>;

void putBe16(Bytes& b, std::uint16_t v) { b.push_back(static_cast<std::uint8_t>((v>>8U)&0xFFU)); b.push_back(static_cast<std::uint8_t>(v&0xFFU)); }
void putBe32(Bytes& b, std::uint32_t v) { for(int s=24;s>=0;s-=8)b.push_back(static_cast<std::uint8_t>((v>>static_cast<unsigned>(s))&0xFFU)); }
void putLe16(Bytes& b, std::uint16_t v) { b.push_back(static_cast<std::uint8_t>(v&0xFFU)); b.push_back(static_cast<std::uint8_t>((v>>8U)&0xFFU)); }
void putLe32(Bytes& b, std::uint32_t v) { for(unsigned s=0;s<32U;s+=8U)b.push_back(static_cast<std::uint8_t>((v>>s)&0xFFU)); }

void setBe32(Bytes& b, std::size_t p, std::uint32_t v){b[p]=static_cast<std::uint8_t>((v>>24U)&0xFFU);b[p+1]=static_cast<std::uint8_t>((v>>16U)&0xFFU);b[p+2]=static_cast<std::uint8_t>((v>>8U)&0xFFU);b[p+3]=static_cast<std::uint8_t>(v&0xFFU);}
void setLe32(Bytes& b, std::size_t p, std::uint32_t v){b[p]=static_cast<std::uint8_t>(v&0xFFU);b[p+1]=static_cast<std::uint8_t>((v>>8U)&0xFFU);b[p+2]=static_cast<std::uint8_t>((v>>16U)&0xFFU);b[p+3]=static_cast<std::uint8_t>((v>>24U)&0xFFU);}

void chunkBe(Bytes& out, const char id[5], const Bytes& payload){out.insert(out.end(),id,id+4);putBe32(out,static_cast<std::uint32_t>(payload.size()));out.insert(out.end(),payload.begin(),payload.end());}
void chunkLe(Bytes& out, const char id[5], const Bytes& payload){out.insert(out.end(),id,id+4);putLe32(out,static_cast<std::uint32_t>(payload.size()));out.insert(out.end(),payload.begin(),payload.end());if(payload.size()&1U)out.push_back(0);}

[[noreturn]] void fail(const std::string& message) {
    std::cerr << "FAIL: " << message << '\n';
    std::exit(1);
}

void require(bool condition, const std::string& message) {
    if (!condition) fail(message);
}

std::string joinPath(const std::string& base, const std::string& leaf) {
    if (base.empty()) return leaf;
    if (base.back() == '/') return base + leaf;
    return base + "/" + leaf;
}

std::string testRoot() {
    const char* tmp = std::getenv("TMPDIR");
    const std::string base = (tmp != nullptr && tmp[0] != '\0') ? std::string(tmp) : std::string("/tmp");
    return joinPath(base, "silveton_manager_tests_" + std::to_string(static_cast<long long>(::getpid())));
}

void writeFile(const std::string& p,const Bytes& b){
    std::ofstream f(p,std::ios::binary);
    require(static_cast<bool>(f), "cannot create fixture file " + p);
    f.write(reinterpret_cast<const char*>(b.data()),static_cast<std::streamsize>(b.size()));
    require(f.good(), "cannot write fixture file " + p);
}

Bytes ksf(const std::string& name, const std::array<std::int16_t,4>& pcm){
    Bytes f,smp(32U,0U); for(std::size_t i=0;i<name.size()&&i<16U;++i)smp[i]=static_cast<std::uint8_t>(name[i]); setBe32(smp,24U,4U); setBe32(smp,28U,4U); chunkBe(f,"SMP1",smp);
    Bytes sno(4U,0U); chunkBe(f,"SNO1",sno);
    Bytes smd; putBe32(smd,48000U); smd.push_back(0xA0U); smd.push_back(0U); smd.push_back(1U); smd.push_back(16U); putBe32(smd,4U);
    for(auto s:pcm){const auto u=static_cast<std::uint16_t>(s);putBe16(smd,u);} chunkBe(f,"SMD1",smd); return f;
}

Bytes ksf8(const std::string& name, const std::array<std::int8_t,4>& pcm){
    Bytes f,smp(32U,0U); for(std::size_t i=0;i<name.size()&&i<16U;++i)smp[i]=static_cast<std::uint8_t>(name[i]); setBe32(smp,24U,4U); setBe32(smp,28U,4U); chunkBe(f,"SMP1",smp);
    Bytes sno(4U,0U); chunkBe(f,"SNO1",sno);
    Bytes smd; putBe32(smd,44100U); smd.push_back(0xA0U); smd.push_back(0U); smd.push_back(1U); smd.push_back(8U); putBe32(smd,4U);
    for(auto value:pcm) smd.push_back(static_cast<std::uint8_t>(value));
    chunkBe(f,"SMD1",smd); return f;
}

void fillName(Bytes& r,std::size_t off,const std::string& name,std::size_t n){for(std::size_t i=0;i<n;++i)r[off+i]=i<name.size()?static_cast<std::uint8_t>(name[i]):static_cast<std::uint8_t>(' ');}
Bytes kmp(){
    Bytes f,msp(18U,0U);fillName(msp,0,"FIXTURE",16U);msp[16]=3U;chunkBe(f,"MSP1",msp);Bytes mno(4U,0U);chunkBe(f,"MNO1",mno);
    Bytes rlp(54U,0U); rlp[0]=1U;rlp[1]=1U;fillName(rlp,6,"SKIPPEDSAMPL",12U);
    const std::size_t r1=18U;rlp[r1]=60U;rlp[r1+1]=63U;rlp[r1+4]=64U;fillName(rlp,r1+6,"A.KSF",12U);
    const std::size_t r2=36U;rlp[r2]=64U;rlp[r2+1]=127U;rlp[r2+4]=64U;fillName(rlp,r2+6,"B.KSF",12U);chunkBe(f,"RLP1",rlp);return f;
}

Bytes wav(){
    Bytes body; body.insert(body.end(),{'W','A','V','E'});
    Bytes fmt;putLe16(fmt,1U);putLe16(fmt,1U);putLe32(fmt,48000U);putLe32(fmt,96000U);putLe16(fmt,2U);putLe16(fmt,16U);chunkLe(body,"fmt ",fmt);
    Bytes smpl(60U,0U);setLe32(smpl,12U,64U);setLe32(smpl,28U,1U);setLe32(smpl,40U,0U);setLe32(smpl,44U,1U);setLe32(smpl,48U,2U);chunkLe(body,"smpl",smpl);
    Bytes data;const std::array<std::int16_t,4> samples{{std::numeric_limits<std::int16_t>::min(), static_cast<std::int16_t>(-1), 0, std::numeric_limits<std::int16_t>::max()}};for(const auto s:samples)putLe16(data,static_cast<std::uint16_t>(s));chunkLe(body,"data",data);
    Bytes out;out.insert(out.end(),{'R','I','F','F'});putLe32(out,static_cast<std::uint32_t>(body.size()));out.insert(out.end(),body.begin(),body.end());return out;
}

Bytes aiff(){
    Bytes body;body.insert(body.end(),{'A','I','F','F'});
    Bytes comm;putBe16(comm,1U);putBe32(comm,4U);putBe16(comm,16U);const std::array<std::uint8_t,10> rate{{0x40,0x0E,0xAC,0x44,0,0,0,0,0,0}};comm.insert(comm.end(),rate.begin(),rate.end());chunkBe(body,"COMM",comm);
    Bytes inst(20U,0U);inst[0]=65U;chunkBe(body,"INST",inst);
    Bytes ssnd;putBe32(ssnd,0U);putBe32(ssnd,0U);const std::array<std::int16_t,4> samples{{std::numeric_limits<std::int16_t>::min(), static_cast<std::int16_t>(-1), 0, std::numeric_limits<std::int16_t>::max()}};for(const auto s:samples)putBe16(ssnd,static_cast<std::uint16_t>(s));chunkBe(body,"SSND",ssnd);
    Bytes out;out.insert(out.end(),{'F','O','R','M'});putBe32(out,static_cast<std::uint32_t>(body.size()));out.insert(out.end(),body.begin(),body.end());return out;
}

std::int16_t pcm16At(const silveton::manager::ImportedSample& sample, std::uint64_t frame, std::uint16_t channel = 0U) {
    require(sample.encoding == silveton::manager::AudioEncoding::Pcm16LE, "pcm16At requires PCM16LE");
    require(channel < sample.channels && frame < sample.totalFrames, "pcm16At index out of range");
    const std::size_t offset = (static_cast<std::size_t>(frame) * static_cast<std::size_t>(sample.channels) + static_cast<std::size_t>(channel)) * 2U;
    const std::uint16_t raw = static_cast<std::uint16_t>(sample.audioData[offset]) |
                              static_cast<std::uint16_t>(static_cast<std::uint16_t>(sample.audioData[offset + 1U]) << 8U);
    return static_cast<std::int16_t>(raw);
}

std::string digestHex(const std::array<std::uint8_t,32>& d){std::ostringstream os;for(auto b:d)os<<std::hex<<std::setw(2)<<std::setfill('0')<<static_cast<unsigned>(b);return os.str();}

} // namespace

int main(){
    using namespace silveton::manager;
    const std::string root=testRoot();
    require(::mkdir(root.c_str(),0700)==0,"cannot create test directory " + root);

    const std::string ksfA=joinPath(root,"A.KSF");
    const std::string ksfB=joinPath(root,"B.KSF");
    const std::string kmpPath=joinPath(root,"FIXTURE.KMP");
    const std::string ksf8Path=joinPath(root,"EIGHTBIT.KSF");
    const std::string wavPath=joinPath(root,"fixture.wav");
    const std::string aiffPath=joinPath(root,"fixture.aiff");
    const std::string bank=joinPath(root,"SILVETON_BANK.sv");

    require(std::fabs(KorgImporter::normalizedPan(0U)+1.0F)<1e-6F, "pan raw 0 must map left");
    require(std::fabs(KorgImporter::normalizedPan(64U))<1e-6F, "pan raw 64 must map centre");
    require(std::fabs(KorgImporter::normalizedPan(127U)-1.0F)<1e-6F, "pan raw 127 must map right");

    writeFile(ksfA,ksf("C4",{{-32768,-100,100,32767}}));
    writeFile(ksfB,ksf("E4",{{-20000,-10,10,20000}}));
    writeFile(kmpPath,kmp());
    writeFile(ksf8Path,ksf8("8BIT",{{-128,-1,0,127}}));
    auto eightBit=KorgImporter::loadKsf(ksf8Path);
    require(eightBit.ok(), "8-bit KSF import");
    require(eightBit.sample.encoding==AudioEncoding::Pcm16LE&&eightBit.sample.bitsPerSample==16U&&eightBit.sample.sampleRate==44100U, "8-bit KSF must become PCM16 without forced resample");
    require(pcm16At(eightBit.sample,0U)==std::numeric_limits<std::int16_t>::min()&&pcm16At(eightBit.sample,3U)==32512, "8-bit KSF signed PCM expansion");
    auto kr=KorgImporter::loadKmp(kmpPath);
    require(kr.ok(), "synthetic KMP import");
    require(kr.samples.size()==2U, "KMP sample count");
    require(kr.multisample.zones.size()==2U, "KMP zone count");
    require(kr.multisample.zones[0].keyLow==2U&&kr.multisample.zones[0].keyHigh==63U&&kr.multisample.zones[0].rootKey==60U, "first KMP zone/root");
    require(kr.multisample.zones[1].keyLow==64U&&kr.multisample.zones[1].keyHigh==127U, "second KMP zone");
    require(kr.multisample.zones[0].sourcePanRaw==64U&&std::fabs(kr.multisample.zones[0].pan)<1e-6F, "KMP raw pan preservation");
    require(kr.samples[0].sampleRate==48000U&&kr.samples[0].channels==1U&&!kr.samples[0].loop.enabled, "KSF format/no fake loop");

    const std::string kscPath=joinPath(root,"COLLECTION.KSC");
    const std::string secondKmpPath=joinPath(root,"SECOND.KMP");
    writeFile(secondKmpPath,kmp());
    {
        std::ofstream kscFile(kscPath,std::ios::binary);
        require(static_cast<bool>(kscFile), "cannot create KSC fixture");
        kscFile << "\xEF\xBB\xBF#Korg Script Version 1.0\r\n";
        kscFile << "#v2\r\n";
        kscFile << "\"FIXTURE.KMP\"\r\n";
        kscFile << "SECOND.KMP\r\n";
        require(kscFile.good(), "cannot write KSC fixture");
    }
    auto kc=KorgImporter::loadKsc(kscPath);
    require(kc.ok(), "KSC must accept Korg header case/BOM/CRLF and load all KMP entries");
    require(kc.multisamples.size()==2U, "KSC must load multiple KMP multisamples");
    require(kc.samples.size()==2U, "KSC must deduplicate identical KSF audio while preserving all KMP zones");
    require(kc.multisamples[0].zones[0].sampleIndex==0U&&kc.multisamples[0].zones[1].sampleIndex==1U&&
            kc.multisamples[1].zones[0].sampleIndex==0U&&kc.multisamples[1].zones[1].sampleIndex==1U,
            "KSC dedup must remap every zone to the shared SampleID source");

    const std::string nestedDir=joinPath(root,"NESTED");
    require(::mkdir(nestedDir.c_str(),0700)==0,"cannot create nested KSC directory");
    writeFile(joinPath(nestedDir,"INNER.KMP"),kmp());
    writeFile(joinPath(nestedDir,"A.KSF"),ksf("C4",{{-32768,-100,100,32767}}));
    writeFile(joinPath(nestedDir,"B.KSF"),ksf("E4",{{-20000,-10,10,20000}}));
    const std::string fallbackKsc=joinPath(root,"NESTED.KSC");
    {
        std::ofstream kscFile(fallbackKsc,std::ios::binary);
        require(static_cast<bool>(kscFile), "cannot create nested-directory KSC fixture");
        kscFile << "#KORG Script Version 1.0\nINNER.KMP\n";
        require(kscFile.good(), "cannot write nested-directory KSC fixture");
    }
    auto nestedCollection=KorgImporter::loadKsc(fallbackKsc);
    require(nestedCollection.ok(), "KSC must find KMP resources in same-name collection folder");
    require(nestedCollection.multisamples.size()==1U, "nested collection KMP count");

    const std::string utf16Ksc=joinPath(root,"UTF16.KSC");
    {
        const std::string text="#KORG Script Version 1.0\r\nFIXTURE.KMP\r\n";
        Bytes encoded{0xFFU,0xFEU};
        for (const char c : text) { encoded.push_back(static_cast<std::uint8_t>(static_cast<unsigned char>(c))); encoded.push_back(0U); }
        writeFile(utf16Ksc, encoded);
    }
    auto utf16Collection=KorgImporter::loadKsc(utf16Ksc);
    require(utf16Collection.ok(), "KSC must decode UTF-16LE text files");
    require(utf16Collection.multisamples.size()==1U, "UTF-16 KSC KMP count");

    const std::string metadataOnlyDir=joinPath(root,"METAONLY");
    require(::mkdir(metadataOnlyDir.c_str(),0700)==0,"cannot create metadata-only KSC directory");
    writeFile(joinPath(metadataOnlyDir,"DISCOVER.KMP"),kmp());
    writeFile(joinPath(metadataOnlyDir,"A.KSF"),ksf("C4",{{-32768,-100,100,32767}}));
    writeFile(joinPath(metadataOnlyDir,"B.KSF"),ksf("E4",{{-20000,-10,10,20000}}));
    const std::string metadataOnlyKsc=joinPath(root,"METAONLY.KSC");
    {
        std::ofstream kscFile(metadataOnlyKsc,std::ios::binary);
        require(static_cast<bool>(kscFile), "cannot create metadata-only KSC fixture");
        kscFile << "#KORG Script Version 1.0\n#v2\n#>Bank10.275.0.Metadata only bank\n";
        require(kscFile.good(), "cannot write metadata-only KSC fixture");
    }
    auto metadataOnlyCollection=KorgImporter::loadKsc(metadataOnlyKsc);
    require(metadataOnlyCollection.ok(), "KSC metadata-only index must fall back to same-name KMP folder");
    require(metadataOnlyCollection.multisamples.size()==1U, "metadata-only KSC fallback KMP count");

    writeFile(wavPath,wav());
    auto wr=AudioFileLoader::load(wavPath);
    require(wr.ok(), "WAV import");
    require(wr.sample.rootKey==64U&&wr.sample.loop.enabled&&wr.sample.loop.startFrame==1U&&wr.sample.loop.endFrame==3U&&wr.sample.totalFrames==4U, "WAV smpl root/loop");

    writeFile(aiffPath,aiff());
    auto ar=AudioFileLoader::load(aiffPath);
    require(ar.ok(), "AIFF import");
    require(ar.sample.sampleRate==44100U&&ar.sample.rootKey==65U&&ar.sample.totalFrames==4U, "AIFF rate/root/frame count");
    require(ar.sample.audioData[0]==0x00U&&ar.sample.audioData[1]==0x80U, "AIFF big-endian to canonical little-endian");

    std::string editError;
    const Bytes originalWavAudio = wr.sample.audioData;

    auto metadataOnly = wr.sample;
    require(SampleEditor::setLoop(metadataOnly, true, 1U, 3U, 1U, editError), "set loop metadata");
    require(metadataOnly.audioData == originalWavAudio, "setLoop must not modify PCM without explicit Apply");
    require(metadataOnly.loop.crossfadeFrames == 1U, "setLoop crossfade metadata");

    auto crossfaded = metadataOnly;
    require(SampleEditor::applyLoopCrossfade(crossfaded, 1U, editError), "apply real loop crossfade");
    require(crossfaded.audioData != originalWavAudio, "loop crossfade must mutate project-copy PCM");
    require(pcm16At(crossfaded, 2U) == static_cast<std::int16_t>(-1), "loop crossfade must blend tail toward loop head");
    require(crossfaded.loop.startFrame == 2U && crossfaded.loop.endFrame == 3U, "loop crossfade must advance loop start by overlap");
    require(crossfaded.loop.crossfadeFrames == 0U, "applied loop crossfade must clear pending metadata");

    auto noLoop = wr.sample;
    noLoop.loop = {};
    require(!SampleEditor::applyLoopCrossfade(noLoop, 1U, editError), "loop crossfade must reject disabled loop");
    require(noLoop.audioData == originalWavAudio, "rejected loop crossfade must not alter PCM");

    auto fadedIn = wr.sample;
    require(SampleEditor::fadeIn(fadedIn, 2U, editError), "fade in");
    require(pcm16At(fadedIn, 0U) == 0, "fade in must zero first frame");

    auto fadedOut = wr.sample;
    require(SampleEditor::fadeOut(fadedOut, 2U, editError), "fade out");
    require(pcm16At(fadedOut, 3U) == 0, "fade out must zero last frame");

    auto trimmed = wr.sample;
    require(SampleEditor::trim(trimmed, 1U, 3U, editError), "trim sample");
    require(trimmed.totalFrames == 2U && trimmed.audioData.size() == 4U, "trim must change real PCM length");
    require(trimmed.loop.enabled && trimmed.loop.startFrame == 0U && trimmed.loop.endFrame == 2U, "trim must remap contained loop");

    // SILVETON_CUT_V1: cutting out the marked part and joining the ends
    {
        auto cut = wr.sample;
        const std::uint64_t before = cut.totalFrames;
        const std::int16_t last = pcm16At(cut, cut.totalFrames - 1U);
        require(SampleEditor::cutOut(cut, 1U, 3U, editError), "cut out the middle");
        require(cut.totalFrames == before - 2U, "cut must shorten the sample by the marked part");
        require(cut.audioData.size() == static_cast<std::size_t>(cut.totalFrames) * 2U, "cut must shorten the real PCM");
        require(pcm16At(cut, 0U) == pcm16At(wr.sample, 0U), "what is before the cut stays");
        require(pcm16At(cut, cut.totalFrames - 1U) == last, "what is after the cut is joined to it");
        require(!cut.loop.enabled, "a loop the cut goes through is switched off");

        auto head = wr.sample;
        require(SampleEditor::cutOut(head, 0U, 2U, editError), "cut the beginning away");
        require(head.totalFrames == before - 2U && pcm16At(head, 0U) == pcm16At(wr.sample, 2U), "cutting the beginning keeps the rest");

        auto tail = wr.sample;
        require(SampleEditor::cutOut(tail, before - 1U, before, editError), "cut the end away");
        require(tail.totalFrames == before - 1U && pcm16At(tail, 0U) == pcm16At(wr.sample, 0U), "cutting the end keeps the beginning");

        auto later = wr.sample;
        require(SampleEditor::setLoop(later, true, before - 2U, before, 0U, editError), "loop at the end");
        require(SampleEditor::cutOut(later, 0U, 1U, editError), "cut before the loop");
        require(later.loop.enabled && later.loop.startFrame == before - 3U && later.loop.endFrame == before - 1U, "a loop after the cut moves back with the audio");

        auto earlier = wr.sample;
        require(SampleEditor::setLoop(earlier, true, 0U, 2U, 0U, editError), "loop at the start");
        require(SampleEditor::cutOut(earlier, 2U, before, editError), "cut after the loop");
        require(earlier.loop.enabled && earlier.loop.startFrame == 0U && earlier.loop.endFrame == 2U, "a loop before the cut stays where it is");

        auto all = wr.sample;
        require(!SampleEditor::cutOut(all, 0U, before, editError), "the whole sample cannot be cut away");
        require(!SampleEditor::cutOut(all, 2U, 2U, editError), "an empty mark is refused");
        require(!SampleEditor::cutOut(all, 1U, before + 5U, editError), "a mark past the end is refused");
        require(all.totalFrames == before, "a refused cut changes nothing");
    }

    // SILVETON_PITCHCURVE_V1: the note moves while the sample plays
    {
        auto tone = [](double hz, double rate, double seconds) {
            ImportedSample x{};
            x.name = "tone"; x.sourceIdentity = "tone";
            x.sampleRate = static_cast<std::uint32_t>(rate);
            x.channels = 1U; x.encoding = AudioEncoding::Pcm16LE; x.bitsPerSample = 16U; x.rootKey = 60U;
            x.totalFrames = static_cast<std::uint64_t>(rate * seconds);
            x.audioData.resize(static_cast<std::size_t>(x.totalFrames) * 2U);
            for (std::uint64_t i = 0U; i < x.totalFrames; ++i) {
                const double v = std::sin(2.0 * M_PI * hz * static_cast<double>(i) / rate) * 0.8;
                const std::int16_t q = static_cast<std::int16_t>(std::lround(v * 32767.0));
                x.audioData[static_cast<std::size_t>(i) * 2U] = static_cast<std::uint8_t>(q & 0xFF);
                x.audioData[static_cast<std::size_t>(i) * 2U + 1U] = static_cast<std::uint8_t>((q >> 8) & 0xFF);
            }
            return x;
        };
        auto crossings = [](const ImportedSample& x, std::uint64_t from, std::uint64_t to) {
            int count = 0;
            double previous = 0.0;
            for (std::uint64_t i = from; i < std::min(to, x.totalFrames); ++i) {
                const std::int16_t q = static_cast<std::int16_t>(static_cast<std::uint16_t>(x.audioData[static_cast<std::size_t>(i) * 2U]) |
                                       (static_cast<std::uint16_t>(x.audioData[static_cast<std::size_t>(i) * 2U + 1U]) << 8));
                const double v = static_cast<double>(q);
                if (i > from && ((previous <= 0.0 && v > 0.0) || (previous >= 0.0 && v < 0.0))) ++count;
                previous = v;
            }
            return count;
        };

        const ImportedSample base = tone(200.0, 44100.0, 0.5);
        const int baseCrossings = crossings(base, 0U, base.totalFrames);

        auto up = base;
        require(SampleEditor::applyPitchCurve(up, std::vector<float>(64U, 12.0F), editError), "pitch curve: one octave up");
        require(up.totalFrames > base.totalFrames * 48U / 100U && up.totalFrames < base.totalFrames * 52U / 100U, "an octave up makes the sample half as long");
        require(std::abs(crossings(up, 0U, up.totalFrames) - baseCrossings) <= 2,
                "an octave up keeps all the waves (same count, half the time -> twice the pitch)");

        auto down = base;
        require(SampleEditor::applyPitchCurve(down, std::vector<float>(64U, -12.0F), editError), "pitch curve: one octave down");
        require(down.totalFrames > base.totalFrames * 195U / 100U && down.totalFrames < base.totalFrames * 205U / 100U, "an octave down makes it twice as long");

        auto flat = base;
        require(SampleEditor::applyPitchCurve(flat, std::vector<float>(64U, 0.0F), editError), "a flat curve is allowed");
        require(flat.totalFrames == base.totalFrames && flat.audioData == base.audioData, "a flat curve changes nothing at all");

        // a kick: high at the start, falling to nothing - the waves must be tighter at the start than at the end
        std::vector<float> fall(64U, 0.0F);
        for (std::size_t i = 0U; i < fall.size(); ++i) {
            fall[i] = static_cast<float>(12.0 * std::exp(-static_cast<double>(i) / 8.0));
        }
        auto kick = base;
        require(SampleEditor::applyPitchCurve(kick, fall, editError), "pitch curve: falling");
        const std::uint64_t tenth = kick.totalFrames / 10U;
        const int head = crossings(kick, 0U, tenth);
        const int tail = crossings(kick, kick.totalFrames - tenth, kick.totalFrames);
        require(head > tail + 2, "a falling curve leaves more waves at the start than at the end");
        require(kick.totalFrames > 0U && kick.totalFrames < base.totalFrames, "a falling curve shortens the sample a little");

        auto looped = base;
        require(SampleEditor::setLoop(looped, true, base.totalFrames / 2U, base.totalFrames, 0U, editError), "loop before the curve");
        require(SampleEditor::applyPitchCurve(looped, std::vector<float>(64U, 12.0F), editError), "pitch curve with a loop");
        require(looped.loop.enabled, "the loop stays");
        require(looped.loop.startFrame > looped.totalFrames * 45U / 100U && looped.loop.startFrame < looped.totalFrames * 55U / 100U, "the loop start moves with the audio");
        require(looped.loop.endFrame <= looped.totalFrames, "the loop end stays inside the sample");

        auto bad = base;
        require(!SampleEditor::applyPitchCurve(bad, std::vector<float>(), editError), "an empty curve is refused");
        require(bad.totalFrames == base.totalFrames, "a refused curve changes nothing");
    }

    // SILVETON_PITCHCURVE_V1: the knob shapes a hand-drawn curve
    {
        std::vector<float> exact(128U, 0.0F);
        for (std::size_t i = 0U; i < exact.size(); ++i) {
            const double t = static_cast<double>(i) / static_cast<double>(exact.size() - 1U);
            exact[i] = static_cast<float>(1.5 + 10.0 * std::exp(-t / 0.2));
        }
        std::vector<float> shaky = exact;
        for (std::size_t i = 0U; i < shaky.size(); ++i) {
            shaky[i] += static_cast<float>(static_cast<int>((i * 37U) % 11U) - 5) * 0.25F;   // a shaky hand
        }

        std::vector<float> untouched = shaky;
        SampleEditor::shapeCurve(untouched, 0.0F);
        require(untouched == shaky, "knob at 0 leaves the drawing exactly as it is");

        std::vector<float> shaped = shaky;
        SampleEditor::shapeCurve(shaped, 1.0F);
        float worstStep = 0.0F, worstStepBefore = 0.0F;
        for (std::size_t i = 1U; i + 1U < shaped.size(); ++i) {
            worstStep = std::max(worstStep, std::fabs(shaped[i + 1U] - 2.0F * shaped[i] + shaped[i - 1U]));
            worstStepBefore = std::max(worstStepBefore, std::fabs(shaky[i + 1U] - 2.0F * shaky[i] + shaky[i - 1U]));
        }
        require(worstStep < worstStepBefore / 10.0F, "knob at 100 takes every corner out");
        float worstOff = 0.0F;
        for (std::size_t i = 0U; i < shaped.size(); ++i) worstOff = std::max(worstOff, std::fabs(shaped[i] - exact[i]));
        require(worstOff < 0.5F, "knob at 100 finds the exact curve the drawing was made of");

        std::vector<float> half = shaky;
        SampleEditor::shapeCurve(half, 0.5F);
        for (std::size_t i = 0U; i < half.size(); ++i) {
            require(std::fabs(half[i] - (shaky[i] + shaped[i]) / 2.0F) < 0.001F, "half way is half way between the drawing and the exact curve");
        }

        std::vector<float> flatLine(64U, 0.0F);
        SampleEditor::shapeCurve(flatLine, 1.0F);
        for (float v : flatLine) require(std::fabs(v) < 0.001F, "a flat drawing stays flat");
    }

    // SILVETON_ATTACK_V1: where the hit begins
    {
        auto make = [](double leadSeconds, double hissLevel) {
            ImportedSample x{};
            x.name = "hit"; x.sourceIdentity = "hit";
            x.sampleRate = 44100U; x.channels = 1U; x.encoding = AudioEncoding::Pcm16LE; x.bitsPerSample = 16U; x.rootKey = 60U;
            const std::uint64_t lead = static_cast<std::uint64_t>(44100.0 * leadSeconds);
            x.totalFrames = lead + 22050U;
            x.audioData.resize(static_cast<std::size_t>(x.totalFrames) * 2U, 0U);
            std::uint32_t seed = 7U;
            for (std::uint64_t i = 0U; i < x.totalFrames; ++i) {
                seed = seed * 1103515245U + 12345U;
                const double hiss = (static_cast<double>(seed % 2000U) / 1000.0 - 1.0) * hissLevel;
                double v = hiss;
                if (i >= lead) {
                    const double t = static_cast<double>(i - lead) / 44100.0;
                    v += std::sin(2.0 * M_PI * 220.0 * t) * 0.8 * std::exp(-t * 12.0);
                }
                const std::int16_t q = static_cast<std::int16_t>(std::lround(std::max(-1.0, std::min(1.0, v)) * 32767.0));
                x.audioData[static_cast<std::size_t>(i) * 2U] = static_cast<std::uint8_t>(q & 0xFF);
                x.audioData[static_cast<std::size_t>(i) * 2U + 1U] = static_cast<std::uint8_t>((q >> 8) & 0xFF);
            }
            return x;
        };

        const ImportedSample late = make(0.25, 0.0005);
        const SampleEditor::AttackPoint a = SampleEditor::findAttack(late);
        require(a.found && a.hasLateStart, "a sample with a quarter second of nothing in front has a late start");
        require(a.leadInSeconds > 0.20 && a.leadInSeconds <= 0.25, "the cut point sits just before the hit");
        require(a.startFrame < static_cast<std::uint64_t>(44100.0 * 0.25), "the cut point never eats into the hit");

        auto cut = late;
        require(SampleEditor::trim(cut, a.startFrame, cut.totalFrames, editError), "cutting at the found point");
        const SampleEditor::AttackPoint again = SampleEditor::findAttack(cut);
        require(again.found && !again.hasLateStart, "after cutting, the sample starts right away");

        const ImportedSample onTime = make(0.0, 0.0005);
        const SampleEditor::AttackPoint b = SampleEditor::findAttack(onTime);
        require(b.found && !b.hasLateStart, "a sample that already starts at once is left alone");

        // hiss in front, not silence: the lead-in is still found
        const ImportedSample hissy = make(0.2, 0.004);
        const SampleEditor::AttackPoint c = SampleEditor::findAttack(hissy);
        require(c.found && c.hasLateStart && c.leadInSeconds > 0.15, "hiss in front counts as a late start too");

        ImportedSample empty{};
        empty.name = "empty"; empty.sampleRate = 44100U; empty.channels = 1U; empty.encoding = AudioEncoding::Pcm16LE;
        empty.bitsPerSample = 16U; empty.totalFrames = 1000U; empty.audioData.assign(2000U, 0U);
        require(!SampleEditor::findAttack(empty).found, "a silent sample has no hit to find");
    }

    auto reversed = wr.sample;
    require(SampleEditor::reverse(reversed, editError), "reverse sample");
    require(pcm16At(reversed, 0U) == std::numeric_limits<std::int16_t>::max(), "reverse must reverse frame order");
    require(reversed.loop.startFrame == 1U && reversed.loop.endFrame == 3U, "reverse must remap loop coordinates");

    auto gained = wr.sample;
    require(SampleEditor::applyGainDb(gained, -6.0F, editError), "gain edit");
    require(std::abs(static_cast<int>(pcm16At(gained, 3U))) < std::abs(static_cast<int>(pcm16At(wr.sample, 3U))), "negative gain must reduce PCM magnitude");

    auto normalized = gained;
    require(SampleEditor::normalize(normalized, -3.0F, editError), "normalize edit");
    const float normalizedPeak = SampleEditor::peakLinear(normalized);
    require(normalizedPeak > 0.70F && normalizedPeak < 0.72F, "normalize must reach requested peak");

    auto tuned = wr.sample;
    require(SampleEditor::setRootKey(tuned, 72U, editError) && tuned.rootKey == 72U, "root key edit");
    require(SampleEditor::setFineTuneCents(tuned, 17.5F, editError) && std::fabs(tuned.fineTuneCents - 17.5F) < 1e-6F, "fine tune edit");

    const std::uint64_t zero = SampleEditor::nearestZeroCrossing(wr.sample, 2U, 2U);
    require(zero >= 1U && zero <= 3U, "zero crossing search range");

    std::vector<WaveformPoint> waveform;
    require(SampleEditor::buildWaveform(wr.sample, 4U, waveform, editError), "waveform generation");
    require(waveform.size() == 4U, "waveform point count");
    require(waveform.front().minimum <= -0.99F, "waveform must reflect real sample minimum");
    require(waveform.back().maximum >= 0.99F, "waveform must reflect real sample maximum");

    // SILVETON_ZOOM_V1: a range gives the same values as the whole picture, one point per frame when deeply zoomed
    {
        std::vector<WaveformPoint> all, part;
        require(SampleEditor::buildWaveformRange(wr.sample, 0U, wr.sample.totalFrames, 100000U, all, editError), "full range, one point per frame");
        require(all.size() == wr.sample.totalFrames, "full range point count equals frames when columns exceed frames");
        require(wr.sample.totalFrames >= 4U, "fixture has at least 4 frames");
        require(SampleEditor::buildWaveformRange(wr.sample, 1U, 3U, 100000U, part, editError), "inner range");
        require(part.size() == 2U, "inner range has two points");
        require(part[0].minimum == all[1].minimum && part[0].maximum == all[1].maximum, "inner range point 0 equals frame 1");
        require(part[1].minimum == all[2].minimum && part[1].maximum == all[2].maximum, "inner range point 1 equals frame 2");
        require(!SampleEditor::buildWaveformRange(wr.sample, 3U, 3U, 10U, part, editError), "empty range is refused");
        require(SampleEditor::buildWaveformRange(wr.sample, 2U, wr.sample.totalFrames + 1000U, 10U, part, editError) && !part.empty(), "end beyond the sample is clamped");
    }

    require(wr.sample.audioData == originalWavAudio, "editor tests must not mutate imported source object implicitly");

    const char* abc="abc";
    require(digestHex(sha256(reinterpret_cast<const std::uint8_t*>(abc),3U))=="ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", "SHA-256 standard vector");

    BankProject project;project.name="TEST BANK";project.samples=kr.samples;project.multisamples.push_back(kr.multisample);
    for (std::size_t i=0U;i<project.samples.size();++i) project.samples[i].sampleId=static_cast<std::uint32_t>(100U+i);
    project.multisamples[0].multisampleId=200U;
    SoundDefinition sound;sound.name="Fixture Sound";sound.position=137U;sound.category=3U;SoundLayer layer;layer.multisampleIndex=0U;sound.layers.push_back(layer);project.sounds.push_back(sound);
    auto duplicate=project.samples.front();duplicate.sampleId=999U;duplicate.name="Duplicate Audio";project.samples.push_back(duplicate);

    auto built=SvBankBuilder::build(project);
    require(built.ok(), "SV bank build");
    require(built.stats.sampleCount==3U&&built.stats.uniqueAudioPayloadCount==2U&&built.stats.audioBytesAfterDedup<built.stats.audioBytesBeforeDedup, "SV audio dedup");

    auto round=SvBankReader::read(built.bytes,true);
    require(round.ok(), "SV bank read/verify");
    require(round.project.name==project.name&&round.project.samples.size()==3U&&round.project.multisamples.size()==1U&&round.project.sounds.size()==1U, "SV round-trip object counts");
    require(round.project.samples[0].audioData==project.samples[0].audioData, "SV exact audio round-trip");
    require(round.project.multisamples[0].zones[0].sourcePanRaw==64U, "SV raw Korg metadata round-trip");
    require(round.project.sounds[0].position==137U&&round.project.sounds[0].category==3U, "SV2 SOUND slot/category round-trip");
    require(round.project.samples[0].sampleId!=0U&&round.project.multisamples[0].multisampleId!=0U, "SV stable SampleID/MultisampleID round-trip");

    auto corrupt=built.bytes;corrupt.back()^=1U;
    require(!SvBankReader::read(corrupt,true).ok(), "SV corrupted payload rejection");

    BankProject invalid=project;invalid.multisamples[0].zones[0].sampleIndex=999U;
    require(!SvBankBuilder::build(invalid).ok(), "SV invalid reference rejection");

    SvBuildStats stats{};std::string error;
    require(SvBankBuilder::writeAtomic(bank,project,stats,error), "SV atomic write");
    require(error.empty(), "SV atomic write error state");
    require(stats.uniqueAudioPayloadCount==2U, "SV atomic write stats");
    require(SvBankReader::readFile(bank,true).ok(), "SV written bank readback");

    std::remove(ksfA.c_str());
    std::remove(ksfB.c_str());
    std::remove(kmpPath.c_str());
    std::remove(ksf8Path.c_str());
    std::remove(wavPath.c_str());
    std::remove(aiffPath.c_str());
    std::remove(bank.c_str());
    ::rmdir(root.c_str());
    std::cout<<"SILVETON Manager core tests PASS\n";
    return 0;
}