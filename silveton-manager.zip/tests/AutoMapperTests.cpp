// SILVETON_AUTOMAP_V1 tests: loose samples, no mapping file - the notes are heard and laid over the keyboard.
#include "silveton/manager/AutoMapper.h"

#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

using namespace silveton::manager;

namespace {

[[noreturn]] void fail(const char* message) {
    std::cerr << "FAIL: " << message << '\n';
    std::exit(1);
}
void require(bool condition, const char* message) { if (!condition) fail(message); }

double hzOf(int midi) { return 440.0 * std::pow(2.0, (static_cast<double>(midi) - 69.0) / 12.0); }

ImportedSample note(const char* name, int midi, double level) {
    ImportedSample s{};
    s.name = name;
    s.sourceIdentity = name;
    s.sampleRate = 44100U;
    s.channels = 1U;
    s.encoding = AudioEncoding::Pcm16LE;
    s.bitsPerSample = 16U;
    s.rootKey = 60U;
    s.totalFrames = 22050U;
    s.audioData.resize(static_cast<std::size_t>(s.totalFrames) * 2U, 0U);
    const double hz = hzOf(midi);
    for (std::uint64_t i = 0U; i < s.totalFrames; ++i) {
        const double t = static_cast<double>(i) / 44100.0;
        const double v = (std::sin(2.0 * M_PI * hz * t) + 0.3 * std::sin(4.0 * M_PI * hz * t)) * level * 0.6;
        const std::int16_t q = static_cast<std::int16_t>(std::lround(std::max(-1.0, std::min(1.0, v)) * 32767.0));
        s.audioData[static_cast<std::size_t>(i) * 2U] = static_cast<std::uint8_t>(q & 0xFF);
        s.audioData[static_cast<std::size_t>(i) * 2U + 1U] = static_cast<std::uint8_t>((q >> 8) & 0xFF);
    }
    return s;
}

} // namespace

int main() {
    // three notes, two octaves apart, in the wrong order in the project
    {
        BankProject p;
        p.samples.push_back(note("high", 72, 0.8));
        p.samples.push_back(note("low", 48, 0.8));
        p.samples.push_back(note("middle", 60, 0.8));
        const AutoMapPlan plan = AutoMapper::listen(p, {0U, 1U, 2U});
        require(plan.entries.size() == 3U, "every sample is listened to");
        for (const AutoMapEntry& e : plan.entries) {
            require(e.heard, "a clear note comes out of every one of them");
        }
        auto keyOf = [&](const char* name) {
            for (const AutoMapEntry& e : plan.entries) if (e.name == name) return e.rootKey;
            fail("sample missing from the plan");
        };
        require(keyOf("low") == 48, "the low note is heard in its own octave");
        require(keyOf("middle") == 60, "the middle note is heard in its own octave");
        require(keyOf("high") == 72, "the high note is heard in its own octave");

        auto rangeOf = [&](const char* name) {
            for (const AutoMapEntry& e : plan.entries) if (e.name == name) return std::pair<int, int>(e.keyLow, e.keyHigh);
            fail("sample missing from the plan");
        };
        require(rangeOf("low").first == 0, "the lowest sample reaches down to the bottom key");
        require(rangeOf("high").second == 127, "the highest sample reaches up to the top key");
        require(rangeOf("low").second + 1 == rangeOf("middle").first, "the ranges touch without a gap (low to middle)");
        require(rangeOf("middle").second + 1 == rangeOf("high").first, "the ranges touch without a gap (middle to high)");
        require(rangeOf("middle").first == 55 && rangeOf("middle").second == 66, "each note holds the keys up to halfway to its neighbour");
        require(plan.layers == 1, "one sample per note means one layer");

        std::size_t created = 0U;
        std::string error;
        require(AutoMapper::build(p, plan, "TEST BLEND", created, error), error.c_str());
        require(p.multisamples.size() == 1U && p.multisamples[0].zones.size() == 3U, "one multisample with three zones");
        require(p.sounds.size() == 1U && p.sounds[0].name == "TEST BLEND" && p.sounds[0].layers.size() == 1U, "one blend with one layer");
        bool covered[128] = {false};
        for (const ImportedZone& z : p.multisamples[0].zones) {
            for (int k = z.keyLow; k <= z.keyHigh; ++k) {
                require(!covered[k], "no key is taken twice");
                covered[k] = true;
            }
        }
        for (int k = 0; k < 128; ++k) require(covered[k], "every key on the keyboard is covered");
    }

    // the same note at three loudnesses becomes three velocity layers, quietest first
    {
        BankProject p;
        p.samples.push_back(note("loud", 60, 0.9));
        p.samples.push_back(note("soft", 60, 0.2));
        p.samples.push_back(note("middle", 60, 0.5));
        AutoMapPlan plan = AutoMapper::listen(p, {0U, 1U, 2U});
        require(plan.layers == 3, "three samples on one note make three layers");
        auto layerOf = [&](const char* name) {
            for (const AutoMapEntry& e : plan.entries) if (e.name == name) return e.layer;
            fail("sample missing from the plan");
        };
        require(layerOf("soft") == 0 && layerOf("middle") == 1 && layerOf("loud") == 2, "quietest first, loudest last");
        for (const AutoMapEntry& e : plan.entries) require(e.keyLow == 0 && e.keyHigh == 127, "one note alone holds the whole keyboard");

        std::size_t created = 0U;
        std::string error;
        require(AutoMapper::build(p, plan, "LAYERS", created, error), error.c_str());
        require(p.multisamples.size() == 3U, "one multisample per layer");
        require(p.sounds[created].layers.size() == 3U, "the blend has three layers");
        require(p.sounds[created].layers[0].velocityLow == 1U, "the first layer starts at the softest touch");
        require(p.sounds[created].layers[2].velocityHigh == 127U, "the last layer reaches the hardest touch");
        for (std::size_t k = 1U; k < p.sounds[created].layers.size(); ++k) {
            require(p.sounds[created].layers[k - 1U].velocityHigh < p.sounds[created].layers[k].velocityLow + 1U,
                    "the velocity bands follow one another without overlapping");
        }
    }

    // a note corrected by hand changes the keyboard, and an empty plan is refused
    {
        BankProject p;
        p.samples.push_back(note("a", 60, 0.8));
        p.samples.push_back(note("b", 64, 0.8));
        AutoMapPlan plan = AutoMapper::listen(p, {0U, 1U});
        plan.entries[1].rootKey = 90;              // by hand: this one really belongs much higher
        AutoMapper::arrange(plan);
        require(plan.entries[0].keyHigh == 75 && plan.entries[1].keyLow == 76, "the keyboard follows the corrected note");

        AutoMapPlan empty;
        std::size_t created = 0U;
        std::string error;
        require(!AutoMapper::build(p, empty, "NOTHING", created, error) && !error.empty(), "an empty plan is refused with a reason");
    }

    // typing a note by hand
    {
        require(AutoMapper::noteFromText("C4") == 60, "C4 is the middle C the sampler calls 60");
        require(AutoMapper::noteFromText("c4") == 60, "small letters work too");
        require(AutoMapper::noteFromText("A#3") == 58, "a sharp is understood");
        require(AutoMapper::noteFromText("Bb3") == 58, "a flat is understood");
        require(AutoMapper::noteFromText("60") == 60, "a plain number is the note itself");
        require(AutoMapper::noteFromText("A-1") == 9, "the lowest octave works");
        require(AutoMapper::noteFromText("") == -1 && AutoMapper::noteFromText("hello") == -1 &&
                AutoMapper::noteFromText("200") == -1 && AutoMapper::noteFromText("H4") == -1,
                "anything that is not a note is refused");
    }

    std::cout << "SILVETON AutoMapper tests PASS\n";
    return 0;
}
