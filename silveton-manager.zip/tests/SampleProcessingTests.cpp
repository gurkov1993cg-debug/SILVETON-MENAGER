#include "silveton/manager/SampleConverter.h"
#include "silveton/manager/SampleProcessing.h"
#include "silveton/manager/SpectrumAnalyzer.h"

#include <cmath>
#include <cstdlib>
#include <iostream>

using namespace silveton::manager;

namespace {
void require(bool c, const char* m) { if (!c) { std::cerr << "FAIL: " << m << '\n'; std::exit(1); } }

// fundamental + 3rd..8th harmonics with level `bright`
ImportedSample tone(std::uint32_t rate, int key, double amp, double bright) {
    ImportedSample s{};
    s.name = "t"; s.sampleRate = rate; s.channels = 1U; s.encoding = AudioEncoding::Pcm24LE; s.bitsPerSample = 24U;
    s.rootKey = static_cast<std::uint8_t>(key); s.totalFrames = rate / 2U;
    const double f0 = 440.0 * std::pow(2.0, (key - 69) / 12.0);
    std::vector<double> v(s.totalFrames);
    for (std::size_t i = 0; i < v.size(); ++i) {
        const double t = static_cast<double>(i) / rate;
        double x = std::sin(2 * 3.14159265358979 * f0 * t);
        for (int h = 5; h <= 8; ++h) x += bright * std::sin(2 * 3.14159265358979 * f0 * h * t);
        v[i] = amp * x / (1.0 + 4.0 * bright);
    }
    s.audioData = SampleConverter::encodeSamples(v, s.encoding, false);
    return s;
}
double peakDb(const ImportedSample& s) {
    double p = 0; for (double x : SampleConverter::decode(s)) p = std::max(p, std::fabs(x));
    return 20 * std::log10(p);
}
}

int main() {
    BankProject p;
    p.samples.push_back(tone(44100U, 48, 0.9, 0.6));
    p.samples.push_back(tone(48000U, 72, 0.1, 0.1));
    ImportedMultisample m; m.name = "m";
    for (std::uint32_t i = 0; i < 2; ++i) { ImportedZone z; z.sampleIndex = i; z.rootKey = p.samples[i].rootKey; m.zones.push_back(z); }
    p.multisamples.push_back(m);
    const BankProject original = p;

    SampleProcessingOptions o; o.convertTo48k = true; o.evenTone = true; o.normalize = true;
    SampleProcessingReport r; std::string e;
    std::atomic<bool> stop{true};
    require(SampleProcessor::process(p, {}, o, nullptr, &stop, r, e) && r.cancelled, "cancel");
    require(p.samples[0].audioData == original.samples[0].audioData, "cancel keeps bank");

    stop = false;
    double last = 0;
    require(SampleProcessor::process(p, {}, o, [&](double f, const std::string&) { require(f >= last - 1e-9, "progress"); last = f; }, &stop, r, e), e.c_str());
    require(last == 1.0, "progress 100");
    require(p.samples[0].sampleRate == 48000U && r.converted == 1U, "48k");
    require(r.toneAdjusted == 2U, "tone");
    require(std::fabs(peakDb(p.samples[0]) + 6.0) < 0.05 && std::fabs(peakDb(p.samples[1]) + 6.0) < 0.05, "-6 dB");
    {
        // analyzer: 1 kHz sine at -6 dB must show about -6 dB at 1 kHz
        ImportedSample s = tone(48000U, 69, 0.5, 0.0);
        std::vector<double> v(s.totalFrames);
        for (std::size_t i = 0; i < v.size(); ++i) v[i] = 0.5 * std::sin(2 * 3.14159265358979 * 1000.0 * i / 48000.0);
        s.audioData = SampleConverter::encodeSamples(v, s.encoding, false);
        const auto c = SpectrumAnalyzer::toCurve(SpectrumAnalyzer::analyse(s).average, 48000U, 1.0 / 6.0);
        std::size_t best = 0; for (std::size_t i = 0; i < c.size(); ++i) if (c[i] > c[best]) best = i;
        require(std::fabs(SpectrumAnalyzer::pointHz(best) - 1000.0) < 20.0 && std::fabs(c[best] + 6.0) < 1.0, "analyzer level");
    }
    {
        // SILVETON_LOOP_RESAMPLE_V1: 44.1 -> 48 kHz keeps a loop seamless (it used to buzz at -29 dB)
        ImportedSample s{}; s.name = "loop"; s.sampleRate = 44100U; s.channels = 1U; s.encoding = AudioEncoding::Float32LE;
        s.bitsPerSample = 32U; s.totalFrames = 8000U;
        std::vector<double> x(8000);
        for (std::size_t i = 0; i < x.size(); ++i) {
            double y = 0.0;
            for (int h = 1; h * 441 < 15000; ++h) y += std::sin(2 * 3.14159265358979 * h * (i / 100.1) + h) / h;
            x[i] = i < 5000 ? 0.4 * std::sin(i * 0.37) : 0.3 * y;
        }
        s.audioData = SampleConverter::encodeSamples(x, s.encoding, false);
        s.loop.enabled = true; s.loop.startFrame = 5000U; s.loop.endFrame = 6001U;
        SampleConversionOptions co; co.sampleRate = 48000U; co.dither = false;
        ImportedSample out; std::string err;
        require(SampleConverter::convert(s, co, out, err), "loop convert");
        const auto v = SampleConverter::decode(out);
        const std::size_t S = out.loop.startFrame, L = out.loop.endFrame - out.loop.startFrame;
        require(L == 1090U, "loop length");
        // the sample after the loop end must continue like the loop start does
        const double jump = std::fabs(v[S] - v[S + L - 1U]);
        double typical = 0.0;
        for (std::size_t i = S + 1U; i < S + L; ++i) typical = std::max(typical, std::fabs(v[i] - v[i - 1U]));
        require(jump <= typical * 1.01, "loop seam");
    }
    std::cout << "sample processing ok\n";
    return 0;
}
