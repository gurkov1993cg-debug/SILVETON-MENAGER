#include "silveton/manager/ObjectManager.h"

#include <cstdlib>
#include <iostream>
#include <string>

using namespace silveton::manager;

namespace {

[[noreturn]] void fail(const char* message) {
    std::cerr << "FAIL: " << message << '\n';
    std::exit(1);
}

void require(bool condition, const char* message) {
    if (!condition) fail(message);
}

ImportedSample sample(const char* name) {
    ImportedSample s{};
    s.name = name;
    s.sourceIdentity = name;
    s.sampleRate = 48000U;
    s.channels = 1U;
    s.encoding = AudioEncoding::Pcm16LE;
    s.bitsPerSample = 16U;
    s.rootKey = 60U;
    s.totalFrames = 2U;
    s.audioData = {0U, 0U, 1U, 0U};
    return s;
}

BankProject makeProject() {
    BankProject p{};
    p.samples.push_back(sample("A"));
    p.samples.push_back(sample("B"));
    p.samples[0].sampleId = 1U;
    p.samples[1].sampleId = 2U;

    ImportedMultisample ms0{};
    ms0.multisampleId = 1U;
    ms0.name = "MS0";
    ImportedZone z0{}; z0.sampleIndex = 0U;
    ImportedZone z1{}; z1.sampleIndex = 1U;
    ms0.zones = {z0, z1};
    p.multisamples.push_back(ms0);

    ImportedMultisample ms1{};
    ms1.multisampleId = 2U;
    ms1.name = "MS1";
    ImportedZone z2{}; z2.sampleIndex = 1U;
    ms1.zones = {z2};
    p.multisamples.push_back(ms1);

    SoundDefinition s0{};
    s0.name = "S0";
    s0.position = 1U;
    SoundLayer l0{}; l0.multisampleIndex = 0U;
    SoundLayer l1{}; l1.multisampleIndex = 1U;
    s0.layers = {l0, l1};
    p.sounds.push_back(s0);

    SoundDefinition s1{};
    s1.name = "S1";
    s1.position = 2U;
    SoundLayer l2{}; l2.multisampleIndex = 1U;
    s1.layers = {l2};
    s1.slot = 1U;
    p.sounds.push_back(s1);
    return p;
}

} // namespace

int main() {
    {
        BankProject p = makeProject();
        std::string e;
        std::size_t created = 0U;
        require(ObjectManager::duplicateSample(p, 0U, created, e), "duplicate sample");
        require(created == 2U && p.samples.size() == 3U, "sample duplicate index");
        require(p.samples[2U].audioData == p.samples[0U].audioData, "sample duplicate PCM");
        require(p.samples[2U].name != p.samples[0U].name, "sample duplicate unique name");
        require(p.samples[2U].sampleId == 3U, "sample duplicate gets stable new SampleID");
        require(ObjectManager::renameSample(p, 2U, "Renamed", e), "rename sample");
        require(p.samples[2U].name == "Renamed", "renamed sample state");
    }

    {
        BankProject p = makeProject();
        std::string e;
        DeleteImpact impact{};
        require(ObjectManager::deleteSampleCascade(p, 0U, impact, e), "delete sample cascade");
        require(p.samples.size() == 1U, "one sample remains");
        require(p.multisamples.size() == 2U, "both multisamples remain");
        require(p.multisamples[0U].zones.size() == 1U, "referencing zone removed");
        require(p.multisamples[0U].zones[0U].sampleIndex == 0U, "sample index remapped");
        require(p.multisamples[1U].zones[0U].sampleIndex == 0U, "second sample index remapped");
        require(impact.samplesRemoved == 1U && impact.zonesRemoved == 1U, "sample delete impact");
    }

    {
        BankProject p = makeProject();
        std::string e;
        DeleteImpact impact{};
        require(ObjectManager::deleteSampleCascade(p, 1U, impact, e), "delete sample with cascading objects");
        require(p.samples.size() == 1U, "sample B removed");
        require(p.multisamples.size() == 1U, "empty multisample removed");
        require(p.sounds.size() == 1U, "empty SOUND removed");
        require(p.sounds[0U].layers.size() == 1U, "removed multisample layer removed");
        require(p.sounds[0U].layers[0U].multisampleIndex == 0U, "remaining multisample reference valid");
        require(impact.multisamplesRemoved == 1U && impact.soundsRemoved == 1U, "cascade impact counts");
    }

    {
        BankProject p = makeProject();
        std::string e;
        std::size_t created = 0U;
        require(ObjectManager::duplicateMultisample(p, 0U, created, e), "duplicate multisample");
        require(created == 2U && p.multisamples[2U].zones.size() == 2U, "multisample duplicate content");
        require(p.multisamples[2U].multisampleId == 3U, "multisample duplicate gets stable new MultisampleID");
        require(ObjectManager::renameMultisample(p, 2U, "MS Copy Renamed", e), "rename multisample");
        require(p.multisamples[2U].name == "MS Copy Renamed", "renamed multisample state");
    }

    {
        BankProject p = makeProject();
        std::string e;
        DeleteImpact impact{};
        require(ObjectManager::deleteMultisampleCascade(p, 0U, impact, e), "delete multisample cascade");
        require(p.multisamples.size() == 1U, "one multisample remains");
        require(p.sounds.size() == 2U, "sounds with valid remaining layer preserved");
        require(p.sounds[0U].layers.size() == 1U && p.sounds[0U].layers[0U].multisampleIndex == 0U, "sound layer remapped");
        require(p.sounds[1U].layers[0U].multisampleIndex == 0U, "second sound layer remapped");
        require(impact.layersRemoved == 1U, "multisample cascade removed layer");
    }

    {
        BankProject p = makeProject();
        std::string e;
        std::size_t created = 0U;
        require(ObjectManager::duplicateSound(p, 0U, created, e), "duplicate sound");
        require(created == 2U && p.sounds.size() == 3U, "sound duplicate count");
        require(!(p.sounds[2U].bank == p.sounds[0U].bank && p.sounds[2U].page == p.sounds[0U].page && p.sounds[2U].slot == p.sounds[0U].slot), "duplicate sound gets free address");
        require(p.sounds[2U].position == 3U, "duplicate sound gets free SOUND position");
        require(ObjectManager::createSoundFromMultisample(p, 1U, "Fresh", created, e), "create sound from multisample");
        require(p.sounds[created].layers.size() == 1U && p.sounds[created].layers[0U].multisampleIndex == 1U, "new sound layer");
        DeleteImpact impact{};
        require(ObjectManager::deleteSound(p, 0U, impact, e), "delete sound");
        require(impact.soundsRemoved == 1U, "sound delete impact");
    }


    {
        BankProject p = makeProject();
        std::string e;
        std::size_t created = 0U;
        while (p.sounds.size() < static_cast<std::size_t>(kMaxSoundPosition)) {
            require(ObjectManager::createSoundFromMultisample(p, 0U, "Fill", created, e), "fill SOUND positions to 500");
        }
        require(p.sounds.size() == 500U, "exactly 500 SOUND positions available");
        require(!ObjectManager::createSoundFromMultisample(p, 0U, "Overflow", created, e), "501st SOUND must be rejected");
        require(e.find("1...500") != std::string::npos, "full SOUND bank error must identify 1...500 limit");
    }

    // SILVETON_DELETE_BLEND_V1: a blend is removed with everything only it uses; shared things stay
    {
        BankProject p = makeProject();
        std::string e;
        DeleteImpact preview{};
        require(ObjectManager::soundContent(p, 0U, preview, e), "preview what a blend delete takes");
        require(preview.samplesRemoved == 1U && preview.multisamplesRemoved == 1U && preview.layersRemoved == 2U && preview.soundsRemoved == 1U,
                "preview counts: sample A, multisample MS0, 2 layers, 1 sound (B and MS1 are shared with S1)");
        require(p.samples.size() == 2U && p.sounds.size() == 2U, "preview must not change the project");

        DeleteImpact impact{};
        require(ObjectManager::deleteSoundWithContent(p, 0U, impact, e), "delete blend with content");
        require(impact.samplesRemoved == 1U && impact.multisamplesRemoved == 1U, "delete impact counts");
        require(p.sounds.size() == 1U && p.sounds[0U].name == "S1", "only S1 stays");
        require(p.samples.size() == 1U && p.samples[0U].name == "B", "shared sample B stays, own sample A goes");
        require(p.multisamples.size() == 1U && p.multisamples[0U].name == "MS1", "shared multisample stays");
        require(p.sounds[0U].layers.size() == 1U && p.sounds[0U].layers[0U].multisampleIndex == 0U, "layer index remapped");
        require(p.multisamples[0U].zones.size() == 1U && p.multisamples[0U].zones[0U].sampleIndex == 0U, "zone index remapped");

        // now S1 is alone: deleting it empties the whole project
        require(ObjectManager::deleteSoundWithContent(p, 0U, impact, e), "delete the last blend");
        require(p.sounds.empty() && p.samples.empty() && p.multisamples.empty(), "nothing is left behind");
        require(!ObjectManager::deleteSoundWithContent(p, 0U, impact, e), "wrong index is rejected");
    }
    {
        // three blends with their own samples; the middle one goes, the others keep working indexes
        BankProject p{};
        for (int i = 0; i < 6; ++i) {
            const std::string name = "smp" + std::to_string(i);
            p.samples.push_back(sample(name.c_str()));
            p.samples.back().sampleId = static_cast<std::uint32_t>(i + 1);
        }
        for (int b = 0; b < 3; ++b) {
            ImportedMultisample ms{};
            ms.multisampleId = static_cast<std::uint32_t>(b + 1);
            ms.name = "MS" + std::to_string(b);
            ImportedZone za{}; za.sampleIndex = static_cast<std::uint32_t>(b * 2);
            ImportedZone zb{}; zb.sampleIndex = static_cast<std::uint32_t>(b * 2 + 1);
            ms.zones = {za, zb};
            p.multisamples.push_back(ms);
            SoundDefinition snd{};
            snd.name = "B" + std::to_string(b);
            snd.position = static_cast<std::uint16_t>(b + 1);
            snd.slot = static_cast<std::uint16_t>(b);
            SoundLayer layer{}; layer.multisampleIndex = static_cast<std::uint32_t>(b);
            snd.layers = {layer};
            p.sounds.push_back(snd);
        }
        std::string e;
        DeleteImpact impact{};
        require(ObjectManager::deleteSoundWithContent(p, 1U, impact, e), "delete middle blend");
        require(impact.samplesRemoved == 2U && impact.multisamplesRemoved == 1U && impact.zonesRemoved == 2U, "middle blend impact");
        require(p.sounds.size() == 2U && p.sounds[0U].name == "B0" && p.sounds[1U].name == "B2", "blends B0 and B2 stay");
        require(p.samples.size() == 4U && p.samples[0U].name == "smp0" && p.samples[1U].name == "smp1" && p.samples[2U].name == "smp4" && p.samples[3U].name == "smp5", "right samples stay in order");
        require(p.multisamples.size() == 2U && p.multisamples[1U].name == "MS2", "multisamples compacted");
        require(p.sounds[1U].layers[0U].multisampleIndex == 1U, "B2 now points at multisample 1");
        require(p.multisamples[1U].zones[0U].sampleIndex == 2U && p.multisamples[1U].zones[1U].sampleIndex == 3U, "MS2 zones point at smp4 and smp5");
    }

    // SILVETON_UNIQUE_SOUND_NAME_V1: the sampler finds a blend by its NAME - the same name gets a number
    {
        BankProject p = makeProject();                       // S0, S1
        require(ObjectManager::uniqueSoundName(p, "Free") == "Free", "a free name stays");
        require(ObjectManager::uniqueSoundName(p, "S0") == "S0 2", "a taken name gets 2");
        require(ObjectManager::uniqueSoundName(p, "S0", 0U) == "S0", "the sound itself does not count");
        p.sounds[1U].name = "S0 2";
        require(ObjectManager::uniqueSoundName(p, "S0") == "S0 3", "2 is taken, so 3");
        require(ObjectManager::uniqueSoundName(p, "S0 2") == "S0 3", "a name that ends with a number counts on");
        std::string e;
        require(ObjectManager::renameSound(p, 1U, "S0", e), "rename to a taken name is allowed, with a number");
        require(p.sounds[1U].name == "S0 2", "renamed to S0 2");
        require(ObjectManager::renameSound(p, 0U, "S0", e) && p.sounds[0U].name == "S0", "rename to its own name changes nothing");
        std::size_t created = 0U;
        require(ObjectManager::createSoundFromMultisample(p, 0U, "S0", created, e), "create with a taken name");
        require(p.sounds[created].name == "S0 3", "new blend with a taken name gets a number");
        // import: settleNewSounds numbers the new ones and never deletes anything
        BankProject q = makeProject();
        SoundDefinition a = q.sounds[0U];
        SoundDefinition b = q.sounds[0U];
        q.sounds.push_back(a);
        q.sounds.push_back(b);                               // S0, S1, S0, S0
        const auto report = ObjectManager::settleNewSounds(q, 2U);
        require(q.sounds.size() == 4U && report.renamed.size() == 2U, "two imported blends numbered, none deleted");
        require(q.sounds[0U].name == "S0" && q.sounds[2U].name == "S0 2" && q.sounds[3U].name == "S0 3", "numbers in order");
    }

    // SILVETON_SAME_BLENDS_V1: the scan lists blends that sound the same, whatever they are called
    {
        BankProject p = makeProject();                       // S0 (MS0 + MS1), S1 (MS1)
        require(ObjectManager::findSameSounds(p).empty(), "different blends: nothing found");
        std::string e;
        std::size_t created = 0U;
        require(ObjectManager::duplicateSound(p, 1U, created, e), "copy of S1");     // S1 Copy, the same sound
        auto groups = ObjectManager::findSameSounds(p);
        require(groups.size() == 1U && groups[0U].size() == 2U && groups[0U][0U] == 1U && groups[0U][1U] == created, "S1 and its copy found");
        require(ObjectManager::soundsSameContent(p, 1U, created), "same content");
        require(!ObjectManager::soundsSameContent(p, 0U, 1U), "S0 is not S1");
        // a different level makes it a different sound
        p.sounds[created].layers[0U].levelDb = -3.0F;
        require(ObjectManager::findSameSounds(p).empty(), "another level is another sound");
        p.sounds[created].layers[0U].levelDb = 0.0F;
        // the same audio in OTHER sample/multisample objects is still the same sound
        ImportedSample s2 = p.samples[1U];
        s2.sampleId = 99U;
        s2.name = "B again";
        p.samples.push_back(s2);
        ImportedMultisample m2{};
        m2.multisampleId = 99U;
        m2.name = "MS1 again";
        ImportedZone z{}; z.sampleIndex = static_cast<std::uint32_t>(p.samples.size() - 1U);
        m2.zones = {z};
        p.multisamples.push_back(m2);
        SoundDefinition t{};
        t.name = "Something else";
        t.position = 50U;
        SoundLayer l{}; l.multisampleIndex = static_cast<std::uint32_t>(p.multisamples.size() - 1U);
        t.layers = {l};
        p.sounds.push_back(t);
        groups = ObjectManager::findSameSounds(p);
        require(groups.size() == 1U && groups[0U].size() == 3U, "three blends with the same audio in one group");
        // other audio in the same shape is another sound
        p.samples.back().audioData = {0U, 0U, 9U, 0U};
        groups = ObjectManager::findSameSounds(p);
        require(groups.size() == 1U && groups[0U].size() == 2U, "different audio leaves the group");
    }

    std::cout << "SILVETON ObjectManager tests PASS\n";
    return 0;
}
