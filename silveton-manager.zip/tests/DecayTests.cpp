// SILVETON_EVEN_DECAY_V1: ОБРАБОТКА > еднакво затихване - every band dies away in the chosen time; a held tone,
// beating and a loop stay as they were.
#include "silveton/manager/SampleProcessing.h"
#include "silveton/manager/SampleConverter.h"

#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>

using namespace silveton::manager;

namespace {

constexpr double kPi = 3.14159265358979323846;
constexpr std::uint32_t kRate = 48000U;

[[noreturn]] void fail(const std::string& message) {
    std::fprintf(stderr, "FAIL: %s\n", message.c_str());
    std::exit(1);
}

void require(bool condition, const std::string& message) {
    if (!condition) fail(message);
}

ImportedSample floatSample(const std::vector<double>& v) {
    ImportedSample s{};
    s.name = "t";
    s.sourceIdentity = "test://t";
    s.sampleId = 1U;
    s.sampleRate = kRate;
    s.channels = 1U;
    s.encoding = AudioEncoding::Float32LE;
    s.bitsPerSample = 32U;
    s.rootKey = 60U;
    s.totalFrames = v.size();
    s.audioData = SampleConverter::encodeSamples(v, AudioEncoding::Float32LE, false);
    return s;
}

std::vector<double> run(const ImportedSample& in, double ms) {
    BankProject p{};
    p.samples.push_back(in);
    SampleProcessingOptions o{};
    o.evenDecay = true;
    o.decayMs = ms;
    SampleProcessingReport r{};
    std::string error;
    require(SampleProcessor::process(p, {}, o, {}, nullptr, r, error), "process: " + error);
    return SampleConverter::decode(p.samples.front());
}

// level (dB) of one frequency in a 20 ms window centred at time t
double levelAt(const std::vector<double>& v, double hz, double t) {
    const std::size_t n = kRate / 50U;
    const std::size_t c = static_cast<std::size_t>(t * kRate);
    const std::size_t a = c > n / 2U ? c - n / 2U : 0U;
    double re = 0.0, im = 0.0;
    for (std::size_t i = a; i < a + n && i < v.size(); ++i) {
        const double w = 0.5 - 0.5 * std::cos(2.0 * kPi * static_cast<double>(i - a) / static_cast<double>(n));
        const double ph = 2.0 * kPi * hz * static_cast<double>(i) / kRate;
        re += v[i] * w * std::cos(ph);
        im += v[i] * w * std::sin(ph);
    }
    return 10.0 * std::log10(re * re + im * im + 1e-30);
}

// time after `from` until the frequency is `drop` dB below its level at `ref`
double timeToDrop(const std::vector<double>& v, double hz, double ref, double from, double drop) {
    const double l0 = levelAt(v, hz, ref);
    for (double t = from; t < static_cast<double>(v.size()) / kRate - 0.02; t += 0.002) {
        if (levelAt(v, hz, t) <= l0 - drop) return t - from;
    }
    return 1e9;
}

} // namespace

int main() {
    // 1. a held chord 0.5 s, then the low tone dies away in 1.5 s and the high one in 0.25 s (-60 dB)
    {
        std::vector<double> v(static_cast<std::size_t>(3.0 * kRate));
        for (std::size_t i = 0; i < v.size(); ++i) {
            const double t = static_cast<double>(i) / kRate;
            const double tail = std::max(0.0, t - 0.5);
            const double low = 0.3 * std::pow(10.0, -3.0 * tail / 1.5);
            const double high = 0.3 * std::pow(10.0, -3.0 * tail / 0.25);
            v[i] = low * std::sin(2.0 * kPi * 150.0 * t) + high * std::sin(2.0 * kPi * 3000.0 * t);
        }
        const std::vector<double> out = run(floatSample(v), 300.0);
        const double lowBefore = timeToDrop(v, 150.0, 0.25, 0.5, 30.0);
        const double lowAfter = timeToDrop(out, 150.0, 0.25, 0.5, 30.0);
        const double highBefore = timeToDrop(v, 3000.0, 0.25, 0.5, 30.0);
        const double highAfter = timeToDrop(out, 3000.0, 0.25, 0.5, 30.0);
        std::printf("-30 dB: low %.0f -> %.0f ms, high %.0f -> %.0f ms (target 150 ms)\n", lowBefore * 1000.0, lowAfter * 1000.0,
                    highBefore * 1000.0, highAfter * 1000.0);
        require(lowBefore > 0.6 && lowAfter > 0.08 && lowAfter < 0.30, "the long low tail is shortened to the target");
        require(highAfter <= highBefore + 0.03, "the short high tail is not made longer");
        for (double hz : {150.0, 3000.0}) {
            const double d = levelAt(out, hz, 0.25) - levelAt(v, hz, 0.25);
            require(std::fabs(d) < 0.3, "the held chord keeps its level (" + std::to_string(d) + " dB)");
        }
    }
    // 2. musette: two reeds 7 Hz apart beat deeply for 2 s; the beating must stay as it is
    {
        std::vector<double> v(static_cast<std::size_t>(2.5 * kRate), 0.0);
        for (std::size_t i = 0; i < static_cast<std::size_t>(2.0 * kRate); ++i) {
            const double t = static_cast<double>(i) / kRate;
            const double fade = std::min(1.0, (2.0 - t) / 0.01);
            v[i] = fade * 0.25 * (std::sin(2.0 * kPi * 440.0 * t) + std::sin(2.0 * kPi * 447.0 * t));
        }
        const std::vector<double> out = run(floatSample(v), 300.0);
        double err = 0.0, sig = 0.0;
        for (std::size_t i = 0; i < static_cast<std::size_t>(1.9 * kRate); ++i) { err += (out[i] - v[i]) * (out[i] - v[i]); sig += v[i] * v[i]; }
        const double db = 10.0 * std::log10(err / sig + 1e-30);
        std::printf("musette: difference while held %.1f dB\n", db);
        for (double a = 0.0; a < 1.95; a += 0.25) {
            double e2 = 0.0, s2 = 0.0;
            for (std::size_t i = static_cast<std::size_t>(a * kRate); i < static_cast<std::size_t>((a + 0.25) * kRate) && i < v.size(); ++i) { e2 += (out[i] - v[i]) * (out[i] - v[i]); s2 += v[i] * v[i]; }
            std::printf("   %.2f s: %.1f dB\n", a, 10.0 * std::log10(e2 / s2 + 1e-30));
        }
        require(db < -60.0, "beating is not touched");
    }
    // 3. a loud attack that settles on a quiet held tone: the held tone stays as it is
    {
        std::vector<double> v(static_cast<std::size_t>(2.0 * kRate));
        for (std::size_t i = 0; i < v.size(); ++i) {
            const double t = static_cast<double>(i) / kRate;
            const double a = 0.05 + 0.35 * std::pow(10.0, -3.0 * t / 0.1);
            v[i] = a * std::sin(2.0 * kPi * 1000.0 * t);
        }
        const std::vector<double> out = run(floatSample(v), 300.0);
        for (double t : {0.4, 0.8, 1.2, 1.6}) {
            const double d = levelAt(out, 1000.0, t) - levelAt(v, 1000.0, t);
            std::printf("attack + held: %.1f s %.2f dB\n", t, d);
            require(std::fabs(d) < 0.5, "the held tone after the attack keeps its level");
        }
    }
    // 4. a decaying tone with a loop at its end: the loop gets one steady gain (seam as before)
    {
        std::vector<double> v(static_cast<std::size_t>(1.0 * kRate));
        for (std::size_t i = 0; i < v.size(); ++i) {
            const double t = static_cast<double>(i) / kRate;
            v[i] = 0.4 * std::pow(10.0, -3.0 * t / 2.0) * std::sin(2.0 * kPi * 240.0 * t);
        }
        ImportedSample s = floatSample(v);
        s.loop.enabled = true;
        s.loop.startFrame = static_cast<std::uint64_t>(0.5 * kRate);
        s.loop.endFrame = static_cast<std::uint64_t>(1.0 * kRate);
        const std::vector<double> out = run(s, 1200.0);
        auto rms = [](const std::vector<double>& x, std::size_t a, std::size_t b) {
            double q = 0.0;
            for (std::size_t i = a; i < b; ++i) q += x[i] * x[i];
            return std::sqrt(q / static_cast<double>(b - a));
        };
        const std::size_t S = static_cast<std::size_t>(0.5 * kRate), E = static_cast<std::size_t>(1.0 * kRate), q = kRate / 20U;
        const double gStart = 20.0 * std::log10(rms(out, S, S + q) / rms(v, S, S + q));
        const double gEnd = 20.0 * std::log10(rms(out, E - q, E) / rms(v, E - q, E));
        const double gHead = 20.0 * std::log10(rms(out, 0, q) / rms(v, 0, q));
        std::printf("loop: start %.2f dB, end %.2f dB (head %.2f dB)\n", gStart, gEnd, gHead);
        require(std::fabs(gStart - gEnd) < 0.5, "one steady gain inside the loop");
        require(gStart < -3.0, "the decay before the loop was shortened");
        require(std::fabs(gHead) < 0.3, "the start of the note is as it was");
    }
    std::printf("decay tests passed\n");
    return 0;
}
