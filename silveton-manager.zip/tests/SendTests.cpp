// SILVETON_SEND_V1: sending SOUNDs to the sampler (planTransfer, transferProject) and joining bank files (SvBankMerge).
#include "silveton/manager/SoundTransfer.h"
#include "silveton/manager/SvBankBuilder.h"
#include "silveton/manager/SvBankMerge.h"
#include "silveton/manager/SvBankReader.h"

#include <cstdio>
#include <cstdlib>
#include <iostream>
#include <map>
#include <set>
#include <string>
#include <vector>

#include <unistd.h>

using namespace silveton::manager;

namespace {

[[noreturn]] void fail(const std::string& message) {
    std::cerr << "FAIL: " << message << '\n';
    std::exit(1);
}

void require(bool condition, const std::string& message) {
    if (!condition) fail(message);
}

ImportedSample sample(const std::string& name, std::uint8_t seed, std::uint64_t frames) {
    ImportedSample s{};
    s.name = name;
    s.sourceIdentity = "test://" + name;
    s.sampleRate = 48000U;
    s.channels = 1U;
    s.encoding = AudioEncoding::Pcm16LE;
    s.bitsPerSample = 16U;
    s.rootKey = 60U;
    s.totalFrames = frames;
    s.audioData.resize(static_cast<std::size_t>(frames * 2U));
    for (std::size_t i = 0U; i < s.audioData.size(); ++i) s.audioData[i] = static_cast<std::uint8_t>((i * 7U + seed) & 0xFFU);
    return s;
}

// SOUNDs "P1".."P4": P1 = sample a, P2 = samples a + b (a is shared), P3 = sample c, P4 = sample d (big: 3 MB, crosses the copy pieces)
BankProject makeProject() {
    BankProject p{};
    p.name = "TEST";
    p.samples.push_back(sample("a", 1U, 1000U));
    p.samples.push_back(sample("b", 2U, 2000U));
    p.samples.push_back(sample("c", 3U, 3000U));
    p.samples.push_back(sample("d", 4U, 1600000U));
    for (std::size_t i = 0U; i < p.samples.size(); ++i) p.samples[i].sampleId = static_cast<std::uint32_t>(i + 1U);
    auto ms = [&](const char* name, std::vector<std::uint32_t> samples) {
        ImportedMultisample m{};
        m.multisampleId = static_cast<std::uint32_t>(p.multisamples.size() + 1U);
        m.name = name;
        std::uint8_t key = 0U;
        for (const auto s : samples) {
            ImportedZone z{};
            z.sampleIndex = s;
            z.keyLow = key;
            z.keyHigh = static_cast<std::uint8_t>(key + 20U);
            key = static_cast<std::uint8_t>(key + 21U);
            m.zones.push_back(z);
        }
        p.multisamples.push_back(m);
    };
    ms("MA", {0U});
    ms("MAB", {0U, 1U});
    ms("MC", {2U});
    ms("MD", {3U});
    auto sound = [&](const char* name, std::uint16_t place, std::uint32_t multisample) {
        SoundDefinition s{};
        s.name = name;
        s.position = place;
        SoundLayer l{};
        l.multisampleIndex = multisample;
        s.layers.push_back(l);
        p.sounds.push_back(s);
    };
    sound("P1", 1U, 0U);
    sound("P2", 2U, 1U);
    sound("P3", 3U, 2U);
    sound("P4", 4U, 3U);
    return p;
}

// name -> the audio bytes of its first zone's sample, from a bank read back from the disk
std::map<std::string, std::vector<std::uint8_t>> firstAudio(const BankProject& p) {
    std::map<std::string, std::vector<std::uint8_t>> out;
    for (const auto& s : p.sounds) {
        const auto& m = p.multisamples[s.layers.front().multisampleIndex];
        out[s.name] = p.samples[m.zones.back().sampleIndex].audioData;
    }
    return out;
}

std::string write(const BankProject& project, const std::string& path) {
    SvBuildStats stats{};
    std::string error;
    require(SvBankBuilder::writeAtomic(path, project, stats, error), "write " + path + ": " + error);
    return path;
}

} // namespace

int main() {
    char dirTemplate[] = "/tmp/silveton-send-XXXXXX";
    require(::mkdtemp(dirTemplate) != nullptr, "temporary folder");
    const std::string dir = dirTemplate;
    const BankProject all = makeProject();
    const auto audio = firstAudio(all);

    // ---- planTransfer
    {
        std::vector<SentSound> plan;
        std::string error;
        const std::vector<std::pair<int, std::string>> sampler = {{1, "A"}, {2, "B"}};
        const std::vector<SentSound> before = {{"C", "C", 5}};
        require(planTransfer({"C", "B", "D", "D"}, sampler, before, plan, error), "plan: " + error);
        require(plan.size() == 3U, "plan size");
        require(plan[0].managerName == "C" && plan[0].place == 5 && plan[0].samplerName == "C", "sent before keeps its place");
        require(plan[1].managerName == "B" && plan[1].samplerName == "B 2" && plan[1].place == 3, "a name the sampler has gets ' 2'");
        require(plan[2].managerName == "D" && plan[2].samplerName == "D" && plan[2].place == 4, "the next free place");
    }

    // ---- transferProject: only what the chosen SOUNDs use
    BankProject baseProject, addProject;
    {
        std::string error;
        require(transferProject(all, {{"P1", "P1", 1}, {"P2", "P2", 2}, {"P3", "P3", 3}}, baseProject, error), "base: " + error);
        require(baseProject.sounds.size() == 3U && baseProject.samples.size() == 3U && baseProject.multisamples.size() == 3U, "base content");
        require(transferProject(all, {{"P4", "P4", 2}, {"P1", "P1 copy", 10}}, addProject, error), "add: " + error);
        require(addProject.sounds.size() == 2U && addProject.samples.size() == 2U, "add content (sample a once)");
        require(addProject.sounds[0].position == 2U && addProject.sounds[1].name == "P1 copy", "places and names of the plan");
    }
    const std::string base = write(baseProject, dir + "/base.sv");
    const std::string add = write(addProject, dir + "/add.sv");

    // ---- merge: P4 replaces P2 at place 2, "P1 copy" comes to 10
    {
        SvMergeStats stats{};
        std::string error;
        const std::string out = dir + "/out.sv";
        require(SvBankMerge::merge(base, {add}, {}, out, "", stats, error), "merge: " + error);
        const auto read = SvBankReader::readFile(out, true);
        require(read.ok(), "read merged: " + read.error);
        std::map<int, std::string> places;
        for (const auto& s : read.project.sounds) places[s.position] = s.name;
        require(places.size() == 4U && places[1] == "P1" && places[2] == "P4" && places[3] == "P3" && places[10] == "P1 copy", "places after the merge");
        const auto got = firstAudio(read.project);
        require(got.at("P1") == audio.at("P1") && got.at("P4") == audio.at("P4") && got.at("P3") == audio.at("P3") && got.at("P1 copy") == audio.at("P1"), "the audio is copied exactly");
        require(read.project.samples.size() == 4U, "a and c (base), d and a (added file); b (only P2 used it) is left out");
        for (const auto& smp : read.project.samples) require(smp.name != "b", "sample b went with P2");
        std::vector<std::pair<int, std::string>> list;
        require(SvBankMerge::soundList(out, list, error) && list.size() == 4U, "soundList");
    }
    // ---- leave out place 3, base missing = only the added file
    {
        SvMergeStats stats{};
        std::string error;
        const std::string out = dir + "/out2.sv";
        require(SvBankMerge::merge(base, {add}, {3}, out, "MY BANK", stats, error), "merge leave out: " + error);
        const auto read = SvBankReader::readFile(out, true);
        require(read.ok() && read.project.sounds.size() == 3U && read.project.name == "MY BANK", "left out + name");
        for (const auto& s : read.project.samples) require(s.name != "c", "sample c went with P3");
        const std::string out3 = dir + "/out3.sv";
        require(SvBankMerge::merge(dir + "/missing.sv", {add}, {}, out3, "", stats, error), "merge without base: " + error);
        const auto read3 = SvBankReader::readFile(out3, true);
        require(read3.ok() && read3.project.sounds.size() == 2U, "only the added SOUNDs");
        require(!SvBankMerge::merge(base, {}, {1, 2, 3}, dir + "/none.sv", "", stats, error), "nothing to write = refused");
    }
    std::cout << "send tests passed\n";
    for (const char* f : {"/base.sv", "/add.sv", "/out.sv", "/out2.sv", "/out3.sv"}) (void)std::remove((dir + f).c_str());
    (void)::rmdir(dir.c_str());
    return 0;
}
