// SILVETON_CLEANWAVE_V1 tests: a rough sample must come out smooth, at the same loudness, with no invention.
#include "silveton/manager/WaveSmoother.h"

#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

using namespace silveton::manager;

namespace {

[[noreturn]] void fail(const char* message) {
    std::cerr << "FAIL: " << message << '\n';
    std::exit(1);
}
void require(bool condition, const char* message) { if (!condition) fail(message); }

void put16(std::vector<std::uint8_t>& out, double v) {
    const std::int32_t q = static_cast<std::int32_t>(std::lround(std::max(-1.0, std::min(1.0, v)) * 32767.0));
    const std::uint16_t raw = static_cast<std::uint16_t>(static_cast<std::int16_t>(q));
    out.push_back(static_cast<std::uint8_t>(raw & 0xFFU));
    out.push_back(static_cast<std::uint8_t>((raw >> 8U) & 0xFFU));
}

// a stomp: a low thump with a lot of noise on it - exactly the kind of sample that looks ugly
ImportedSample stomp(std::uint16_t channels = 1U) {
    ImportedSample s{};
    s.name = "stomp";
    s.sourceIdentity = "stomp";
    s.sampleRate = 44100U;
    s.channels = channels;
    s.encoding = AudioEncoding::Pcm16LE;
    s.bitsPerSample = 16U;
    s.rootKey = 36U;
    s.totalFrames = 44100U * 9U / 10U;
    double ph = 0.0;
    std::uint32_t seed = 31U;
    for (std::uint64_t i = 0U; i < s.totalFrames; ++i) {
        const double t = static_cast<double>(i) / 44100.0;
        ph += 2.0 * 3.14159265358979323846 * (42.0 + 60.0 * std::exp(-t / 0.02)) / 44100.0;
        seed = seed * 1103515245U + 12345U;
        const double r = static_cast<double>(seed % 2000000U) / 1000000.0 - 1.0;
        const double v = std::sin(ph) * std::exp(-t * 9.0) * 0.5 + r * 0.55 * std::exp(-t * 45.0) + r * 0.05 * std::exp(-t * 4.0);
        for (std::uint16_t c = 0U; c < channels; ++c) put16(s.audioData, v);
    }
    return s;
}

double roughness(const ImportedSample& s) {
    auto at = [&](std::uint64_t i) {
        const std::size_t off = static_cast<std::size_t>(i) * 2U * s.channels;
        const std::uint16_t raw = static_cast<std::uint16_t>(s.audioData[off]) | static_cast<std::uint16_t>(static_cast<std::uint16_t>(s.audioData[off + 1U]) << 8U);
        return static_cast<double>(static_cast<std::int16_t>(raw)) / 32768.0;
    };
    double sum = 0.0;
    for (std::uint64_t i = 2U; i < s.totalFrames; ++i) {
        const double d = at(i) - 2.0 * at(i - 1U) + at(i - 2U);
        sum += d * d;
    }
    return std::sqrt(sum / static_cast<double>(s.totalFrames));
}
double peak(const ImportedSample& s) {
    double p = 0.0;
    for (std::uint64_t i = 0U; i < s.totalFrames * s.channels; ++i) {
        const std::size_t off = static_cast<std::size_t>(i) * 2U;
        const std::uint16_t raw = static_cast<std::uint16_t>(s.audioData[off]) | static_cast<std::uint16_t>(static_cast<std::uint16_t>(s.audioData[off + 1U]) << 8U);
        p = std::max(p, std::fabs(static_cast<double>(static_cast<std::int16_t>(raw)) / 32768.0));
    }
    return p;
}

} // namespace

int main() {
    const ImportedSample source = stomp();
    const double roughBefore = roughness(source), peakBefore = peak(source);
    require(roughBefore > 0.01, "the test sample really is rough");

    {
        ImportedSample s = source;
        WaveCleanOptions o;
        o.amount = {1.0F};
        o.overtones = 1;
        o.edges = 1.0F;
        std::string e;
        require(WaveSmoother::clean(s, o, e), e.c_str());
        require(s.totalFrames == source.totalFrames, "cleaning keeps the length");
        require(s.audioData.size() == source.audioData.size(), "cleaning keeps the size");
        const double after = roughness(s);
        require(after < roughBefore / 50.0, "a fully cleaned sample is far smoother than it was");
        require(peak(s) > peakBefore * 0.7 && peak(s) <= peakBefore * 1.02, "the loudness stays where it was");
    }
    {
        // nothing asked for, nothing changed
        ImportedSample s = source;
        WaveCleanOptions o;
        o.amount = {0.0F};
        std::string e;
        require(WaveSmoother::clean(s, o, e), e.c_str());
        double worst = 0.0;
        for (std::size_t i = 0U; i < s.audioData.size(); ++i) {
            worst = std::max(worst, std::fabs(static_cast<double>(s.audioData[i]) - static_cast<double>(source.audioData[i])));
        }
        require(worst <= 1.0, "amount 0 leaves the sample as it was");
    }
    {
        // the pen: clean only the second half
        ImportedSample s = source;
        WaveCleanOptions o;
        o.amount = {0.0F, 0.0F, 1.0F, 1.0F};
        o.overtones = 1;
        o.edges = 1.0F;
        std::string e;
        require(WaveSmoother::clean(s, o, e), e.c_str());
        auto half = [&](const ImportedSample& x, bool second) {
            double sum = 0.0;
            const std::uint64_t from = second ? x.totalFrames * 3U / 4U : 0U;
            const std::uint64_t to = second ? x.totalFrames : x.totalFrames / 8U;
            auto at = [&](std::uint64_t i) {
                const std::size_t off = static_cast<std::size_t>(i) * 2U;
                const std::uint16_t raw = static_cast<std::uint16_t>(x.audioData[off]) | static_cast<std::uint16_t>(static_cast<std::uint16_t>(x.audioData[off + 1U]) << 8U);
                return static_cast<double>(static_cast<std::int16_t>(raw)) / 32768.0;
            };
            for (std::uint64_t i = from + 2U; i < to; ++i) {
                const double d = at(i) - 2.0 * at(i - 1U) + at(i - 2U);
                sum += d * d;
            }
            return std::sqrt(sum / static_cast<double>(to - from));
        };
        require(half(s, true) < half(source, true) / 10.0, "the marked part is cleaned");
        require(half(s, false) > half(source, false) * 0.5, "the part left alone keeps its rough edges");
    }
    {
        // stereo stays stereo, and both sides are cleaned
        ImportedSample s = stomp(2U);
        const double before = roughness(s);
        WaveCleanOptions o;
        o.amount = {1.0F};
        std::string e;
        require(WaveSmoother::clean(s, o, e), e.c_str());
        require(s.channels == 2U && s.audioData.size() == static_cast<std::size_t>(s.totalFrames) * 4U, "stereo size is kept");
        require(roughness(s) < before / 20.0, "stereo is cleaned too");
    }
    {
        // more overtones brings more of the sample's own colour back
        ImportedSample one = source, many = source;
        WaveCleanOptions a, b;
        a.amount = {1.0F}; a.overtones = 1; a.edges = 1.0F;
        b.amount = {1.0F}; b.overtones = 8; b.edges = 1.0F;
        std::string e;
        require(WaveSmoother::clean(one, a, e), e.c_str());
        require(WaveSmoother::clean(many, b, e), e.c_str());
        require(roughness(many) > roughness(one), "eight overtones keep more detail than one");
        require(roughness(many) < roughBefore / 10.0, "eight overtones are still far smoother than the source");
    }
    {
        // the note the sample sits on is read, and a sample too short to read says so
        const std::vector<float> note = WaveSmoother::noteTrack(source, 64U);
        require(note.size() == 64U, "the note track has the asked-for length");
        require(note.front() > 30.0F && note.front() < 400.0F, "the note is in a believable range");
        ImportedSample tiny = source;
        tiny.totalFrames = 64U;
        tiny.audioData.resize(128U);
        WaveCleanOptions o;
        std::string e;
        require(!WaveSmoother::clean(tiny, o, e) && !e.empty(), "a sample too short to clean is refused with a reason");
    }

    std::cout << "SILVETON WaveSmoother tests PASS\n";
    return 0;
}
