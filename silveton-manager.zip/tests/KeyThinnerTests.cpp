// SILVETON_THIN_V1 tests: which notes of a set of loose samples a neighbour can play for.
#include "silveton/manager/AutoMapper.h"
#include "silveton/manager/KeyThinner.h"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <map>
#include <string>
#include <vector>

using namespace silveton::manager;

namespace {

[[noreturn]] void fail(const char* message) {
    std::cerr << "FAIL: " << message << '\n';
    std::exit(1);
}
void require(bool condition, const char* message) { if (!condition) fail(message); }

constexpr double kPi = 3.14159265358979323846;

struct Tone {
    int midi{60};
    double cents{0.0};
    double level{0.5};
    double tau{0.5};                              // seconds for the sound to fall to 1/e
    std::vector<double> harmonics{1.0, 0.3, 0.1}; // strength of each harmonic
};

ImportedSample makeTone(const std::string& name, const Tone& tone) {
    ImportedSample s{};
    s.name = name;
    s.sourceIdentity = name;
    s.sampleRate = 44100U;
    s.channels = 1U;
    s.encoding = AudioEncoding::Pcm16LE;
    s.bitsPerSample = 16U;
    s.rootKey = 60U;
    s.totalFrames = 66150U;     // 1.5 s
    s.audioData.resize(static_cast<std::size_t>(s.totalFrames) * 2U, 0U);
    const double hz = 440.0 * std::pow(2.0, (static_cast<double>(tone.midi) + tone.cents / 100.0 - 69.0) / 12.0);
    double norm = 0.0;
    for (double h : tone.harmonics) norm += h;
    for (std::uint64_t i = 0U; i < s.totalFrames; ++i) {
        const double t = static_cast<double>(i) / 44100.0;
        double v = 0.0;
        for (std::size_t h = 0U; h < tone.harmonics.size(); ++h) {
            v += tone.harmonics[h] * std::sin(2.0 * kPi * hz * static_cast<double>(h + 1U) * t);
        }
        v = v / norm * tone.level * std::exp(-t / tone.tau) * std::min(1.0, t / 0.005);
        const std::int16_t q = static_cast<std::int16_t>(std::lround(std::max(-1.0, std::min(1.0, v)) * 32767.0));
        s.audioData[static_cast<std::size_t>(i) * 2U] = static_cast<std::uint8_t>(q & 0xFF);
        s.audioData[static_cast<std::size_t>(i) * 2U + 1U] = static_cast<std::uint8_t>((q >> 8) & 0xFF);
    }
    return s;
}

// a plain run of notes, one sample each, all alike
BankProject chromatic(int from, int to) {
    BankProject p;
    for (int m = from; m <= to; ++m) {
        Tone t;
        t.midi = m;
        p.samples.push_back(makeTone("n" + std::to_string(m), t));
    }
    return p;
}

std::vector<std::size_t> allSamples(const BankProject& p) {
    std::vector<std::size_t> all;
    for (std::size_t i = 0U; i < p.samples.size(); ++i) all.push_back(i);
    return all;
}

struct Verdict {
    std::vector<int> kept;
    std::vector<int> dropped;
};

Verdict verdictOf(const AutoMapPlan& plan, const std::vector<ThinDecision>& d) {
    Verdict v;
    for (std::size_t i = 0U; i < plan.entries.size(); ++i) (d[i].drop ? v.dropped : v.kept).push_back(plan.entries[i].rootKey);
    std::sort(v.kept.begin(), v.kept.end());
    std::sort(v.dropped.begin(), v.dropped.end());
    return v;
}

const ThinDecision& decisionFor(const AutoMapPlan& plan, const std::vector<ThinDecision>& d, int note) {
    for (std::size_t i = 0U; i < plan.entries.size(); ++i) if (plan.entries[i].rootKey == note) return d[i];
    fail("note not in the plan");
}

// a plan written by hand: the note, whether it was heard, and the number of velocity layers
AutoMapPlan handPlan(const std::vector<int>& notes, const std::vector<int>& unclear, const std::vector<int>& twoLayers) {
    AutoMapPlan plan;
    for (int n : notes) {
        const bool odd = std::find(unclear.begin(), unclear.end(), n) != unclear.end();
        const int copies = std::find(twoLayers.begin(), twoLayers.end(), n) != twoLayers.end() ? 2 : 1;
        for (int c = 0; c < copies; ++c) {
            AutoMapEntry e;
            e.sampleIndex = plan.entries.size();
            e.name = "h" + std::to_string(n) + "_" + std::to_string(c);
            e.rootKey = n;
            e.heard = !odd;
            e.confidence = odd ? 0.2F : 0.95F;
            e.peak = 0.3F + 0.3F * static_cast<float>(c);
            plan.entries.push_back(e);
        }
    }
    AutoMapper::arrange(plan);
    return plan;
}

// no kept note may be further from the next kept one than the step; a dropped one is played from at most 1 key away
void requireChain(const Verdict& v, int step, const char* what) {
    const std::vector<int>& kept = v.kept;
    for (std::size_t i = 1U; i < kept.size(); ++i) {
        if (kept[i] - kept[i - 1U] > step) { std::cerr << what << ": gap " << kept[i - 1U] << " -> " << kept[i] << '\n'; fail("two kept notes are further apart than the step"); }
    }
}

} // namespace

int main() {
    // ---- every key: nothing goes
    {
        BankProject p = chromatic(48, 59);
        const AutoMapPlan plan = AutoMapper::listen(p, allSamples(p));
        const std::vector<ThinDecision> d = KeyThinner::decide(p, plan, ThinMode::EveryKey);
        require(d.size() == plan.entries.size(), "one decision per entry");
        for (const ThinDecision& x : d) require(!x.drop && x.reason == ThinReason::KeepAll, "every key keeps its sample");
    }

    // ---- one sample for 3 keys over twelve notes in a row
    {
        BankProject p = chromatic(48, 59);
        const AutoMapPlan plan = AutoMapper::listen(p, allSamples(p));
        for (const AutoMapEntry& e : plan.entries) require(e.heard && e.confidence >= 0.5F, "the synthetic notes are heard clearly");
        const std::vector<ThinDecision> d = KeyThinner::decide(p, plan, ThinMode::EveryThree);
        const Verdict v = verdictOf(plan, d);
        require(v.kept.size() == 5U && v.dropped.size() == 7U, "twelve notes in a row need five samples for three keys each");
        require(v.kept.front() == 48 && v.kept.back() == 59, "the lowest and the highest note stay");
        requireChain(v, 3, "every three");
        for (std::size_t i = 0U; i < plan.entries.size(); ++i) {
            if (!d[i].drop) continue;
            require(std::abs(d[i].coveredBy - plan.entries[i].rootKey) == 1, "a dropped note is played by a neighbour one key away");
            require(std::find(v.kept.begin(), v.kept.end(), d[i].coveredBy) != v.kept.end(), "the one that plays for it stays");
            require(d[i].reason == ThinReason::DropCovered, "a fixed step says why");
        }
        // the blend that comes out of the kept ones really covers 3 keys at most
        AutoMapPlan keptOnly;
        for (std::size_t i = 0U; i < plan.entries.size(); ++i) if (!d[i].drop) keptOnly.entries.push_back(plan.entries[i]);
        AutoMapper::arrange(keptOnly);
        for (const AutoMapEntry& e : keptOnly.entries) {
            if (e.keyLow == 0 || e.keyHigh == 127) continue;               // the ends run out to the keyboard's edge
            require(e.keyHigh - e.keyLow + 1 <= 3, "a kept sample covers three keys at most");
        }
        const ThinSummary sum = KeyThinner::summarize(p, plan, d);
        require(sum.notes == 12U && sum.notesDropped == 7U && sum.samples == 12U && sum.samplesDropped == 7U, "the summary counts notes and samples");
        require(sum.bytesAll == 12U * 66150U * 2U && sum.bytesDropped == 7U * 66150U * 2U, "the summary counts the memory that is saved");
    }

    // ---- one sample for 2 keys
    {
        BankProject p = chromatic(48, 59);
        const AutoMapPlan plan = AutoMapper::listen(p, allSamples(p));
        const std::vector<ThinDecision> d = KeyThinner::decide(p, plan, ThinMode::EveryTwo);
        const Verdict v = verdictOf(plan, d);
        require(v.kept.size() == 7U && v.dropped.size() == 5U, "twelve notes in a row need seven samples for two keys each");
        requireChain(v, 2, "every two");
        require(v.kept.front() == 48 && v.kept.back() == 59, "the ends stay (two keys)");
    }

    // ---- notes that are already three keys apart: nothing to throw away, and the manager says so
    {
        BankProject p;
        for (int m : {48, 51, 54, 57, 60}) { Tone t; t.midi = m; p.samples.push_back(makeTone("s" + std::to_string(m), t)); }
        const AutoMapPlan plan = AutoMapper::listen(p, allSamples(p));
        for (ThinMode mode : {ThinMode::EveryTwo, ThinMode::EveryThree, ThinMode::Decide}) {
            const std::vector<ThinDecision> d = KeyThinner::decide(p, plan, mode);
            for (const ThinDecision& x : d) require(!x.drop, "notes that are already spread are left alone");
            require(decisionFor(plan, d, 51).reason == ThinReason::KeepSpread, "an inner note that is already spread says so");
            require(decisionFor(plan, d, 48).reason == ThinReason::KeepEdge, "the lowest note is an edge");
        }
        const ThinSummary sum = KeyThinner::summarize(p, plan, KeyThinner::decide(p, plan, ThinMode::Decide));
        require(sum.samplesDropped == 0U && sum.notesSpread == 3U, "the summary tells how many notes are already spread");
    }

    // ---- notes every second key: dropping one would leave a sample to cover 4 keys, so none goes
    {
        BankProject p;
        for (int m : {48, 50, 52, 54, 56}) { Tone t; t.midi = m; p.samples.push_back(makeTone("t" + std::to_string(m), t)); }
        const AutoMapPlan plan = AutoMapper::listen(p, allSamples(p));
        const Verdict v = verdictOf(plan, KeyThinner::decide(p, plan, ThinMode::EveryThree));
        requireChain(v, 3, "every second key");
        require(v.kept.size() == 5U && v.dropped.empty(), "dropping one of notes two keys apart would make a sample cover four keys");
    }

    // ---- listening: alike notes go, different ones stay
    {
        BankProject p = chromatic(48, 59);
        const AutoMapPlan plan = AutoMapper::listen(p, allSamples(p));
        const std::vector<ThinDecision> d = KeyThinner::decide(p, plan, ThinMode::Decide);
        const Verdict v = verdictOf(plan, d);
        require(v.dropped.size() == 7U, "when every note sounds alike the manager thins as far as 3 keys");
        for (std::size_t i = 0U; i < plan.entries.size(); ++i) {
            if (d[i].drop) require(d[i].reason == ThinReason::DropSimilar, "a note that goes because it sounds alike says so");
        }
    }
    {
        // note 54 is much louder than its neighbours
        BankProject p;
        for (int m = 48; m <= 59; ++m) { Tone t; t.midi = m; if (m == 54) t.level = 1.0; else t.level = 0.4; p.samples.push_back(makeTone("l" + std::to_string(m), t)); }
        const AutoMapPlan plan = AutoMapper::listen(p, allSamples(p));
        const std::vector<ThinDecision> d = KeyThinner::decide(p, plan, ThinMode::Decide);
        require(!decisionFor(plan, d, 54).drop, "a louder note stays");
        for (const ThinDecision& x : d) require(!(x.drop && x.coveredBy == 54), "a louder note does not play for its neighbours");
        const std::size_t droppedDecide = verdictOf(plan, d).dropped.size();
        const std::size_t droppedThree = verdictOf(plan, KeyThinner::decide(p, plan, ThinMode::EveryThree)).dropped.size();
        require(droppedDecide < droppedThree, "listening throws away fewer than the fixed step when a note is different");
        requireChain(verdictOf(plan, d), 3, "louder note");
    }
    {
        // note 50 dies away much faster
        BankProject p;
        for (int m = 48; m <= 53; ++m) { Tone t; t.midi = m; if (m == 50) t.tau = 0.08; p.samples.push_back(makeTone("d" + std::to_string(m), t)); }
        const AutoMapPlan plan = AutoMapper::listen(p, allSamples(p));
        const std::vector<ThinDecision> d = KeyThinner::decide(p, plan, ThinMode::Decide);
        require(!decisionFor(plan, d, 50).drop, "a note with a different fade-out stays");
        for (const ThinDecision& x : d) require(!(x.drop && x.coveredBy == 50), "it does not play for its neighbours either");
    }
    {
        // note 50 is much brighter
        BankProject p;
        for (int m = 48; m <= 53; ++m) {
            Tone t; t.midi = m;
            if (m == 50) t.harmonics = {0.4, 1.0, 0.8};   // as loud (within 2 dB), but the weight is on the upper harmonics
            p.samples.push_back(makeTone("b" + std::to_string(m), t));
        }
        const AutoMapPlan plan = AutoMapper::listen(p, allSamples(p));
        const std::vector<ThinDecision> d = KeyThinner::decide(p, plan, ThinMode::Decide);
        require(!decisionFor(plan, d, 50).drop, "a brighter note stays");
        for (const ThinDecision& x : d) require(!(x.drop && x.coveredBy == 50), "a brighter note does not play for its neighbours");
    }
    {
        // note 50 is tuned 30 cents high
        BankProject p;
        for (int m = 48; m <= 53; ++m) { Tone t; t.midi = m; if (m == 50) t.cents = 30.0; p.samples.push_back(makeTone("c" + std::to_string(m), t)); }
        const AutoMapPlan plan = AutoMapper::listen(p, allSamples(p));
        const std::vector<ThinDecision> d = KeyThinner::decide(p, plan, ThinMode::Decide);
        require(!decisionFor(plan, d, 50).drop, "a note tuned differently stays");
        for (const ThinDecision& x : d) require(!(x.drop && x.coveredBy == 50), "a detuned note does not play for its neighbours");
    }

    // ---- a note with no clear pitch stays, and nothing is moved across it
    {
        const AutoMapPlan plan = handPlan({48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59}, {53}, {});
        BankProject p;     // fixed steps do not look at the audio
        const std::vector<ThinDecision> d = KeyThinner::decide(p, plan, ThinMode::EveryThree);
        require(!decisionFor(plan, d, 53).drop && decisionFor(plan, d, 53).reason == ThinReason::KeepUnclear, "an unclear note stays and says why");
        require(!decisionFor(plan, d, 52).drop && !decisionFor(plan, d, 54).drop, "the notes beside an unclear one stay");
        require(decisionFor(plan, d, 54).reason == ThinReason::KeepNextToOdd || decisionFor(plan, d, 54).reason == ThinReason::KeepCovers,
                "the note beside an unclear one says why");
        for (std::size_t i = 0U; i < plan.entries.size(); ++i) {
            if (!d[i].drop) continue;
            const int from = plan.entries[i].rootKey, to = d[i].coveredBy;
            require(!(std::min(from, to) < 53 && std::max(from, to) > 53), "nothing is moved across an unclear note");
        }
        require(verdictOf(plan, d).dropped.size() >= 3U, "the clear notes on both sides are still thinned");
    }

    // ---- a note with another number of velocity layers is a wall too
    {
        const AutoMapPlan plan = handPlan({48, 49, 50, 51, 52, 53, 54, 55, 56, 57}, {}, {52, 53, 54, 55});
        BankProject p;
        const std::vector<ThinDecision> d = KeyThinner::decide(p, plan, ThinMode::EveryThree);
        for (std::size_t i = 0U; i < plan.entries.size(); ++i) {
            if (!d[i].drop) continue;
            const bool fromTwo = plan.entries[i].rootKey >= 52 && plan.entries[i].rootKey <= 55;
            const bool toTwo = d[i].coveredBy >= 52 && d[i].coveredBy <= 55;
            require(fromTwo == toTwo, "a note is only played by one with the same number of layers");
        }
        // the layers of one note go or stay together
        std::map<int, int> verdict;
        for (std::size_t i = 0U; i < plan.entries.size(); ++i) {
            const int note = plan.entries[i].rootKey;
            const int now = d[i].drop ? 1 : 0;
            if (verdict.count(note) != 0U) require(verdict[note] == now, "the velocity layers of a note are dropped together");
            verdict[note] = now;
        }
    }

    // ---- real layers: two samples per note, found by listening
    {
        BankProject p;
        for (int m = 48; m <= 53; ++m) {
            Tone soft; soft.midi = m; soft.level = 0.2;
            Tone loud; loud.midi = m; loud.level = 0.6;
            p.samples.push_back(makeTone("soft" + std::to_string(m), soft));
            p.samples.push_back(makeTone("loud" + std::to_string(m), loud));
        }
        const AutoMapPlan plan = AutoMapper::listen(p, allSamples(p));
        require(plan.layers == 2, "two samples per note make two layers");
        const std::vector<ThinDecision> d = KeyThinner::decide(p, plan, ThinMode::Decide);
        std::map<int, int> verdict;
        for (std::size_t i = 0U; i < plan.entries.size(); ++i) {
            const int note = plan.entries[i].rootKey;
            const int now = d[i].drop ? 1 : 0;
            if (verdict.count(note) != 0U) require(verdict[note] == now, "both layers of a note go or stay together");
            verdict[note] = now;
        }
        require(verdictOf(plan, d).dropped.size() == 6U, "six notes in a row with two layers each: three notes go, both layers of each");
        const ThinSummary sum = KeyThinner::summarize(p, plan, d);
        require(sum.notes == 6U && sum.samples == 12U, "the summary counts notes once, samples per layer");
    }

    // ---- looking again with a memory gives the same answer and measures nothing twice
    {
        BankProject p = chromatic(48, 53);
        const AutoMapPlan plan = AutoMapper::listen(p, allSamples(p));
        ThinMemory memory;
        const std::vector<ThinDecision> first = KeyThinner::decide(p, plan, ThinMode::Decide, &memory);
        require(!memory.features.empty(), "the first look is remembered");
        const std::size_t remembered = memory.features.size();
        const std::vector<ThinDecision> second = KeyThinner::decide(p, plan, ThinMode::Decide, &memory);
        require(memory.features.size() == remembered, "the second look measures nothing new");
        const std::vector<ThinDecision> plain = KeyThinner::decide(p, plan, ThinMode::Decide);
        for (std::size_t i = 0U; i < first.size(); ++i) {
            require(first[i].drop == second[i].drop && first[i].drop == plain[i].drop, "with or without a memory the verdict is the same");
        }
    }

    // ---- taking the thrown-away samples out of the project
    {
        BankProject p = chromatic(48, 53);
        AutoMapPlan plan = AutoMapper::listen(p, allSamples(p));
        const std::vector<ThinDecision> d = KeyThinner::decide(p, plan, ThinMode::EveryThree);
        AutoMapPlan keptOnly;
        std::vector<std::size_t> gone;
        std::vector<std::string> keptNames;
        for (std::size_t i = 0U; i < plan.entries.size(); ++i) {
            if (d[i].drop) gone.push_back(plan.entries[i].sampleIndex);
            else { keptOnly.entries.push_back(plan.entries[i]); keptNames.push_back(plan.entries[i].name); }
        }
        AutoMapper::arrange(keptOnly);
        std::size_t created = 0U;
        std::string error;
        require(AutoMapper::build(p, keptOnly, "THIN", created, error), error.c_str());
        const std::size_t before = p.samples.size();
        const std::size_t removed = AutoMapper::dropSamples(p, gone);
        require(removed == gone.size() && p.samples.size() == before - gone.size(), "the dropped samples leave the project");
        require(!p.multisamples.empty() && !p.sounds.empty(), "the blend is still there");
        std::vector<std::string> inBlend;
        for (const ImportedMultisample& ms : p.multisamples) {
            for (const ImportedZone& z : ms.zones) {
                require(z.sampleIndex < p.samples.size(), "every zone still points at a sample that exists");
                inBlend.push_back(p.samples[z.sampleIndex].name);
            }
        }
        std::sort(inBlend.begin(), inBlend.end());
        std::sort(keptNames.begin(), keptNames.end());
        require(inBlend == keptNames, "the blend plays exactly the samples that were kept");
        require(AutoMapper::dropSamples(p, {9999U}) == 0U, "a number that is not a sample is ignored");
    }

    std::cout << "KeyThinner tests passed\n";
    return 0;
}
