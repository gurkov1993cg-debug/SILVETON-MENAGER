// SILVETON_KONTAKT_V1 tests: FastLZ, NCW block decoding, velocity layer choice. SILVETON_PITCH_V1: note detection.
#include "silveton/manager/KontaktImporter.h"
#include "silveton/manager/PitchDetector.h"

#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

using namespace silveton::manager;

namespace {

[[noreturn]] void fail(const char* message) {
    std::cerr << "FAIL: " << message << '\n';
    std::exit(1);
}

void require(bool condition, const char* message) {
    if (!condition) fail(message);
}

void put32(std::vector<std::uint8_t>& v, std::uint32_t x) {
    for (int k = 0; k < 4; ++k) v.push_back(static_cast<std::uint8_t>((x >> (8U * static_cast<unsigned>(k))) & 0xFFU));
}
void put16(std::vector<std::uint8_t>& v, std::uint16_t x) {
    v.push_back(static_cast<std::uint8_t>(x & 0xFFU));
    v.push_back(static_cast<std::uint8_t>((x >> 8U) & 0xFFU));
}

} // namespace

int main() {
    // FastLZ level 1: literal "abcde", copy 5 bytes from 5 back, then 4 x the previous byte
    {
        const std::vector<std::uint8_t> src = {0x04, 'a', 'b', 'c', 'd', 'e', 0x60, 0x04, 0x40, 0x00};
        std::vector<std::uint8_t> out;
        require(KontaktImporter::fastLzDecompress(src.data(), src.size(), 14U, out), "fastlz decompress");
        require(std::string(out.begin(), out.end()) == "abcdeabcdeeeee", "fastlz content");
        require(!KontaktImporter::fastLzDecompress(src.data(), src.size(), 20U, out), "fastlz wrong expected size");
    }

    // velocity layers: always the softest, evenly spread middle ones and the top one
    {
        const auto a = KontaktImporter::chooseVelocityLayers(7U, 5);
        require(a == std::vector<std::size_t>({0U, 2U, 3U, 5U, 6U}), "choose 7 -> 5");
        require(KontaktImporter::chooseVelocityLayers(3U, 5) == std::vector<std::size_t>({0U, 1U, 2U}), "choose 3 -> 3");
        require(KontaktImporter::chooseVelocityLayers(1U, 5) == std::vector<std::size_t>({0U}), "choose 1");
        require(KontaktImporter::chooseVelocityLayers(12U, 5).back() == 11U, "top layer kept");
    }

    // NCW: one channel, two blocks - a constant block (bits 0) and a delta block (bits 4, +1 per sample)
    {
        std::vector<std::uint8_t> ncw;
        put32(ncw, 0xD69EA801U); put32(ncw, 0x131U); put16(ncw, 1U); put16(ncw, 16U);
        put32(ncw, 44100U); put32(ncw, 1024U);
        put32(ncw, 120U);                 // block definitions
        put32(ncw, 120U + 3U * 4U);       // blocks
        const std::uint32_t block0 = 16U, block1 = 16U + 512U * 4U / 8U;
        put32(ncw, block0 + block1);      // blocks size
        while (ncw.size() < 120U) ncw.push_back(0U);
        put32(ncw, 0U); put32(ncw, block0); put32(ncw, block0 + block1);
        // block 0: base 100, bits 0
        put32(ncw, 0x3E9A0C16U); put32(ncw, 100U); put16(ncw, 0U); put16(ncw, 0U); put32(ncw, 0U);
        // block 1: base 0, bits 4, every delta +1 (two nibbles per byte)
        put32(ncw, 0x3E9A0C16U); put32(ncw, 0U); put16(ncw, 4U); put16(ncw, 0U); put32(ncw, 0U);
        for (int i = 0; i < 256; ++i) ncw.push_back(0x11U);
        std::uint32_t rate = 0U, frames = 0U; std::uint16_t channels = 0U; std::uint8_t bits = 0U;
        std::vector<std::uint8_t> pcm; std::string error;
        require(KontaktImporter::decodeNcw(ncw.data(), ncw.size(), rate, channels, bits, frames, pcm, error), error.c_str());
        require(rate == 44100U && channels == 1U && bits == 16U && frames == 1024U, "ncw header");
        require(pcm.size() == 2048U, "ncw pcm size");
        auto at = [&](std::size_t i) { return static_cast<std::int16_t>(pcm[i * 2U] | (static_cast<std::uint16_t>(pcm[i * 2U + 1U]) << 8U)); };
        require(at(0) == 100 && at(511) == 100, "ncw constant block");
        require(at(512) == 0 && at(513) == 1 && at(600) == 88 && at(1023) == 511, "ncw delta block");
    }

    // a missing file is an error, not a crash
    {
        const KontaktLibrary lib = KontaktImporter::open("/nonexistent/folder/missing.nki");
        require(!lib.ok() && !lib.error.empty(), "missing nki reports an error");
    }

    // a bass split per string: one SOUND per playing technique, every key played by one string only
    {
        KontaktLibrary lib;
        lib.programName = "Test_Bass";
        // B reaches 35..45, E 40..50, A 45..55 (the strings overlap like on a real bass)
        struct Str { const char* name; char letter; int low; int high; };
        const Str strs[] = {{"B_sus_1", 'B', 35, 45}, {"E_sus_1", 'E', 40, 50}, {"A_sus_1", 'A', 45, 55}, {"B_mute_1", 'B', 35, 45}};
        for (const Str& st : strs) {
            KontaktGroup g; g.name = st.name;
            for (int key = st.low; key <= st.high; ++key) {
                for (int layer = 0; layer < 3; ++layer) {
                    KontaktZone z;
                    z.groupIndex = static_cast<std::uint32_t>(lib.groups.size());
                    z.keyLow = z.keyHigh = static_cast<std::uint8_t>(key);
                    z.velocityLow = static_cast<std::uint8_t>(layer == 0 ? 1 : layer == 1 ? 41 : 91);
                    z.velocityHigh = static_cast<std::uint8_t>(layer == 0 ? 40 : layer == 1 ? 90 : 127);
                    z.rootKey = static_cast<std::uint8_t>(key);
                    z.fileIndex = static_cast<std::uint32_t>(lib.files.size());
                    z.numFrames = 100U; z.channels = 1U; z.sampleRateTag = 44100U;
                    KontaktFile f; f.name = std::string(1, st.letter) + "_" + std::string(st.name).substr(2) + "_" + std::to_string(key) + "_" + std::to_string(layer) + ".ncw"; f.relativePath = f.name;
                    lib.files.push_back(f);
                    g.zoneIndices.push_back(static_cast<std::uint32_t>(lib.zones.size()));
                    lib.zones.push_back(z);
                }
            }
            lib.groups.push_back(g);
        }
        const std::vector<KontaktInstrumentSet> sets = KontaktImporter::instrumentSets(lib);
        // only 3 strings share "sus_1": it is merged; "mute_1" has one group: plain
        require(sets.size() == 2U, "one merged set + one plain group");
        require(sets[0].merged() && sets[0].groups.size() == 3U && sets[0].strings == "BEA", "sus_1 holds three strings");
        require(sets[0].groups.front() == 2U && sets[0].groups.back() == 0U, "the highest string is preferred");
        require(sets[0].keyLow == 35U && sets[0].keyHigh == 55U, "merged key range");
        require(sets[0].soundName == "Test Bass sus 1", "merged sound name");
        require(!sets[1].merged() && sets[1].name == "B mute 1", "plain group stays a group");
        KontaktImportOptions o; o.dryRun = true; o.maxVelocityLayers = 5;
        const KontaktImportResult r = KontaktImporter::importSet(lib, sets[0], o, nullptr);
        require(r.ok(), r.error.c_str());
        require(r.sound.name == "Test Bass sus 1" && r.sourceLayers == 3U, "merged result name and source layers");
        require(r.multisamples.size() == 3U, "three velocity layers");
        for (const ImportedMultisample& ms : r.multisamples) {
            require(ms.zones.size() == 21U, "21 keys per layer, none twice");
            std::vector<int> seen(128, 0);
            for (const ImportedZone& z : ms.zones) {
                require(z.keyLow == z.keyHigh, "single key zones");
                ++seen[z.keyLow];
                const char letter = r.samples[z.sampleIndex].name[0];
                const char want = z.keyLow >= 45U ? 'A' : z.keyLow >= 40U ? 'E' : 'B';
                require(letter == want, "key is played by the highest string that reaches it");
            }
            for (int k = 35; k <= 55; ++k) require(seen[static_cast<std::size_t>(k)] == 1, "every key exactly once");
        }
        // one 3-key step still leaves no gap and no overlap
        o.keyStep = 3;
        const KontaktImportResult r3 = KontaktImporter::importSet(lib, sets[0], o, nullptr);
        require(r3.ok() && r3.samples.size() == 21U, "keyStep 3 keeps 7 keys x 3 layers");
        for (const ImportedMultisample& ms : r3.multisamples) {
            std::vector<int> cover(128, 0);
            for (const ImportedZone& z : ms.zones) for (int k = z.keyLow; k <= z.keyHigh; ++k) ++cover[static_cast<std::size_t>(k)];
            for (int k = 35; k <= 55; ++k) require(cover[static_cast<std::size_t>(k)] == 1, "keyStep 3 covers every key once");
        }
        // a single group on its own is imported as before
        KontaktImportOptions plain; plain.dryRun = true;
        const KontaktImportResult single = KontaktImporter::importGroup(lib, 3U, plain, nullptr);
        require(single.ok() && single.sound.name == "B mute 1" && single.multisamples.size() == 3U, "single group import");
    }

    // SILVETON_PITCH_V1: which note a recording is. Pure tones and a piano-like tone with a weak fundamental.
    {
        auto tone = [](double hz, double rate, int midiExpected, bool pianoLike) {
            const std::size_t frames = static_cast<std::size_t>(rate * 0.5);
            std::vector<float> x(frames);
            for (std::size_t i = 0U; i < frames; ++i) {
                const double t = static_cast<double>(i) / rate;
                double v = std::sin(2.0 * M_PI * hz * t);
                if (pianoLike) v = 0.2 * v + 0.9 * std::sin(2.0 * M_PI * 2.0 * hz * t + 0.3) + 0.5 * std::sin(2.0 * M_PI * 3.0 * hz * t + 1.1) + 0.3 * std::sin(2.0 * M_PI * 4.0 * hz * t);
                x[i] = static_cast<float>(0.3 * v);
            }
            const PitchResult r = PitchDetector::detect(x.data(), x.size(), rate);
            if (!r.found) fail("pitch not found");
            if (r.midi != midiExpected) { std::cerr << "expected " << midiExpected << " got " << r.midi << " (" << r.hz << " Hz)\n"; fail("pitch midi"); }
            if (std::fabs(r.cents) > 10.0F) fail("pitch cents");
        };
        tone(27.5, 44100.0, 21, false);     // A0
        tone(55.0, 48000.0, 33, true);      // A1 with a weak fundamental
        tone(261.6256, 44100.0, 60, false); // C4
        tone(261.6256, 96000.0, 60, true);  // C4 at 96 kHz
        tone(1046.502, 44100.0, 84, false); // C6
        tone(4186.009, 44100.0, 108, false);// C8
        require(PitchDetector::noteName(21) == "A0" && PitchDetector::noteName(60) == "C4" && PitchDetector::noteName(61) == "C#4" && PitchDetector::noteName(108) == "C8", "note names");
        // silence: nothing found, no crash
        std::vector<float> quiet(22050U, 0.0F);
        require(!PitchDetector::detect(quiet.data(), quiet.size(), 44100.0).found, "silence has no note");
        // a real ImportedSample (16 bit, stereo) goes through the same path
        ImportedSample s;
        s.sampleRate = 44100U; s.channels = 2U; s.bitsPerSample = 16U; s.encoding = AudioEncoding::Pcm16LE;
        s.totalFrames = 22050U;
        s.audioData.resize(static_cast<std::size_t>(s.totalFrames) * 4U);
        for (std::size_t i = 0U; i < static_cast<std::size_t>(s.totalFrames); ++i) {
            const auto v = static_cast<std::int16_t>(std::lround(12000.0 * std::sin(2.0 * M_PI * 440.0 * static_cast<double>(i) / 44100.0)));
            for (std::size_t c = 0U; c < 2U; ++c) { s.audioData[(i * 2U + c) * 2U] = static_cast<std::uint8_t>(v & 0xFF); s.audioData[(i * 2U + c) * 2U + 1U] = static_cast<std::uint8_t>((v >> 8) & 0xFF); }
        }
        const PitchResult r = PitchDetector::detect(s);
        require(r.found && r.midi == 69 && r.noteName() == "A4", "sample A4");
    }

    std::cout << "SILVETON Manager Kontakt import tests PASS\n";
    return 0;
}
