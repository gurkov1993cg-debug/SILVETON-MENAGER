// SILVETON_KONTAKT_V1 tests: FastLZ, NCW block decoding, velocity layer choice.
#include "silveton/manager/KontaktImporter.h"

#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>

using namespace silveton::manager;

namespace {

[[noreturn]] void fail(const char* message) {
    std::cerr << "FAIL: " << message << '\n';
    std::exit(1);
}

void require(bool condition, const char* message) {
    if (!condition) fail(message);
}

void put32(std::vector<std::uint8_t>& v, std::uint32_t x) {
    for (int k = 0; k < 4; ++k) v.push_back(static_cast<std::uint8_t>((x >> (8U * static_cast<unsigned>(k))) & 0xFFU));
}
void put16(std::vector<std::uint8_t>& v, std::uint16_t x) {
    v.push_back(static_cast<std::uint8_t>(x & 0xFFU));
    v.push_back(static_cast<std::uint8_t>((x >> 8U) & 0xFFU));
}

} // namespace

int main() {
    // FastLZ level 1: literal "abcde", copy 5 bytes from 5 back, then 4 x the previous byte
    {
        const std::vector<std::uint8_t> src = {0x04, 'a', 'b', 'c', 'd', 'e', 0x60, 0x04, 0x40, 0x00};
        std::vector<std::uint8_t> out;
        require(KontaktImporter::fastLzDecompress(src.data(), src.size(), 14U, out), "fastlz decompress");
        require(std::string(out.begin(), out.end()) == "abcdeabcdeeeee", "fastlz content");
        require(!KontaktImporter::fastLzDecompress(src.data(), src.size(), 20U, out), "fastlz wrong expected size");
    }

    // velocity layers: always the softest, evenly spread middle ones and the top one
    {
        const auto a = KontaktImporter::chooseVelocityLayers(7U, 5);
        require(a == std::vector<std::size_t>({0U, 2U, 3U, 5U, 6U}), "choose 7 -> 5");
        require(KontaktImporter::chooseVelocityLayers(3U, 5) == std::vector<std::size_t>({0U, 1U, 2U}), "choose 3 -> 3");
        require(KontaktImporter::chooseVelocityLayers(1U, 5) == std::vector<std::size_t>({0U}), "choose 1");
        require(KontaktImporter::chooseVelocityLayers(12U, 5).back() == 11U, "top layer kept");
    }

    // NCW: one channel, two blocks - a constant block (bits 0) and a delta block (bits 4, +1 per sample)
    {
        std::vector<std::uint8_t> ncw;
        put32(ncw, 0xD69EA801U); put32(ncw, 0x131U); put16(ncw, 1U); put16(ncw, 16U);
        put32(ncw, 44100U); put32(ncw, 1024U);
        put32(ncw, 120U);                 // block definitions
        put32(ncw, 120U + 3U * 4U);       // blocks
        const std::uint32_t block0 = 16U, block1 = 16U + 512U * 4U / 8U;
        put32(ncw, block0 + block1);      // blocks size
        while (ncw.size() < 120U) ncw.push_back(0U);
        put32(ncw, 0U); put32(ncw, block0); put32(ncw, block0 + block1);
        // block 0: base 100, bits 0
        put32(ncw, 0x3E9A0C16U); put32(ncw, 100U); put16(ncw, 0U); put16(ncw, 0U); put32(ncw, 0U);
        // block 1: base 0, bits 4, every delta +1 (two nibbles per byte)
        put32(ncw, 0x3E9A0C16U); put32(ncw, 0U); put16(ncw, 4U); put16(ncw, 0U); put32(ncw, 0U);
        for (int i = 0; i < 256; ++i) ncw.push_back(0x11U);
        std::uint32_t rate = 0U, frames = 0U; std::uint16_t channels = 0U; std::uint8_t bits = 0U;
        std::vector<std::uint8_t> pcm; std::string error;
        require(KontaktImporter::decodeNcw(ncw.data(), ncw.size(), rate, channels, bits, frames, pcm, error), error.c_str());
        require(rate == 44100U && channels == 1U && bits == 16U && frames == 1024U, "ncw header");
        require(pcm.size() == 2048U, "ncw pcm size");
        auto at = [&](std::size_t i) { return static_cast<std::int16_t>(pcm[i * 2U] | (static_cast<std::uint16_t>(pcm[i * 2U + 1U]) << 8U)); };
        require(at(0) == 100 && at(511) == 100, "ncw constant block");
        require(at(512) == 0 && at(513) == 1 && at(600) == 88 && at(1023) == 511, "ncw delta block");
    }

    // a missing file is an error, not a crash
    {
        const KontaktLibrary lib = KontaktImporter::open("/nonexistent/folder/missing.nki");
        require(!lib.ok() && !lib.error.empty(), "missing nki reports an error");
    }

    std::cout << "SILVETON Manager Kontakt import tests PASS\n";
    return 0;
}
