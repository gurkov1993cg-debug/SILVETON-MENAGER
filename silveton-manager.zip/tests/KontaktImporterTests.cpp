// SILVETON_KONTAKT_V1 tests: FastLZ, NCW block decoding, velocity layer choice. SILVETON_PITCH_V1: note detection.
#include "silveton/manager/KontaktImporter.h"
#include "silveton/manager/PitchDetector.h"

#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <functional>
#include <iostream>
#include <string>
#include <vector>

#include <sys/stat.h>
#include <unistd.h>

using namespace silveton::manager;

namespace {

[[noreturn]] void fail(const char* message) {
    std::cerr << "FAIL: " << message << '\n';
    std::exit(1);
}

void require(bool condition, const char* message) {
    if (!condition) fail(message);
}

void put32(std::vector<std::uint8_t>& v, std::uint32_t x) {
    for (int k = 0; k < 4; ++k) v.push_back(static_cast<std::uint8_t>((x >> (8U * static_cast<unsigned>(k))) & 0xFFU));
}
void put16(std::vector<std::uint8_t>& v, std::uint16_t x) {
    v.push_back(static_cast<std::uint8_t>(x & 0xFFU));
    v.push_back(static_cast<std::uint8_t>((x >> 8U) & 0xFFU));
}

} // namespace

int main() {
    // FastLZ level 1: literal "abcde", copy 5 bytes from 5 back, then 4 x the previous byte
    {
        const std::vector<std::uint8_t> src = {0x04, 'a', 'b', 'c', 'd', 'e', 0x60, 0x04, 0x40, 0x00};
        std::vector<std::uint8_t> out;
        require(KontaktImporter::fastLzDecompress(src.data(), src.size(), 14U, out), "fastlz decompress");
        require(std::string(out.begin(), out.end()) == "abcdeabcdeeeee", "fastlz content");
        require(!KontaktImporter::fastLzDecompress(src.data(), src.size(), 20U, out), "fastlz wrong expected size");
    }

    // velocity layers: always the softest, evenly spread middle ones and the top one
    {
        const auto a = KontaktImporter::chooseVelocityLayers(7U, 5);
        require(a == std::vector<std::size_t>({0U, 2U, 3U, 5U, 6U}), "choose 7 -> 5");
        require(KontaktImporter::chooseVelocityLayers(3U, 5) == std::vector<std::size_t>({0U, 1U, 2U}), "choose 3 -> 3");
        require(KontaktImporter::chooseVelocityLayers(1U, 5) == std::vector<std::size_t>({0U}), "choose 1");
        require(KontaktImporter::chooseVelocityLayers(12U, 5).back() == 11U, "top layer kept");
    }

    // NCW: one channel, two blocks - a constant block (bits 0) and a delta block (bits 4, +1 per sample)
    {
        std::vector<std::uint8_t> ncw;
        put32(ncw, 0xD69EA801U); put32(ncw, 0x131U); put16(ncw, 1U); put16(ncw, 16U);
        put32(ncw, 44100U); put32(ncw, 1024U);
        put32(ncw, 120U);                 // block definitions
        put32(ncw, 120U + 3U * 4U);       // blocks
        const std::uint32_t block0 = 16U, block1 = 16U + 512U * 4U / 8U;
        put32(ncw, block0 + block1);      // blocks size
        while (ncw.size() < 120U) ncw.push_back(0U);
        put32(ncw, 0U); put32(ncw, block0); put32(ncw, block0 + block1);
        // block 0: base 100, bits 0
        put32(ncw, 0x3E9A0C16U); put32(ncw, 100U); put16(ncw, 0U); put16(ncw, 0U); put32(ncw, 0U);
        // block 1: base 0, bits 4, every delta +1 (two nibbles per byte)
        put32(ncw, 0x3E9A0C16U); put32(ncw, 0U); put16(ncw, 4U); put16(ncw, 0U); put32(ncw, 0U);
        for (int i = 0; i < 256; ++i) ncw.push_back(0x11U);
        std::uint32_t rate = 0U, frames = 0U; std::uint16_t channels = 0U; std::uint8_t bits = 0U;
        std::vector<std::uint8_t> pcm; std::string error;
        require(KontaktImporter::decodeNcw(ncw.data(), ncw.size(), rate, channels, bits, frames, pcm, error), error.c_str());
        require(rate == 44100U && channels == 1U && bits == 16U && frames == 1024U, "ncw header");
        require(pcm.size() == 2048U, "ncw pcm size");
        auto at = [&](std::size_t i) { return static_cast<std::int16_t>(pcm[i * 2U] | (static_cast<std::uint16_t>(pcm[i * 2U + 1U]) << 8U)); };
        require(at(0) == 100 && at(511) == 100, "ncw constant block");
        require(at(512) == 0 && at(513) == 1 && at(600) == 88 && at(1023) == 511, "ncw delta block");
    }

    // a missing file is an error, not a crash
    {
        const KontaktLibrary lib = KontaktImporter::open("/nonexistent/folder/missing.nki");
        require(!lib.ok() && !lib.error.empty(), "missing nki reports an error");
    }

    // SILVETON_KONTAKT_OLD_V1: a Kontakt 2-4 file (0x7FA89012 in front, then one FastLZ stream with the chunk list) is
    // read through its container: program chunk and old file name table are found (a program without groups is
    // then reported as "no groups", not as a damaged container)
    {
        std::vector<std::uint8_t> priv;                       // the program name "Old": u32 characters + UTF-16
        put32(priv, 3U);
        for (char ch : std::string("Old")) { priv.push_back(static_cast<std::uint8_t>(ch)); priv.push_back(0U); }
        std::vector<std::uint8_t> program;                    // structured object: 1, version, public, private, children
        program.push_back(1U); program.push_back(0x80U); program.push_back(0U);
        put32(program, 0U);
        put32(program, static_cast<std::uint32_t>(priv.size()));
        program.insert(program.end(), priv.begin(), priv.end());
        put32(program, 0U);
        std::vector<std::uint8_t> table;                      // old file name table: version 1, no resources, no files
        put32(table, 1U); put32(table, 0U); put32(table, 0U);
        std::vector<std::uint8_t> chunks;
        auto chunk = [&](std::uint16_t id, const std::vector<std::uint8_t>& data) {
            chunks.push_back(static_cast<std::uint8_t>(id & 0xFFU)); chunks.push_back(static_cast<std::uint8_t>(id >> 8U));
            put32(chunks, static_cast<std::uint32_t>(data.size()));
            chunks.insert(chunks.end(), data.begin(), data.end());
        };
        chunk(0x28U, program);
        chunk(0x3DU, table);
        std::vector<std::uint8_t> file(0x60U, 0U);            // header
        file[0] = 0x12U; file[1] = 0x90U; file[2] = 0xA8U; file[3] = 0x7FU;
        for (std::size_t pos = 0U; pos < chunks.size();) {    // FastLZ with literals only: (n - 1), then n bytes
            const std::size_t n = std::min<std::size_t>(32U, chunks.size() - pos);
            file.push_back(static_cast<std::uint8_t>(n - 1U));
            file.insert(file.end(), chunks.begin() + static_cast<std::ptrdiff_t>(pos), chunks.begin() + static_cast<std::ptrdiff_t>(pos + n));
            pos += n;
        }
        file.insert(file.end(), 16U, 0U);
        const std::string path = "/tmp/silveton_old_nki_test.nki";
        {
            std::ofstream out(path, std::ios::binary);
            out.write(reinterpret_cast<const char*>(file.data()), static_cast<std::streamsize>(file.size()));
        }
        const KontaktLibrary lib = KontaktImporter::open(path);
        std::remove(path.c_str());
        require(lib.programName == "Old", "old nki: program name read");
        require(lib.error == "Kontakt file has no groups", "old nki: container and file table read");
    }

    // a bass split per string: one SOUND per playing technique, every key played by one string only
    {
        KontaktLibrary lib;
        lib.programName = "Test_Bass";
        // B reaches 35..45, E 40..50, A 45..55 (the strings overlap like on a real bass)
        struct Str { const char* name; char letter; int low; int high; };
        const Str strs[] = {{"B_sus_1", 'B', 35, 45}, {"E_sus_1", 'E', 40, 50}, {"A_sus_1", 'A', 45, 55}, {"B_mute_1", 'B', 35, 45}};
        for (const Str& st : strs) {
            KontaktGroup g; g.name = st.name;
            for (int key = st.low; key <= st.high; ++key) {
                for (int layer = 0; layer < 3; ++layer) {
                    KontaktZone z;
                    z.groupIndex = static_cast<std::uint32_t>(lib.groups.size());
                    z.keyLow = z.keyHigh = static_cast<std::uint8_t>(key);
                    z.velocityLow = static_cast<std::uint8_t>(layer == 0 ? 1 : layer == 1 ? 41 : 91);
                    z.velocityHigh = static_cast<std::uint8_t>(layer == 0 ? 40 : layer == 1 ? 90 : 127);
                    z.rootKey = static_cast<std::uint8_t>(key);
                    z.fileIndex = static_cast<std::uint32_t>(lib.files.size());
                    z.numFrames = 100U; z.channels = 1U; z.sampleRateTag = 44100U;
                    KontaktFile f; f.name = std::string(1, st.letter) + "_" + std::string(st.name).substr(2) + "_" + std::to_string(key) + "_" + std::to_string(layer) + ".ncw"; f.relativePath = f.name;
                    lib.files.push_back(f);
                    g.zoneIndices.push_back(static_cast<std::uint32_t>(lib.zones.size()));
                    lib.zones.push_back(z);
                }
            }
            lib.groups.push_back(g);
        }
        const std::vector<KontaktInstrumentSet> sets = KontaktImporter::instrumentSets(lib);
        // only 3 strings share "sus_1": it is merged; "mute_1" has one group: plain
        require(sets.size() == 2U, "one merged set + one plain group");
        require(sets[0].merged() && sets[0].groups.size() == 3U && sets[0].strings == "B E A", "sus_1 holds three strings");
        require(sets[0].groups.front() == 2U && sets[0].groups.back() == 0U, "the highest string is preferred");
        require(sets[0].keyLow == 35U && sets[0].keyHigh == 55U, "merged key range");
        require(sets[0].soundName == "Test Bass sus 1", "merged sound name");
        require(!sets[1].merged() && sets[1].name == "B mute 1", "plain group stays a group");
        KontaktImportOptions o; o.dryRun = true; o.maxVelocityLayers = 5;
        const KontaktImportResult r = KontaktImporter::importSet(lib, sets[0], o, nullptr);
        require(r.ok(), r.error.c_str());
        require(r.sound.name == "Test Bass sus 1" && r.sourceLayers == 3U, "merged result name and source layers");
        require(r.multisamples.size() == 3U, "three velocity layers");
        for (const ImportedMultisample& ms : r.multisamples) {
            require(ms.zones.size() == 21U, "21 keys per layer, none twice");
            std::vector<int> seen(128, 0);
            for (const ImportedZone& z : ms.zones) {
                require(z.keyLow == z.keyHigh, "single key zones");
                ++seen[z.keyLow];
                const char letter = r.samples[z.sampleIndex].name[0];
                const char want = z.keyLow >= 45U ? 'A' : z.keyLow >= 40U ? 'E' : 'B';
                require(letter == want, "key is played by the highest string that reaches it");
            }
            for (int k = 35; k <= 55; ++k) require(seen[static_cast<std::size_t>(k)] == 1, "every key exactly once");
        }
        // one 3-key step still leaves no gap and no overlap
        o.keyStep = 3;
        const KontaktImportResult r3 = KontaktImporter::importSet(lib, sets[0], o, nullptr);
        require(r3.ok() && r3.samples.size() == 21U, "keyStep 3 keeps 7 keys x 3 layers");
        for (const ImportedMultisample& ms : r3.multisamples) {
            std::vector<int> cover(128, 0);
            for (const ImportedZone& z : ms.zones) for (int k = z.keyLow; k <= z.keyHigh; ++k) ++cover[static_cast<std::size_t>(k)];
            for (int k = 35; k <= 55; ++k) require(cover[static_cast<std::size_t>(k)] == 1, "keyStep 3 covers every key once");
        }
        // a single group on its own is imported as before
        KontaktImportOptions plain; plain.dryRun = true;
        const KontaktImportResult single = KontaktImporter::importGroup(lib, 3U, plain, nullptr);
        require(single.ok() && single.sound.name == "B mute 1" && single.multisamples.size() == 3U, "single group import");
    }

    // a guitar: strings E6 A D G H E1, every group of the file twice -> ONE set per technique, first copy of each string
    {
        KontaktLibrary lib;
        lib.programName = "TG";
        const char* strings[] = {"E6", "A", "D", "G", "H", "E1"};
        const int lows[] = {40, 45, 50, 55, 59, 64};
        for (int copy = 0; copy < 2; ++copy) {
            for (int s = 0; s < 6; ++s) {
                KontaktGroup g; g.name = std::string(strings[s]) + "_sus_1";
                for (int key = lows[s]; key < lows[s] + 20; ++key) {
                    KontaktZone z;
                    z.groupIndex = static_cast<std::uint32_t>(lib.groups.size());
                    z.keyLow = z.keyHigh = static_cast<std::uint8_t>(key); z.rootKey = z.keyLow;
                    z.fileIndex = static_cast<std::uint32_t>(lib.files.size());
                    z.numFrames = 100U; z.channels = 1U; z.sampleRateTag = 44100U;
                    KontaktFile f; f.name = std::string(strings[s]) + "_" + std::to_string(key) + ".ncw"; f.relativePath = f.name;
                    lib.files.push_back(f);
                    g.zoneIndices.push_back(static_cast<std::uint32_t>(lib.zones.size()));
                    lib.zones.push_back(z);
                }
                lib.groups.push_back(g);
            }
        }
        KontaktGroup ks; ks.name = "KS";   // not a string group: stays on its own
        { KontaktZone z; z.groupIndex = static_cast<std::uint32_t>(lib.groups.size()); z.keyLow = z.keyHigh = 20U; z.rootKey = 20U; z.fileIndex = 0U; z.numFrames = 100U; z.channels = 1U; z.sampleRateTag = 44100U;
          ks.zoneIndices.push_back(static_cast<std::uint32_t>(lib.zones.size())); lib.zones.push_back(z); }
        lib.groups.push_back(ks);
        const std::vector<KontaktInstrumentSet> sets = KontaktImporter::instrumentSets(lib);
        require(sets.size() == 2U, "guitar: one merged set + KS");
        require(sets[0].merged() && sets[0].groups.size() == 6U && sets[0].strings == "E6 A D G H E1", "guitar: all six strings, first copy only");
        require(sets[0].groups.front() == 5U, "guitar: highest string (E1, first copy) is preferred");
        require(sets[0].keyLow == 40U && sets[0].keyHigh == 83U, "guitar: merged key range");
        require(!sets[1].merged() && sets[1].name == "KS", "guitar: KS stays a plain group");
    }

    // a monolith with folders inside (the guitars: Resources/..., Samples/...) hands every file its own data
    {
        auto makeNcw = [&](std::uint32_t base) {
            std::vector<std::uint8_t> ncw;
            put32(ncw, 0xD69EA801U); put32(ncw, 0x131U); put16(ncw, 1U); put16(ncw, 16U);
            put32(ncw, 44100U); put32(ncw, 512U);
            put32(ncw, 120U); put32(ncw, 120U + 2U * 4U);
            put32(ncw, 16U);
            while (ncw.size() < 120U) ncw.push_back(0U);
            put32(ncw, 0U); put32(ncw, 16U);
            put32(ncw, 0x3E9A0C16U); put32(ncw, base); put16(ncw, 0U); put16(ncw, 0U); put32(ncw, 0U);
            return ncw;
        };
        // the real layout: a block = header + entries, the data of its files right after the entries, then the
        // blocks of its folders (a folder entry's value is the offset of its block)
        // bogus = a folder entry that leads nowhere (value 0 = back to the first block, or past the end of the file)
        struct Node { std::string name; bool folder; std::vector<std::uint8_t> data; std::vector<Node> children; bool bogus = false; std::uint32_t fixed = 0U; std::uint16_t kind = 2U; bool resource = false; };
        bool inlineOrder = false;     // true: the data of the block comes in entry order, a folder's block right where its entry stands
        std::function<void(std::vector<std::uint8_t>&, const std::vector<Node>&)> writeBlock;
        auto writeFile = [&](std::vector<std::uint8_t>& f, const Node& n) {
            const std::size_t at = f.size();
            if (n.resource) {   // pictures / texts: another header, its length is not known from outside
                put32(f, 0x2AE905FAU);
                while (f.size() < at + 16U) f.push_back(0U);
                f.insert(f.end(), n.data.begin(), n.data.end());
                return;
            }
            put32(f, 0x16CCF80AU); while (f.size() < at + 19U) f.push_back(0U);
            put32(f, static_cast<std::uint32_t>(n.data.size())); put32(f, 0U);
            while (f.size() < at + 31U) f.push_back(0U);
            f.insert(f.end(), n.data.begin(), n.data.end());
        };
        writeBlock = [&](std::vector<std::uint8_t>& f, const std::vector<Node>& nodes) {
            const std::size_t start = f.size();
            put32(f, 0x5E70AC54U); put32(f, 0x0110U); put16(f, 0U); put16(f, 0xFF00U); put16(f, 0U);   // magic, version, flags
            put32(f, static_cast<std::uint32_t>(nodes.size())); put32(f, 0U);
            (void)start;
            std::vector<std::size_t> valueAt;
            for (const Node& n : nodes) {
                const std::uint16_t len = static_cast<std::uint16_t>(8U + n.name.size() * 2U + 2U);
                put16(f, len);
                valueAt.push_back(f.size()); put32(f, n.bogus ? n.fixed : n.folder ? 0U : 0xABCDEF01U);   // a file's value is not an offset
                put16(f, n.folder ? 1U : n.kind);
                for (char c : n.name) { f.push_back(static_cast<std::uint8_t>(c)); f.push_back(0U); }
                put16(f, 0U);
            }
            auto setValue = [&](std::size_t i) {
                const std::uint32_t where = static_cast<std::uint32_t>(f.size());
                for (int k = 0; k < 4; ++k) f[valueAt[i] + static_cast<std::size_t>(k)] = static_cast<std::uint8_t>((where >> (8U * static_cast<unsigned>(k))) & 0xFFU);
            };
            if (inlineOrder) {
                for (std::size_t i = 0U; i < nodes.size(); ++i) {
                    if (nodes[i].bogus) continue;
                    if (nodes[i].folder) { setValue(i); writeBlock(f, nodes[i].children); }
                    else writeFile(f, nodes[i]);
                }
                return;
            }
            for (const Node& n : nodes) if (!n.folder) writeFile(f, n);
            for (std::size_t i = 0U; i < nodes.size(); ++i) {
                if (!nodes[i].folder || nodes[i].bogus) continue;
                setValue(i);
                writeBlock(f, nodes[i].children);
            }
        };
        auto writeNkx = [&](const std::string& path, const std::vector<Node>& tree) {
            std::vector<std::uint8_t> f;
            writeBlock(f, tree);
            const std::size_t cut = path.find_last_of('/');
            const std::string dir = path.substr(0U, cut);
            ::mkdir(dir.substr(0U, dir.find_last_of('/')).c_str(), 0755);   // the test root
            ::mkdir(dir.c_str(), 0755);                                       // its Samples folder
            std::ofstream out(path, std::ios::binary);
            out.write(reinterpret_cast<const char*>(f.data()), static_cast<std::streamsize>(f.size()));
        };
        const std::string root = "/tmp/silveton_nkx_test_" + std::to_string(static_cast<long>(::getpid()));
        const std::vector<std::uint8_t> a = makeNcw(100U), b = makeNcw(200U), png = {1, 2, 3, 4, 5};
        const char* layoutNames[] = {"Flat", "Folders", "Inline", "Bogus", "Mixed", "Pictures"};
        for (int layout = 0; layout < 6; ++layout) {
            const std::string rel = std::string("Samples/") + layoutNames[layout] + ".nkx";
            inlineOrder = layout == 2 || layout == 4 || layout == 5;
            if (layout == 0) writeNkx(root + "/" + rel, {{"a.ncw", false, a, {}}, {"b.ncw", false, b, {}}});
            else if (layout == 1) writeNkx(root + "/" + rel, {{"Resources", true, {}, {{"ir_samples", true, {}, {{"hall.wav", false, png, {}}, {"room.wav", false, png, {}}}}, {"pictures", true, {}, {{"p.png", false, png, {}}}}}},
                                             {"Samples", true, {}, {{"a.ncw", false, a, {}}, {"b.ncw", false, b, {}}}}});
            // the real order of the AG monoliths: a folder's block sits right after the entries, the next folder after it
            else if (layout == 2) writeNkx(root + "/" + rel, {{"Resources", true, {}, {{"ir_samples", true, {}, {{"hall.wav", false, png, {}}}}, {"pictures", true, {}, {{"p.png", false, png, {}}}}}},
                                             {"Samples", true, {}, {{"a.ncw", false, a, {}}, {"b.ncw", false, b, {}}}}});
            // folders that lead nowhere (back to the first block, past the end of the file) must not hide the samples
            else if (layout == 3) writeNkx(root + "/" + rel, {{"Loop", true, {}, {}, true, 0U}, {"Nowhere", true, {}, {}, true, 99999999U},
                                             {"Samples", true, {}, {{"a.ncw", false, a, {}}, {"b.ncw", false, b, {}}}}});
            // a block that holds a folder AND files, folder first
            else if (layout == 4) writeNkx(root + "/" + rel, {{"Samples", true, {}, {{"Extra", true, {}, {{"p.png", false, png, {}}}}, {"a.ncw", false, a, {}}, {"b.ncw", false, b, {}}}}});
            // the real shape of AG / NG / LP / TC Samples 1: a "pictures" folder of type-4 entries whose data
            // uses another header, standing between the impulses and the Samples folder (this is what used to
            // stop the whole import with "Kontakt monolith ... is damaged")
            else {
                Node blank{"_Blank.PNG", false, png, {}, false, 0U, 4U, true};
                Node blankTxt{"_Blank.txt", false, png, {}, false, 0U, 4U, true};
                Node hall{"hall.wav", false, png, {}};
                Node irs{"ir_samples", true, {}, {hall}};
                Node pics{"pictures", true, {}, {blank, blankTxt}};
                Node res{"Resources", true, {}, {irs, pics}};
                Node smp{"Samples", true, {}, {{"a.ncw", false, a, {}}, {"b.ncw", false, b, {}}}};
                writeNkx(root + "/" + rel, {res, smp});
            }
            KontaktLibrary lib;
            lib.programName = "Mono"; lib.directory = root;
            KontaktGroup g; g.name = "Group";
            const char* names[] = {"a.ncw", "b.ncw"};
            for (int i = 0; i < 2; ++i) {
                KontaktFile f; f.name = names[i]; f.monolith = rel; f.relativePath = rel + "/Samples/" + names[i];
                KontaktZone z; z.groupIndex = 0U; z.keyLow = z.keyHigh = static_cast<std::uint8_t>(60 + i); z.rootKey = z.keyLow;
                z.fileIndex = static_cast<std::uint32_t>(lib.files.size()); z.numFrames = 512U; z.channels = 1U; z.sampleRateTag = 44100U;
                g.zoneIndices.push_back(static_cast<std::uint32_t>(lib.zones.size()));
                lib.files.push_back(f); lib.zones.push_back(z);
            }
            lib.groups.push_back(g);
            KontaktImportOptions o; o.maxVelocityLayers = 5;
            const KontaktImportResult r = KontaktImporter::importGroup(lib, 0U, o, nullptr);
            require(r.ok(), r.error.c_str());
            require(r.samples.size() == 2U, "monolith: two samples");
            std::int16_t first[2] = {0, 0};
            for (const ImportedMultisample& ms : r.multisamples) for (const ImportedZone& z : ms.zones) {
                const ImportedSample& smp = r.samples[z.sampleIndex];
                first[z.keyLow - 60U] = static_cast<std::int16_t>(smp.audioData[0] | (static_cast<std::uint16_t>(smp.audioData[1]) << 8U));
            }
            require(first[0] == 100 && first[1] == 200, (std::string("monolith layout ") + layoutNames[layout] + ": every file its own data").c_str());
        }
        // a missing sample says why the directory was not read completely; a broken first block is "damaged" with the reason
        {
            KontaktLibrary lib;
            lib.programName = "Mono"; lib.directory = root;
            KontaktGroup g; g.name = "Group";
            KontaktFile f; f.name = "zzz.ncw"; f.monolith = "Samples/Bogus.nkx"; f.relativePath = "Samples/Bogus.nkx/Samples/zzz.ncw";
            KontaktZone z; z.groupIndex = 0U; z.keyLow = z.keyHigh = 60U; z.rootKey = 60U; z.fileIndex = 0U; z.numFrames = 512U; z.channels = 1U; z.sampleRateTag = 44100U;
            g.zoneIndices.push_back(0U); lib.files.push_back(f); lib.zones.push_back(z); lib.groups.push_back(g);
            KontaktImportOptions o; o.maxVelocityLayers = 5;
            const KontaktImportResult r = KontaktImporter::importGroup(lib, 0U, o, nullptr);
            require(!r.ok(), "a sample that is not in the monolith fails");
            require(r.error.find("zzz.ncw") != std::string::npos && r.error.find("not inside") != std::string::npos, "the error names the sample");
            require(r.error.find("could not be read completely") != std::string::npos, "the error says what was odd in the directory");
        }
        {
            std::vector<std::uint8_t> bad;
            put32(bad, 0x5E70AC54U); put32(bad, 0x0110U); put16(bad, 0U); put16(bad, 0xFF00U); put16(bad, 0U);
            put32(bad, 1U); put32(bad, 0U);
            put16(bad, 7U); put32(bad, 0U); put16(bad, 2U);     // an entry shorter than its own header
            put16(bad, 0U);
            { std::ofstream out(root + "/Samples/Broken.nkx", std::ios::binary); out.write(reinterpret_cast<const char*>(bad.data()), static_cast<std::streamsize>(bad.size())); }
            KontaktLibrary lib;
            lib.programName = "Mono"; lib.directory = root;
            KontaktGroup g; g.name = "Group";
            KontaktFile f; f.name = "a.ncw"; f.monolith = "Samples/Broken.nkx"; f.relativePath = "Samples/Broken.nkx/Samples/a.ncw";
            KontaktZone z; z.groupIndex = 0U; z.keyLow = z.keyHigh = 60U; z.rootKey = 60U; z.fileIndex = 0U; z.numFrames = 512U; z.channels = 1U; z.sampleRateTag = 44100U;
            g.zoneIndices.push_back(0U); lib.files.push_back(f); lib.zones.push_back(z); lib.groups.push_back(g);
            KontaktImportOptions o; o.maxVelocityLayers = 5;
            const KontaktImportResult r = KontaktImporter::importGroup(lib, 0U, o, nullptr);
            require(!r.ok() && r.error.find("directory is damaged") != std::string::npos && r.error.find("length 7") != std::string::npos, "a broken first block is damaged, with the reason");
            ::unlink((root + "/Samples/Broken.nkx").c_str());
        }
        for (const char* n : layoutNames) ::unlink((root + "/Samples/" + n + ".nkx").c_str());
        ::rmdir((root + "/Samples").c_str()); ::rmdir(root.c_str());
    }

    // SILVETON_PITCH_V1: which note a recording is. Pure tones and a piano-like tone with a weak fundamental.
    {
        auto tone = [](double hz, double rate, int midiExpected, bool pianoLike) {
            const std::size_t frames = static_cast<std::size_t>(rate * 0.5);
            std::vector<float> x(frames);
            for (std::size_t i = 0U; i < frames; ++i) {
                const double t = static_cast<double>(i) / rate;
                double v = std::sin(2.0 * M_PI * hz * t);
                if (pianoLike) v = 0.2 * v + 0.9 * std::sin(2.0 * M_PI * 2.0 * hz * t + 0.3) + 0.5 * std::sin(2.0 * M_PI * 3.0 * hz * t + 1.1) + 0.3 * std::sin(2.0 * M_PI * 4.0 * hz * t);
                x[i] = static_cast<float>(0.3 * v);
            }
            const PitchResult r = PitchDetector::detect(x.data(), x.size(), rate);
            if (!r.found) fail("pitch not found");
            if (r.midi != midiExpected) { std::cerr << "expected " << midiExpected << " got " << r.midi << " (" << r.hz << " Hz)\n"; fail("pitch midi"); }
            if (std::fabs(r.cents) > 10.0F) fail("pitch cents");
        };
        tone(27.5, 44100.0, 21, false);     // A0
        tone(55.0, 48000.0, 33, true);      // A1 with a weak fundamental
        tone(261.6256, 44100.0, 60, false); // C4
        tone(261.6256, 96000.0, 60, true);  // C4 at 96 kHz
        tone(1046.502, 44100.0, 84, false); // C6
        tone(4186.009, 44100.0, 108, false);// C8
        require(PitchDetector::noteName(21) == "A0" && PitchDetector::noteName(60) == "C4" && PitchDetector::noteName(61) == "C#4" && PitchDetector::noteName(108) == "C8", "note names");
        // silence: nothing found, no crash
        std::vector<float> quiet(22050U, 0.0F);
        require(!PitchDetector::detect(quiet.data(), quiet.size(), 44100.0).found, "silence has no note");
        // a real ImportedSample (16 bit, stereo) goes through the same path
        ImportedSample s;
        s.sampleRate = 44100U; s.channels = 2U; s.bitsPerSample = 16U; s.encoding = AudioEncoding::Pcm16LE;
        s.totalFrames = 22050U;
        s.audioData.resize(static_cast<std::size_t>(s.totalFrames) * 4U);
        for (std::size_t i = 0U; i < static_cast<std::size_t>(s.totalFrames); ++i) {
            const auto v = static_cast<std::int16_t>(std::lround(12000.0 * std::sin(2.0 * M_PI * 440.0 * static_cast<double>(i) / 44100.0)));
            for (std::size_t c = 0U; c < 2U; ++c) { s.audioData[(i * 2U + c) * 2U] = static_cast<std::uint8_t>(v & 0xFF); s.audioData[(i * 2U + c) * 2U + 1U] = static_cast<std::uint8_t>((v >> 8) & 0xFF); }
        }
        const PitchResult r = PitchDetector::detect(s);
        require(r.found && r.midi == 69 && r.noteName() == "A4", "sample A4");
    }

    std::cout << "SILVETON Manager Kontakt import tests PASS\n";
    return 0;
}
