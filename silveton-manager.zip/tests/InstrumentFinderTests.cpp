#include "silveton/manager/InstrumentFinder.h"

#include <atomic>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <string>
#include <sys/stat.h>
#include <unistd.h>

using namespace silveton::manager;

namespace {

[[noreturn]] void fail(const char* message) {
    std::cerr << "FAIL: " << message << '\n';
    std::exit(1);
}

void require(bool condition, const char* message) {
    if (!condition) fail(message);
}

void makeDir(const std::string& path) {
    if (::mkdir(path.c_str(), 0755) != 0) fail(("cannot make folder " + path).c_str());
}

void makeFile(const std::string& path, std::size_t size) {
    std::ofstream out(path, std::ios::binary);
    if (!out) fail(("cannot make file " + path).c_str());
    out << std::string(size, 'x');
}

} // namespace

int main() {
    char pattern[] = "/tmp/silveton_finder_XXXXXX";
    if (::mkdtemp(pattern) == nullptr) fail("mkdtemp");
    const std::string root = pattern;

    makeDir(root + "/a");
    makeDir(root + "/a/b");
    makeDir(root + "/c");
    makeDir(root + "/.hidden");
    makeDir(root + "/Zeta");
    makeFile(root + "/top.nki", 10);
    makeFile(root + "/a/Piano.NKI", 20);
    makeFile(root + "/a/b/Strings.kmp", 30);
    makeFile(root + "/a/b/Strings.ksf", 5);       // a sample of a KMP: never listed
    makeFile(root + "/a/b/old.ksc", 5);           // KSC: never listed
    makeFile(root + "/c/readme.txt", 5);
    makeFile(root + "/c/loose.wav", 5);
    makeFile(root + "/c/Piano.nkx", 5);           // monolith: never listed
    makeFile(root + "/c/Piano.ncw", 5);           // compressed wave: never listed
    makeFile(root + "/.hidden/Hid.nki", 5);       // hidden folder: not looked into
    makeFile(root + "/a/._Piano.nki", 5);         // macOS copy file: hidden
    makeFile(root + "/Zeta/b.kmp", 7);
    makeFile(root + "/Zeta/A.kmp", 8);
    if (::symlink(root.c_str(), (root + "/loop").c_str()) != 0) fail("symlink");   // a link back to the top: must not be followed

    const InstrumentSearchOptions options{};
    std::size_t reports = 0U;
    const InstrumentSearchResult found = InstrumentFinder::search(root, options, nullptr,
        [&reports](std::size_t, std::size_t) { ++reports; });
    require(found.error.empty(), "search without error");
    require(!found.cutOff && !found.cancelled, "search runs to the end");
    require(found.files.size() == 5U, "five instrument files (.nki and .kmp only)");
    require(reports >= 1U, "progress is reported at the end");
    require(found.directories == 5U, "root, a, a/b, c, Zeta and nothing else (hidden folder and link skipped)");
    // sorted by folder (upper / lower case ignored), then by name
    require(found.files[0].folder.empty() && found.files[0].name == "top.nki", "top file first");
    require(found.files[1].folder == "a" && found.files[1].name == "Piano.NKI" && found.files[1].kontakt, "Piano.NKI in a");
    require(found.files[2].folder == "a/b" && found.files[2].name == "Strings.kmp" && !found.files[2].kontakt, "Strings.kmp in a/b");
    require(found.files[3].folder == "Zeta" && found.files[3].name == "A.kmp", "A.kmp before b.kmp");
    require(found.files[4].folder == "Zeta" && found.files[4].name == "b.kmp", "b.kmp after A.kmp");
    require(found.files[0].bytes == 10U && found.files[1].bytes == 20U && found.files[2].bytes == 30U, "file sizes");
    require(found.files[2].path == root + "/a/b/Strings.kmp", "full path");

    // a limit on the results
    InstrumentSearchOptions few;
    few.maxResults = 2U;
    const InstrumentSearchResult cut = InstrumentFinder::search(root, few, nullptr, InstrumentFinder::Progress());
    require(cut.cutOff && cut.files.size() == 2U, "result limit cuts the search");

    // a limit on the depth: a/b is two levels down
    InstrumentSearchOptions shallow;
    shallow.maxDepth = 1;
    const InstrumentSearchResult flat = InstrumentFinder::search(root, shallow, nullptr, InstrumentFinder::Progress());
    require(flat.cutOff, "depth limit is reported");
    bool deepSeen = false;
    for (const FoundInstrumentFile& f : flat.files) if (f.folder == "a/b") deepSeen = true;
    require(!deepSeen, "nothing below the depth limit");

    // cancelling
    std::atomic<bool> stop{true};
    const InstrumentSearchResult stopped = InstrumentFinder::search(root, options, &stop, InstrumentFinder::Progress());
    require(stopped.cancelled && stopped.files.empty(), "cancel stops before the first folder");

    // a folder that is not there
    const InstrumentSearchResult missing = InstrumentFinder::search(root + "/nope", options, nullptr, InstrumentFinder::Progress());
    require(!missing.error.empty() && missing.files.empty(), "missing folder gives an error");
    const InstrumentSearchResult notFolder = InstrumentFinder::search(root + "/top.nki", options, nullptr, InstrumentFinder::Progress());
    require(!notFolder.error.empty(), "a file is not a folder");

    // clean up what the test made
    const std::string clean = "rm -rf '" + root + "'";
    if (std::system(clean.c_str()) != 0) std::cerr << "note: could not remove " << root << '\n';

    std::cout << "SILVETON Manager instrument finder tests PASS\n";
    return 0;
}
