#pragma once
// SILVETON_THIN_V1 - decide which notes of a set of loose samples can be thrown away, because the sample next to
// them can be shifted by one semitone and play for them (a lower-memory bank). Used by the window that lays
// loose samples over the keyboard (AutoMapper); this file only DECIDES, it changes nothing.
//
// What it will not do:
//  - the lowest and the highest note always stay;
//  - a note with no clear pitch (noise, drums, effects) always stays and nothing is shifted across it;
//  - the notes next to a note that is different (no clear pitch, or another number of velocity layers) stay;
//  - notes that are already as far apart as the step (a set that was thinned before, or recorded every 3rd
//    note) are left alone: a sample never ends up covering more than 3 keys (2 keys for "every 2nd");
//  - samples of one note (velocity layers) are kept or dropped together.
// ThinMode::Decide also LISTENS: a note is dropped only when the neighbour that would play for it, shifted to
// its pitch, still sounds like it - same level, same brightness, same length of fade-out, same tuning.
// The limits for "sounds like it" are estimates (kLevelDb ... in KeyThinner.cpp) - to be tuned on real banks.

#include "silveton/manager/AutoMapper.h"
#include "silveton/manager/ManagerTypes.h"

#include <cstddef>
#include <cstdint>
#include <map>
#include <utility>
#include <vector>

namespace silveton::manager {

enum class ThinMode {
    EveryKey = 0,    // nothing is thrown away
    EveryTwo = 1,    // one sample for 2 keys
    EveryThree = 2,  // one sample for 3 keys
    Decide = 3       // up to 3 keys, but only where the neighbour really sounds the same
};

enum class ThinReason {
    KeepAll,           // mode EveryKey: every key keeps its own sample
    KeepEdge,          // the lowest or the highest note
    KeepUnclear,       // no clear pitch was heard
    KeepNextToOdd,     // the note beside it is different (no clear pitch / another number of layers)
    KeepSpread,        // the notes are already as far apart as the step allows
    KeepCovers,        // stays and plays for the neighbours that are dropped
    KeepDifferent,     // Decide: the neighbour sounds different (see ThinDifference)
    DropCovered,       // fixed step: the neighbour plays for it
    DropSimilar        // Decide: the shifted neighbour sounds the same
};

enum class ThinDifference {
    None,
    Level,       // loudness differs by more than about 3 dB
    Brightness,  // the sound is brighter / duller (harmonic balance)
    Decay,       // dies away faster or slower than a shift would give
    Tuning,      // the two are tuned differently (more than about 15 cents apart)
    Unknown      // too short or too quiet to be measured
};

struct ThinDecision {
    bool drop{false};
    ThinReason reason{ThinReason::KeepAll};
    ThinDifference difference{ThinDifference::None};
    int coveredBy{-1};   // for a dropped note: the MIDI note whose sample plays for it
};

struct ThinSummary {
    std::size_t notes{0U};              // different notes in the plan
    std::size_t notesDropped{0U};
    std::size_t notesSpread{0U};        // kept only because they are already as far apart as the step allows
    std::size_t notesUnclear{0U};
    std::size_t samples{0U};
    std::size_t samplesDropped{0U};
    std::uint64_t bytesAll{0U};         // audio bytes of all the samples in the plan
    std::uint64_t bytesDropped{0U};
};

// What one sample sounds like, as far as thinning is concerned.
struct ThinFeatures {
    bool valid{false};
    double levelDb{0.0};      // the loudest moment
    double brightness{0.0};   // where the spectrum is centred, in multiples of the note itself
    double decaySec{0.0};     // time to fall by 12 dB
    bool sustained{false};    // it never fell by 12 dB before the end: decaySec is only a lower limit
};

// Measured features, kept between looks at the same samples (the window asks again after every tick). Valid only
// while the samples of the project stay as they are. Key: sample index and the note it was heard as.
struct ThinMemory {
    std::map<std::pair<std::size_t, int>, ThinFeatures> features;
};

class KeyThinner final {
public:
    // One decision for every entry of the plan, in the same order. The entries must be the ones that will really
    // go into the blend (ticked ones). `plan` needs rootKey, cents, heard, confidence and peak (AutoMapper::listen
    // fills them); the audio comes from `project`.
    [[nodiscard]] static std::vector<ThinDecision> decide(const BankProject& project, const AutoMapPlan& plan, ThinMode mode,
                                                          ThinMemory* memory = nullptr);

    [[nodiscard]] static ThinSummary summarize(const BankProject& project, const AutoMapPlan& plan,
                                               const std::vector<ThinDecision>& decisions);
};

} // namespace silveton::manager
