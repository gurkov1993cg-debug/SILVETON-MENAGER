#pragma once

// SILVETON_ANALYZER_V2 - analyser like Voxengo SPAN:
// FFT 8192 + Hann, smoothing in octaves, slope in dB/oct (applied by the display), average + max.

#include "silveton/manager/ManagerTypes.h"

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <vector>

namespace silveton::manager {

struct SpectrumPower {
    std::uint32_t sampleRate{0U};
    std::vector<float> average;   // power per FFT bin (kFftSize/2 + 1)
    std::vector<float> maximum;   // highest power per FFT bin over the whole sample
    float peak{0.0F};             // sample peak 0..1
    float rms{0.0F};              // whole sample RMS 0..1
    [[nodiscard]] bool empty() const noexcept { return average.empty(); }
};

class SpectrumAnalyzer final {
public:
    static constexpr std::size_t kPoints = 512U;     // log spaced 20 Hz ... 20 kHz
    static constexpr std::size_t kFftSize = 8192U;
    static constexpr float kFloorDb = -160.0F;

    static double pointHz(std::size_t point) noexcept;

    // Mono mix of the sample, -1..+1.
    static std::vector<float> monoMix(const ImportedSample& sample);

    // Power per FFT bin of the block that ends at `frame` (live display).
    static std::vector<float> powerAt(const std::vector<float>& mono, std::uint64_t frame);

    // Average + maximum power per FFT bin over the whole sample.
    static SpectrumPower analyse(const ImportedSample& sample);

    // Bins -> kPoints dB values. smoothOctaves = width of the smoothing (1/3, 1/6, 1/12 ...).
    // Energy per smoothing band: a full scale sine shows 0 dB. Display tilt = (slope - 3) dB/oct.
    static std::vector<float> toCurve(const std::vector<float>& binPower, std::uint32_t sampleRate, double smoothOctaves);

    // analyse() for many samples on several threads; progress 0..1 only from the calling thread.
    static std::vector<SpectrumPower> analyseMany(const BankProject& project,
                                                  const std::vector<std::size_t>& indexes,
                                                  const std::function<void(double)>& progress,
                                                  const std::atomic<bool>* cancel);
};

} // namespace silveton::manager
