#pragma once

#include "silveton/manager/ManagerTypes.h"

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace silveton::manager {

// SILVETON_CLEANWAVE_V1 - write a rough sample out again as a clean, rounded wave.
//
// Nothing is invented: the note, the overtones and the loudness are all measured from the sample itself,
// only the writing is clean. The steps are
//   1. find the note at every moment (FFT -> the band the note lives in -> lock on and read the leftover turn),
//   2. average every cycle with its neighbours, which cancels what does not repeat (noise, a chipped edge),
//   3. measure how strong each overtone is against that note and write the wave from those overtones,
//   4. pull the note and the loudness towards one clean falling curve by `edges`,
//   5. mix the result with the original by `amount` (one value per point along the sample).
struct WaveCleanOptions {
    std::vector<float> amount;      // 0 = leave as it is, 1 = fully clean; points spread over the whole sample
    int overtones{1};               // 1 = a plain round wave, more = more of the sample's own colour (1...12)
    float edges{1.0F};              // 0 = the note and the loudness stay as measured, 1 = one clean curve
};

class WaveSmoother final {
public:
    static bool clean(ImportedSample& sample, const WaveCleanOptions& options, std::string& error);

    // The same work without touching the sample: `out` gets one channel-mixed copy of the result, for drawing.
    static bool preview(const ImportedSample& sample, const WaveCleanOptions& options,
                        std::vector<float>& out, std::string& error);

    // The note the sample is on, at evenly spaced points (Hz). Empty when there is no clear note.
    static std::vector<float> noteTrack(const ImportedSample& sample, std::size_t points);

    static constexpr int kMaxOvertones = 12;
};

} // namespace silveton::manager
