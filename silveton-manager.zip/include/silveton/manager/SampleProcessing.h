#pragma once

// SILVETON_PROCESSING_V1
// Optional sample processing. Nothing here runs by itself: the user switches
// every function ON or OFF and presses START.

#include "silveton/manager/ManagerTypes.h"

#include <atomic>
#include <cstddef>
#include <functional>
#include <string>
#include <vector>

namespace silveton::manager {

struct SampleProcessingOptions {
    bool convertTo48k{false};          // samples that are not 48 kHz -> 48 kHz
    bool evenTone{false};              // same tone colour from low to high keys
    double maxToneCorrectionDb{6.0};   // limit for the tone correction
    bool normalize{false};             // equal loudness
    double normalizeDb{-6.0};          // peak target in dBFS
    bool normalizePerInstrument{false};// false = every sample alone, true = one gain per instrument
    bool softLimiter{false};           // rounded limiter: evens the peaks of the tones in every KMP
    double maxLimitDb{3.0};            // the limiter never takes more than this off a peak
    // SILVETON_EVEN_DECAY_V1: the room echo recorded in the samples dies away in the same time in every
    // frequency band. Only real decays are touched (a fall that does not come back): a held tone, beating
    // (musette) and the loop stay as they are. A band that already dies away faster stays as it is.
    bool evenDecay{false};
    double decayMs{300.0};             // the time to die away (-60 dB), 30...10000 ms
    unsigned threads{0U};              // 0 = all CPU cores
};

struct SampleProcessingReport {
    std::size_t converted{0U};
    std::size_t toneAdjusted{0U};
    std::size_t normalized{0U};
    std::size_t limited{0U};
    std::size_t decayShaped{0U};       // SILVETON_EVEN_DECAY_V1
    std::size_t skipped{0U};
    bool cancelled{false};
};

// fraction 0..1 and a short stage text. Called only from the thread that calls process().
using SampleProcessingProgress = std::function<void(double fraction, const std::string& stage)>;

class SampleProcessor final {
public:
    // Works on copies. The bank is changed only when everything finished
    // (cancel = bank stays exactly as it was).
    // onlySamples: indexes into project.samples; empty = all samples.
    static bool process(BankProject& project,
                        const std::vector<std::size_t>& onlySamples,
                        const SampleProcessingOptions& options,
                        const SampleProcessingProgress& progress,
                        const std::atomic<bool>* cancel,
                        SampleProcessingReport& report,
                        std::string& error);
};

} // namespace silveton::manager
