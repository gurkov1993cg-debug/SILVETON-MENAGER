#pragma once
// SILVETON_FIND_V1: search a folder AND all its sub-folders for the instrument files the Manager reads:
// Kontakt .nki and Korg .kmp. Nothing else is listed (the samples of a .nki / the .ksf of a .kmp are taken
// from beside the instrument file by the importers). Hidden entries and links are not followed.
// POSIX only (opendir / lstat) on purpose: std::filesystem is not available for macOS 10.13.

#include <atomic>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <string>
#include <vector>

namespace silveton::manager {

struct FoundInstrumentFile {
    std::string path;       // full path of the file
    std::string folder;     // folder of the file relative to the searched folder, '/' between names ("" = the folder itself)
    std::string name;       // file name with its extension
    bool kontakt{false};    // true = .nki, false = .kmp
    std::uint64_t bytes{0}; // size of the file itself (not of its samples)
};

struct InstrumentSearchOptions {
    std::size_t maxResults{20000U};
    std::size_t maxDirectories{300000U};
    int maxDepth{40};
};

struct InstrumentSearchResult {
    std::vector<FoundInstrumentFile> files;   // sorted by folder, then by name (upper / lower case ignored)
    std::size_t directories{0U};              // folders looked into
    bool cutOff{false};                       // a limit of InstrumentSearchOptions stopped the search
    bool cancelled{false};                    // the cancel flag was raised
    std::string error;                        // not empty = the folder could not be searched at all
};

class InstrumentFinder final {
public:
    // progress(directories, found) is called now and then from the searching thread and once at the end.
    using Progress = std::function<void(std::size_t directories, std::size_t found)>;

    [[nodiscard]] static InstrumentSearchResult search(const std::string& root,
                                                       const InstrumentSearchOptions& options,
                                                       const std::atomic<bool>* cancel,
                                                       const Progress& progress);
};

} // namespace silveton::manager
