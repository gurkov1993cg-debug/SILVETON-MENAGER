#pragma once
// SILVETON_KONTAKT_V1 - import of Native Instruments Kontakt instruments (.nki, Kontakt 5+ container,
// not encrypted) with their samples (.ncw inside .nkx monoliths or loose .ncw/.wav files).
// One Kontakt group = one instrument = one SILVETON SOUND with up to 5 velocity layers
// (the basic sound + L1..L4 of an Upper): soft, medium, stronger, strong and the top hit.

#include "silveton/manager/ManagerTypes.h"

#include <cstddef>
#include <cstdint>
#include <functional>
#include <string>
#include <utility>
#include <vector>

namespace silveton::manager {

struct KontaktLoop {
    std::uint32_t start{0};
    std::uint32_t length{0};
    std::uint32_t count{0};          // 0 = endless
    std::uint32_t crossfade{0};
};

struct KontaktZone {
    std::uint32_t groupIndex{0};
    std::uint8_t keyLow{0};
    std::uint8_t keyHigh{127};
    std::uint8_t velocityLow{1};
    std::uint8_t velocityHigh{127};
    std::uint8_t rootKey{60};
    float volumeGain{1.0F};          // linear, 1.0 = 0 dB
    float pan{0.0F};                 // -1..1
    float tuneCents{0.0F};
    std::uint32_t fileIndex{0};
    std::uint32_t numFrames{0};
    std::uint16_t channels{0};
    std::uint32_t sampleRateTag{0};  // as written in the .nki (may be wrong, see probeSampleRate)
    bool hasLoop{false};
    KontaktLoop loop{};
};

struct KontaktGroup {
    std::string name;
    float volumeGain{1.0F};
    float pan{0.0F};
    float tuneCents{0.0F};
    // amp envelope as Kontakt stores it (milliseconds, sustain 0..1); only valid when hasEnvelope
    bool hasEnvelope{false};
    float attackMs{0.0F};
    float holdMs{0.0F};
    float decayMs{0.0F};
    float releaseMs{0.0F};
    float sustain{1.0F};
    // velocity -> volume: gain(v) = 1 - intensity * (1 - curve(v / 127))
    bool hasVelocityToVolume{false};
    float velocityIntensity{1.0F};
    std::vector<std::pair<float, float>> velocityCurve;   // (x, y) points 0..1, empty = straight line
    std::vector<std::uint32_t> zoneIndices;
};

struct KontaktFile {
    std::string relativePath;   // folders + file name, '/' separated, relative to the .nki folder
    std::string monolith;       // relative path of the .nkx that holds the file, empty = loose file
    std::string name;           // file name only
};

struct KontaktLibrary {
    std::string nkiPath;
    std::string directory;
    std::string programName;
    std::vector<KontaktGroup> groups;
    std::vector<KontaktZone> zones;
    std::vector<KontaktFile> files;
    std::string error;
    std::vector<std::string> warnings;
    [[nodiscard]] bool ok() const noexcept { return error.empty(); }
};

struct KontaktImportOptions {
    int maxVelocityLayers{5};
    std::uint32_t sampleRate{0};   // 0 = as in the sample files
    int keyStep{1};                // 1 = every key as in Kontakt; 2 / 3 = one sample covers 2 / 3 neighbouring keys (less memory)
    bool dryRun{false};            // layout only, no audio is decoded (silent samples)
};

struct KontaktImportResult {
    std::vector<ImportedSample> samples;
    std::vector<ImportedMultisample> multisamples;   // soft -> strong; zone.sampleIndex is relative to samples
    SoundDefinition sound;                           // layer.multisampleIndex is relative to multisamples
    std::string error;
    std::vector<std::string> warnings;
    [[nodiscard]] bool ok() const noexcept { return error.empty() && !multisamples.empty(); }
};

// Reports progress 0..1; return false to stop.
using KontaktProgress = std::function<bool(double fraction, const std::string& text)>;

class KontaktImporter {
public:
    [[nodiscard]] static KontaktLibrary open(const std::string& nkiPath);

    [[nodiscard]] static KontaktImportResult importGroup(const KontaktLibrary& library,
                                                         std::size_t groupIndex,
                                                         const KontaktImportOptions& options,
                                                         const KontaktProgress& progress);

    // Decodes a few pitched zones of the group and checks their pitch against the root key for the
    // common rates. Returns the rate that fits (0 = could not tell). `tagged` = the rate written in the files.
    [[nodiscard]] static std::uint32_t probeSampleRate(const KontaktLibrary& library, std::size_t groupIndex,
                                                       std::uint32_t& tagged, std::string& note);

    // Picks which velocity layers of one key survive when there are more than `maxLayers`:
    // the softest, evenly spread middle ones and always the top (strongest) one.
    [[nodiscard]] static std::vector<std::size_t> chooseVelocityLayers(std::size_t layerCount, int maxLayers);

    // Native Instruments FastLZ-style decompression used by Kontakt 5+ files.
    [[nodiscard]] static bool fastLzDecompress(const std::uint8_t* src, std::size_t size, std::size_t expected,
                                               std::vector<std::uint8_t>& out);

    // NCW (Kontakt lossless) decoder -> PCM. bitsPerSample is 16 or 24, pcm is little-endian packed.
    [[nodiscard]] static bool decodeNcw(const std::uint8_t* data, std::size_t size, std::uint32_t& sampleRate,
                                        std::uint16_t& channels, std::uint8_t& bitsPerSample, std::uint32_t& frames,
                                        std::vector<std::uint8_t>& pcm, std::string& error);
};

} // namespace silveton::manager
