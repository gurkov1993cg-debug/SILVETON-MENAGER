#pragma once
// SILVETON_KONTAKT_V1 - import of Native Instruments Kontakt instruments (.nki, Kontakt 5+ container, and since
// SILVETON_KONTAKT_OLD_V1 also the older Kontakt 2-4 files that start with 0x7FA89012; not encrypted) with their samples (.ncw inside .nkx monoliths or loose .ncw/.wav files).
// One Kontakt group = one instrument = one SILVETON SOUND with up to 5 velocity layers
// (the basic sound + L1..L4 of an Upper): soft, medium, stronger, strong and the top hit.

#include "silveton/manager/ManagerTypes.h"

#include <cstddef>
#include <cstdint>
#include <functional>
#include <string>
#include <utility>
#include <vector>

namespace silveton::manager {

struct KontaktLoop {
    std::uint32_t start{0};
    std::uint32_t length{0};
    std::uint32_t count{0};          // 0 = endless
    std::uint32_t crossfade{0};
};

struct KontaktZone {
    std::uint32_t groupIndex{0};
    std::uint8_t keyLow{0};
    std::uint8_t keyHigh{127};
    std::uint8_t velocityLow{1};
    std::uint8_t velocityHigh{127};
    std::uint8_t rootKey{60};
    float volumeGain{1.0F};          // linear, 1.0 = 0 dB
    float pan{0.0F};                 // -1..1
    float tuneCents{0.0F};
    std::uint32_t fileIndex{0};
    std::uint32_t numFrames{0};
    std::uint16_t channels{0};
    std::uint32_t sampleRateTag{0};  // as written in the .nki (may be wrong, see probeSampleRate)
    bool hasLoop{false};
    KontaktLoop loop{};
};

struct KontaktGroup {
    std::string name;
    float volumeGain{1.0F};
    float pan{0.0F};
    float tuneCents{0.0F};
    // amp envelope as Kontakt stores it (milliseconds, sustain 0..1); only valid when hasEnvelope
    bool hasEnvelope{false};
    float attackMs{0.0F};
    float holdMs{0.0F};
    float decayMs{0.0F};
    float releaseMs{0.0F};
    float sustain{1.0F};
    // velocity -> volume: gain(v) = 1 - intensity * (1 - curve(v / 127))
    bool hasVelocityToVolume{false};
    float velocityIntensity{1.0F};
    std::vector<std::pair<float, float>> velocityCurve;   // (x, y) points 0..1, empty = straight line
    std::vector<std::uint32_t> zoneIndices;
};

struct KontaktFile {
    std::string relativePath;   // folders + file name, '/' separated, relative to the .nki folder
    std::string monolith;       // relative path of the .nkx that holds the file, empty = loose file
    std::string name;           // file name only
};

struct KontaktLibrary {
    std::string nkiPath;
    std::string directory;
    std::string programName;
    std::vector<KontaktGroup> groups;
    std::vector<KontaktZone> zones;
    std::vector<KontaktFile> files;
    std::string error;
    std::vector<std::string> warnings;
    [[nodiscard]] bool ok() const noexcept { return error.empty(); }
};

struct KontaktImportOptions {
    int maxVelocityLayers{5};
    std::uint32_t sampleRate{0};   // 0 = as in the sample files
    int keyStep{1};                // 1 = every key as in Kontakt; 2 / 3 = one sample covers 2 / 3 neighbouring keys (less memory)
    bool dryRun{false};            // layout only, no audio is decoded (silent samples)
};

struct KontaktImportResult {
    std::vector<ImportedSample> samples;
    std::vector<ImportedMultisample> multisamples;   // soft -> strong; zone.sampleIndex is relative to samples
    SoundDefinition sound;                           // layer.multisampleIndex is relative to multisamples
    std::size_t sourceLayers{0};                     // most velocity layers one key had in Kontakt (before the choice of 5)
    std::string error;
    std::vector<std::string> warnings;
    [[nodiscard]] bool ok() const noexcept { return error.empty() && !multisamples.empty(); }
};

// What the importer offers as ONE ready instrument. A plain Kontakt group is one set. Instruments that are
// split per string (a bass: groups "B_sus_1", "E_sus_1", "A_sus_1" ...) give one set per playing technique that
// holds all its strings, so the whole keyboard comes in as one SOUND.
struct KontaktInstrumentSet {
    std::string name;                    // "sus 1" - or the group name for a plain group
    std::string soundName;               // name of the SOUND that is made
    std::vector<std::size_t> groups;     // preferred first: on a key reached by several strings the first one wins
    std::string strings;                 // "B E A D G" (low to high, separated by spaces) when the set merges strings, else empty
    std::uint8_t keyLow{127};
    std::uint8_t keyHigh{0};
    std::size_t zoneCount{0};
    [[nodiscard]] bool merged() const noexcept { return groups.size() > 1U; }
};

// SILVETON_KONTAKT_LISTEN_V1: listening only. One entry per sample (zone) of an instrument, nothing is decoded for the list.
struct KontaktListenItem {
    std::uint32_t zoneIndex{0};      // index into KontaktLibrary::zones
    std::uint8_t keyLow{0};
    std::uint8_t keyHigh{127};
    std::uint8_t rootKey{60};
    std::uint8_t velocityLow{1};
    std::uint8_t velocityHigh{127};
    std::uint32_t frames{0};
    std::uint32_t sampleRateTag{0};
    std::uint16_t channels{0};
    std::string group;               // the Kontakt group (a string of a bass) the sample belongs to
};

// One sample decoded for listening: little-endian packed PCM, 16 or 24 bit.
struct KontaktListenAudio {
    std::uint32_t sampleRate{0};
    std::uint16_t channels{0};
    std::uint8_t bitsPerSample{16};
    std::uint32_t frames{0};
    std::vector<std::uint8_t> pcm;
};

// Reports progress 0..1; return false to stop.
using KontaktProgress = std::function<bool(double fraction, const std::string& text)>;

class KontaktImporter {
public:
    [[nodiscard]] static KontaktLibrary open(const std::string& nkiPath);

    [[nodiscard]] static KontaktImportResult importGroup(const KontaktLibrary& library,
                                                         std::size_t groupIndex,
                                                         const KontaktImportOptions& options,
                                                         const KontaktProgress& progress);

    // Several groups (the strings of one playing technique) as ONE SOUND. `groups` is in order of preference:
    // a key that more than one group reaches is played by the first group that has it, never by two.
    // soundName empty = taken from the first group.
    [[nodiscard]] static KontaktImportResult importGroups(const KontaktLibrary& library,
                                                          const std::vector<std::size_t>& groups,
                                                          const std::string& soundName,
                                                          const KontaktImportOptions& options,
                                                          const KontaktProgress& progress);

    [[nodiscard]] static KontaktImportResult importSet(const KontaktLibrary& library,
                                                       const KontaktInstrumentSet& set,
                                                       const KontaktImportOptions& options,
                                                       const KontaktProgress& progress);

    // The list the user picks from. Groups that only differ by the string letter in front of the name
    // (B_ E_ A_ D_ G_ ... or E6_ A_ D_ G_ H_ E1_ on a guitar) are merged per technique; the highest string is preferred (first position).
    [[nodiscard]] static std::vector<KontaktInstrumentSet> instrumentSets(const KontaktLibrary& library);

    // Decodes a few pitched zones of the group and checks their pitch against the root key for the
    // common rates. Returns the rate that fits (0 = could not tell). `tagged` = the rate written in the files.
    [[nodiscard]] static std::uint32_t probeSampleRate(const KontaktLibrary& library, std::size_t groupIndex,
                                                       std::uint32_t& tagged, std::string& note);

    // Picks which velocity layers of one key survive when there are more than `maxLayers`:
    // the softest, evenly spread middle ones and always the top (strongest) one.
    [[nodiscard]] static std::vector<std::size_t> chooseVelocityLayers(std::size_t layerCount, int maxLayers);

    // SILVETON_KONTAKT_LISTEN_V1: the samples of one instrument in key order (then soft to strong), for the listening window.
    [[nodiscard]] static std::vector<KontaktListenItem> listenItems(const KontaktLibrary& library, const KontaktInstrumentSet& set);

    // Decodes ONE sample of the library for listening. The opened files are kept between calls (listening to the next
    // sample must not open the big sample file again); the cache follows the library that is asked for.
    [[nodiscard]] static bool loadListenAudio(const KontaktLibrary& library, std::uint32_t zoneIndex, KontaktListenAudio& out, std::string& error);

    // Native Instruments FastLZ-style decompression used by Kontakt 5+ files.
    [[nodiscard]] static bool fastLzDecompress(const std::uint8_t* src, std::size_t size, std::size_t expected,
                                               std::vector<std::uint8_t>& out);

    // NCW (Kontakt lossless) decoder -> PCM. bitsPerSample is 16 or 24, pcm is little-endian packed.
    [[nodiscard]] static bool decodeNcw(const std::uint8_t* data, std::size_t size, std::uint32_t& sampleRate,
                                        std::uint16_t& channels, std::uint8_t& bitsPerSample, std::uint32_t& frames,
                                        std::vector<std::uint8_t>& pcm, std::string& error);
};

} // namespace silveton::manager
