#pragma once

#include "silveton/manager/ManagerTypes.h"

#include <cstdint>
#include <functional>
#include <string>
#include <vector>

namespace silveton::manager {

struct SvBuildStats {
    std::uint32_t soundCount{0};
    std::uint32_t multisampleCount{0};
    std::uint32_t sampleCount{0};
    std::uint32_t zoneCount{0};
    std::uint32_t uniqueAudioPayloadCount{0};
    std::uint64_t audioBytesBeforeDedup{0};
    std::uint64_t audioBytesAfterDedup{0};
};

struct SvBuildResult {
    std::vector<std::uint8_t> bytes;
    SvBuildStats stats{};
    std::string error;
    [[nodiscard]] bool ok() const noexcept { return error.empty() && !bytes.empty(); }
};

// Progress 0..1 with a short text; return false to stop (the file is then left untouched).
using SvBuildProgress = std::function<bool(double fraction, const std::string& text)>;

class SvBankBuilder {
public:
    // Whole bank in memory (tests, small banks).
    [[nodiscard]] static SvBuildResult build(const BankProject& project);
    // Streams the bank to <path>.tmp straight from the project (no copies of the audio in memory),
    // verifies what landed on disk by reading it back, then renames it over <path>.
    [[nodiscard]] static bool writeAtomic(const std::string& path, const BankProject& project, SvBuildStats& stats, std::string& error,
                                          const SvBuildProgress& progress = nullptr);
};

} // namespace silveton::manager
