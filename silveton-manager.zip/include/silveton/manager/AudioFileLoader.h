#pragma once

#include "silveton/manager/ManagerTypes.h"

#include <string>

namespace silveton::manager {

struct AudioLoadResult {
    ImportedSample sample{};
    std::string error;
    [[nodiscard]] bool ok() const noexcept { return error.empty() && sample.valid(); }
};

class AudioFileLoader {
public:
    [[nodiscard]] static AudioLoadResult load(const std::string& path);
    [[nodiscard]] static AudioLoadResult loadWav(const std::string& path);
    [[nodiscard]] static AudioLoadResult loadAiff(const std::string& path);
    // SILVETON_NCW_V1: a loose Kontakt .ncw file (the same decoder that reads the samples of a .nki)
    [[nodiscard]] static AudioLoadResult loadNcw(const std::string& path);
};

} // namespace silveton::manager
