#pragma once

#include "silveton/manager/ManagerTypes.h"

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace silveton::manager {

struct WaveformPoint {
    float minimum{0.0F};
    float maximum{0.0F};
};

struct SampleRegion {
    std::uint32_t sampleRate{0U};
    std::uint16_t channels{0U};
    AudioEncoding encoding{AudioEncoding::Pcm16LE};
    std::uint8_t bitsPerSample{0U};
    std::uint64_t frameCount{0U};
    std::vector<std::uint8_t> audioData;

    [[nodiscard]] bool empty() const noexcept { return frameCount == 0U || audioData.empty(); }
};

class SampleEditor final {
public:
    static bool trim(ImportedSample& sample,
                     std::uint64_t startFrame,
                     std::uint64_t endFrame,
                     std::string& error);

    // SILVETON_CUT_V1: the opposite of trim - the part [startFrame, endFrame) is thrown away and what is
    // before it is joined to what is after it. A loop inside the removed part is switched off; a loop after
    // it moves back with the audio.
    // SILVETON_ATTACK_V1: where the sound really starts. `hasLateStart` is true when there is quiet or hiss in
    // front of the hit; `startFrame` is where to cut so the sample begins at the hit (already backed off a
    // little and moved to the nearest zero crossing, so cutting there cannot click).
    struct AttackPoint {
        bool found{false};
        bool hasLateStart{false};
        std::uint64_t startFrame{0U};
        double leadInSeconds{0.0};
        double riseSeconds{0.0};
    };
    [[nodiscard]] static AttackPoint findAttack(const ImportedSample& sample) noexcept;

    static bool cutOut(ImportedSample& sample,
                       std::uint64_t startFrame,
                       std::uint64_t endFrame,
                       std::string& error);

    // SILVETON_PITCHCURVE_V1: how the note moves while the sample plays.
    // `curve` holds semitones (+ up, - down) at evenly spaced points over the WHOLE sample: the first point is
    // the beginning, the last the end, straight lines in between. 0 everywhere = nothing changes.
    // shapeCurve turns a hand-drawn curve into a mathematically exact, smooth one: amount 0 leaves it exactly as
    // drawn, 1 gives the clean curve (c + a * e^(-t/T), fitted to the drawing), in between is a mix of the two.
    static void shapeCurve(std::vector<float>& curve, float amount) noexcept;

    // Writes the curve into the audio: the sample is read faster where the curve is high and slower where it is
    // low, so its length changes too. A loop moves with the audio; a loop is switched off when it cannot follow.
    static bool applyPitchCurve(ImportedSample& sample,
                                const std::vector<float>& curve,
                                std::string& error);

    static constexpr float kPitchCurveLimitSemitones = 24.0F;

    static bool setLoop(ImportedSample& sample,
                        bool enabled,
                        std::uint64_t startFrame,
                        std::uint64_t endFrame,
                        std::uint32_t crossfadeFrames,
                        std::string& error);

    static bool applyLoopCrossfade(ImportedSample& sample,
                                   std::uint32_t crossfadeFrames,
                                   std::string& error);

    static bool reverse(ImportedSample& sample, std::string& error);

    static bool applyGainDb(ImportedSample& sample,
                            float gainDb,
                            std::string& error);

    static bool normalize(ImportedSample& sample,
                          float targetPeakDb,
                          std::string& error);

    static bool fadeIn(ImportedSample& sample,
                       std::uint64_t fadeFrames,
                       std::string& error);

    static bool fadeOut(ImportedSample& sample,
                        std::uint64_t fadeFrames,
                        std::string& error);

    static bool copyRegion(const ImportedSample& sample,
                           std::uint64_t startFrame,
                           std::uint64_t endFrame,
                           SampleRegion& region,
                           std::string& error);

    static bool deleteRegion(ImportedSample& sample,
                             std::uint64_t startFrame,
                             std::uint64_t endFrame,
                             std::string& error);

    static bool silenceRegion(ImportedSample& sample,
                              std::uint64_t startFrame,
                              std::uint64_t endFrame,
                              std::string& error);

    static bool insertRegion(ImportedSample& sample,
                             std::uint64_t atFrame,
                             const SampleRegion& region,
                             std::string& error);

    static bool reverseRegion(ImportedSample& sample,
                              std::uint64_t startFrame,
                              std::uint64_t endFrame,
                              std::string& error);

    static bool applyGainDbRegion(ImportedSample& sample,
                                  std::uint64_t startFrame,
                                  std::uint64_t endFrame,
                                  float gainDb,
                                  std::string& error);

    static bool normalizeRegion(ImportedSample& sample,
                                std::uint64_t startFrame,
                                std::uint64_t endFrame,
                                float targetPeakDb,
                                std::string& error);

    static bool fadeInRegion(ImportedSample& sample,
                             std::uint64_t startFrame,
                             std::uint64_t endFrame,
                             std::string& error);

    static bool fadeOutRegion(ImportedSample& sample,
                              std::uint64_t startFrame,
                              std::uint64_t endFrame,
                              std::string& error);

    static bool setRootKey(ImportedSample& sample,
                           std::uint8_t rootKey,
                           std::string& error) noexcept;

    static bool setFineTuneCents(ImportedSample& sample,
                                 float cents,
                                 std::string& error) noexcept;

    [[nodiscard]] static float peakLinear(const ImportedSample& sample) noexcept;

    [[nodiscard]] static std::uint64_t nearestZeroCrossing(const ImportedSample& sample,
                                                           std::uint64_t frame,
                                                           std::uint64_t searchRadiusFrames) noexcept;

    static bool buildWaveform(const ImportedSample& sample,
                              std::size_t pointCount,
                              std::vector<WaveformPoint>& points,
                              std::string& error);

    // SILVETON_ZOOM_V1: the same picture, but only for frames [startFrame, endFrame).
    // pointCount is the number of columns on screen; when the range has fewer frames than
    // columns, one point per frame is returned (so a deep zoom shows the real samples).
    // SILVETON_PITCHCURVE_V1: the picture the sample WOULD have with this curve, without changing anything.
    // startFrame/endFrame are positions in the sample as it is now; outFrames is how long that part becomes.
    static bool buildWaveformWithCurve(const ImportedSample& sample,
                                       const std::vector<float>& curve,
                                       std::uint64_t startFrame,
                                       std::uint64_t endFrame,
                                       std::size_t pointCount,
                                       std::vector<WaveformPoint>& points,
                                       std::uint64_t& outFrames,
                                       std::string& error);

    static bool buildWaveformRange(const ImportedSample& sample,
                                   std::uint64_t startFrame,
                                   std::uint64_t endFrame,
                                   std::size_t pointCount,
                                   std::vector<WaveformPoint>& points,
                                   std::string& error);
};

} // namespace silveton::manager
