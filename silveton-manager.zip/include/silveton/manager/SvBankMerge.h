#pragma once
// SILVETON_SEND_V1 - joins SILVETON_BANK.sv files without reading their audio into memory.
// The Manager sends sounds to the sampler as small bank files; at the end the sampler's bank and those files become one bank
// (the bank for the tablet). The audio is copied piece by piece, so a bank of many gigabytes needs only a little memory.

#include <cstdint>
#include <functional>
#include <set>
#include <string>
#include <vector>

namespace silveton::manager {

struct SvMergeStats {
    std::uint32_t soundCount{0U};
    std::uint32_t sampleCount{0U};
    std::uint64_t audioBytes{0U};
};

using SvMergeProgress = std::function<bool(double fraction, const std::string& text)>;   // false = stop

class SvBankMerge {
public:
    // Writes `outPath` (a temporary file first, then renamed over it) with the SOUNDs of `basePath` (empty or missing = none) and
    // of every file in `addPaths`, in this order: a SOUND of a later file replaces the one at the same place (1..500).
    // SOUNDs at the places in `leaveOut` are not written. Multisamples and samples that no written SOUND uses are left out.
    // `bankName` empty = the name of the first file that has one.
    static bool merge(const std::string& basePath, const std::vector<std::string>& addPaths, const std::set<int>& leaveOut,
                      const std::string& outPath, const std::string& bankName, SvMergeStats& stats, std::string& error,
                      const SvMergeProgress& progress = {});

    // The places (1..500) and names of the SOUNDs of a bank file (only the small records are read).
    static bool soundList(const std::string& path, std::vector<std::pair<int, std::string>>& sounds, std::string& error);
};

} // namespace silveton::manager
