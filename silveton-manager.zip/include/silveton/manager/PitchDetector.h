#pragma once
// SILVETON_PITCH_V1 - tells which note (and octave) a recording is, from the audio itself.

#include "silveton/manager/ManagerTypes.h"

#include <cstddef>
#include <string>

namespace silveton::manager {

struct PitchResult {
    bool found{false};
    double hz{0.0};
    int midi{60};          // nearest MIDI note
    float cents{0.0F};     // how far the recording sits from that note (-50..50)
    float confidence{0.0F};// 0..1, below ~0.5 the note is a guess
    [[nodiscard]] std::string noteName() const;   // "A0", "C#4" ...
};

class PitchDetector {
public:
    [[nodiscard]] static PitchResult detect(const ImportedSample& sample);
    // mono float signal, any rate
    [[nodiscard]] static PitchResult detect(const float* mono, std::size_t frames, double sampleRate);
    [[nodiscard]] static std::string noteName(int midi);
};

} // namespace silveton::manager
