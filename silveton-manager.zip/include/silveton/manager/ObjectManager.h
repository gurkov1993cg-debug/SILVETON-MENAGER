#pragma once

#include "silveton/manager/ManagerTypes.h"

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace silveton::manager {

struct DeleteImpact {
    std::size_t samplesRemoved{0U};
    std::size_t zonesRemoved{0U};
    std::size_t multisamplesRemoved{0U};
    std::size_t layersRemoved{0U};
    std::size_t soundsRemoved{0U};
};

class ObjectManager final {
public:
    static bool renameSample(BankProject& project, std::size_t sampleIndex, const std::string& name, std::string& error);
    static bool duplicateSample(BankProject& project, std::size_t sampleIndex, std::size_t& createdIndex, std::string& error);
    static bool deleteSampleCascade(BankProject& project, std::size_t sampleIndex, DeleteImpact& impact, std::string& error);

    static bool renameMultisample(BankProject& project, std::size_t multisampleIndex, const std::string& name, std::string& error);
    static bool duplicateMultisample(BankProject& project, std::size_t multisampleIndex, std::size_t& createdIndex, std::string& error);
    static bool deleteMultisampleCascade(BankProject& project, std::size_t multisampleIndex, DeleteImpact& impact, std::string& error);

    static bool renameSound(BankProject& project, std::size_t soundIndex, const std::string& name, std::string& error);
    static bool createSoundFromMultisample(BankProject& project, std::size_t multisampleIndex, const std::string& name, std::size_t& createdIndex, std::string& error);
    static bool duplicateSound(BankProject& project, std::size_t soundIndex, std::size_t& createdIndex, std::string& error);
    static bool deleteSound(BankProject& project, std::size_t soundIndex, DeleteImpact& impact, std::string& error);

    // SILVETON_DELETE_BLEND_V1: delete a SOUND (a blend) together with everything that only it uses:
    // its layers' multisamples and the samples inside them. Anything also used by another SOUND
    // (or by a multisample outside this SOUND) is kept. Indexes of everything that stays are remapped.
    // soundContent() tells in advance what would go (same rule), without changing anything.
    static bool soundContent(const BankProject& project, std::size_t soundIndex, DeleteImpact& impact, std::string& error);
    static bool deleteSoundWithContent(BankProject& project, std::size_t soundIndex, DeleteImpact& impact, std::string& error);

private:
    static bool planSoundContent(const BankProject& project, std::size_t soundIndex,
                                 std::vector<std::size_t>& multisamples, std::vector<std::size_t>& samples,
                                 DeleteImpact& impact, std::string& error);
    static bool validName(const std::string& name) noexcept;
    static std::string uniqueName(const std::string& base, const BankProject& project, int kind);
    static bool assignNextFreeSoundAddress(BankProject& project, SoundDefinition& sound, std::string& error);
    static bool assignNextFreeSoundPosition(BankProject& project, SoundDefinition& sound, std::string& error);
};

} // namespace silveton::manager
