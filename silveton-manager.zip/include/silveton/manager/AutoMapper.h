#pragma once

#include "silveton/manager/ManagerTypes.h"

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace silveton::manager {

// SILVETON_AUTOMAP_V1 - make a playable blend out of loose samples, with no KMP and no mapping file.
// Every sample is listened to: which note it is and in which octave. The notes are then laid out over the
// keyboard, each sample holding the keys up to halfway towards its neighbours. Samples that turn out to be the
// same note become velocity layers, quietest first.
struct AutoMapEntry {
    std::size_t sampleIndex{0U};
    std::string name;
    int rootKey{60};            // the note that was heard (or typed in by hand later)
    float confidence{0.0F};     // 0...1; under 0.5 the note is a guess worth looking at
    float peak{0.0F};           // how loud the sample is, used to order the velocity layers
    int keyLow{0};
    int keyHigh{127};
    int velocityLow{1};
    int velocityHigh{127};
    int layer{0};               // which velocity layer this sample ends up in
    bool heard{false};          // false when no clear note came out of the audio
};

struct AutoMapPlan {
    std::vector<AutoMapEntry> entries;
    int layers{1};
};

class AutoMapper final {
public:
    // "C4", "a#3", "Bb2" or plain "60" -> the MIDI note; -1 when it is not a note at all
    static int noteFromText(const std::string& text) noexcept;

    // listen to every sample and work out the note; nothing is changed
    static AutoMapPlan listen(const BankProject& project, const std::vector<std::size_t>& sampleIndexes);

    // lay the entries over the keyboard again (after a note was corrected by hand)
    static void arrange(AutoMapPlan& plan);

    // write the plan into the project: one multisample per velocity layer, plus the SOUND that plays them
    static bool build(BankProject& project, const AutoMapPlan& plan, const std::string& name,
                      std::size_t& createdSoundIndex, std::string& error);

    // Every file that comes in on its own gets a blend of its own, with one zone over the whole keyboard.
    // Once those samples are in a real blend, those one-file blends are only in the way: this throws away the
    // ones that hold a sample from `sampleIndexes` and nothing else, and keeps every other blend working.
    static std::size_t dropSingleBlendsFor(BankProject& project, const std::vector<std::size_t>& sampleIndexes);

    // true when this multisample is one of those one-file blends
    static bool isSingleBlend(const ImportedMultisample& multisample) noexcept;
};

} // namespace silveton::manager
