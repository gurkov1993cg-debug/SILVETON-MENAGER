#pragma once
// SILVETON_SEND_V1 - sending SOUNDs of the Manager to the sampler (page СЕМПЛЕР) without writing the bank:
// the chosen SOUNDs become a small bank of their own (transferProject + SvBankBuilder) that the sampler takes in at once.

#include "silveton/manager/ManagerTypes.h"

#include <cstdint>
#include <string>
#include <utility>
#include <vector>

namespace silveton::manager {

// One SOUND that went to the sampler.
struct SentSound {
    std::string managerName;   // its name in the Manager
    std::string samplerName;   // its name in the sampler (the same, or with " 2" when the sampler already had that name)
    int place{0};              // its place in the sampler (1..500)
};

// Where each SOUND goes: one sent before (the same Manager name) keeps its place and name - the new version replaces the old one;
// a new one takes the first place no sound of the sampler and no sent one has. false = no free place left.
bool planTransfer(const std::vector<std::string>& managerNames, const std::vector<std::pair<int, std::string>>& samplerSounds,
                  const std::vector<SentSound>& sentBefore, std::vector<SentSound>& plan, std::string& error);

// A project with only the SOUNDs of `plan` (by their Manager name, the first one with that name), each with the place and name of the plan,
// and only the multisamples and samples they use.
bool transferProject(const BankProject& from, const std::vector<SentSound>& plan, BankProject& out, std::string& error);

} // namespace silveton::manager
