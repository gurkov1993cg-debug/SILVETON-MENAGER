# SILVETON Manager — SV2 bank contract fix

Date: 2026-10-05

Scope: SILVETON Manager only. GUI and Sample Editor are unchanged. SILVETON Sampler is not modified.

## Export contract

- Magic: `SILVSV2\0`
- Major version: `2`
- SOUND address: `soundSlotId` in the fixed user range `1..500`
- No SV1 `bank/page/slot` address is serialized into an SV2 SOUND record.
- SAMPLE uses persistent non-zero `uint32_t sampleId`.
- MULTISAMPLE uses persistent non-zero `uint32_t multisampleId`.
- Zone serializes `sampleId`, not `sampleIndex`.
- SoundLayer serializes `multisampleId`, not `multisampleIndex`.
- Sample metadata, loop metadata, direct AUDIO offsets/sizes and audio hash are preserved.
- Mixed sample rates are preserved; 44.1 kHz is not forced to 48 kHz.
- AUDIO payload remains inside `SILVETON_BANK.sv` and is addressed by offsets.
- Identical sample audio+metadata is deduplicated while retaining ID references.

## Export validation

The builder/reader rejects:

- zero or duplicate SampleID;
- zero or duplicate MultisampleID;
- SOUND slot outside 1..500 or duplicate SOUND slot;
- Zone references to missing SampleID;
- SoundLayer references to missing MultisampleID;
- invalid section/audio offsets and sizes;
- invalid sample audio hash;
- invalid payload SHA-256;
- legacy `SILVSV1` magic;
- major version 1.

The atomic export path self-opens and validates the generated SV2 bytes before replacing the destination file.

## Regression verification

`silveton_sv2_bank_contract` creates 4 SOUNDs at slots 1, 7, 250 and 500, with 44.1 kHz and 48 kHz samples. It writes the bank, opens it again and verifies magic/version/counts, persistent IDs, ID relationships, SOUND slots, mixed sample rates, deduplication, AUDIO bounds/hashes and SHA integrity.

Verified with both Clang and GCC under strict warnings-as-errors:

- 7/7 tests PASS (Clang)
- 7/7 tests PASS (GCC)
